

package com.bt.ngp.common.util;

import java.lang.reflect.Field;
import java.util.Collection;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;


/**
 * Class contains all the utility methods
 *
 * @since 11 Jan 2018
 * @author Mahesh 611174701
 */
public class CommonUtils {

	/**
	 * wrapper method for null and empty checks
	 * @since 11 Jan 2018
	 * @author Mahesh 611174701
	 * @param any entity
	 * @return
	 * @return boolean
	 */
	public static <T> boolean isPresent(T entity) {
		if(null == entity) return false;
		else if (entity instanceof Collection<?>) {
			if (((Collection<?>) entity).isEmpty())
				return false;
		}
		else if (entity instanceof Map<?, ?>) {
			if (((Map<?, ?>) entity).isEmpty())
				return false;
		}
		else if (entity instanceof String && StringUtils.isEmpty((String) entity)) {
				return false;
		}
		return true;

	}

	public static <T> T convertMapToObject(Object entitySpecificObject, T userDefinedObj) {
		Map<String, Object> map = (Map<String, Object>) entitySpecificObject;
		if (userDefinedObj == null)
			return null;
		Class<?> clazz = userDefinedObj.getClass();
		for (Field field : clazz.getDeclaredFields()) {
			field.setAccessible(true);
			if (map.get(field.getName()) == null)
				continue;
			try {
				field.set(userDefinedObj, map.get(field.getName()));
			} catch (IllegalArgumentException | IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return userDefinedObj;
	}

}
