package com.bt.ngp.common.util;

public enum TerminationType{
	ORIGINATING,
	TERMINATING
}
