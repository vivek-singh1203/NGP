/**
 * 
 */
package com.bt.ngp.common.util;

/**
 * @author 609375622
 *
 */
public enum EntityTypes{
	STRUCTURE,
	EQUIPMENT,
	SPAN_SECTION,
	CABLE_SECTION
} 