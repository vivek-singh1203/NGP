package com.bt.ngp.common.util;

/**
 * This Enum Class has possible types of PhysicalStructure 
 * @author Naghaveer 609620609
 *
 */
public enum PhysicalStructureEntityTypes {

	POLES,
	JOINTING_CHAMBERS,
	CABINET,
	STRUCTURE,
	ENCLOSURE
}
