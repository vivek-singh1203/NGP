package com.bt.ngp.common.util;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bt.ngp.common.data.jpa.repository.CcpPortRepository;
import com.bt.ngp.common.data.jpa.repository.CommonOperation;
import com.bt.ngp.common.data.jpa.repository.ConductorRepository;
import com.bt.ngp.common.data.jpa.repository.CpePortRepository;
import com.bt.ngp.common.data.jpa.repository.DfPortRepository;
import com.bt.ngp.common.data.jpa.repository.DpPortRepository;
import com.bt.ngp.common.data.jpa.repository.DslamPortRepository;
import com.bt.ngp.common.data.jpa.repository.HierarchyConfigurationRepository;
import com.bt.ngp.common.data.jpa.repository.JcPortRepository;
import com.bt.ngp.common.data.jpa.repository.MfnPortRepository;
import com.bt.ngp.common.data.jpa.repository.NtePortRepository;
import com.bt.ngp.common.data.jpa.repository.PortSpecRepository;
import com.bt.ngp.common.data.jpa.repository.WePortRepository;

import com.bt.ngp.common.data.jpa.spec.repository.ConductorSpecRepository;
import com.bt.ngp.common.data.jpa.spec.repository.EqSpecRepository;
import com.bt.ngp.common.dto.Inventory;
import com.bt.ngp.datasource.entities.Conductor;

import com.bt.ngp.datasource.entities.HierarchyConfiguration;
import com.bt.ngp.datasource.spec.PortSpec;
import com.bt.ngp.datasource.spec.ConductorSpec;
import com.bt.ngp.datasource.spec.EqSpec;
import com.bt.ngp.datasource.spec.SpecCategory;
import com.bt.ngp.datasource.spec.SpecType;
import com.bt.ngp.framework.common.aop.logging.LogMe;

@Component
public class CommonUtilsImpl {

	 private static final Logger logger = LoggerFactory.getLogger(CommonUtilsImpl.class);

	@Autowired
	private HierarchyConfigurationRepository hierarchyConfigurationRepository;
	@Autowired
	private CcpPortRepository   ccpPortRepository ;
	@Autowired
	private CpePortRepository   cpePortRepository ;
	@Autowired
	private DfPortRepository    dfPortRepository  ;
	@Autowired
	private DpPortRepository    dpPortRepository  ;
	@Autowired
	private DslamPortRepository dslamPortReposito ;
	@Autowired
	private JcPortRepository    jcPortRepository  ;
	@Autowired
	private MfnPortRepository   mfnPortRepository ;
	@Autowired
	private NtePortRepository   ntePortRepository ;
	@Autowired
	private WePortRepository    wePortRepository  ;
	@Autowired
	private  PortSpecRepository portSpecRepository;
	@Autowired
	private ConductorRepository conductorRepository; 
	@Autowired
	private EqSpecRepository eqSpecRepository;
	@Autowired
	private ConductorSpecRepository conductorSpecRepository;
	public static final String PORT_OBJECT ="PORT_OBJECT";
	public static final String CLASS_NAME ="CLASSNAME";

	/**
	 * Fetch the the table information of Equipment/Structure
	 * @since 11 Jan 2018
	 * @author Suvarna.K 609375622
	 * @param entityType Either STRUCTURE or EQUIPMENT.
	 * @param categoryName name of Equipment category.
	 * @param typeName name of Equipment type.
	 * @return HierarchyConfiguration
	 */
	public HierarchyConfiguration getEntityByCategoryAndTypeName(String entityName,String categoryName,String typeName) {
		logger.info("Enter getEntityByCategoryAndTypeName");
		HierarchyConfiguration hierarchyConfig=	hierarchyConfigurationRepository.findByEntityNameAndSpecCategoryNameOrSpecTypeName(entityName,categoryName,typeName);

		if(hierarchyConfig == null && entityName.equalsIgnoreCase(EntityTypes.EQUIPMENT.name())) { // For JC
			SpecCategory specCategory = new SpecCategory();
			SpecType specType = new SpecType();
			EqSpec eqSpec = new EqSpec();
			
			specCategory.setName(categoryName);
			specType.setName(typeName);
			eqSpec.setSpecCategory(specCategory);
			eqSpec.setSpecType(specType);
			String entityNme = EquipmentEntityTypes.JOINT_CLOSURE.toString();
			eqSpec.setEntityName(entityNme);
			String jcEntity = eqSpecRepository.findEntityNameByCategoryAndType(eqSpec);
			if(jcEntity != null && jcEntity.equals(entityNme)) {
				hierarchyConfig = new HierarchyConfiguration();
				hierarchyConfig.setEntityName(EntityTypes.EQUIPMENT.toString());
				hierarchyConfig.setShortName("JC");
				hierarchyConfig.setHierarchy1(EquipmentEntityTypes.JOINT_CLOSURE.name());	
				hierarchyConfig.setHierarchy2(EquipmentEntityTypes.CHASSIS.name());
				hierarchyConfig.setHierarchy3(EquipmentEntityTypes.PLUGIN_HOLDERS.name());
				hierarchyConfig.setHierarchy4(EquipmentEntityTypes.PLUGIN.name());
				hierarchyConfig.setHierarchy5(EquipmentEntityTypes.JC_PORTS.name());
				hierarchyConfig.setAssoc23("JC_CHASSIS_PH_ASSOC");
				hierarchyConfig.setAssoc34("JC_PH_PLUGIN_ASSOC");
				hierarchyConfig.setAssoc45("JC_PLUGIN_PORT_ASSOC");
			}	
		}	
	logger.debug("HierarchyConfiguration :", hierarchyConfig);	
	logger.info("End getEntityByCategoryAndTypeName");
	return hierarchyConfig;
}

/**
 * Method to Identify the proper port table and fetch the record.
 * @param hierarchyConfig
 * @param inventory
 * @return Map<String,Object>
 */
	@LogMe
	public Map<String, Object> getPhysicalPort(HierarchyConfiguration hierarchyConfig, Inventory inventory) {
		logger.info("Enter getPhysicalPort");
		Map<String, Object> portInfoMap = new HashMap<>();
		String portTable = null;
		if (null != hierarchyConfig) {
			portTable = hierarchyConfig.getHierarchy5();
			EquipmentEntityTypes table = EquipmentEntityTypes.valueOf(portTable.trim());
			String portName = inventory.getDetails().getName();
			switch (table) {
			case CCP_PORTS:
				portInfoMap = fetchPort(ccpPortRepository, portName, table);
				portInfoMap.put(CLASS_NAME, portTable);
				break;
			case CPE_PORTS:
				portInfoMap = fetchPort(cpePortRepository, portName, table);
				portInfoMap.put(CLASS_NAME, portTable);
				break;
			case DF_PORTS:
				portInfoMap = fetchPort(dfPortRepository, portName, table);
				portInfoMap.put(CLASS_NAME, portTable);
				break;
			case DP_PORTS:
				portInfoMap = fetchPort(dpPortRepository, portName, table);
				portInfoMap.put(CLASS_NAME, portTable);
				break;
			case DSLAM_PORTS:
				portInfoMap = fetchPort(dslamPortReposito, portName, table);
				portInfoMap.put(CLASS_NAME, portTable);
				break;
			case JC_PORTS:
				portInfoMap = fetchPort(jcPortRepository, portName, table);
				portInfoMap.put(CLASS_NAME, portTable);
				break;
			case MFN_PORTS:
				portInfoMap = fetchPort(mfnPortRepository, portName, table);
				portInfoMap.put(CLASS_NAME, portTable);
				break;
			case NTE_PORTS:
				portInfoMap = fetchPort(ntePortRepository, portName, table);
				portInfoMap.put(CLASS_NAME, portTable);
				break;
			case WE_PORTS:
				portInfoMap = fetchPort(wePortRepository, portName, table);
				portInfoMap.put(CLASS_NAME, portTable);
				break;
			default:
				break;
			}

		}
		return portInfoMap;
	}


/**

 * Description : fetch entity info 
 * @param repository
 * @param  : EquipmentEntityTypes tableEnum
 * @return : Map<String,Object> Description : get entity info 

 */
	@LogMe
	public <T> Map<String, Object> fetchPort(CommonOperation<T> repository, String portName,
			EquipmentEntityTypes tableEnum) {
		Map<String, Object> portInfoMap = new HashMap<>();
		portInfoMap.put(PORT_OBJECT, repository.findByName(portName));
		return portInfoMap;
	}

/**
 * To get the portSpec info by specName
 * @param      : String specName
 * @return
 */
	@LogMe
	public PortSpec getPhysicalPortSpec(String specName) {
		return portSpecRepository.findByPortSpecPKIdName(specName);
	}



/**
 * to fetch conductor properties from DB by name
 * @param String conductorName
 * @return Conductor
 */
	@LogMe
	public Conductor getConductorProperties(String conductorName) {
		return conductorRepository.findByName(conductorName);
	}

/**
 * To get the portSpec info by specName
 * @param      : String specName
 * @return
 */
	@LogMe
	public ConductorSpec getConductorSpec(String specName) {
		return conductorSpecRepository.findByConductorSpecPKIdName(specName);
	}
	/**
	 * Method to get system time.
	 * @since 10 Jan 2018
	 * @author Suvarna.K 609375622
	 * @return long System time.
	 */
	@LogMe
	public static long getTime() {
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		return date.getTime();
	}
}

