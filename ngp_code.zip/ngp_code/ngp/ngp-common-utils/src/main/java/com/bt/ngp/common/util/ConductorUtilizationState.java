package com.bt.ngp.common.util;

/**
 * 
 * Enum to define Conductor Utilization State
 * @author Aditya Ajmera
 *
 */
public enum ConductorUtilizationState {
	PLACED ("Placed"),
	NOT_PLACED("Not Placed"),
	STUMPED ("Stumped"),
	LOOPED ("Looped");
	
	private String utilizationStateValue;
	
	private ConductorUtilizationState(String utilizationStateValue) {
		this.utilizationStateValue = utilizationStateValue;
	}
	
	public String getUtilizationStateValue() {
		return this.utilizationStateValue;
	}
}
