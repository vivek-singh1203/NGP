package com.bt.ngp.common.util;
import com.bt.ngp.common.constants.ValidationConstants;

/**
 * Equipment types that can be used
 * @author Vivek Singh
 */
public enum EquipmentEntityTypes {
	PLUGIN_HOLDERS("1007","PLUGIN_HOLDER"),
	BLOCK_HOLDERS("1007","BLOCK_HOLDER"),
	CARD_HOLDERS("1007","CARD_HOLDERS"),
	CONNECTED_PORTS("1007","CONNECTED_PORTS"),
    CHASSIS("1007","CHASSIS"),
    RACKS("1007","RACKS"),
    CARDS("1007","CARDS"),
	BLOCKS("1007","BLOCKS"),
	PLUGIN(ValidationConstants.PLUGIN_MISSING,"PLUGIN"),
    //Ports table
    CCP_PORTS(ValidationConstants.CCP_PORT_MISSING,"CCP_PORTS"),
	CPE_PORTS(ValidationConstants.CPE_PORT_MISSING,"CPE_PORTS"),
	DF_PORTS(ValidationConstants.DF_PORT_MISSING,"DF_PORTS"),
	DP_PORTS(ValidationConstants.DP_PORT_MISSING,"DP_PORTS"),
	DSLAM_PORTS(ValidationConstants.DSLAM_PORT_MISSING,"DSLAM_PORTS"),
	JC_PORTS(ValidationConstants.JC_PORT_MISSING,"JC_PORTS"),
	MFN_PORTS(ValidationConstants.MFN_PORT_MISSING,"MFN_PORTS"),
	NTE_PORTS(ValidationConstants.NTE_PORT_MISSING,"NTE_PORTS"),
	WE_PORTS(ValidationConstants.WE_PORT_MISSING,"WE_PORTS"),	
	//End Ports table
    CUSTOMER_PREMISE_EQUIPMENT("1007","CUSTOMER_PREMISE_EQUIPMENT"),
    DISTRIBUTION_POINTS("1007","DISTRIBUTION_POINTS"),
    NETWORK_TERMINATING_EQUIPMENT("1007","NETWORK_TERMINATING_EQUIPMENT"),
    DISTRIBUTION_FRAMES("1007","DISTRIBUTION_FRAMES"),
    WIRELESS_EQUIPMENT("1007","WIRELESS_EQUIPMENT"),
    MULTI_FUNCTIONAL_NODE("1007","MULTI_FUNCTIONAL_NODE"),
    CROSS_CONNECT_POINTS("1007","CROSS_CONNECT_POINTS"),
    DSLAM("1007","DSLAM"),
    JOINT_CLOSURE("1007","JOINT_CLOSURE");


    private String errorCode;
    private String tableName;

	private EquipmentEntityTypes(String errorCode,String tableName) {
		this.errorCode = errorCode;
		this.tableName = tableName;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public String valueOf() {
		return tableName;
	}

	
}
