package com.bt.ngp.common.util;

public enum ResourceState{
	  PDA, 
	  IPL,
	  PDR,
	  PLA,
	  POU
}
