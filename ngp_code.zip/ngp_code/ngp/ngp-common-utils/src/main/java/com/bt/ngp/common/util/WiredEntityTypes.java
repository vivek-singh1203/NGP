/**
 * This enum is to capture network element of type wired elements.
 *
 * @since 11 Jan 2018
 * @author Aditya Ajmera 609734641
 */

package com.bt.ngp.common.util;

/**
 * @author 609734641
 *
 */
public enum WiredEntityTypes {
	CABLE_SECTION("CABLE_SECTION"), CONDUCTOR_BUNDLE("CONDUCTOR_BUNDLE"), CONDUCTOR("CONDUCTOR");

	private String wiredEntityValue;

	/**
	 * @return the wiredEntityValue
	 */
	public String getWiredEntityValue() {
		return wiredEntityValue;
	}

	private WiredEntityTypes(String wiredEntityValue) {
		this.wiredEntityValue = wiredEntityValue;
	}
}
