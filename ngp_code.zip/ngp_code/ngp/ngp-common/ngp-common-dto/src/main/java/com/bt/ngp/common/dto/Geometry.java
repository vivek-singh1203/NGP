/**
 * 
 */
package com.bt.ngp.common.dto;


/**
 * Marker Interface for all the geometry types for eg : Point,LineString etc
 *
 * @since 25 Jan 2018
 * @author Mahesh 611174701
 */
public interface Geometry {

}
