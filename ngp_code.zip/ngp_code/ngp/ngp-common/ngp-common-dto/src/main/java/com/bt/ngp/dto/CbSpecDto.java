package com.bt.ngp.dto;
import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CB_SPEC database table.
 * 
 */

public class CbSpecDto  {
	//private CbSpecPKDto id;
	private String createdBy;
	private Timestamp createdDate;
	private double depth;
	private String depthUnit;
	private double diameter;
	private String diameterUnit;
	private double height;
	private String heightUnit;
	private long id;
	private String isOrderable;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private double length;
	private String lengthUnit;
	private String manufacturerCode;
	private double materialCostPerUnit;
	private String materialCostUnit;
	private String materialType;
	private double powerConsumption;
	private String powerConsumptionUnit;
	private double powerDissipation;
	private String powerDissipationUnit;
	private double powerRating;
	private String powerRatingUnit;
	private String specRemarks;
	private String specStatus;
	private Timestamp validFrom;
	private Timestamp validTo;
	private double volume;
	private String volumeUnit;
	private double weight;
	private String weightUnit;
	private double width;
	private String widthUnit;
	
	private List<CableCbAssocSpecDto> cableCbAssocSpecs;
	
	private List<CbCondAssocSpecDto> cbCondAssocSpecs;
	
	private List<CbSelfAssocSpecDto> cbSelfAssocSpecs1;
	
	private List<CbSelfAssocSpecDto> cbSelfAssocSpecs2;
	
	private EntityDto entity;
	
	private ManufacturerDto manufacturer;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	
	private List<CbSpecCharSpecDto> cbSpecCharSpecs;
	
	private List<CbSpecCharSpecRelDto> cbSpecCharSpecRels;
	
	private List<CbSpecCharValueSpecDto> cbSpecCharValueSpecs;
	
	private List<ConductorBundleDto> conductorBundles;
	public CbSpecDto() {
	}
/*	public CbSpecPKDto getId() {
		return this.id;
	}
	public void setId(CbSpecPKDto id) {
		this.id = id;
	}*/
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public double getDepth() {
		return this.depth;
	}
	public void setDepth(double depth) {
		this.depth = depth;
	}
	public String getDepthUnit() {
		return this.depthUnit;
	}
	public void setDepthUnit(String depthUnit) {
		this.depthUnit = depthUnit;
	}
	public double getDiameter() {
		return this.diameter;
	}
	public void setDiameter(double diameter) {
		this.diameter = diameter;
	}
	public String getDiameterUnit() {
		return this.diameterUnit;
	}
	public void setDiameterUnit(String diameterUnit) {
		this.diameterUnit = diameterUnit;
	}
	public double getHeight() {
		return this.height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public String getHeightUnit() {
		return this.heightUnit;
	}
	public void setHeightUnit(String heightUnit) {
		this.heightUnit = heightUnit;
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getIsOrderable() {
		return this.isOrderable;
	}
	public void setIsOrderable(String isOrderable) {
		this.isOrderable = isOrderable;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public double getLength() {
		return this.length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	public String getLengthUnit() {
		return this.lengthUnit;
	}
	public void setLengthUnit(String lengthUnit) {
		this.lengthUnit = lengthUnit;
	}
	public String getManufacturerCode() {
		return this.manufacturerCode;
	}
	public void setManufacturerCode(String manufacturerCode) {
		this.manufacturerCode = manufacturerCode;
	}
	public double getMaterialCostPerUnit() {
		return this.materialCostPerUnit;
	}
	public void setMaterialCostPerUnit(double materialCostPerUnit) {
		this.materialCostPerUnit = materialCostPerUnit;
	}
	public String getMaterialCostUnit() {
		return this.materialCostUnit;
	}
	public void setMaterialCostUnit(String materialCostUnit) {
		this.materialCostUnit = materialCostUnit;
	}
	public String getMaterialType() {
		return this.materialType;
	}
	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}
	public double getPowerConsumption() {
		return this.powerConsumption;
	}
	public void setPowerConsumption(double powerConsumption) {
		this.powerConsumption = powerConsumption;
	}
	public String getPowerConsumptionUnit() {
		return this.powerConsumptionUnit;
	}
	public void setPowerConsumptionUnit(String powerConsumptionUnit) {
		this.powerConsumptionUnit = powerConsumptionUnit;
	}
	public double getPowerDissipation() {
		return this.powerDissipation;
	}
	public void setPowerDissipation(double powerDissipation) {
		this.powerDissipation = powerDissipation;
	}
	public String getPowerDissipationUnit() {
		return this.powerDissipationUnit;
	}
	public void setPowerDissipationUnit(String powerDissipationUnit) {
		this.powerDissipationUnit = powerDissipationUnit;
	}
	public double getPowerRating() {
		return this.powerRating;
	}
	public void setPowerRating(double powerRating) {
		this.powerRating = powerRating;
	}
	public String getPowerRatingUnit() {
		return this.powerRatingUnit;
	}
	public void setPowerRatingUnit(String powerRatingUnit) {
		this.powerRatingUnit = powerRatingUnit;
	}
	public String getSpecRemarks() {
		return this.specRemarks;
	}
	public void setSpecRemarks(String specRemarks) {
		this.specRemarks = specRemarks;
	}
	public String getSpecStatus() {
		return this.specStatus;
	}
	public void setSpecStatus(String specStatus) {
		this.specStatus = specStatus;
	}
	public Timestamp getValidFrom() {
		return this.validFrom;
	}
	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}
	public Timestamp getValidTo() {
		return this.validTo;
	}
	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}
	public double getVolume() {
		return this.volume;
	}
	public void setVolume(double volume) {
		this.volume = volume;
	}
	public String getVolumeUnit() {
		return this.volumeUnit;
	}
	public void setVolumeUnit(String volumeUnit) {
		this.volumeUnit = volumeUnit;
	}
	public double getWeight() {
		return this.weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public String getWeightUnit() {
		return this.weightUnit;
	}
	public void setWeightUnit(String weightUnit) {
		this.weightUnit = weightUnit;
	}
	public double getWidth() {
		return this.width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public String getWidthUnit() {
		return this.widthUnit;
	}
	public void setWidthUnit(String widthUnit) {
		this.widthUnit = widthUnit;
	}
	public List<CableCbAssocSpecDto> getCableCbAssocSpecs() {
		return this.cableCbAssocSpecs;
	}
	public void setCableCbAssocSpecs(List<CableCbAssocSpecDto> cableCbAssocSpecs) {
		this.cableCbAssocSpecs = cableCbAssocSpecs;
	}
	public CableCbAssocSpecDto addCableCbAssocSpec(CableCbAssocSpecDto cableCbAssocSpec) {
		getCableCbAssocSpecs().add(cableCbAssocSpec);
		cableCbAssocSpec.setCbSpec(this);
		return cableCbAssocSpec;
	}
	public CableCbAssocSpecDto removeCableCbAssocSpec(CableCbAssocSpecDto cableCbAssocSpec) {
		getCableCbAssocSpecs().remove(cableCbAssocSpec);
		cableCbAssocSpec.setCbSpec(null);
		return cableCbAssocSpec;
	}
	public List<CbCondAssocSpecDto> getCbCondAssocSpecs() {
		return this.cbCondAssocSpecs;
	}
	public void setCbCondAssocSpecs(List<CbCondAssocSpecDto> cbCondAssocSpecs) {
		this.cbCondAssocSpecs = cbCondAssocSpecs;
	}
	public CbCondAssocSpecDto addCbCondAssocSpec(CbCondAssocSpecDto cbCondAssocSpec) {
		getCbCondAssocSpecs().add(cbCondAssocSpec);
		cbCondAssocSpec.setCbSpec(this);
		return cbCondAssocSpec;
	}
	public CbCondAssocSpecDto removeCbCondAssocSpec(CbCondAssocSpecDto cbCondAssocSpec) {
		getCbCondAssocSpecs().remove(cbCondAssocSpec);
		cbCondAssocSpec.setCbSpec(null);
		return cbCondAssocSpec;
	}
	public List<CbSelfAssocSpecDto> getCbSelfAssocSpecs1() {
		return this.cbSelfAssocSpecs1;
	}
	public void setCbSelfAssocSpecs1(List<CbSelfAssocSpecDto> cbSelfAssocSpecs1) {
		this.cbSelfAssocSpecs1 = cbSelfAssocSpecs1;
	}
	public CbSelfAssocSpecDto addCbSelfAssocSpecs1(CbSelfAssocSpecDto cbSelfAssocSpecs1) {
		getCbSelfAssocSpecs1().add(cbSelfAssocSpecs1);
		cbSelfAssocSpecs1.setCbSpec1(this);
		return cbSelfAssocSpecs1;
	}
	public CbSelfAssocSpecDto removeCbSelfAssocSpecs1(CbSelfAssocSpecDto cbSelfAssocSpecs1) {
		getCbSelfAssocSpecs1().remove(cbSelfAssocSpecs1);
		cbSelfAssocSpecs1.setCbSpec1(null);
		return cbSelfAssocSpecs1;
	}
	public List<CbSelfAssocSpecDto> getCbSelfAssocSpecs2() {
		return this.cbSelfAssocSpecs2;
	}
	public void setCbSelfAssocSpecs2(List<CbSelfAssocSpecDto> cbSelfAssocSpecs2) {
		this.cbSelfAssocSpecs2 = cbSelfAssocSpecs2;
	}
	public CbSelfAssocSpecDto addCbSelfAssocSpecs2(CbSelfAssocSpecDto cbSelfAssocSpecs2) {
		getCbSelfAssocSpecs2().add(cbSelfAssocSpecs2);
		cbSelfAssocSpecs2.setCbSpec2(this);
		return cbSelfAssocSpecs2;
	}
	public CbSelfAssocSpecDto removeCbSelfAssocSpecs2(CbSelfAssocSpecDto cbSelfAssocSpecs2) {
		getCbSelfAssocSpecs2().remove(cbSelfAssocSpecs2);
		cbSelfAssocSpecs2.setCbSpec2(null);
		return cbSelfAssocSpecs2;
	}
	public EntityDto getEntity() {
		return this.entity;
	}
	public void setEntity(EntityDto entity) {
		this.entity = entity;
	}
	public ManufacturerDto getManufacturer() {
		return this.manufacturer;
	}
	public void setManufacturer(ManufacturerDto manufacturer) {
		this.manufacturer = manufacturer;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
	public List<CbSpecCharSpecDto> getCbSpecCharSpecs() {
		return this.cbSpecCharSpecs;
	}
	public void setCbSpecCharSpecs(List<CbSpecCharSpecDto> cbSpecCharSpecs) {
		this.cbSpecCharSpecs = cbSpecCharSpecs;
	}
	public CbSpecCharSpecDto addCbSpecCharSpec(CbSpecCharSpecDto cbSpecCharSpec) {
		getCbSpecCharSpecs().add(cbSpecCharSpec);
		cbSpecCharSpec.setCbSpec(this);
		return cbSpecCharSpec;
	}
	public CbSpecCharSpecDto removeCbSpecCharSpec(CbSpecCharSpecDto cbSpecCharSpec) {
		getCbSpecCharSpecs().remove(cbSpecCharSpec);
		cbSpecCharSpec.setCbSpec(null);
		return cbSpecCharSpec;
	}
	public List<CbSpecCharSpecRelDto> getCbSpecCharSpecRels() {
		return this.cbSpecCharSpecRels;
	}
	public void setCbSpecCharSpecRels(List<CbSpecCharSpecRelDto> cbSpecCharSpecRels) {
		this.cbSpecCharSpecRels = cbSpecCharSpecRels;
	}
	public CbSpecCharSpecRelDto addCbSpecCharSpecRel(CbSpecCharSpecRelDto cbSpecCharSpecRel) {
		getCbSpecCharSpecRels().add(cbSpecCharSpecRel);
		cbSpecCharSpecRel.setCbSpec(this);
		return cbSpecCharSpecRel;
	}
	public CbSpecCharSpecRelDto removeCbSpecCharSpecRel(CbSpecCharSpecRelDto cbSpecCharSpecRel) {
		getCbSpecCharSpecRels().remove(cbSpecCharSpecRel);
		cbSpecCharSpecRel.setCbSpec(null);
		return cbSpecCharSpecRel;
	}
	public List<CbSpecCharValueSpecDto> getCbSpecCharValueSpecs() {
		return this.cbSpecCharValueSpecs;
	}
	public void setCbSpecCharValueSpecs(List<CbSpecCharValueSpecDto> cbSpecCharValueSpecs) {
		this.cbSpecCharValueSpecs = cbSpecCharValueSpecs;
	}
	public CbSpecCharValueSpecDto addCbSpecCharValueSpec(CbSpecCharValueSpecDto cbSpecCharValueSpec) {
		getCbSpecCharValueSpecs().add(cbSpecCharValueSpec);
		cbSpecCharValueSpec.setCbSpec(this);
		return cbSpecCharValueSpec;
	}
	public CbSpecCharValueSpecDto removeCbSpecCharValueSpec(CbSpecCharValueSpecDto cbSpecCharValueSpec) {
		getCbSpecCharValueSpecs().remove(cbSpecCharValueSpec);
		cbSpecCharValueSpec.setCbSpec(null);
		return cbSpecCharValueSpec;
	}
	public List<ConductorBundleDto> getConductorBundles() {
		return this.conductorBundles;
	}
	public void setConductorBundles(List<ConductorBundleDto> conductorBundles) {
		this.conductorBundles = conductorBundles;
	}
	public ConductorBundleDto addConductorBundle(ConductorBundleDto conductorBundle) {
		getConductorBundles().add(conductorBundle);
		conductorBundle.setCbSpec(this);
		return conductorBundle;
	}
	public ConductorBundleDto removeConductorBundle(ConductorBundleDto conductorBundle) {
		getConductorBundles().remove(conductorBundle);
		conductorBundle.setCbSpec(null);
		return conductorBundle;
	}
}
