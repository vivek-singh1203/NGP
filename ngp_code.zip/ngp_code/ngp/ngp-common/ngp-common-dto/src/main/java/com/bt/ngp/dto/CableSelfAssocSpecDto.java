package com.bt.ngp.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CABLE_SELF_ASSOC_SPEC database table.
 * 
 */

public class CableSelfAssocSpecDto  {
	private long id;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String noOfChildInstances;
	
	private List<CableSectionSelfAssocDto> cableSectionSelfAssocs;
	
		
	private CableSpecDto cableSpec1;
	
		
	private CableSpecDto cableSpec2;
	public CableSelfAssocSpecDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getNoOfChildInstances() {
		return this.noOfChildInstances;
	}
	public void setNoOfChildInstances(String noOfChildInstances) {
		this.noOfChildInstances = noOfChildInstances;
	}
	public List<CableSectionSelfAssocDto> getCableSectionSelfAssocs() {
		return this.cableSectionSelfAssocs;
	}
	public void setCableSectionSelfAssocs(List<CableSectionSelfAssocDto> cableSectionSelfAssocs) {
		this.cableSectionSelfAssocs = cableSectionSelfAssocs;
	}
	public CableSectionSelfAssocDto addCableSectionSelfAssoc(CableSectionSelfAssocDto cableSectionSelfAssoc) {
		getCableSectionSelfAssocs().add(cableSectionSelfAssoc);
		cableSectionSelfAssoc.setCableSelfAssocSpec(this);
		return cableSectionSelfAssoc;
	}
	public CableSectionSelfAssocDto removeCableSectionSelfAssoc(CableSectionSelfAssocDto cableSectionSelfAssoc) {
		getCableSectionSelfAssocs().remove(cableSectionSelfAssoc);
		cableSectionSelfAssoc.setCableSelfAssocSpec(null);
		return cableSectionSelfAssoc;
	}
	public CableSpecDto getCableSpec1() {
		return this.cableSpec1;
	}
	public void setCableSpec1(CableSpecDto cableSpec1) {
		this.cableSpec1 = cableSpec1;
	}
	public CableSpecDto getCableSpec2() {
		return this.cableSpec2;
	}
	public void setCableSpec2(CableSpecDto cableSpec2) {
		this.cableSpec2 = cableSpec2;
	}
}
