package com.bt.ngp.common.dto;

public enum FeatureType {

    EQUIPMENT("Equipment"), JOINT_CLOSURE("JointClosure"), PHYSICAL_STRUCTURE("PhysicalStructure"), CABLE_SECTION(
                    "CableSection"), SPAN_SECTION("SpanSection"), CONDUCTOR_BUNDLE("ConductorBundle"), CONDUCTOR(
                    "Conductor"), CHASSIS("Chassis"), HOLDER("Holder"), PHYSICAL_PORT("PhysicalPort"), PLUGIN("Plugin"), CARD(
                    "Card");

    private final String value;

    FeatureType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static FeatureType fromValue(String v) {
        for (FeatureType c : FeatureType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
