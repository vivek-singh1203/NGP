package com.bt.ngp.common.dto.generator;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.apache.commons.io.FileUtils;

import com.bt.ngp.common.dto.generator.context.PojoCtx;
import com.github.mustachejava.DefaultMustacheFactory;
import com.github.mustachejava.Mustache;
import com.github.mustachejava.MustacheFactory;

public class MustacheUtil {

    public static void generatePojo(String outputDir, String templateName, PojoCtx pojoCtx) {
        MustacheFactory mustacheFactory = new DefaultMustacheFactory();
        Mustache mustache = mustacheFactory.compile(templateName);
        Writer execute = mustache.execute(new StringWriter(), pojoCtx);
        String result = execute.toString();
        try {
            FileUtils.writeStringToFile(new File(outputDir + pojoCtx.getClassNamePrefix() + pojoCtx.getClassName()
                            + pojoCtx.getClassNameSuffix() + ".java"), result, "utf-8");
        } catch (IOException e) {
            e.printStackTrace();
            // Ignore Exception
        }
    }
}