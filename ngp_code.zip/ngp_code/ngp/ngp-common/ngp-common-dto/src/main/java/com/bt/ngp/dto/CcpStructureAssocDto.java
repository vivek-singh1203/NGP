package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the CCP_STRUCTURE_ASSOC database table.
 * 
 */

public class CcpStructureAssocDto  {
	private long id;
	private String associationState;
	private String ccpName;
	private String createdBy;
	private Timestamp createdDate;
	private String dataQualityIndicator;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String structureName;
	
	private EntityDto entity;
	public CcpStructureAssocDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAssociationState() {
		return this.associationState;
	}
	public void setAssociationState(String associationState) {
		this.associationState = associationState;
	}
	public String getCcpName() {
		return this.ccpName;
	}
	public void setCcpName(String ccpName) {
		this.ccpName = ccpName;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getStructureName() {
		return this.structureName;
	}
	public void setStructureName(String structureName) {
		this.structureName = structureName;
	}
	public EntityDto getEntity() {
		return this.entity;
	}
	public void setEntity(EntityDto entity) {
		this.entity = entity;
	}
}
