package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the AUX_COMPONENTS database table.
 * 
 */

public class AuxComponentDto  {
	private String name;
	private String alternateName;
	private String assetIdentifier;
	private String ccpName;
	private String cpeName;
	private String createdBy;
	private Timestamp createdDate;
	private String dataQualityIndicator;
	private String dslamName;
	private String faultState;
	private String frameName;
	private long id;
	private String jcName;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String mfnName;
	private String nteName;
	private String resource1141Code;
	private String resourceState;
	private String serialNumber;
	private String serviceState;
	private String userLabel;
	private String weqName;
	
	public DistributionPointDto getDistributionPoints() {
		return distributionPoints;
	}
	public void setDistributionPoints(DistributionPointDto distributionPoints) {
		this.distributionPoints = distributionPoints;
	}
	private DistributionPointDto distributionPoints;
	
		
	private EqSpecDto eqSpec;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	
	private StoreDto store;
	
	private SupplierDto supplier;
	public AuxComponentDto() {
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAlternateName() {
		return this.alternateName;
	}
	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}
	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}
	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}
	public String getCcpName() {
		return this.ccpName;
	}
	public void setCcpName(String ccpName) {
		this.ccpName = ccpName;
	}
	public String getCpeName() {
		return this.cpeName;
	}
	public void setCpeName(String cpeName) {
		this.cpeName = cpeName;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}
	public String getDslamName() {
		return this.dslamName;
	}
	public void setDslamName(String dslamName) {
		this.dslamName = dslamName;
	}
	public String getFaultState() {
		return this.faultState;
	}
	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}
	public String getFrameName() {
		return this.frameName;
	}
	public void setFrameName(String frameName) {
		this.frameName = frameName;
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getJcName() {
		return this.jcName;
	}
	public void setJcName(String jcName) {
		this.jcName = jcName;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getMfnName() {
		return this.mfnName;
	}
	public void setMfnName(String mfnName) {
		this.mfnName = mfnName;
	}
	public String getNteName() {
		return this.nteName;
	}
	public void setNteName(String nteName) {
		this.nteName = nteName;
	}
	public String getResource1141Code() {
		return this.resource1141Code;
	}
	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}
	public String getResourceState() {
		return this.resourceState;
	}
	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}
	public String getSerialNumber() {
		return this.serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getServiceState() {
		return this.serviceState;
	}
	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}
	public String getUserLabel() {
		return this.userLabel;
	}
	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}
	public String getWeqName() {
		return this.weqName;
	}
	public void setWeqName(String weqName) {
		this.weqName = weqName;
	}

	public EqSpecDto getEqSpec() {
		return this.eqSpec;
	}
	public void setEqSpec(EqSpecDto eqSpec) {
		this.eqSpec = eqSpec;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
	public StoreDto getStore() {
		return this.store;
	}
	public void setStore(StoreDto store) {
		this.store = store;
	}
	public SupplierDto getSupplier() {
		return this.supplier;
	}
	public void setSupplier(SupplierDto supplier) {
		this.supplier = supplier;
	}
}
