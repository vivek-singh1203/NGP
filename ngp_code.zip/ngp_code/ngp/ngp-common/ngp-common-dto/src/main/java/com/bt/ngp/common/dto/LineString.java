/**
 * 
 */
package com.bt.ngp.common.dto;

import java.util.List;

/**
 * LineString geometry type
 *
 * @since 25 Jan 2018
 * @author Mahesh 611174701
 */
public class LineString implements Geometry {

	private List<Point> points;

	/**
	 * @return the points
	 */
	public List<Point> getPoints() {
		return points;
	}

	/**
	 * @param points the points to set
	 */
	public void setPoints(List<Point> points) {
		this.points = points;
	}

}
