package com.bt.ngp.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CB_SPEC_CHAR_VALUE_SPEC database table.
 * 
 */

public class CbSpecCharValueSpecDto  {
	private long id;
	private String createdBy;
	private Timestamp createdDate;
	private String defaultValue;
	private String description;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String measurementUnit;
	private String rangeInterval;
	private String remarks;
	private Timestamp validFrom;
	private Timestamp validTo;
	private String valueFrom;
	private String valueTo;
	
	private List<CbCharDto> cbChars;
	
	private List<CbSpecCharSpecDto> cbSpecCharSpecs;
	
		
	private CbSpecDto cbSpec;
	
	private EntityDto entity;
	
	private EntityCharValueSpecDto entityCharValueSpec;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	public CbSpecCharValueSpecDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDefaultValue() {
		return this.defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	public String getDescription() {
		return this.description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getMeasurementUnit() {
		return this.measurementUnit;
	}
	public void setMeasurementUnit(String measurementUnit) {
		this.measurementUnit = measurementUnit;
	}
	public String getRangeInterval() {
		return this.rangeInterval;
	}
	public void setRangeInterval(String rangeInterval) {
		this.rangeInterval = rangeInterval;
	}
	public String getRemarks() {
		return this.remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Timestamp getValidFrom() {
		return this.validFrom;
	}
	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}
	public Timestamp getValidTo() {
		return this.validTo;
	}
	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}
	public String getValueFrom() {
		return this.valueFrom;
	}
	public void setValueFrom(String valueFrom) {
		this.valueFrom = valueFrom;
	}
	public String getValueTo() {
		return this.valueTo;
	}
	public void setValueTo(String valueTo) {
		this.valueTo = valueTo;
	}
	public List<CbCharDto> getCbChars() {
		return this.cbChars;
	}
	public void setCbChars(List<CbCharDto> cbChars) {
		this.cbChars = cbChars;
	}
	public CbCharDto addCbChar(CbCharDto cbChar) {
		getCbChars().add(cbChar);
		cbChar.setCbSpecCharValueSpec(this);
		return cbChar;
	}
	public CbCharDto removeCbChar(CbCharDto cbChar) {
		getCbChars().remove(cbChar);
		cbChar.setCbSpecCharValueSpec(null);
		return cbChar;
	}
	public List<CbSpecCharSpecDto> getCbSpecCharSpecs() {
		return this.cbSpecCharSpecs;
	}
	public void setCbSpecCharSpecs(List<CbSpecCharSpecDto> cbSpecCharSpecs) {
		this.cbSpecCharSpecs = cbSpecCharSpecs;
	}
	public CbSpecCharSpecDto addCbSpecCharSpec(CbSpecCharSpecDto cbSpecCharSpec) {
		getCbSpecCharSpecs().add(cbSpecCharSpec);
		cbSpecCharSpec.setCbSpecCharValueSpec(this);
		return cbSpecCharSpec;
	}
	public CbSpecCharSpecDto removeCbSpecCharSpec(CbSpecCharSpecDto cbSpecCharSpec) {
		getCbSpecCharSpecs().remove(cbSpecCharSpec);
		cbSpecCharSpec.setCbSpecCharValueSpec(null);
		return cbSpecCharSpec;
	}
	public CbSpecDto getCbSpec() {
		return this.cbSpec;
	}
	public void setCbSpec(CbSpecDto cbSpec) {
		this.cbSpec = cbSpec;
	}
	public EntityDto getEntity() {
		return this.entity;
	}
	public void setEntity(EntityDto entity) {
		this.entity = entity;
	}
	public EntityCharValueSpecDto getEntityCharValueSpec() {
		return this.entityCharValueSpec;
	}
	public void setEntityCharValueSpec(EntityCharValueSpecDto entityCharValueSpec) {
		this.entityCharValueSpec = entityCharValueSpec;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
}
