package com.bt.ngp.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CABLE_HIERARCHY_SPEC database table.
 * 
 */

public class CableHierarchySpecDto  {
	private long id;
	private String condStartSeqNo;
	private String createdBy;
	private Timestamp createdDate;
	private String hierarchyLegId;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	
	private CableCbAssocSpecDto cableCbAssocSpec;
	
	private CableCondAssocSpecDto cableCondAssocSpec;
	
		
	private CableSpecDto cableSpec;
	
	private CbCondAssocSpecDto cbCondAssocSpec;
	
	private EntityDto entity;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	
	private List<CableSectionHierarchyDto> cableSectionHierarchies;
	public CableHierarchySpecDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCondStartSeqNo() {
		return this.condStartSeqNo;
	}
	public void setCondStartSeqNo(String condStartSeqNo) {
		this.condStartSeqNo = condStartSeqNo;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getHierarchyLegId() {
		return this.hierarchyLegId;
	}
	public void setHierarchyLegId(String hierarchyLegId) {
		this.hierarchyLegId = hierarchyLegId;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public CableCbAssocSpecDto getCableCbAssocSpec() {
		return this.cableCbAssocSpec;
	}
	public void setCableCbAssocSpec(CableCbAssocSpecDto cableCbAssocSpec) {
		this.cableCbAssocSpec = cableCbAssocSpec;
	}
	public CableCondAssocSpecDto getCableCondAssocSpec() {
		return this.cableCondAssocSpec;
	}
	public void setCableCondAssocSpec(CableCondAssocSpecDto cableCondAssocSpec) {
		this.cableCondAssocSpec = cableCondAssocSpec;
	}
	public CableSpecDto getCableSpec() {
		return this.cableSpec;
	}
	public void setCableSpec(CableSpecDto cableSpec) {
		this.cableSpec = cableSpec;
	}
	public CbCondAssocSpecDto getCbCondAssocSpec() {
		return this.cbCondAssocSpec;
	}
	public void setCbCondAssocSpec(CbCondAssocSpecDto cbCondAssocSpec) {
		this.cbCondAssocSpec = cbCondAssocSpec;
	}
	public EntityDto getEntity() {
		return this.entity;
	}
	public void setEntity(EntityDto entity) {
		this.entity = entity;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
	public List<CableSectionHierarchyDto> getCableSectionHierarchies() {
		return this.cableSectionHierarchies;
	}
	public void setCableSectionHierarchies(List<CableSectionHierarchyDto> cableSectionHierarchies) {
		this.cableSectionHierarchies = cableSectionHierarchies;
	}
	public CableSectionHierarchyDto addCableSectionHierarchy(CableSectionHierarchyDto cableSectionHierarchy) {
		getCableSectionHierarchies().add(cableSectionHierarchy);
		cableSectionHierarchy.setCableHierarchySpec(this);
		return cableSectionHierarchy;
	}
	public CableSectionHierarchyDto removeCableSectionHierarchy(CableSectionHierarchyDto cableSectionHierarchy) {
		getCableSectionHierarchies().remove(cableSectionHierarchy);
		cableSectionHierarchy.setCableHierarchySpec(null);
		return cableSectionHierarchy;
	}
}
