package com.bt.ngp.dto;
import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the BLOCKS database table.
 * 
 */

public class BlockDto  {
	private String name;
	private String alternateName;
	private String assetIdentifier;
	private String createdBy;
	private Timestamp createdDate;
	private String dataQualityIndicator;
	private String faultState;
	private String frameName;
	private long id;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String resource1141Code;
	private String resourceState;
	private String serialNumber;
	private String serviceState;
	private String userLabel;
	
	private BlockHolderDto blockHolder;
	
		
	private EqSpecDto eqSpec;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	
	private StoreDto store;
	
	private SupplierDto supplier;
	
	private List<BlockCharDto> blockChars;
	
	private List<BlockSelfAssocDto> blockSelfAssocs1;
	
	private List<BlockSelfAssocDto> blockSelfAssocs2;
	
	private List<DfBhBlockAssocDto> dfBhBlockAssocs;
	
	private List<DfBlockPortAssocDto> dfBlockPortAssocs;
	
	private List<DfCsPortTermDto> dfCsPortTerms;
	
	private List<DfPortDto> dfPorts;
	public BlockDto() {
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAlternateName() {
		return this.alternateName;
	}
	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}
	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}
	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}
	public String getFaultState() {
		return this.faultState;
	}
	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}
	public String getFrameName() {
		return this.frameName;
	}
	public void setFrameName(String frameName) {
		this.frameName = frameName;
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getResource1141Code() {
		return this.resource1141Code;
	}
	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}
	public String getResourceState() {
		return this.resourceState;
	}
	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}
	public String getSerialNumber() {
		return this.serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getServiceState() {
		return this.serviceState;
	}
	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}
	public String getUserLabel() {
		return this.userLabel;
	}
	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}
	public BlockHolderDto getBlockHolder() {
		return this.blockHolder;
	}
	public void setBlockHolder(BlockHolderDto blockHolder) {
		this.blockHolder = blockHolder;
	}
	public EqSpecDto getEqSpec() {
		return this.eqSpec;
	}
	public void setEqSpec(EqSpecDto eqSpec) {
		this.eqSpec = eqSpec;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
	public StoreDto getStore() {
		return this.store;
	}
	public void setStore(StoreDto store) {
		this.store = store;
	}
	public SupplierDto getSupplier() {
		return this.supplier;
	}
	public void setSupplier(SupplierDto supplier) {
		this.supplier = supplier;
	}
	public List<BlockCharDto> getBlockChars() {
		return this.blockChars;
	}
	public void setBlockChars(List<BlockCharDto> blockChars) {
		this.blockChars = blockChars;
	}
	public BlockCharDto addBlockChar(BlockCharDto blockChar) {
		getBlockChars().add(blockChar);
		blockChar.setBlock(this);
		return blockChar;
	}
	public BlockCharDto removeBlockChar(BlockCharDto blockChar) {
		getBlockChars().remove(blockChar);
		blockChar.setBlock(null);
		return blockChar;
	}
	public List<BlockSelfAssocDto> getBlockSelfAssocs1() {
		return this.blockSelfAssocs1;
	}
	public void setBlockSelfAssocs1(List<BlockSelfAssocDto> blockSelfAssocs1) {
		this.blockSelfAssocs1 = blockSelfAssocs1;
	}
	public BlockSelfAssocDto addBlockSelfAssocs1(BlockSelfAssocDto blockSelfAssocs1) {
		getBlockSelfAssocs1().add(blockSelfAssocs1);
		blockSelfAssocs1.setBlock1(this);
		return blockSelfAssocs1;
	}
	public BlockSelfAssocDto removeBlockSelfAssocs1(BlockSelfAssocDto blockSelfAssocs1) {
		getBlockSelfAssocs1().remove(blockSelfAssocs1);
		blockSelfAssocs1.setBlock1(null);
		return blockSelfAssocs1;
	}
	public List<BlockSelfAssocDto> getBlockSelfAssocs2() {
		return this.blockSelfAssocs2;
	}
	public void setBlockSelfAssocs2(List<BlockSelfAssocDto> blockSelfAssocs2) {
		this.blockSelfAssocs2 = blockSelfAssocs2;
	}
	public BlockSelfAssocDto addBlockSelfAssocs2(BlockSelfAssocDto blockSelfAssocs2) {
		getBlockSelfAssocs2().add(blockSelfAssocs2);
		blockSelfAssocs2.setBlock2(this);
		return blockSelfAssocs2;
	}
	public BlockSelfAssocDto removeBlockSelfAssocs2(BlockSelfAssocDto blockSelfAssocs2) {
		getBlockSelfAssocs2().remove(blockSelfAssocs2);
		blockSelfAssocs2.setBlock2(null);
		return blockSelfAssocs2;
	}
	public List<DfBhBlockAssocDto> getDfBhBlockAssocs() {
		return this.dfBhBlockAssocs;
	}
	public void setDfBhBlockAssocs(List<DfBhBlockAssocDto> dfBhBlockAssocs) {
		this.dfBhBlockAssocs = dfBhBlockAssocs;
	}
	public DfBhBlockAssocDto addDfBhBlockAssoc(DfBhBlockAssocDto dfBhBlockAssoc) {
		getDfBhBlockAssocs().add(dfBhBlockAssoc);
		dfBhBlockAssoc.setBlock(this);
		return dfBhBlockAssoc;
	}
	public DfBhBlockAssocDto removeDfBhBlockAssoc(DfBhBlockAssocDto dfBhBlockAssoc) {
		getDfBhBlockAssocs().remove(dfBhBlockAssoc);
		dfBhBlockAssoc.setBlock(null);
		return dfBhBlockAssoc;
	}
	public List<DfBlockPortAssocDto> getDfBlockPortAssocs() {
		return this.dfBlockPortAssocs;
	}
	public void setDfBlockPortAssocs(List<DfBlockPortAssocDto> dfBlockPortAssocs) {
		this.dfBlockPortAssocs = dfBlockPortAssocs;
	}
	public DfBlockPortAssocDto addDfBlockPortAssoc(DfBlockPortAssocDto dfBlockPortAssoc) {
		getDfBlockPortAssocs().add(dfBlockPortAssoc);
		dfBlockPortAssoc.setBlock(this);
		return dfBlockPortAssoc;
	}
	public DfBlockPortAssocDto removeDfBlockPortAssoc(DfBlockPortAssocDto dfBlockPortAssoc) {
		getDfBlockPortAssocs().remove(dfBlockPortAssoc);
		dfBlockPortAssoc.setBlock(null);
		return dfBlockPortAssoc;
	}
	public List<DfCsPortTermDto> getDfCsPortTerms() {
		return this.dfCsPortTerms;
	}
	public void setDfCsPortTerms(List<DfCsPortTermDto> dfCsPortTerms) {
		this.dfCsPortTerms = dfCsPortTerms;
	}
	public DfCsPortTermDto addDfCsPortTerm(DfCsPortTermDto dfCsPortTerm) {
		getDfCsPortTerms().add(dfCsPortTerm);
		dfCsPortTerm.setBlock(this);
		return dfCsPortTerm;
	}
	public DfCsPortTermDto removeDfCsPortTerm(DfCsPortTermDto dfCsPortTerm) {
		getDfCsPortTerms().remove(dfCsPortTerm);
		dfCsPortTerm.setBlock(null);
		return dfCsPortTerm;
	}
	public List<DfPortDto> getDfPorts() {
		return this.dfPorts;
	}
	public void setDfPorts(List<DfPortDto> dfPorts) {
		this.dfPorts = dfPorts;
	}
	public DfPortDto addDfPort(DfPortDto dfPort) {
		getDfPorts().add(dfPort);
		dfPort.setBlock(this);
		return dfPort;
	}
	public DfPortDto removeDfPort(DfPortDto dfPort) {
		getDfPorts().remove(dfPort);
		dfPort.setBlock(null);
		return dfPort;
	}
}
