package com.bt.ngp.common.dto.generator.context;

public class MapperCtx extends PojoCtx {

    private String sourceType;
    private String targetType;
    private String dependencyMappers;

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getTargetType() {
        return targetType;
    }

    public void setTargetType(String targetType) {
        this.targetType = targetType;
    }

    public String getDependencyMappers() {
        return dependencyMappers;
    }

    public void setDependencyMappers(String dependencyMappers) {
        this.dependencyMappers = dependencyMappers;
    }

    public boolean hasDependencyMappers() {
        return this.dependencyMappers != null && !this.dependencyMappers.isEmpty();
    }

}
