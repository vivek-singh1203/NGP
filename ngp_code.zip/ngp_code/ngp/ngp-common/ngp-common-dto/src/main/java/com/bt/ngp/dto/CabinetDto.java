package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the CABINET database table.
 * 
 */

public class CabinetDto  {
	private String alternateName;
	private String assetIdentifier;
	private String createdBy;
	private Timestamp createdDate;
	private String dataQualityIndicator;
	private String desgName;
	private String desgNum;
	private String exchange1141Code;
	private String faultState;
	private String fieldLabel;
	private Object geoPosition;
	private long id;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String name;
	private String resource1141Code;
	private String resourceState;
	private String serialNumber;
	private String serviceState;
	private String specCategoryName;
	private String specName;
	private String specTypeName;
	private String specVersion;
	private String storeName;
	private String supplierName;
	private String userLabel;
	public CabinetDto() {
	}
	public String getAlternateName() {
		return this.alternateName;
	}
	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}
	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}
	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}
	public String getDesgName() {
		return this.desgName;
	}
	public void setDesgName(String desgName) {
		this.desgName = desgName;
	}
	public String getDesgNum() {
		return this.desgNum;
	}
	public void setDesgNum(String desgNum) {
		this.desgNum = desgNum;
	}
	public String getExchange1141Code() {
		return this.exchange1141Code;
	}
	public void setExchange1141Code(String exchange1141Code) {
		this.exchange1141Code = exchange1141Code;
	}
	public String getFaultState() {
		return this.faultState;
	}
	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}
	public String getFieldLabel() {
		return this.fieldLabel;
	}
	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}
	public Object getGeoPosition() {
		return this.geoPosition;
	}
	public void setGeoPosition(Object geoPosition) {
		this.geoPosition = geoPosition;
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getResource1141Code() {
		return this.resource1141Code;
	}
	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}
	public String getResourceState() {
		return this.resourceState;
	}
	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}
	public String getSerialNumber() {
		return this.serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getServiceState() {
		return this.serviceState;
	}
	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}
	public String getSpecCategoryName() {
		return this.specCategoryName;
	}
	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}
	public String getSpecName() {
		return this.specName;
	}
	public void setSpecName(String specName) {
		this.specName = specName;
	}
	public String getSpecTypeName() {
		return this.specTypeName;
	}
	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}
	public String getSpecVersion() {
		return this.specVersion;
	}
	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}
	public String getStoreName() {
		return this.storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getSupplierName() {
		return this.supplierName;
	}
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}
	public String getUserLabel() {
		return this.userLabel;
	}
	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}
}
