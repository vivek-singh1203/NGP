/**
 * 
 */
package com.bt.ngp.common.dto;

/**
 * Geometry type point, This class is immutable
 *
 * @since 25 Jan 2018
 * @author Mahesh 611174701
 */
public class Point implements Geometry {
	private double x;

	private double y;

	/**
	 * constructor to initialize the point
	 * @param x and y co-ordinates
	 */
	public Point(double x, double y) {
		this.x = x;
		this.y = y;
	}


	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

}
