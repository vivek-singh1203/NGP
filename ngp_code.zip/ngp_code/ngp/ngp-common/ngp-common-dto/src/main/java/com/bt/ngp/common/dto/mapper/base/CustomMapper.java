/*package com.bt.ngp.common.dto.mapper.base;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CustomMapper {

	@Autowired
	private ModelFactory modelFactory;

	public com.bt.platform.domain.model.spatial.Coordinate asCoordinate(
			com.bt.platform.domain.model.spatial.Coordinate inCoordinate) {
		com.bt.platform.domain.model.spatial.Coordinate out = null;
		if (inCoordinate != null) {
			out = new com.bt.platform.domain.model.spatial.Coordinate(inCoordinate.getX(), inCoordinate.getY()); // Edited
		}
		return out;
	}

	public com.bt.platform.domain.model.graph.Edge asEdge(com.bt.platform.domain.model.graph.Edge inEdge) {
		com.bt.platform.domain.model.graph.Edge out = null;
		if (inEdge != null) {
			out = modelFactory.createModel(inEdge.getClass());
			out.setParent(asEdge(inEdge.getParent()));
		}
		return out;
	}

	-public com.bt.ngp.common.dto.inventory.rootentities.EntityDto asEntityDto(
			com.bt.srims.shared.inventory.model.rootentities.Entity inEntity) {
		return null;
	}
	
	public com.bt.srims.shared.inventory.model.rootentities.Entity asEntity(
			com.bt.ngp.common.dto.inventory.rootentities.EntityDto inEntity) {
		return null;
	}

		public static <T extends Element> T createModel(Class<T> modelClass) {
	    return GraphTemplate.getInstance().createElement(modelClass);
	}

}
*/