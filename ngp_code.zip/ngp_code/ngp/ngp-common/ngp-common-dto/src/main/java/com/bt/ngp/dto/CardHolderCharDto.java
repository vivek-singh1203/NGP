package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the CARD_HOLDER_CHAR database table.
 * 
 */

public class CardHolderCharDto  {
	private long id;
	private String charName;
	private String charValue;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	
	private CardHolderDto cardHolder;
	
	private HolderSpecCharSpecDto holderSpecCharSpec;
	
	private HolderSpecCharValueSpecDto holderSpecCharValueSpec;
	public CardHolderCharDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCharName() {
		return this.charName;
	}
	public void setCharName(String charName) {
		this.charName = charName;
	}
	public String getCharValue() {
		return this.charValue;
	}
	public void setCharValue(String charValue) {
		this.charValue = charValue;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public CardHolderDto getCardHolder() {
		return this.cardHolder;
	}
	public void setCardHolder(CardHolderDto cardHolder) {
		this.cardHolder = cardHolder;
	}
	public HolderSpecCharSpecDto getHolderSpecCharSpec() {
		return this.holderSpecCharSpec;
	}
	public void setHolderSpecCharSpec(HolderSpecCharSpecDto holderSpecCharSpec) {
		this.holderSpecCharSpec = holderSpecCharSpec;
	}
	public HolderSpecCharValueSpecDto getHolderSpecCharValueSpec() {
		return this.holderSpecCharValueSpec;
	}
	public void setHolderSpecCharValueSpec(HolderSpecCharValueSpecDto holderSpecCharValueSpec) {
		this.holderSpecCharValueSpec = holderSpecCharValueSpec;
	}
}
