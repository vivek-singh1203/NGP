package com.bt.ngp.common.dto.generator;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.core.type.filter.RegexPatternTypeFilter;

import com.bt.ngp.common.dto.generator.context.PojoCtx;
import com.bt.ngp.common.dto.generator.context.PojoFieldCtx;

public class DtoGenerator {

    private static final String OUTPUT_DIR = "./target/generated-source-dto/";
    private static final String CLASS_NAME_PREFIX = "";
    private static final String CLASS_NAME_SUFFIX = "Dto";
    private static final String IN_PACKAGE_NAME = "com.bt.srims.shared.inventory.model";
    
    private static final String OUT_PACKAGE_NAME = "com.bt.ngp.common.dto.inventory";
    private static final String TEMPLATE = "mustache-template/dto-pojo.mustache";

    public static void main(String[] args) throws IntrospectionException, ClassNotFoundException {

        ClassPathScanner provider = new ClassPathScanner();
        provider.addIncludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*")));
        final Set<BeanDefinition> classes = provider.findCandidateComponents(IN_PACKAGE_NAME);
        System.out.println("length of set" +classes.size());
        for (BeanDefinition bean : classes) {
            PojoCtx pojoCtx = new PojoCtx();

            Class<?> clazz = Class.forName(bean.getBeanClassName());
           /* SchemaClass schemaClass = clazz.getAnnotation(SchemaClass.class);
            if (schemaClass != null) {

                pojoCtx.setAbstractClass(schemaClass.isAbstract());
                pojoCtx.setClassName(clazz.getSimpleName());
                pojoCtx.setClassNamePrefix(CLASS_NAME_PREFIX);
                pojoCtx.setClassNameSuffix(CLASS_NAME_SUFFIX);
                String packageName = clazz.getPackage().getName().replace(IN_PACKAGE_NAME, OUT_PACKAGE_NAME);
                pojoCtx.setPackageName(packageName);
                if (clazz.getInterfaces().length > 0) {
                    Class<?> superInterface = clazz.getInterfaces()[0];
                    pojoCtx.setSuperClass(superInterface.getPackage().getName()
                                    .replace(IN_PACKAGE_NAME, OUT_PACKAGE_NAME)
                                    + "." + CLASS_NAME_PREFIX + superInterface.getSimpleName() + CLASS_NAME_SUFFIX);
                }

                BeanInfo beanInfo = Introspector.getBeanInfo(clazz);
                List<PojoFieldCtx> fields = new ArrayList<>();
                pojoCtx.setFields(fields);
                for (PropertyDescriptor desc : beanInfo.getPropertyDescriptors()) {

                    PojoFieldCtx pojoFieldCtx = new PojoFieldCtx();
                    fields.add(pojoFieldCtx);

                    Type returnType = desc.getReadMethod().getGenericReturnType();
                    String returnTypeStr = returnType.getTypeName();
                    if (returnType instanceof ParameterizedType) {
                        ParameterizedType parameterizedReturnType = (ParameterizedType) returnType;
                        for (Type type : parameterizedReturnType.getActualTypeArguments()) {
                            if (!((Class<?>) type).isEnum() && returnTypeStr.contains(type.getTypeName())
                                            && type.getTypeName().contains(IN_PACKAGE_NAME)) {
                                returnTypeStr = returnTypeStr.replace(type.getTypeName(),
                                                type.getTypeName().replace(IN_PACKAGE_NAME, OUT_PACKAGE_NAME) + "Dto");
                            }
                        }
                    } else {
                        if (!((Class<?>) returnType).isEnum() && returnTypeStr.contains(returnType.getTypeName())
                                        && returnType.getTypeName().contains(IN_PACKAGE_NAME)) {
                            returnTypeStr = returnTypeStr.replace(returnType.getTypeName(), returnType.getTypeName()
                                            .replace(IN_PACKAGE_NAME, OUT_PACKAGE_NAME) + "Dto");
                        }
                    }

                    pojoFieldCtx.setFieldName(desc.getDisplayName());

                    pojoFieldCtx.setFieldType(returnTypeStr);
                }

                //
                System.out.println("Generating DTO for " + packageName + "." + pojoCtx.getClassName());
                MustacheUtil.generatePojo(OUTPUT_DIR + packageName.replace(".", "/") + "/", TEMPLATE, pojoCtx);
            }*/
        }
    }
}
