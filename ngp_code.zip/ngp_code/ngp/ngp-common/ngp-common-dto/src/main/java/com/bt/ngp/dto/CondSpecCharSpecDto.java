package com.bt.ngp.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the COND_SPEC_CHAR_SPEC database table.
 * 
 */

public class CondSpecCharSpecDto  {
	private long id;
	private String canBeOverriden;
	private String createdBy;
	private Timestamp createdDate;
	private String description;
	private String isUniqueWhenPresent;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String maxCardinality;
	private String minCardinality;
	private String name;
	private String remarks;
	private Timestamp validFrom;
	private Timestamp validTo;
	private String valueType;
	
	private List<ConductorCharDto> conductorChars;
	
		
	private ConductorSpecDto conductorSpec;
	
	private CondSpecCharValueSpecDto condSpecCharValueSpec;
	
	private EntityDto entity;
	
	private EntityCharCategoryDto entityCharCategory;
	
	private EntityCharSpecDto entityCharSpec;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	
	private List<CondSpecCharSpecRelDto> condSpecCharSpecRels1;
	
	private List<CondSpecCharSpecRelDto> condSpecCharSpecRels2;
	public CondSpecCharSpecDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCanBeOverriden() {
		return this.canBeOverriden;
	}
	public void setCanBeOverriden(String canBeOverriden) {
		this.canBeOverriden = canBeOverriden;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDescription() {
		return this.description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIsUniqueWhenPresent() {
		return this.isUniqueWhenPresent;
	}
	public void setIsUniqueWhenPresent(String isUniqueWhenPresent) {
		this.isUniqueWhenPresent = isUniqueWhenPresent;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getMaxCardinality() {
		return this.maxCardinality;
	}
	public void setMaxCardinality(String maxCardinality) {
		this.maxCardinality = maxCardinality;
	}
	public String getMinCardinality() {
		return this.minCardinality;
	}
	public void setMinCardinality(String minCardinality) {
		this.minCardinality = minCardinality;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRemarks() {
		return this.remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Timestamp getValidFrom() {
		return this.validFrom;
	}
	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}
	public Timestamp getValidTo() {
		return this.validTo;
	}
	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}
	public String getValueType() {
		return this.valueType;
	}
	public void setValueType(String valueType) {
		this.valueType = valueType;
	}
	public List<ConductorCharDto> getConductorChars() {
		return this.conductorChars;
	}
	public void setConductorChars(List<ConductorCharDto> conductorChars) {
		this.conductorChars = conductorChars;
	}
	public ConductorCharDto addConductorChar(ConductorCharDto conductorChar) {
		getConductorChars().add(conductorChar);
		conductorChar.setCondSpecCharSpec(this);
		return conductorChar;
	}
	public ConductorCharDto removeConductorChar(ConductorCharDto conductorChar) {
		getConductorChars().remove(conductorChar);
		conductorChar.setCondSpecCharSpec(null);
		return conductorChar;
	}
	public ConductorSpecDto getConductorSpec() {
		return this.conductorSpec;
	}
	public void setConductorSpec(ConductorSpecDto conductorSpec) {
		this.conductorSpec = conductorSpec;
	}
	public CondSpecCharValueSpecDto getCondSpecCharValueSpec() {
		return this.condSpecCharValueSpec;
	}
	public void setCondSpecCharValueSpec(CondSpecCharValueSpecDto condSpecCharValueSpec) {
		this.condSpecCharValueSpec = condSpecCharValueSpec;
	}
	public EntityDto getEntity() {
		return this.entity;
	}
	public void setEntity(EntityDto entity) {
		this.entity = entity;
	}
	public EntityCharCategoryDto getEntityCharCategory() {
		return this.entityCharCategory;
	}
	public void setEntityCharCategory(EntityCharCategoryDto entityCharCategory) {
		this.entityCharCategory = entityCharCategory;
	}
	public EntityCharSpecDto getEntityCharSpec() {
		return this.entityCharSpec;
	}
	public void setEntityCharSpec(EntityCharSpecDto entityCharSpec) {
		this.entityCharSpec = entityCharSpec;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
	public List<CondSpecCharSpecRelDto> getCondSpecCharSpecRels1() {
		return this.condSpecCharSpecRels1;
	}
	public void setCondSpecCharSpecRels1(List<CondSpecCharSpecRelDto> condSpecCharSpecRels1) {
		this.condSpecCharSpecRels1 = condSpecCharSpecRels1;
	}
	public CondSpecCharSpecRelDto addCondSpecCharSpecRels1(CondSpecCharSpecRelDto condSpecCharSpecRels1) {
		getCondSpecCharSpecRels1().add(condSpecCharSpecRels1);
		condSpecCharSpecRels1.setCondSpecCharSpec1(this);
		return condSpecCharSpecRels1;
	}
	public CondSpecCharSpecRelDto removeCondSpecCharSpecRels1(CondSpecCharSpecRelDto condSpecCharSpecRels1) {
		getCondSpecCharSpecRels1().remove(condSpecCharSpecRels1);
		condSpecCharSpecRels1.setCondSpecCharSpec1(null);
		return condSpecCharSpecRels1;
	}
	public List<CondSpecCharSpecRelDto> getCondSpecCharSpecRels2() {
		return this.condSpecCharSpecRels2;
	}
	public void setCondSpecCharSpecRels2(List<CondSpecCharSpecRelDto> condSpecCharSpecRels2) {
		this.condSpecCharSpecRels2 = condSpecCharSpecRels2;
	}
	public CondSpecCharSpecRelDto addCondSpecCharSpecRels2(CondSpecCharSpecRelDto condSpecCharSpecRels2) {
		getCondSpecCharSpecRels2().add(condSpecCharSpecRels2);
		condSpecCharSpecRels2.setCondSpecCharSpec2(this);
		return condSpecCharSpecRels2;
	}
	public CondSpecCharSpecRelDto removeCondSpecCharSpecRels2(CondSpecCharSpecRelDto condSpecCharSpecRels2) {
		getCondSpecCharSpecRels2().remove(condSpecCharSpecRels2);
		condSpecCharSpecRels2.setCondSpecCharSpec2(null);
		return condSpecCharSpecRels2;
	}
}
