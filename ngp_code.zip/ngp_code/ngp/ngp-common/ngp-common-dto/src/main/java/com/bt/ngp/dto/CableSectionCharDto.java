package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the CABLE_SECTION_CHAR database table.
 * 
 */

public class CableSectionCharDto  {
	private long id;
	private String charName;
	private String charValue;
	private String createdBy;
	private Timestamp createdDate;
	private String csName;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	
	private CableSpecCharSpecDto cableSpecCharSpec;
	
	private CableSpecCharValueSpecDto cableSpecCharValueSpec;
	
	private SpecCategoryDto specCategory;
	public CableSectionCharDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCharName() {
		return this.charName;
	}
	public void setCharName(String charName) {
		this.charName = charName;
	}
	public String getCharValue() {
		return this.charValue;
	}
	public void setCharValue(String charValue) {
		this.charValue = charValue;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getCsName() {
		return this.csName;
	}
	public void setCsName(String csName) {
		this.csName = csName;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public CableSpecCharSpecDto getCableSpecCharSpec() {
		return this.cableSpecCharSpec;
	}
	public void setCableSpecCharSpec(CableSpecCharSpecDto cableSpecCharSpec) {
		this.cableSpecCharSpec = cableSpecCharSpec;
	}
	public CableSpecCharValueSpecDto getCableSpecCharValueSpec() {
		return this.cableSpecCharValueSpec;
	}
	public void setCableSpecCharValueSpec(CableSpecCharValueSpecDto cableSpecCharValueSpec) {
		this.cableSpecCharValueSpec = cableSpecCharValueSpec;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
}
