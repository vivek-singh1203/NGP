/*package com.bt.ngp.common.dto.mapper.base;

import org.springframework.stereotype.Component;

import com.bt.platform.domain.model.graph.Element;

@Component
public class ModelFactory {
//    @Autowired
   // private GraphTemplate graphTemplate;

    public <T extends Element> T createModel( @TargetType Class<T> modelClass) {
      //  return graphTemplate.createElement(modelClass);
    	return null;
    }

}
*/