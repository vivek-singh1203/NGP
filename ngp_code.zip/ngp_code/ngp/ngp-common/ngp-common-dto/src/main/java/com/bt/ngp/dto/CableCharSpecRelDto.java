package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the CABLE_CHAR_SPEC_REL database table.
 * 
 */

public class CableCharSpecRelDto  {
	private long id;
	private String charSpecRelationType;
	private String charValueSpecRelationType;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	
		
	private CableSpecDto cableSpec;
	
	private CableSpecCharSpecDto cableSpecCharSpec1;
	
	private CableSpecCharSpecDto cableSpecCharSpec2;
	
	private EntityDto entity;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	public CableCharSpecRelDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCharSpecRelationType() {
		return this.charSpecRelationType;
	}
	public void setCharSpecRelationType(String charSpecRelationType) {
		this.charSpecRelationType = charSpecRelationType;
	}
	public String getCharValueSpecRelationType() {
		return this.charValueSpecRelationType;
	}
	public void setCharValueSpecRelationType(String charValueSpecRelationType) {
		this.charValueSpecRelationType = charValueSpecRelationType;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public CableSpecDto getCableSpec() {
		return this.cableSpec;
	}
	public void setCableSpec(CableSpecDto cableSpec) {
		this.cableSpec = cableSpec;
	}
	public CableSpecCharSpecDto getCableSpecCharSpec1() {
		return this.cableSpecCharSpec1;
	}
	public void setCableSpecCharSpec1(CableSpecCharSpecDto cableSpecCharSpec1) {
		this.cableSpecCharSpec1 = cableSpecCharSpec1;
	}
	public CableSpecCharSpecDto getCableSpecCharSpec2() {
		return this.cableSpecCharSpec2;
	}
	public void setCableSpecCharSpec2(CableSpecCharSpecDto cableSpecCharSpec2) {
		this.cableSpecCharSpec2 = cableSpecCharSpec2;
	}
	public EntityDto getEntity() {
		return this.entity;
	}
	public void setEntity(EntityDto entity) {
		this.entity = entity;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
}
