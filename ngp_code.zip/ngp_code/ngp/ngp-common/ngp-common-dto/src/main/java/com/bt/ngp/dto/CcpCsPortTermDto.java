package com.bt.ngp.dto;

import java.sql.Timestamp;
/**
 * The persistent class for the CCP_CS_PORT_TERM database table.
 * 
 */

public class CcpCsPortTermDto  {
	private long id;
	private String ccpName;
	private String condSeqNum;
	private String createdBy;
	private Timestamp createdDate;
	private String csName;
	private String dataQualityIndicator;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String portSeqNum;
	private String terminatingResource;
	private String terminationState;
	private String terminationType;
	
	private CcpPortDto ccpPort;
	
	private ChassiDto chassi;
	
	private ConductorDto conductor;
	
	private ConductorBundleDto conductorBundle;
	
	private EqCableCompatSpecDto eqCableCompatSpec;
	
	private PluginDto plugin;
	public CcpCsPortTermDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCcpName() {
		return this.ccpName;
	}
	public void setCcpName(String ccpName) {
		this.ccpName = ccpName;
	}
	public String getCondSeqNum() {
		return this.condSeqNum;
	}
	public void setCondSeqNum(String condSeqNum) {
		this.condSeqNum = condSeqNum;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getCsName() {
		return this.csName;
	}
	public void setCsName(String csName) {
		this.csName = csName;
	}
	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getPortSeqNum() {
		return this.portSeqNum;
	}
	public void setPortSeqNum(String portSeqNum) {
		this.portSeqNum = portSeqNum;
	}
	public String getTerminatingResource() {
		return this.terminatingResource;
	}
	public void setTerminatingResource(String terminatingResource) {
		this.terminatingResource = terminatingResource;
	}
	public String getTerminationState() {
		return this.terminationState;
	}
	public void setTerminationState(String terminationState) {
		this.terminationState = terminationState;
	}
	public String getTerminationType() {
		return this.terminationType;
	}
	public void setTerminationType(String terminationType) {
		this.terminationType = terminationType;
	}
	public CcpPortDto getCcpPort() {
		return this.ccpPort;
	}
	public void setCcpPort(CcpPortDto ccpPort) {
		this.ccpPort = ccpPort;
	}
	public ChassiDto getChassi() {
		return this.chassi;
	}
	public void setChassi(ChassiDto chassi) {
		this.chassi = chassi;
	}
	public ConductorDto getConductor() {
		return this.conductor;
	}
	public void setConductor(ConductorDto conductor) {
		this.conductor = conductor;
	}
	public ConductorBundleDto getConductorBundle() {
		return this.conductorBundle;
	}
	public void setConductorBundle(ConductorBundleDto conductorBundle) {
		this.conductorBundle = conductorBundle;
	}
	public EqCableCompatSpecDto getEqCableCompatSpec() {
		return this.eqCableCompatSpec;
	}
	public void setEqCableCompatSpec(EqCableCompatSpecDto eqCableCompatSpec) {
		this.eqCableCompatSpec = eqCableCompatSpec;
	}
	public PluginDto getPlugin() {
		return this.plugin;
	}
	public void setPlugin(PluginDto plugin) {
		this.plugin = plugin;
	}
}
