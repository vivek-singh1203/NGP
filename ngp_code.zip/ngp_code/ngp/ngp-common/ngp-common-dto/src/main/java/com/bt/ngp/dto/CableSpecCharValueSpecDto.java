package com.bt.ngp.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CABLE_SPEC_CHAR_VALUE_SPEC database table.
 * 
 */

public class CableSpecCharValueSpecDto  {
	private long id;
	private String createdBy;
	private Timestamp createdDate;
	private String defaultValue;
	private String description;
	private String entityCharValueSpecId;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String measurementUnit;
	private String rangeInterval;
	private String remarks;
	private Timestamp validFrom;
	private Timestamp validTo;
	private String valueFrom;
	private String valueTo;
	
	private List<CableSectionCharDto> cableSectionChars;
	
	private List<CableSpecCharSpecDto> cableSpecCharSpecs;
	
		
	private CableSpecDto cableSpec;
	
	private EntityDto entity;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	public CableSpecCharValueSpecDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDefaultValue() {
		return this.defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	public String getDescription() {
		return this.description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEntityCharValueSpecId() {
		return this.entityCharValueSpecId;
	}
	public void setEntityCharValueSpecId(String entityCharValueSpecId) {
		this.entityCharValueSpecId = entityCharValueSpecId;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getMeasurementUnit() {
		return this.measurementUnit;
	}
	public void setMeasurementUnit(String measurementUnit) {
		this.measurementUnit = measurementUnit;
	}
	public String getRangeInterval() {
		return this.rangeInterval;
	}
	public void setRangeInterval(String rangeInterval) {
		this.rangeInterval = rangeInterval;
	}
	public String getRemarks() {
		return this.remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Timestamp getValidFrom() {
		return this.validFrom;
	}
	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}
	public Timestamp getValidTo() {
		return this.validTo;
	}
	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}
	public String getValueFrom() {
		return this.valueFrom;
	}
	public void setValueFrom(String valueFrom) {
		this.valueFrom = valueFrom;
	}
	public String getValueTo() {
		return this.valueTo;
	}
	public void setValueTo(String valueTo) {
		this.valueTo = valueTo;
	}
	public List<CableSectionCharDto> getCableSectionChars() {
		return this.cableSectionChars;
	}
	public void setCableSectionChars(List<CableSectionCharDto> cableSectionChars) {
		this.cableSectionChars = cableSectionChars;
	}
	public CableSectionCharDto addCableSectionChar(CableSectionCharDto cableSectionChar) {
		getCableSectionChars().add(cableSectionChar);
		cableSectionChar.setCableSpecCharValueSpec(this);
		return cableSectionChar;
	}
	public CableSectionCharDto removeCableSectionChar(CableSectionCharDto cableSectionChar) {
		getCableSectionChars().remove(cableSectionChar);
		cableSectionChar.setCableSpecCharValueSpec(null);
		return cableSectionChar;
	}
	public List<CableSpecCharSpecDto> getCableSpecCharSpecs() {
		return this.cableSpecCharSpecs;
	}
	public void setCableSpecCharSpecs(List<CableSpecCharSpecDto> cableSpecCharSpecs) {
		this.cableSpecCharSpecs = cableSpecCharSpecs;
	}
	public CableSpecCharSpecDto addCableSpecCharSpec(CableSpecCharSpecDto cableSpecCharSpec) {
		getCableSpecCharSpecs().add(cableSpecCharSpec);
		cableSpecCharSpec.setCableSpecCharValueSpec(this);
		return cableSpecCharSpec;
	}
	public CableSpecCharSpecDto removeCableSpecCharSpec(CableSpecCharSpecDto cableSpecCharSpec) {
		getCableSpecCharSpecs().remove(cableSpecCharSpec);
		cableSpecCharSpec.setCableSpecCharValueSpec(null);
		return cableSpecCharSpec;
	}
	public CableSpecDto getCableSpec() {
		return this.cableSpec;
	}
	public void setCableSpec(CableSpecDto cableSpec) {
		this.cableSpec = cableSpec;
	}
	public EntityDto getEntity() {
		return this.entity;
	}
	public void setEntity(EntityDto entity) {
		this.entity = entity;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
}
