package com.bt.ngp.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CCP_CHASSIS_PH_ASSOC database table.
 * 
 */

public class CcpChassisPhAssocDto  {
	private long id;
	private String ccpName;
	private String createdBy;
	private Timestamp createdDate;
	private String endPositionNum;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String startPositionNum;
	
	private ChassiDto chassi;
	
	private EqCompHolderAssocSpecDto eqCompHolderAssocSpec;
	
	private PluginHolderDto pluginHolder;
	
	private List<CcpHierarchyDto> ccpHierarchies;
	public CcpChassisPhAssocDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCcpName() {
		return this.ccpName;
	}
	public void setCcpName(String ccpName) {
		this.ccpName = ccpName;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getEndPositionNum() {
		return this.endPositionNum;
	}
	public void setEndPositionNum(String endPositionNum) {
		this.endPositionNum = endPositionNum;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getStartPositionNum() {
		return this.startPositionNum;
	}
	public void setStartPositionNum(String startPositionNum) {
		this.startPositionNum = startPositionNum;
	}
	public ChassiDto getChassi() {
		return this.chassi;
	}
	public void setChassi(ChassiDto chassi) {
		this.chassi = chassi;
	}
	public EqCompHolderAssocSpecDto getEqCompHolderAssocSpec() {
		return this.eqCompHolderAssocSpec;
	}
	public void setEqCompHolderAssocSpec(EqCompHolderAssocSpecDto eqCompHolderAssocSpec) {
		this.eqCompHolderAssocSpec = eqCompHolderAssocSpec;
	}
	public PluginHolderDto getPluginHolder() {
		return this.pluginHolder;
	}
	public void setPluginHolder(PluginHolderDto pluginHolder) {
		this.pluginHolder = pluginHolder;
	}
	public List<CcpHierarchyDto> getCcpHierarchies() {
		return this.ccpHierarchies;
	}
	public void setCcpHierarchies(List<CcpHierarchyDto> ccpHierarchies) {
		this.ccpHierarchies = ccpHierarchies;
	}
	public CcpHierarchyDto addCcpHierarchy(CcpHierarchyDto ccpHierarchy) {
		getCcpHierarchies().add(ccpHierarchy);
		ccpHierarchy.setCcpChassisPhAssoc(this);
		return ccpHierarchy;
	}
	public CcpHierarchyDto removeCcpHierarchy(CcpHierarchyDto ccpHierarchy) {
		getCcpHierarchies().remove(ccpHierarchy);
		ccpHierarchy.setCcpChassisPhAssoc(null);
		return ccpHierarchy;
	}
}
