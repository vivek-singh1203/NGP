package com.bt.ngp.common.dto.generator.context;

import java.util.List;

import org.springframework.util.StringUtils;

public class PojoCtx {

    private String packageName;
    private String className;
    private String classNamePrefix;
    private String classNameSuffix;
    private String superClass;
    private String interfaces;
    private boolean abstractClass;
    private List<PojoFieldCtx> fields;
    private List<String> imports;

    public List<String> getImports() {
        return imports;
    }

    public void setImports(List<String> imports) {
        this.imports = imports;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public List<PojoFieldCtx> getFields() {
        return fields;
    }

    public void setFields(List<PojoFieldCtx> fields) {
        this.fields = fields;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public boolean isConcrete() {
        return abstractClass;
    }

    public String getClassNamePrefix() {
        return classNamePrefix;
    }

    public boolean isAbstractClass() {
        return abstractClass;
    }

    public void setAbstractClass(boolean abstractClass) {
        this.abstractClass = abstractClass;
    }

    public void setClassNamePrefix(String classNamePrefix) {
        this.classNamePrefix = classNamePrefix;
    }

    public String getClassNameSuffix() {
        return classNameSuffix;
    }

    public void setClassNameSuffix(String classNameSuffix) {
        this.classNameSuffix = classNameSuffix;
    }

    public boolean hasSuperClass() {
        return !StringUtils.isEmpty(this.superClass);
    }

    public String getSuperClass() {
        return superClass;
    }

    public String getInterfaces() {
        return interfaces;
    }

    public void setSuperClass(String superClass) {
        this.superClass = superClass;
    }

    public void setInterfaces(String interfaces) {
        this.interfaces = interfaces;
    }
    
    
    public boolean hasInterfaces() {
        return !StringUtils.isEmpty(this.interfaces);
    }

    /*-public String getSuperClassSimpleName() {
        return this.superClass != null ? this.superClass.getSimpleName() : "";
    }

    public String getSuperClassName() {
        return this.superClass != null ? this.superClass.getName() : "";
    }

    public String getInterfacesAsCsv() {
        return this.interfaces != null && this.interfaces.length > 0 ? Arrays.asList(this.interfaces).stream()
                        .map(clazz -> clazz.getSimpleName()).collect(Collectors.joining(",")) : "";
    }*/
}
