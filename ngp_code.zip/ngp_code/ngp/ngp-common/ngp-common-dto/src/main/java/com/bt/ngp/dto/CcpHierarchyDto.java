package com.bt.ngp.dto;

import java.sql.Timestamp;
/**
 * The persistent class for the CCP_HIERARCHY database table.
 * 
 */

public class CcpHierarchyDto  {
	private long id;
	private String ccpName;
	private String ccpPosEndNum;
	private String ccpPosStartNum;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String legId;
	
	private CcpChassisPhAssocDto ccpChassisPhAssoc;
	
	private CcpPhPluginAssocDto ccpPhPluginAssoc;
	
	private CcpPluginPortAssocDto ccpPluginPortAssoc;
	
	private EqHierarchySpecDto eqHierarchySpec;
	public CcpHierarchyDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCcpName() {
		return this.ccpName;
	}
	public void setCcpName(String ccpName) {
		this.ccpName = ccpName;
	}
	public String getCcpPosEndNum() {
		return this.ccpPosEndNum;
	}
	public void setCcpPosEndNum(String ccpPosEndNum) {
		this.ccpPosEndNum = ccpPosEndNum;
	}
	public String getCcpPosStartNum() {
		return this.ccpPosStartNum;
	}
	public void setCcpPosStartNum(String ccpPosStartNum) {
		this.ccpPosStartNum = ccpPosStartNum;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getLegId() {
		return this.legId;
	}
	public void setLegId(String legId) {
		this.legId = legId;
	}
	public CcpChassisPhAssocDto getCcpChassisPhAssoc() {
		return this.ccpChassisPhAssoc;
	}
	public void setCcpChassisPhAssoc(CcpChassisPhAssocDto ccpChassisPhAssoc) {
		this.ccpChassisPhAssoc = ccpChassisPhAssoc;
	}
	public CcpPhPluginAssocDto getCcpPhPluginAssoc() {
		return this.ccpPhPluginAssoc;
	}
	public void setCcpPhPluginAssoc(CcpPhPluginAssocDto ccpPhPluginAssoc) {
		this.ccpPhPluginAssoc = ccpPhPluginAssoc;
	}
	public CcpPluginPortAssocDto getCcpPluginPortAssoc() {
		return this.ccpPluginPortAssoc;
	}
	public void setCcpPluginPortAssoc(CcpPluginPortAssocDto ccpPluginPortAssoc) {
		this.ccpPluginPortAssoc = ccpPluginPortAssoc;
	}
	public EqHierarchySpecDto getEqHierarchySpec() {
		return this.eqHierarchySpec;
	}
	public void setEqHierarchySpec(EqHierarchySpecDto eqHierarchySpec) {
		this.eqHierarchySpec = eqHierarchySpec;
	}
}
