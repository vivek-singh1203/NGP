package com.bt.ngp.common.dto;

public class PhysicalResourceModel extends EntityDetailsDto{

}
