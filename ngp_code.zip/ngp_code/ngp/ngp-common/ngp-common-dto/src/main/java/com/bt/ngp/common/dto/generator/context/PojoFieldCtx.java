package com.bt.ngp.common.dto.generator.context;

public class PojoFieldCtx {

    private String fieldName;
    private String fieldType;

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getFieldNameInitCap() {
        return fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
    }

    public String getFieldType() {
        return fieldType;
    }

    public void setFieldType(String fieldType) {
        this.fieldType = fieldType;
    }

}
