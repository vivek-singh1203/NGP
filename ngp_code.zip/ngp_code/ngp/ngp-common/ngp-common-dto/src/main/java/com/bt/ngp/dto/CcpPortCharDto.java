package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the CCP_PORT_CHAR database table.
 * 
 */

public class CcpPortCharDto  {
	private long id;
	private String ccpName;
	private String charName;
	private String charValue;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	
	private CcpPortDto ccpPort;
	
	private PortSpecCharSpecDto portSpecCharSpec;
	
	private PortSpecCharValueSpecDto portSpecCharValueSpec;
	public CcpPortCharDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCcpName() {
		return this.ccpName;
	}
	public void setCcpName(String ccpName) {
		this.ccpName = ccpName;
	}
	public String getCharName() {
		return this.charName;
	}
	public void setCharName(String charName) {
		this.charName = charName;
	}
	public String getCharValue() {
		return this.charValue;
	}
	public void setCharValue(String charValue) {
		this.charValue = charValue;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public CcpPortDto getCcpPort() {
		return this.ccpPort;
	}
	public void setCcpPort(CcpPortDto ccpPort) {
		this.ccpPort = ccpPort;
	}
	public PortSpecCharSpecDto getPortSpecCharSpec() {
		return this.portSpecCharSpec;
	}
	public void setPortSpecCharSpec(PortSpecCharSpecDto portSpecCharSpec) {
		this.portSpecCharSpec = portSpecCharSpec;
	}
	public PortSpecCharValueSpecDto getPortSpecCharValueSpec() {
		return this.portSpecCharValueSpec;
	}
	public void setPortSpecCharValueSpec(PortSpecCharValueSpecDto portSpecCharValueSpec) {
		this.portSpecCharValueSpec = portSpecCharValueSpec;
	}
}
