package com.bt.ngp.dto;

import java.sql.Timestamp;
/**
 * The persistent class for the CCP_CABLE_CONDUCTOR_SPLICING database table.
 * 
 */

public class CcpCableConductorSplicingDto  {
	private String ccpName;
	private String createdBy;
	private Timestamp createdDate;
	private String dataQualityIndicator;
	private String exchange1141Code;
	private long id;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String origCbName;
	private String origCondName;
	private String origCondSeqNum;
	private String origCsName;
	private String origParentCsName;
	private String splicingResource;
	private String splicingState;
	private String termCbName;
	private String termCondName;
	private String termCondSeqNum;
	private String termCsName;
	private String termParentCsName;
	public CcpCableConductorSplicingDto() {
	}
	public String getCcpName() {
		return this.ccpName;
	}
	public void setCcpName(String ccpName) {
		this.ccpName = ccpName;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}
	public String getExchange1141Code() {
		return this.exchange1141Code;
	}
	public void setExchange1141Code(String exchange1141Code) {
		this.exchange1141Code = exchange1141Code;
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getOrigCbName() {
		return this.origCbName;
	}
	public void setOrigCbName(String origCbName) {
		this.origCbName = origCbName;
	}
	public String getOrigCondName() {
		return this.origCondName;
	}
	public void setOrigCondName(String origCondName) {
		this.origCondName = origCondName;
	}
	public String getOrigCondSeqNum() {
		return this.origCondSeqNum;
	}
	public void setOrigCondSeqNum(String origCondSeqNum) {
		this.origCondSeqNum = origCondSeqNum;
	}
	public String getOrigCsName() {
		return this.origCsName;
	}
	public void setOrigCsName(String origCsName) {
		this.origCsName = origCsName;
	}
	public String getOrigParentCsName() {
		return this.origParentCsName;
	}
	public void setOrigParentCsName(String origParentCsName) {
		this.origParentCsName = origParentCsName;
	}
	public String getSplicingResource() {
		return this.splicingResource;
	}
	public void setSplicingResource(String splicingResource) {
		this.splicingResource = splicingResource;
	}
	public String getSplicingState() {
		return this.splicingState;
	}
	public void setSplicingState(String splicingState) {
		this.splicingState = splicingState;
	}
	public String getTermCbName() {
		return this.termCbName;
	}
	public void setTermCbName(String termCbName) {
		this.termCbName = termCbName;
	}
	public String getTermCondName() {
		return this.termCondName;
	}
	public void setTermCondName(String termCondName) {
		this.termCondName = termCondName;
	}
	public String getTermCondSeqNum() {
		return this.termCondSeqNum;
	}
	public void setTermCondSeqNum(String termCondSeqNum) {
		this.termCondSeqNum = termCondSeqNum;
	}
	public String getTermCsName() {
		return this.termCsName;
	}
	public void setTermCsName(String termCsName) {
		this.termCsName = termCsName;
	}
	public String getTermParentCsName() {
		return this.termParentCsName;
	}
	public void setTermParentCsName(String termParentCsName) {
		this.termParentCsName = termParentCsName;
	}
}
