package com.bt.ngp.dto;
import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CABLE_SPEC database table.
 * 
 */

public class CableSpecDto  {
	//private CableSpecPKDto id;
	private String createdBy;
	private Timestamp createdDate;
	private double depth;
	private String depthUnit;
	private double diameter;
	private String diameterUnit;
	private double height;
	private String heightUnit;
	private long id;
	private String isOrderable;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private double length;
	private String lengthUnit;
	private String manufacturerCode;
	private double materialCostPerUnit;
	private String materialCostUnit;
	private String materialType;
	private double powerConsumption;
	private String powerConsumptionUnit;
	private double powerDissipation;
	private String powerDissipationUnit;
	private double powerRating;
	private String powerRatingUnit;
	private String specRemarks;
	private String specStatus;
	private Timestamp validFrom;
	private Timestamp validTo;
	private double volume;
	private String volumeUnit;
	private double weight;
	private String weightUnit;
	private double width;
	private String widthUnit;
	
	private List<CableCbAssocSpecDto> cableCbAssocSpecs;
	
	private List<CableCharSpecRelDto> cableCharSpecRels;
	
	private List<CableCondAssocSpecDto> cableCondAssocSpecs;
	
	private List<CableHierarchySpecDto> cableHierarchySpecs;
	
	private List<CableSelfAssocSpecDto> cableSelfAssocSpecs1;
	
	private List<CableSelfAssocSpecDto> cableSelfAssocSpecs2;
	
	private List<CableSpanCompatSpecDto> cableSpanCompatSpecs;
	
	private EntityDto entity;
	
	private ManufacturerDto manufacturer;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	
	private List<CableSpecCharSpecDto> cableSpecCharSpecs;
	
	private List<CableSpecCharValueSpecDto> cableSpecCharValueSpecs;
	
	private List<DeviceCableCompatSpecDto> deviceCableCompatSpecs;
	
	private List<EqCableCompatSpecDto> eqCableCompatSpecs;
	public CableSpecDto() {
	}
/*	public CableSpecPKDto getId() {
		return this.id;
	}
	public void setId(CableSpecPKDto id) {
		this.id = id;
	}*/
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public double getDepth() {
		return this.depth;
	}
	public void setDepth(double depth) {
		this.depth = depth;
	}
	public String getDepthUnit() {
		return this.depthUnit;
	}
	public void setDepthUnit(String depthUnit) {
		this.depthUnit = depthUnit;
	}
	public double getDiameter() {
		return this.diameter;
	}
	public void setDiameter(double diameter) {
		this.diameter = diameter;
	}
	public String getDiameterUnit() {
		return this.diameterUnit;
	}
	public void setDiameterUnit(String diameterUnit) {
		this.diameterUnit = diameterUnit;
	}
	public double getHeight() {
		return this.height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public String getHeightUnit() {
		return this.heightUnit;
	}
	public void setHeightUnit(String heightUnit) {
		this.heightUnit = heightUnit;
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getIsOrderable() {
		return this.isOrderable;
	}
	public void setIsOrderable(String isOrderable) {
		this.isOrderable = isOrderable;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public double getLength() {
		return this.length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	public String getLengthUnit() {
		return this.lengthUnit;
	}
	public void setLengthUnit(String lengthUnit) {
		this.lengthUnit = lengthUnit;
	}
	public String getManufacturerCode() {
		return this.manufacturerCode;
	}
	public void setManufacturerCode(String manufacturerCode) {
		this.manufacturerCode = manufacturerCode;
	}
	public double getMaterialCostPerUnit() {
		return this.materialCostPerUnit;
	}
	public void setMaterialCostPerUnit(double materialCostPerUnit) {
		this.materialCostPerUnit = materialCostPerUnit;
	}
	public String getMaterialCostUnit() {
		return this.materialCostUnit;
	}
	public void setMaterialCostUnit(String materialCostUnit) {
		this.materialCostUnit = materialCostUnit;
	}
	public String getMaterialType() {
		return this.materialType;
	}
	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}
	public double getPowerConsumption() {
		return this.powerConsumption;
	}
	public void setPowerConsumption(double powerConsumption) {
		this.powerConsumption = powerConsumption;
	}
	public String getPowerConsumptionUnit() {
		return this.powerConsumptionUnit;
	}
	public void setPowerConsumptionUnit(String powerConsumptionUnit) {
		this.powerConsumptionUnit = powerConsumptionUnit;
	}
	public double getPowerDissipation() {
		return this.powerDissipation;
	}
	public void setPowerDissipation(double powerDissipation) {
		this.powerDissipation = powerDissipation;
	}
	public String getPowerDissipationUnit() {
		return this.powerDissipationUnit;
	}
	public void setPowerDissipationUnit(String powerDissipationUnit) {
		this.powerDissipationUnit = powerDissipationUnit;
	}
	public double getPowerRating() {
		return this.powerRating;
	}
	public void setPowerRating(double powerRating) {
		this.powerRating = powerRating;
	}
	public String getPowerRatingUnit() {
		return this.powerRatingUnit;
	}
	public void setPowerRatingUnit(String powerRatingUnit) {
		this.powerRatingUnit = powerRatingUnit;
	}
	public String getSpecRemarks() {
		return this.specRemarks;
	}
	public void setSpecRemarks(String specRemarks) {
		this.specRemarks = specRemarks;
	}
	public String getSpecStatus() {
		return this.specStatus;
	}
	public void setSpecStatus(String specStatus) {
		this.specStatus = specStatus;
	}
	public Timestamp getValidFrom() {
		return this.validFrom;
	}
	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}
	public Timestamp getValidTo() {
		return this.validTo;
	}
	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}
	public double getVolume() {
		return this.volume;
	}
	public void setVolume(double volume) {
		this.volume = volume;
	}
	public String getVolumeUnit() {
		return this.volumeUnit;
	}
	public void setVolumeUnit(String volumeUnit) {
		this.volumeUnit = volumeUnit;
	}
	public double getWeight() {
		return this.weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public String getWeightUnit() {
		return this.weightUnit;
	}
	public void setWeightUnit(String weightUnit) {
		this.weightUnit = weightUnit;
	}
	public double getWidth() {
		return this.width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public String getWidthUnit() {
		return this.widthUnit;
	}
	public void setWidthUnit(String widthUnit) {
		this.widthUnit = widthUnit;
	}
	public List<CableCbAssocSpecDto> getCableCbAssocSpecs() {
		return this.cableCbAssocSpecs;
	}
	public void setCableCbAssocSpecs(List<CableCbAssocSpecDto> cableCbAssocSpecs) {
		this.cableCbAssocSpecs = cableCbAssocSpecs;
	}
	public CableCbAssocSpecDto addCableCbAssocSpec(CableCbAssocSpecDto cableCbAssocSpec) {
		getCableCbAssocSpecs().add(cableCbAssocSpec);
		cableCbAssocSpec.setCableSpec(this);
		return cableCbAssocSpec;
	}
	public CableCbAssocSpecDto removeCableCbAssocSpec(CableCbAssocSpecDto cableCbAssocSpec) {
		getCableCbAssocSpecs().remove(cableCbAssocSpec);
		cableCbAssocSpec.setCableSpec(null);
		return cableCbAssocSpec;
	}
	public List<CableCharSpecRelDto> getCableCharSpecRels() {
		return this.cableCharSpecRels;
	}
	public void setCableCharSpecRels(List<CableCharSpecRelDto> cableCharSpecRels) {
		this.cableCharSpecRels = cableCharSpecRels;
	}
	public CableCharSpecRelDto addCableCharSpecRel(CableCharSpecRelDto cableCharSpecRel) {
		getCableCharSpecRels().add(cableCharSpecRel);
		cableCharSpecRel.setCableSpec(this);
		return cableCharSpecRel;
	}
	public CableCharSpecRelDto removeCableCharSpecRel(CableCharSpecRelDto cableCharSpecRel) {
		getCableCharSpecRels().remove(cableCharSpecRel);
		cableCharSpecRel.setCableSpec(null);
		return cableCharSpecRel;
	}
	public List<CableCondAssocSpecDto> getCableCondAssocSpecs() {
		return this.cableCondAssocSpecs;
	}
	public void setCableCondAssocSpecs(List<CableCondAssocSpecDto> cableCondAssocSpecs) {
		this.cableCondAssocSpecs = cableCondAssocSpecs;
	}
	public CableCondAssocSpecDto addCableCondAssocSpec(CableCondAssocSpecDto cableCondAssocSpec) {
		getCableCondAssocSpecs().add(cableCondAssocSpec);
		cableCondAssocSpec.setCableSpec(this);
		return cableCondAssocSpec;
	}
	public CableCondAssocSpecDto removeCableCondAssocSpec(CableCondAssocSpecDto cableCondAssocSpec) {
		getCableCondAssocSpecs().remove(cableCondAssocSpec);
		cableCondAssocSpec.setCableSpec(null);
		return cableCondAssocSpec;
	}
	public List<CableHierarchySpecDto> getCableHierarchySpecs() {
		return this.cableHierarchySpecs;
	}
	public void setCableHierarchySpecs(List<CableHierarchySpecDto> cableHierarchySpecs) {
		this.cableHierarchySpecs = cableHierarchySpecs;
	}
	public CableHierarchySpecDto addCableHierarchySpec(CableHierarchySpecDto cableHierarchySpec) {
		getCableHierarchySpecs().add(cableHierarchySpec);
		cableHierarchySpec.setCableSpec(this);
		return cableHierarchySpec;
	}
	public CableHierarchySpecDto removeCableHierarchySpec(CableHierarchySpecDto cableHierarchySpec) {
		getCableHierarchySpecs().remove(cableHierarchySpec);
		cableHierarchySpec.setCableSpec(null);
		return cableHierarchySpec;
	}
	public List<CableSelfAssocSpecDto> getCableSelfAssocSpecs1() {
		return this.cableSelfAssocSpecs1;
	}
	public void setCableSelfAssocSpecs1(List<CableSelfAssocSpecDto> cableSelfAssocSpecs1) {
		this.cableSelfAssocSpecs1 = cableSelfAssocSpecs1;
	}
	public CableSelfAssocSpecDto addCableSelfAssocSpecs1(CableSelfAssocSpecDto cableSelfAssocSpecs1) {
		getCableSelfAssocSpecs1().add(cableSelfAssocSpecs1);
		cableSelfAssocSpecs1.setCableSpec1(this);
		return cableSelfAssocSpecs1;
	}
	public CableSelfAssocSpecDto removeCableSelfAssocSpecs1(CableSelfAssocSpecDto cableSelfAssocSpecs1) {
		getCableSelfAssocSpecs1().remove(cableSelfAssocSpecs1);
		cableSelfAssocSpecs1.setCableSpec1(null);
		return cableSelfAssocSpecs1;
	}
	public List<CableSelfAssocSpecDto> getCableSelfAssocSpecs2() {
		return this.cableSelfAssocSpecs2;
	}
	public void setCableSelfAssocSpecs2(List<CableSelfAssocSpecDto> cableSelfAssocSpecs2) {
		this.cableSelfAssocSpecs2 = cableSelfAssocSpecs2;
	}
	public CableSelfAssocSpecDto addCableSelfAssocSpecs2(CableSelfAssocSpecDto cableSelfAssocSpecs2) {
		getCableSelfAssocSpecs2().add(cableSelfAssocSpecs2);
		cableSelfAssocSpecs2.setCableSpec2(this);
		return cableSelfAssocSpecs2;
	}
	public CableSelfAssocSpecDto removeCableSelfAssocSpecs2(CableSelfAssocSpecDto cableSelfAssocSpecs2) {
		getCableSelfAssocSpecs2().remove(cableSelfAssocSpecs2);
		cableSelfAssocSpecs2.setCableSpec2(null);
		return cableSelfAssocSpecs2;
	}
	public List<CableSpanCompatSpecDto> getCableSpanCompatSpecs() {
		return this.cableSpanCompatSpecs;
	}
	public void setCableSpanCompatSpecs(List<CableSpanCompatSpecDto> cableSpanCompatSpecs) {
		this.cableSpanCompatSpecs = cableSpanCompatSpecs;
	}
	public CableSpanCompatSpecDto addCableSpanCompatSpec(CableSpanCompatSpecDto cableSpanCompatSpec) {
		getCableSpanCompatSpecs().add(cableSpanCompatSpec);
		cableSpanCompatSpec.setCableSpec(this);
		return cableSpanCompatSpec;
	}
	public CableSpanCompatSpecDto removeCableSpanCompatSpec(CableSpanCompatSpecDto cableSpanCompatSpec) {
		getCableSpanCompatSpecs().remove(cableSpanCompatSpec);
		cableSpanCompatSpec.setCableSpec(null);
		return cableSpanCompatSpec;
	}
	public EntityDto getEntity() {
		return this.entity;
	}
	public void setEntity(EntityDto entity) {
		this.entity = entity;
	}
	public ManufacturerDto getManufacturer() {
		return this.manufacturer;
	}
	public void setManufacturer(ManufacturerDto manufacturer) {
		this.manufacturer = manufacturer;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
	public List<CableSpecCharSpecDto> getCableSpecCharSpecs() {
		return this.cableSpecCharSpecs;
	}
	public void setCableSpecCharSpecs(List<CableSpecCharSpecDto> cableSpecCharSpecs) {
		this.cableSpecCharSpecs = cableSpecCharSpecs;
	}
	public CableSpecCharSpecDto addCableSpecCharSpec(CableSpecCharSpecDto cableSpecCharSpec) {
		getCableSpecCharSpecs().add(cableSpecCharSpec);
		cableSpecCharSpec.setCableSpec(this);
		return cableSpecCharSpec;
	}
	public CableSpecCharSpecDto removeCableSpecCharSpec(CableSpecCharSpecDto cableSpecCharSpec) {
		getCableSpecCharSpecs().remove(cableSpecCharSpec);
		cableSpecCharSpec.setCableSpec(null);
		return cableSpecCharSpec;
	}
	public List<CableSpecCharValueSpecDto> getCableSpecCharValueSpecs() {
		return this.cableSpecCharValueSpecs;
	}
	public void setCableSpecCharValueSpecs(List<CableSpecCharValueSpecDto> cableSpecCharValueSpecs) {
		this.cableSpecCharValueSpecs = cableSpecCharValueSpecs;
	}
	public CableSpecCharValueSpecDto addCableSpecCharValueSpec(CableSpecCharValueSpecDto cableSpecCharValueSpec) {
		getCableSpecCharValueSpecs().add(cableSpecCharValueSpec);
		cableSpecCharValueSpec.setCableSpec(this);
		return cableSpecCharValueSpec;
	}
	public CableSpecCharValueSpecDto removeCableSpecCharValueSpec(CableSpecCharValueSpecDto cableSpecCharValueSpec) {
		getCableSpecCharValueSpecs().remove(cableSpecCharValueSpec);
		cableSpecCharValueSpec.setCableSpec(null);
		return cableSpecCharValueSpec;
	}
	public List<DeviceCableCompatSpecDto> getDeviceCableCompatSpecs() {
		return this.deviceCableCompatSpecs;
	}
	public void setDeviceCableCompatSpecs(List<DeviceCableCompatSpecDto> deviceCableCompatSpecs) {
		this.deviceCableCompatSpecs = deviceCableCompatSpecs;
	}
	public DeviceCableCompatSpecDto addDeviceCableCompatSpec(DeviceCableCompatSpecDto deviceCableCompatSpec) {
		getDeviceCableCompatSpecs().add(deviceCableCompatSpec);
		deviceCableCompatSpec.setCableSpec(this);
		return deviceCableCompatSpec;
	}
	public DeviceCableCompatSpecDto removeDeviceCableCompatSpec(DeviceCableCompatSpecDto deviceCableCompatSpec) {
		getDeviceCableCompatSpecs().remove(deviceCableCompatSpec);
		deviceCableCompatSpec.setCableSpec(null);
		return deviceCableCompatSpec;
	}
	public List<EqCableCompatSpecDto> getEqCableCompatSpecs() {
		return this.eqCableCompatSpecs;
	}
	public void setEqCableCompatSpecs(List<EqCableCompatSpecDto> eqCableCompatSpecs) {
		this.eqCableCompatSpecs = eqCableCompatSpecs;
	}
	public EqCableCompatSpecDto addEqCableCompatSpec(EqCableCompatSpecDto eqCableCompatSpec) {
		getEqCableCompatSpecs().add(eqCableCompatSpec);
		eqCableCompatSpec.setCableSpec(this);
		return eqCableCompatSpec;
	}
	public EqCableCompatSpecDto removeEqCableCompatSpec(EqCableCompatSpecDto eqCableCompatSpec) {
		getEqCableCompatSpecs().remove(eqCableCompatSpec);
		eqCableCompatSpec.setCableSpec(null);
		return eqCableCompatSpec;
	}
}
