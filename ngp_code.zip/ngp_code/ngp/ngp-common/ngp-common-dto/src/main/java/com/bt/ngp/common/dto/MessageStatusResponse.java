package com.bt.ngp.common.dto;

public class MessageStatusResponse {
	String message;
	
	public MessageStatusResponse(){
	}
	
	public MessageStatusResponse(String msg){
		message = msg;
	}
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
