package com.bt.ngp.dto;

import java.sql.Timestamp;
/**
 * The persistent class for the CCP_PORT_PORT_ASSOC database table.
 * 
 */

public class CcpPortPortAssocDto  {
	private long id;
	private String ccpName;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String sourcePortSeqNo;
	private String targetPortSeqNo;
	
	private CcpPortDto ccpPort1;
	
	private CcpPortDto ccpPort2;
	
	private ChassiDto chassi1;
	
	private ChassiDto chassi2;
	
	private EqPortPortAssocSpecDto eqPortPortAssocSpec;
	
	private PluginDto plugin1;
	
	private PluginDto plugin2;
	public CcpPortPortAssocDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCcpName() {
		return this.ccpName;
	}
	public void setCcpName(String ccpName) {
		this.ccpName = ccpName;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getSourcePortSeqNo() {
		return this.sourcePortSeqNo;
	}
	public void setSourcePortSeqNo(String sourcePortSeqNo) {
		this.sourcePortSeqNo = sourcePortSeqNo;
	}
	public String getTargetPortSeqNo() {
		return this.targetPortSeqNo;
	}
	public void setTargetPortSeqNo(String targetPortSeqNo) {
		this.targetPortSeqNo = targetPortSeqNo;
	}
	public CcpPortDto getCcpPort1() {
		return this.ccpPort1;
	}
	public void setCcpPort1(CcpPortDto ccpPort1) {
		this.ccpPort1 = ccpPort1;
	}
	public CcpPortDto getCcpPort2() {
		return this.ccpPort2;
	}
	public void setCcpPort2(CcpPortDto ccpPort2) {
		this.ccpPort2 = ccpPort2;
	}
	public ChassiDto getChassi1() {
		return this.chassi1;
	}
	public void setChassi1(ChassiDto chassi1) {
		this.chassi1 = chassi1;
	}
	public ChassiDto getChassi2() {
		return this.chassi2;
	}
	public void setChassi2(ChassiDto chassi2) {
		this.chassi2 = chassi2;
	}
	public EqPortPortAssocSpecDto getEqPortPortAssocSpec() {
		return this.eqPortPortAssocSpec;
	}
	public void setEqPortPortAssocSpec(EqPortPortAssocSpecDto eqPortPortAssocSpec) {
		this.eqPortPortAssocSpec = eqPortPortAssocSpec;
	}
	public PluginDto getPlugin1() {
		return this.plugin1;
	}
	public void setPlugin1(PluginDto plugin1) {
		this.plugin1 = plugin1;
	}
	public PluginDto getPlugin2() {
		return this.plugin2;
	}
	public void setPlugin2(PluginDto plugin2) {
		this.plugin2 = plugin2;
	}
}
