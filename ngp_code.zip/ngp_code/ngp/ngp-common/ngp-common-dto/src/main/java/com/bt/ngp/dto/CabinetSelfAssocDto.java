package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the CABINET_SELF_ASSOC database table.
 * 
 */

public class CabinetSelfAssocDto  {
	private long id;
	private String childCabinetName;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String parentCabinetName;
	
	private CabinetSelfAssocSpecDto cabinetSelfAssocSpec;
	public CabinetSelfAssocDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getChildCabinetName() {
		return this.childCabinetName;
	}
	public void setChildCabinetName(String childCabinetName) {
		this.childCabinetName = childCabinetName;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getParentCabinetName() {
		return this.parentCabinetName;
	}
	public void setParentCabinetName(String parentCabinetName) {
		this.parentCabinetName = parentCabinetName;
	}
	public CabinetSelfAssocSpecDto getCabinetSelfAssocSpec() {
		return this.cabinetSelfAssocSpec;
	}
	public void setCabinetSelfAssocSpec(CabinetSelfAssocSpecDto cabinetSelfAssocSpec) {
		this.cabinetSelfAssocSpec = cabinetSelfAssocSpec;
	}
}
