package com.bt.ngp.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CABLE_SPEC_CHAR_SPEC database table.
 * 
 */

public class CableSpecCharSpecDto  {
	private long id;
	private String canBeOverriden;
	private String createdBy;
	private Timestamp createdDate;
	private String description;
	private String isUniqueWhenPresent;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String maxCardinality;
	private String minCardinality;
	private String name;
	private String remarks;
	private Timestamp validFrom;
	private Timestamp validTo;
	private String valueType;
	
	private List<CableCharSpecRelDto> cableCharSpecRels1;
	
	private List<CableCharSpecRelDto> cableCharSpecRels2;
	
	private List<CableSectionCharDto> cableSectionChars;
	
		
	private CableSpecDto cableSpec;
	
	private CableSpecCharValueSpecDto cableSpecCharValueSpec;
	
	private EntityDto entity;
	
	private EntityCharCategoryDto entityCharCategory;
	
	private EntityCharSpecDto entityCharSpec;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	public CableSpecCharSpecDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCanBeOverriden() {
		return this.canBeOverriden;
	}
	public void setCanBeOverriden(String canBeOverriden) {
		this.canBeOverriden = canBeOverriden;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDescription() {
		return this.description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIsUniqueWhenPresent() {
		return this.isUniqueWhenPresent;
	}
	public void setIsUniqueWhenPresent(String isUniqueWhenPresent) {
		this.isUniqueWhenPresent = isUniqueWhenPresent;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getMaxCardinality() {
		return this.maxCardinality;
	}
	public void setMaxCardinality(String maxCardinality) {
		this.maxCardinality = maxCardinality;
	}
	public String getMinCardinality() {
		return this.minCardinality;
	}
	public void setMinCardinality(String minCardinality) {
		this.minCardinality = minCardinality;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRemarks() {
		return this.remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Timestamp getValidFrom() {
		return this.validFrom;
	}
	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}
	public Timestamp getValidTo() {
		return this.validTo;
	}
	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}
	public String getValueType() {
		return this.valueType;
	}
	public void setValueType(String valueType) {
		this.valueType = valueType;
	}
	public List<CableCharSpecRelDto> getCableCharSpecRels1() {
		return this.cableCharSpecRels1;
	}
	public void setCableCharSpecRels1(List<CableCharSpecRelDto> cableCharSpecRels1) {
		this.cableCharSpecRels1 = cableCharSpecRels1;
	}
	public CableCharSpecRelDto addCableCharSpecRels1(CableCharSpecRelDto cableCharSpecRels1) {
		getCableCharSpecRels1().add(cableCharSpecRels1);
		cableCharSpecRels1.setCableSpecCharSpec1(this);
		return cableCharSpecRels1;
	}
	public CableCharSpecRelDto removeCableCharSpecRels1(CableCharSpecRelDto cableCharSpecRels1) {
		getCableCharSpecRels1().remove(cableCharSpecRels1);
		cableCharSpecRels1.setCableSpecCharSpec1(null);
		return cableCharSpecRels1;
	}
	public List<CableCharSpecRelDto> getCableCharSpecRels2() {
		return this.cableCharSpecRels2;
	}
	public void setCableCharSpecRels2(List<CableCharSpecRelDto> cableCharSpecRels2) {
		this.cableCharSpecRels2 = cableCharSpecRels2;
	}
	public CableCharSpecRelDto addCableCharSpecRels2(CableCharSpecRelDto cableCharSpecRels2) {
		getCableCharSpecRels2().add(cableCharSpecRels2);
		cableCharSpecRels2.setCableSpecCharSpec2(this);
		return cableCharSpecRels2;
	}
	public CableCharSpecRelDto removeCableCharSpecRels2(CableCharSpecRelDto cableCharSpecRels2) {
		getCableCharSpecRels2().remove(cableCharSpecRels2);
		cableCharSpecRels2.setCableSpecCharSpec2(null);
		return cableCharSpecRels2;
	}
	public List<CableSectionCharDto> getCableSectionChars() {
		return this.cableSectionChars;
	}
	public void setCableSectionChars(List<CableSectionCharDto> cableSectionChars) {
		this.cableSectionChars = cableSectionChars;
	}
	public CableSectionCharDto addCableSectionChar(CableSectionCharDto cableSectionChar) {
		getCableSectionChars().add(cableSectionChar);
		cableSectionChar.setCableSpecCharSpec(this);
		return cableSectionChar;
	}
	public CableSectionCharDto removeCableSectionChar(CableSectionCharDto cableSectionChar) {
		getCableSectionChars().remove(cableSectionChar);
		cableSectionChar.setCableSpecCharSpec(null);
		return cableSectionChar;
	}
	public CableSpecDto getCableSpec() {
		return this.cableSpec;
	}
	public void setCableSpec(CableSpecDto cableSpec) {
		this.cableSpec = cableSpec;
	}
	public CableSpecCharValueSpecDto getCableSpecCharValueSpec() {
		return this.cableSpecCharValueSpec;
	}
	public void setCableSpecCharValueSpec(CableSpecCharValueSpecDto cableSpecCharValueSpec) {
		this.cableSpecCharValueSpec = cableSpecCharValueSpec;
	}
	public EntityDto getEntity() {
		return this.entity;
	}
	public void setEntity(EntityDto entity) {
		this.entity = entity;
	}
	public EntityCharCategoryDto getEntityCharCategory() {
		return this.entityCharCategory;
	}
	public void setEntityCharCategory(EntityCharCategoryDto entityCharCategory) {
		this.entityCharCategory = entityCharCategory;
	}
	public EntityCharSpecDto getEntityCharSpec() {
		return this.entityCharSpec;
	}
	public void setEntityCharSpec(EntityCharSpecDto entityCharSpec) {
		this.entityCharSpec = entityCharSpec;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
}
