package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the CB_SELF_ASSOC database table.
 * 
 */

public class CbSelfAssocDto  {
	private long id;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	
	private CbSelfAssocSpecDto cbSelfAssocSpec;
	
	private ConductorBundleDto conductorBundle1;
	
	private ConductorBundleDto conductorBundle2;
	public CbSelfAssocDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public CbSelfAssocSpecDto getCbSelfAssocSpec() {
		return this.cbSelfAssocSpec;
	}
	public void setCbSelfAssocSpec(CbSelfAssocSpecDto cbSelfAssocSpec) {
		this.cbSelfAssocSpec = cbSelfAssocSpec;
	}
	public ConductorBundleDto getConductorBundle1() {
		return this.conductorBundle1;
	}
	public void setConductorBundle1(ConductorBundleDto conductorBundle1) {
		this.conductorBundle1 = conductorBundle1;
	}
	public ConductorBundleDto getConductorBundle2() {
		return this.conductorBundle2;
	}
	public void setConductorBundle2(ConductorBundleDto conductorBundle2) {
		this.conductorBundle2 = conductorBundle2;
	}
}
