package com.bt.ngp.common.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class EntityDetailsDto {
	
	private String id;
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	@Valid
	@NotNull
	@Size (min=1)
	private String name;
	@Valid
	@NotNull
	@Size (min=1)
	String specName;
	@Valid
	@NotNull
	@Size (min=1)
	String specTypeName;
	@Valid
	@NotNull
	@Size (min=1)
	String specCategoryName;	
	String resourceState;
	
	private String userLabel;


	/**
	 * Returns the field id.
	 *
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * Sets the field id.
	 *
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Returns the field name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the field name.
	 *
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	public String getSpecName() {
		return specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecCategoryName() {
		return specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getResourceState() {
		return resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}
	
	public String getUserLabel() {
		return userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

}
