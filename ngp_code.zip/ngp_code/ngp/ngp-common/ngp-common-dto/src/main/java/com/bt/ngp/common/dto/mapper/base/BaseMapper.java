/*package com.bt.ngp.common.dto.mapper.base;

import fr.xebia.extras.selma.Mapper;

//@MapperConfig(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.WARN, implementationName = "<CLASS_NAME>MapStructImpl", implementationPackage = "<PACKAGE_NAME>.impl", collectionMappingStrategy = CollectionMappingStrategy.ACCESSOR_ONLY, mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_FROM_CONFIG, disableSubMappingMethodsGeneration = true)
@Mapper(withFactories = { ModelFactory.class })
public interface BaseMapper {
   
}
*/