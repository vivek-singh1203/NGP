/*package com.bt.ngp.common.dto.generator;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.core.type.filter.RegexPatternTypeFilter;

import com.bt.ngp.common.dto.generator.context.MapperCtx;
import com.bt.platform.domain.model.graph.annotation.SchemaClass;

public class MapStructMapperGenerator {

    private static final String OUTPUT_DIR = "./target/generated-source-mapper/";
    private static final String CLASS_NAME_PREFIX = "";
    private static final String CLASS_NAME_SUFFIX = "Mapper";
    private static final String IN_PACKAGE_NAME = "com.bt.srims.shared.inventory.model";
    private static final String OUT_PACKAGE_NAME = "com.bt.ngp.common.dto.mapper.inventory";
    private static final String TEMPLATE = "mustache-template/mapstruct-mapper-pojo.mustache";

    public static void main(String[] args) throws IntrospectionException, ClassNotFoundException {

        ClassPathScanner provider = new ClassPathScanner();
        provider.addIncludeFilter(new RegexPatternTypeFilter(Pattern.compile(".*")));
        final Set<BeanDefinition> classes = provider.findCandidateComponents(IN_PACKAGE_NAME);

        for (BeanDefinition bean : classes) {
            MapperCtx mapperCtx = new MapperCtx();

            Class<?> clazz = Class.forName(bean.getBeanClassName());
            SchemaClass schemaClass = clazz.getAnnotation(SchemaClass.class);
            if (schemaClass != null) {
                - if (schemaClass.isAbstract()) {
                     continue;
                 }
                List<String> imports = new ArrayList<>();
                imports.add("java.util.ArrayList");
                imports.add("java.util.List");
                imports.add("java.util.HashSet");
                imports.add("java.util.Set");
                imports.add("java.util.Collection");

                mapperCtx.setImports(imports);
                mapperCtx.setClassName(clazz.getSimpleName());
                mapperCtx.setClassNamePrefix(CLASS_NAME_PREFIX);
                mapperCtx.setClassNameSuffix(CLASS_NAME_SUFFIX);
                String packageName = clazz.getPackage().getName().replace(IN_PACKAGE_NAME, OUT_PACKAGE_NAME);
                mapperCtx.setPackageName(packageName);
                mapperCtx.setSuperClass(Arrays.asList(clazz.getInterfaces()).stream().filter(iface -> {
                    SchemaClass sClazz = iface.getAnnotation(SchemaClass.class);
                    return sClazz != null  && !sClazz.isAbstract() ;
                }).map(iface -> iface.getSimpleName() + "Mapper").collect(Collectors.joining(",")));
                mapperCtx.setInterfaces("BaseMapper");
                mapperCtx.setSourceType(clazz.getName());
                mapperCtx.setTargetType(clazz.getPackage().getName()
                                .replace(IN_PACKAGE_NAME, OUT_PACKAGE_NAME.replace("mapper.", ""))
                                + "." + mapperCtx.getClassName() + "Dto");

                Set<String> dependencyMappers = new HashSet<>();
                dependencyMappers.add("ModelFactory.class");
                getDependencyMappers(clazz, dependencyMappers);
                mapperCtx.setDependencyMappers(dependencyMappers.stream().collect(Collectors.joining(",")));

                System.out.println("Generating Mapper for " + packageName + "." + mapperCtx.getClassName());
                MustacheUtil.generatePojo(OUTPUT_DIR + packageName.replace(".", "/") + "/", TEMPLATE, mapperCtx);
            }
        }
    }

    private static Set<String> getDependencyMappers(Class<?> clazz, Set<String> dependencyMappers)
                    throws IntrospectionException {
        if (clazz != null && clazz.getSuperclass() != null) {
            SchemaClass schemaClass = clazz.getSuperclass().getAnnotation(SchemaClass.class);
            if (schemaClass != null  && !schemaClass.isAbstract() ) {
                getDependencyMappers(clazz.getSuperclass(), dependencyMappers);
            }
        }
        BeanInfo beanInfo = Introspector.getBeanInfo(clazz);
        for (PropertyDescriptor desc : beanInfo.getPropertyDescriptors()) {
            Type returnType = desc.getReadMethod().getGenericReturnType();
            String returnTypeStr = returnType.getTypeName();
            if (returnType instanceof ParameterizedType) {
                ParameterizedType parameterizedReturnType = (ParameterizedType) returnType;
                for (Type type : parameterizedReturnType.getActualTypeArguments()) {
                    if (!((Class<?>) type).isEnum() && returnTypeStr.contains(type.getTypeName())
                                    && type.getTypeName().contains(IN_PACKAGE_NAME)) {
                        SchemaClass schemaClass = ((Class<?>) type).getAnnotation(SchemaClass.class);
                        if (schemaClass != null  && !schemaClass.isAbstract() ) {
                            // getDependencyMappers((Class<?>) type, dependencyMappers);
                            dependencyMappers.add(((Class) type).getSimpleName() + "Mapper.class");
                        }

                    }
                }
            } else {
                if (!((Class<?>) returnType).isEnum() && returnTypeStr.contains(returnType.getTypeName())
                                && returnType.getTypeName().contains(IN_PACKAGE_NAME)) {
                    SchemaClass schemaClass = ((Class<?>) returnType).getAnnotation(SchemaClass.class);
                    if (schemaClass != null  && !schemaClass.isAbstract() ) {
                        // getDependencyMappers((Class<?>) returnType, dependencyMappers);
                        dependencyMappers.add(((Class) returnType).getSimpleName() + "Mapper.class");
                    }

                }
            }
        }

        return dependencyMappers;
    }
}
*/