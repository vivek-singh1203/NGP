package com.bt.ngp.dto;
/**
 * The primary key class for the CABLE_SPEC database table.
 * 
 */
public class CableSpecPKDto  {

	private String name;
	private String specVersion;
	public CableSpecPKDto() {
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSpecVersion() {
		return this.specVersion;
	}
	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof CableSpecPKDto)) {
			return false;
		}
		CableSpecPKDto castOther = (CableSpecPKDto)other;
		return 
			this.name.equals(castOther.name)
			&& this.specVersion.equals(castOther.specVersion);
	}
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.name.hashCode();
		hash = hash * prime + this.specVersion.hashCode();
		return hash;
	}
}
