package com.bt.ngp.dto;
import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CARD_HOLDERS database table.
 * 
 */

public class CardHolderDto  {
	private String name;
	private String alternateName;
	private String assetIdentifier;
	private String createdBy;
	private Timestamp createdDate;
	private String dataQualityIndicator;
	private String dslamName;
	private String faultState;
	private long id;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String resource1141Code;
	private String resourceState;
	private String serialNumber;
	private String serviceState;
	private String userLabel;
	
	private List<CardDto> cards;
	
		
	private HolderSpecDto holderSpec;
	
	private RackDto rack;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	
	private List<CardHolderCharDto> cardHolderChars;
	
	private List<DslamChCardAssocDto> dslamChCardAssocs;
	
	private List<DslamRackChAssocDto> dslamRackChAssocs;
	public CardHolderDto() {
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAlternateName() {
		return this.alternateName;
	}
	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}
	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}
	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}
	public String getDslamName() {
		return this.dslamName;
	}
	public void setDslamName(String dslamName) {
		this.dslamName = dslamName;
	}
	public String getFaultState() {
		return this.faultState;
	}
	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getResource1141Code() {
		return this.resource1141Code;
	}
	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}
	public String getResourceState() {
		return this.resourceState;
	}
	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}
	public String getSerialNumber() {
		return this.serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getServiceState() {
		return this.serviceState;
	}
	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}
	public String getUserLabel() {
		return this.userLabel;
	}
	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}
	public List<CardDto> getCards() {
		return this.cards;
	}
	public void setCards(List<CardDto> cards) {
		this.cards = cards;
	}
	public CardDto addCard(CardDto card) {
		getCards().add(card);
		card.setCardHolder(this);
		return card;
	}
	public CardDto removeCard(CardDto card) {
		getCards().remove(card);
		card.setCardHolder(null);
		return card;
	}
	public HolderSpecDto getHolderSpec() {
		return this.holderSpec;
	}
	public void setHolderSpec(HolderSpecDto holderSpec) {
		this.holderSpec = holderSpec;
	}
	public RackDto getRack() {
		return this.rack;
	}
	public void setRack(RackDto rack) {
		this.rack = rack;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
	public List<CardHolderCharDto> getCardHolderChars() {
		return this.cardHolderChars;
	}
	public void setCardHolderChars(List<CardHolderCharDto> cardHolderChars) {
		this.cardHolderChars = cardHolderChars;
	}
	public CardHolderCharDto addCardHolderChar(CardHolderCharDto cardHolderChar) {
		getCardHolderChars().add(cardHolderChar);
		cardHolderChar.setCardHolder(this);
		return cardHolderChar;
	}
	public CardHolderCharDto removeCardHolderChar(CardHolderCharDto cardHolderChar) {
		getCardHolderChars().remove(cardHolderChar);
		cardHolderChar.setCardHolder(null);
		return cardHolderChar;
	}
	public List<DslamChCardAssocDto> getDslamChCardAssocs() {
		return this.dslamChCardAssocs;
	}
	public void setDslamChCardAssocs(List<DslamChCardAssocDto> dslamChCardAssocs) {
		this.dslamChCardAssocs = dslamChCardAssocs;
	}
	public DslamChCardAssocDto addDslamChCardAssoc(DslamChCardAssocDto dslamChCardAssoc) {
		getDslamChCardAssocs().add(dslamChCardAssoc);
		dslamChCardAssoc.setCardHolder(this);
		return dslamChCardAssoc;
	}
	public DslamChCardAssocDto removeDslamChCardAssoc(DslamChCardAssocDto dslamChCardAssoc) {
		getDslamChCardAssocs().remove(dslamChCardAssoc);
		dslamChCardAssoc.setCardHolder(null);
		return dslamChCardAssoc;
	}
	public List<DslamRackChAssocDto> getDslamRackChAssocs() {
		return this.dslamRackChAssocs;
	}
	public void setDslamRackChAssocs(List<DslamRackChAssocDto> dslamRackChAssocs) {
		this.dslamRackChAssocs = dslamRackChAssocs;
	}
	public DslamRackChAssocDto addDslamRackChAssoc(DslamRackChAssocDto dslamRackChAssoc) {
		getDslamRackChAssocs().add(dslamRackChAssoc);
		dslamRackChAssoc.setCardHolder(this);
		return dslamRackChAssoc;
	}
	public DslamRackChAssocDto removeDslamRackChAssoc(DslamRackChAssocDto dslamRackChAssoc) {
		getDslamRackChAssocs().remove(dslamRackChAssoc);
		dslamRackChAssoc.setCardHolder(null);
		return dslamRackChAssoc;
	}
}
