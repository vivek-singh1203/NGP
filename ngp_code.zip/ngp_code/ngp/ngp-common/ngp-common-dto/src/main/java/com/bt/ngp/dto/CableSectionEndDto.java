package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the CABLE_SECTION_ENDS database table.
 * 
 */

public class CableSectionEndDto  {
	private String connectionState;
	private String createdBy;
	private Timestamp createdDate;
	private String csName;
	private String dataQualityIndicator;
	private String exchange1141Code;
	private long id;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String origEndEntityName;
	private String origEndName;
	private String termEndEntityName;
	private String termEndName;
	public CableSectionEndDto() {
	}
	public String getConnectionState() {
		return this.connectionState;
	}
	public void setConnectionState(String connectionState) {
		this.connectionState = connectionState;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getCsName() {
		return this.csName;
	}
	public void setCsName(String csName) {
		this.csName = csName;
	}
	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}
	public String getExchange1141Code() {
		return this.exchange1141Code;
	}
	public void setExchange1141Code(String exchange1141Code) {
		this.exchange1141Code = exchange1141Code;
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getOrigEndEntityName() {
		return this.origEndEntityName;
	}
	public void setOrigEndEntityName(String origEndEntityName) {
		this.origEndEntityName = origEndEntityName;
	}
	public String getOrigEndName() {
		return this.origEndName;
	}
	public void setOrigEndName(String origEndName) {
		this.origEndName = origEndName;
	}
	public String getTermEndEntityName() {
		return this.termEndEntityName;
	}
	public void setTermEndEntityName(String termEndEntityName) {
		this.termEndEntityName = termEndEntityName;
	}
	public String getTermEndName() {
		return this.termEndName;
	}
	public void setTermEndName(String termEndName) {
		this.termEndName = termEndName;
	}
}
