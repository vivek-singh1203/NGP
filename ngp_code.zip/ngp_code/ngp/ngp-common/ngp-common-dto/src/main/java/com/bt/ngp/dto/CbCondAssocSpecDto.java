package com.bt.ngp.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CB_COND_ASSOC_SPEC database table.
 * 
 */

public class CbCondAssocSpecDto  {
	private long id;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String noOfCondSpecInstances;
	
	private List<CableHierarchySpecDto> cableHierarchySpecs;
	
		
	private CbSpecDto cbSpec;
	
		
	private ConductorSpecDto conductorSpec;
	
	private EntityDto entity1;
	
	private EntityDto entity2;
	
	private SpecCategoryDto specCategory1;
	
	private SpecCategoryDto specCategory2;
	
	private SpecTypeDto specType1;
	
	private SpecTypeDto specType2;
	public CbCondAssocSpecDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getNoOfCondSpecInstances() {
		return this.noOfCondSpecInstances;
	}
	public void setNoOfCondSpecInstances(String noOfCondSpecInstances) {
		this.noOfCondSpecInstances = noOfCondSpecInstances;
	}
	public List<CableHierarchySpecDto> getCableHierarchySpecs() {
		return this.cableHierarchySpecs;
	}
	public void setCableHierarchySpecs(List<CableHierarchySpecDto> cableHierarchySpecs) {
		this.cableHierarchySpecs = cableHierarchySpecs;
	}
	public CableHierarchySpecDto addCableHierarchySpec(CableHierarchySpecDto cableHierarchySpec) {
		getCableHierarchySpecs().add(cableHierarchySpec);
		cableHierarchySpec.setCbCondAssocSpec(this);
		return cableHierarchySpec;
	}
	public CableHierarchySpecDto removeCableHierarchySpec(CableHierarchySpecDto cableHierarchySpec) {
		getCableHierarchySpecs().remove(cableHierarchySpec);
		cableHierarchySpec.setCbCondAssocSpec(null);
		return cableHierarchySpec;
	}
	public CbSpecDto getCbSpec() {
		return this.cbSpec;
	}
	public void setCbSpec(CbSpecDto cbSpec) {
		this.cbSpec = cbSpec;
	}
	public ConductorSpecDto getConductorSpec() {
		return this.conductorSpec;
	}
	public void setConductorSpec(ConductorSpecDto conductorSpec) {
		this.conductorSpec = conductorSpec;
	}
	public EntityDto getEntity1() {
		return this.entity1;
	}
	public void setEntity1(EntityDto entity1) {
		this.entity1 = entity1;
	}
	public EntityDto getEntity2() {
		return this.entity2;
	}
	public void setEntity2(EntityDto entity2) {
		this.entity2 = entity2;
	}
	public SpecCategoryDto getSpecCategory1() {
		return this.specCategory1;
	}
	public void setSpecCategory1(SpecCategoryDto specCategory1) {
		this.specCategory1 = specCategory1;
	}
	public SpecCategoryDto getSpecCategory2() {
		return this.specCategory2;
	}
	public void setSpecCategory2(SpecCategoryDto specCategory2) {
		this.specCategory2 = specCategory2;
	}
	public SpecTypeDto getSpecType1() {
		return this.specType1;
	}
	public void setSpecType1(SpecTypeDto specType1) {
		this.specType1 = specType1;
	}
	public SpecTypeDto getSpecType2() {
		return this.specType2;
	}
	public void setSpecType2(SpecTypeDto specType2) {
		this.specType2 = specType2;
	}
}
