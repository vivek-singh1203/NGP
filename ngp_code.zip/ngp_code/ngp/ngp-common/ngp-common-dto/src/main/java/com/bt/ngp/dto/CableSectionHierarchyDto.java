package com.bt.ngp.dto;

import java.sql.Timestamp;
/**
 * The persistent class for the CABLE_SECTION_HIERARCHY database table.
 * 
 */

public class CableSectionHierarchyDto  {
	private long id;
	private String condSeqNum;
	private String createdBy;
	private Timestamp createdDate;
	private String csName;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	
	private CableHierarchySpecDto cableHierarchySpec;
	
	private ConductorDto conductor;
	
	private ConductorBundleDto conductorBundle;
	public CableSectionHierarchyDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCondSeqNum() {
		return this.condSeqNum;
	}
	public void setCondSeqNum(String condSeqNum) {
		this.condSeqNum = condSeqNum;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getCsName() {
		return this.csName;
	}
	public void setCsName(String csName) {
		this.csName = csName;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public CableHierarchySpecDto getCableHierarchySpec() {
		return this.cableHierarchySpec;
	}
	public void setCableHierarchySpec(CableHierarchySpecDto cableHierarchySpec) {
		this.cableHierarchySpec = cableHierarchySpec;
	}
	public ConductorDto getConductor() {
		return this.conductor;
	}
	public void setConductor(ConductorDto conductor) {
		this.conductor = conductor;
	}
	public ConductorBundleDto getConductorBundle() {
		return this.conductorBundle;
	}
	public void setConductorBundle(ConductorBundleDto conductorBundle) {
		this.conductorBundle = conductorBundle;
	}
}
