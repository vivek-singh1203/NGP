package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the BLOCK_SELF_ASSOC database table.
 * 
 */

public class BlockSelfAssocDto  {
	private long id;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	
	private BlockDto block1;
	
	private BlockDto block2;
	
	private BlockSelfAssocSpecDto blockSelfAssocSpec;
	public BlockSelfAssocDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public BlockDto getBlock1() {
		return this.block1;
	}
	public void setBlock1(BlockDto block1) {
		this.block1 = block1;
	}
	public BlockDto getBlock2() {
		return this.block2;
	}
	public void setBlock2(BlockDto block2) {
		this.block2 = block2;
	}
	public BlockSelfAssocSpecDto getBlockSelfAssocSpec() {
		return this.blockSelfAssocSpec;
	}
	public void setBlockSelfAssocSpec(BlockSelfAssocSpecDto blockSelfAssocSpec) {
		this.blockSelfAssocSpec = blockSelfAssocSpec;
	}
}
