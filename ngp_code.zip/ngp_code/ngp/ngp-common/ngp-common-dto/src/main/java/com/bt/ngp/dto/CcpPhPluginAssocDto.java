package com.bt.ngp.dto;
import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CCP_PH_PLUGIN_ASSOC database table.
 * 
 */

public class CcpPhPluginAssocDto  {
	private long id;
	private String ccpName;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	
	private List<CcpHierarchyDto> ccpHierarchies;
	
	private EqHolderCompAssocSpecDto eqHolderCompAssocSpec;
	
	private PluginDto plugin;
	
	private PluginHolderDto pluginHolder;
	public CcpPhPluginAssocDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCcpName() {
		return this.ccpName;
	}
	public void setCcpName(String ccpName) {
		this.ccpName = ccpName;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public List<CcpHierarchyDto> getCcpHierarchies() {
		return this.ccpHierarchies;
	}
	public void setCcpHierarchies(List<CcpHierarchyDto> ccpHierarchies) {
		this.ccpHierarchies = ccpHierarchies;
	}
	public CcpHierarchyDto addCcpHierarchy(CcpHierarchyDto ccpHierarchy) {
		getCcpHierarchies().add(ccpHierarchy);
		ccpHierarchy.setCcpPhPluginAssoc(this);
		return ccpHierarchy;
	}
	public CcpHierarchyDto removeCcpHierarchy(CcpHierarchyDto ccpHierarchy) {
		getCcpHierarchies().remove(ccpHierarchy);
		ccpHierarchy.setCcpPhPluginAssoc(null);
		return ccpHierarchy;
	}
	public EqHolderCompAssocSpecDto getEqHolderCompAssocSpec() {
		return this.eqHolderCompAssocSpec;
	}
	public void setEqHolderCompAssocSpec(EqHolderCompAssocSpecDto eqHolderCompAssocSpec) {
		this.eqHolderCompAssocSpec = eqHolderCompAssocSpec;
	}
	public PluginDto getPlugin() {
		return this.plugin;
	}
	public void setPlugin(PluginDto plugin) {
		this.plugin = plugin;
	}
	public PluginHolderDto getPluginHolder() {
		return this.pluginHolder;
	}
	public void setPluginHolder(PluginHolderDto pluginHolder) {
		this.pluginHolder = pluginHolder;
	}
}
