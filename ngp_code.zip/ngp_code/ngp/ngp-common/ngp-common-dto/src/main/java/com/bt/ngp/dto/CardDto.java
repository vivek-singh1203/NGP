package com.bt.ngp.dto;
import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CARDS database table.
 * 
 */

public class CardDto  {
	private String name;
	private String alternateName;
	private String assetIdentifier;
	private String createdBy;
	private Timestamp createdDate;
	private String dataQualityIndicator;
	private String dslamName;
	private String faultState;
	private long id;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String resource1141Code;
	private String resourceState;
	private String serialNumber;
	private String serviceState;
	private String userLabel;
	
	private CardHolderDto cardHolder;
	
		
	private EqSpecDto eqSpec;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	
	private StoreDto store;
	
	private SupplierDto supplier;
	
	private List<CardCharDto> cardChars;
	
	private List<DslamCardPortAssocDto> dslamCardPortAssocs;
	
	private List<DslamChCardAssocDto> dslamChCardAssocs;
	
	private List<DslamCsPortTermDto> dslamCsPortTerms;
	
	private List<DslamPortDto> dslamPorts;
	
	private List<DslamPortPortAssocDto> dslamPortPortAssocs1;
	
	private List<DslamPortPortAssocDto> dslamPortPortAssocs2;
	public CardDto() {
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAlternateName() {
		return this.alternateName;
	}
	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}
	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}
	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}
	public String getDslamName() {
		return this.dslamName;
	}
	public void setDslamName(String dslamName) {
		this.dslamName = dslamName;
	}
	public String getFaultState() {
		return this.faultState;
	}
	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getResource1141Code() {
		return this.resource1141Code;
	}
	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}
	public String getResourceState() {
		return this.resourceState;
	}
	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}
	public String getSerialNumber() {
		return this.serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getServiceState() {
		return this.serviceState;
	}
	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}
	public String getUserLabel() {
		return this.userLabel;
	}
	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}
	public CardHolderDto getCardHolder() {
		return this.cardHolder;
	}
	public void setCardHolder(CardHolderDto cardHolder) {
		this.cardHolder = cardHolder;
	}
	public EqSpecDto getEqSpec() {
		return this.eqSpec;
	}
	public void setEqSpec(EqSpecDto eqSpec) {
		this.eqSpec = eqSpec;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
	public StoreDto getStore() {
		return this.store;
	}
	public void setStore(StoreDto store) {
		this.store = store;
	}
	public SupplierDto getSupplier() {
		return this.supplier;
	}
	public void setSupplier(SupplierDto supplier) {
		this.supplier = supplier;
	}
	public List<CardCharDto> getCardChars() {
		return this.cardChars;
	}
	public void setCardChars(List<CardCharDto> cardChars) {
		this.cardChars = cardChars;
	}
	public CardCharDto addCardChar(CardCharDto cardChar) {
		getCardChars().add(cardChar);
		cardChar.setCard(this);
		return cardChar;
	}
	public CardCharDto removeCardChar(CardCharDto cardChar) {
		getCardChars().remove(cardChar);
		cardChar.setCard(null);
		return cardChar;
	}
	public List<DslamCardPortAssocDto> getDslamCardPortAssocs() {
		return this.dslamCardPortAssocs;
	}
	public void setDslamCardPortAssocs(List<DslamCardPortAssocDto> dslamCardPortAssocs) {
		this.dslamCardPortAssocs = dslamCardPortAssocs;
	}
	public DslamCardPortAssocDto addDslamCardPortAssoc(DslamCardPortAssocDto dslamCardPortAssoc) {
		getDslamCardPortAssocs().add(dslamCardPortAssoc);
		dslamCardPortAssoc.setCard(this);
		return dslamCardPortAssoc;
	}
	public DslamCardPortAssocDto removeDslamCardPortAssoc(DslamCardPortAssocDto dslamCardPortAssoc) {
		getDslamCardPortAssocs().remove(dslamCardPortAssoc);
		dslamCardPortAssoc.setCard(null);
		return dslamCardPortAssoc;
	}
	public List<DslamChCardAssocDto> getDslamChCardAssocs() {
		return this.dslamChCardAssocs;
	}
	public void setDslamChCardAssocs(List<DslamChCardAssocDto> dslamChCardAssocs) {
		this.dslamChCardAssocs = dslamChCardAssocs;
	}
	public DslamChCardAssocDto addDslamChCardAssoc(DslamChCardAssocDto dslamChCardAssoc) {
		getDslamChCardAssocs().add(dslamChCardAssoc);
		dslamChCardAssoc.setCard(this);
		return dslamChCardAssoc;
	}
	public DslamChCardAssocDto removeDslamChCardAssoc(DslamChCardAssocDto dslamChCardAssoc) {
		getDslamChCardAssocs().remove(dslamChCardAssoc);
		dslamChCardAssoc.setCard(null);
		return dslamChCardAssoc;
	}
	public List<DslamCsPortTermDto> getDslamCsPortTerms() {
		return this.dslamCsPortTerms;
	}
	public void setDslamCsPortTerms(List<DslamCsPortTermDto> dslamCsPortTerms) {
		this.dslamCsPortTerms = dslamCsPortTerms;
	}
	public DslamCsPortTermDto addDslamCsPortTerm(DslamCsPortTermDto dslamCsPortTerm) {
		getDslamCsPortTerms().add(dslamCsPortTerm);
		dslamCsPortTerm.setCard(this);
		return dslamCsPortTerm;
	}
	public DslamCsPortTermDto removeDslamCsPortTerm(DslamCsPortTermDto dslamCsPortTerm) {
		getDslamCsPortTerms().remove(dslamCsPortTerm);
		dslamCsPortTerm.setCard(null);
		return dslamCsPortTerm;
	}
	public List<DslamPortDto> getDslamPorts() {
		return this.dslamPorts;
	}
	public void setDslamPorts(List<DslamPortDto> dslamPorts) {
		this.dslamPorts = dslamPorts;
	}
	public DslamPortDto addDslamPort(DslamPortDto dslamPort) {
		getDslamPorts().add(dslamPort);
		dslamPort.setCard(this);
		return dslamPort;
	}
	public DslamPortDto removeDslamPort(DslamPortDto dslamPort) {
		getDslamPorts().remove(dslamPort);
		dslamPort.setCard(null);
		return dslamPort;
	}
	public List<DslamPortPortAssocDto> getDslamPortPortAssocs1() {
		return this.dslamPortPortAssocs1;
	}
	public void setDslamPortPortAssocs1(List<DslamPortPortAssocDto> dslamPortPortAssocs1) {
		this.dslamPortPortAssocs1 = dslamPortPortAssocs1;
	}
	public DslamPortPortAssocDto addDslamPortPortAssocs1(DslamPortPortAssocDto dslamPortPortAssocs1) {
		getDslamPortPortAssocs1().add(dslamPortPortAssocs1);
		dslamPortPortAssocs1.setCard1(this);
		return dslamPortPortAssocs1;
	}
	public DslamPortPortAssocDto removeDslamPortPortAssocs1(DslamPortPortAssocDto dslamPortPortAssocs1) {
		getDslamPortPortAssocs1().remove(dslamPortPortAssocs1);
		dslamPortPortAssocs1.setCard1(null);
		return dslamPortPortAssocs1;
	}
	public List<DslamPortPortAssocDto> getDslamPortPortAssocs2() {
		return this.dslamPortPortAssocs2;
	}
	public void setDslamPortPortAssocs2(List<DslamPortPortAssocDto> dslamPortPortAssocs2) {
		this.dslamPortPortAssocs2 = dslamPortPortAssocs2;
	}
	public DslamPortPortAssocDto addDslamPortPortAssocs2(DslamPortPortAssocDto dslamPortPortAssocs2) {
		getDslamPortPortAssocs2().add(dslamPortPortAssocs2);
		dslamPortPortAssocs2.setCard2(this);
		return dslamPortPortAssocs2;
	}
	public DslamPortPortAssocDto removeDslamPortPortAssocs2(DslamPortPortAssocDto dslamPortPortAssocs2) {
		getDslamPortPortAssocs2().remove(dslamPortPortAssocs2);
		dslamPortPortAssocs2.setCard2(null);
		return dslamPortPortAssocs2;
	}
}
