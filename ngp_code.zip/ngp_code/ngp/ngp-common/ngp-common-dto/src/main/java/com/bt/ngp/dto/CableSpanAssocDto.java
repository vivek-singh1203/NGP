package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the CABLE_SPAN_ASSOC database table.
 * 
 */

public class CableSpanAssocDto  {
	private long id;
	private String associationState;
	private String createdBy;
	private Timestamp createdDate;
	private String csName;
	private String dataQualityIndicator;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String spanSectionName;
	
	private CableSpanCompatSpecDto cableSpanCompatSpec;
	public CableSpanAssocDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAssociationState() {
		return this.associationState;
	}
	public void setAssociationState(String associationState) {
		this.associationState = associationState;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getCsName() {
		return this.csName;
	}
	public void setCsName(String csName) {
		this.csName = csName;
	}
	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getSpanSectionName() {
		return this.spanSectionName;
	}
	public void setSpanSectionName(String spanSectionName) {
		this.spanSectionName = spanSectionName;
	}
	public CableSpanCompatSpecDto getCableSpanCompatSpec() {
		return this.cableSpanCompatSpec;
	}
	public void setCableSpanCompatSpec(CableSpanCompatSpecDto cableSpanCompatSpec) {
		this.cableSpanCompatSpec = cableSpanCompatSpec;
	}
}
