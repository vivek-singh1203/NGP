package com.bt.ngp.dto;
import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the BLOCK_HOLDERS database table.
 * 
 */

public class BlockHolderDto  {
	private String name;
	private String alternateName;
	private String assetIdentifier;
	private String createdBy;
	private Timestamp createdDate;
	private String dataQualityIndicator;
	private String faultState;
	private String frameName;
	private long id;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String resource1141Code;
	private String resourceState;
	private String serialNumber;
	private String serviceState;
	private String userLabel;
	
	private List<BlockDto> blocks;
	
		
	private HolderSpecDto holderSpec;
	
	private RackDto rack;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	
	private List<BlockHolderCharDto> blockHolderChars;
	
	private List<DfBhBlockAssocDto> dfBhBlockAssocs;
	
	private List<DfRackBhAssocDto> dfRackBhAssocs;
	public BlockHolderDto() {
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAlternateName() {
		return this.alternateName;
	}
	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}
	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}
	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}
	public String getFaultState() {
		return this.faultState;
	}
	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}
	public String getFrameName() {
		return this.frameName;
	}
	public void setFrameName(String frameName) {
		this.frameName = frameName;
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getResource1141Code() {
		return this.resource1141Code;
	}
	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}
	public String getResourceState() {
		return this.resourceState;
	}
	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}
	public String getSerialNumber() {
		return this.serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getServiceState() {
		return this.serviceState;
	}
	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}
	public String getUserLabel() {
		return this.userLabel;
	}
	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}
	public List<BlockDto> getBlocks() {
		return this.blocks;
	}
	public void setBlocks(List<BlockDto> blocks) {
		this.blocks = blocks;
	}
	public BlockDto addBlock(BlockDto block) {
		getBlocks().add(block);
		block.setBlockHolder(this);
		return block;
	}
	public BlockDto removeBlock(BlockDto block) {
		getBlocks().remove(block);
		block.setBlockHolder(null);
		return block;
	}
	public HolderSpecDto getHolderSpec() {
		return this.holderSpec;
	}
	public void setHolderSpec(HolderSpecDto holderSpec) {
		this.holderSpec = holderSpec;
	}
	public RackDto getRack() {
		return this.rack;
	}
	public void setRack(RackDto rack) {
		this.rack = rack;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
	public List<BlockHolderCharDto> getBlockHolderChars() {
		return this.blockHolderChars;
	}
	public void setBlockHolderChars(List<BlockHolderCharDto> blockHolderChars) {
		this.blockHolderChars = blockHolderChars;
	}
	public BlockHolderCharDto addBlockHolderChar(BlockHolderCharDto blockHolderChar) {
		getBlockHolderChars().add(blockHolderChar);
		blockHolderChar.setBlockHolder(this);
		return blockHolderChar;
	}
	public BlockHolderCharDto removeBlockHolderChar(BlockHolderCharDto blockHolderChar) {
		getBlockHolderChars().remove(blockHolderChar);
		blockHolderChar.setBlockHolder(null);
		return blockHolderChar;
	}
	public List<DfBhBlockAssocDto> getDfBhBlockAssocs() {
		return this.dfBhBlockAssocs;
	}
	public void setDfBhBlockAssocs(List<DfBhBlockAssocDto> dfBhBlockAssocs) {
		this.dfBhBlockAssocs = dfBhBlockAssocs;
	}
	public DfBhBlockAssocDto addDfBhBlockAssoc(DfBhBlockAssocDto dfBhBlockAssoc) {
		getDfBhBlockAssocs().add(dfBhBlockAssoc);
		dfBhBlockAssoc.setBlockHolder(this);
		return dfBhBlockAssoc;
	}
	public DfBhBlockAssocDto removeDfBhBlockAssoc(DfBhBlockAssocDto dfBhBlockAssoc) {
		getDfBhBlockAssocs().remove(dfBhBlockAssoc);
		dfBhBlockAssoc.setBlockHolder(null);
		return dfBhBlockAssoc;
	}
	public List<DfRackBhAssocDto> getDfRackBhAssocs() {
		return this.dfRackBhAssocs;
	}
	public void setDfRackBhAssocs(List<DfRackBhAssocDto> dfRackBhAssocs) {
		this.dfRackBhAssocs = dfRackBhAssocs;
	}
	public DfRackBhAssocDto addDfRackBhAssoc(DfRackBhAssocDto dfRackBhAssoc) {
		getDfRackBhAssocs().add(dfRackBhAssoc);
		dfRackBhAssoc.setBlockHolder(this);
		return dfRackBhAssoc;
	}
	public DfRackBhAssocDto removeDfRackBhAssoc(DfRackBhAssocDto dfRackBhAssoc) {
		getDfRackBhAssocs().remove(dfRackBhAssoc);
		dfRackBhAssoc.setBlockHolder(null);
		return dfRackBhAssoc;
	}
}
