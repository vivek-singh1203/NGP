package com.bt.ngp.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CB_SPEC_CHAR_SPEC database table.
 * 
 */

public class CbSpecCharSpecDto  {
	private long id;
	private String canBeOverriden;
	private String createdBy;
	private Timestamp createdDate;
	private String description;
	private String isUniqueWhenPresent;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String maxCardinality;
	private String minCardinality;
	private String name;
	private String remarks;
	private Timestamp validFrom;
	private Timestamp validTo;
	private String valueType;
	
	private List<CbCharDto> cbChars;
	
		
	private CbSpecDto cbSpec;
	
	private CbSpecCharValueSpecDto cbSpecCharValueSpec;
	
	private EntityDto entity;
	
	private EntityCharCategoryDto entityCharCategory;
	
	private EntityCharSpecDto entityCharSpec;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	
	private List<CbSpecCharSpecRelDto> cbSpecCharSpecRels1;
	
	private List<CbSpecCharSpecRelDto> cbSpecCharSpecRels2;
	public CbSpecCharSpecDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCanBeOverriden() {
		return this.canBeOverriden;
	}
	public void setCanBeOverriden(String canBeOverriden) {
		this.canBeOverriden = canBeOverriden;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDescription() {
		return this.description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getIsUniqueWhenPresent() {
		return this.isUniqueWhenPresent;
	}
	public void setIsUniqueWhenPresent(String isUniqueWhenPresent) {
		this.isUniqueWhenPresent = isUniqueWhenPresent;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getMaxCardinality() {
		return this.maxCardinality;
	}
	public void setMaxCardinality(String maxCardinality) {
		this.maxCardinality = maxCardinality;
	}
	public String getMinCardinality() {
		return this.minCardinality;
	}
	public void setMinCardinality(String minCardinality) {
		this.minCardinality = minCardinality;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRemarks() {
		return this.remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Timestamp getValidFrom() {
		return this.validFrom;
	}
	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}
	public Timestamp getValidTo() {
		return this.validTo;
	}
	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}
	public String getValueType() {
		return this.valueType;
	}
	public void setValueType(String valueType) {
		this.valueType = valueType;
	}
	public List<CbCharDto> getCbChars() {
		return this.cbChars;
	}
	public void setCbChars(List<CbCharDto> cbChars) {
		this.cbChars = cbChars;
	}
	public CbCharDto addCbChar(CbCharDto cbChar) {
		getCbChars().add(cbChar);
		cbChar.setCbSpecCharSpec(this);
		return cbChar;
	}
	public CbCharDto removeCbChar(CbCharDto cbChar) {
		getCbChars().remove(cbChar);
		cbChar.setCbSpecCharSpec(null);
		return cbChar;
	}
	public CbSpecDto getCbSpec() {
		return this.cbSpec;
	}
	public void setCbSpec(CbSpecDto cbSpec) {
		this.cbSpec = cbSpec;
	}
	public CbSpecCharValueSpecDto getCbSpecCharValueSpec() {
		return this.cbSpecCharValueSpec;
	}
	public void setCbSpecCharValueSpec(CbSpecCharValueSpecDto cbSpecCharValueSpec) {
		this.cbSpecCharValueSpec = cbSpecCharValueSpec;
	}
	public EntityDto getEntity() {
		return this.entity;
	}
	public void setEntity(EntityDto entity) {
		this.entity = entity;
	}
	public EntityCharCategoryDto getEntityCharCategory() {
		return this.entityCharCategory;
	}
	public void setEntityCharCategory(EntityCharCategoryDto entityCharCategory) {
		this.entityCharCategory = entityCharCategory;
	}
	public EntityCharSpecDto getEntityCharSpec() {
		return this.entityCharSpec;
	}
	public void setEntityCharSpec(EntityCharSpecDto entityCharSpec) {
		this.entityCharSpec = entityCharSpec;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
	public List<CbSpecCharSpecRelDto> getCbSpecCharSpecRels1() {
		return this.cbSpecCharSpecRels1;
	}
	public void setCbSpecCharSpecRels1(List<CbSpecCharSpecRelDto> cbSpecCharSpecRels1) {
		this.cbSpecCharSpecRels1 = cbSpecCharSpecRels1;
	}
	public CbSpecCharSpecRelDto addCbSpecCharSpecRels1(CbSpecCharSpecRelDto cbSpecCharSpecRels1) {
		getCbSpecCharSpecRels1().add(cbSpecCharSpecRels1);
		cbSpecCharSpecRels1.setCbSpecCharSpec1(this);
		return cbSpecCharSpecRels1;
	}
	public CbSpecCharSpecRelDto removeCbSpecCharSpecRels1(CbSpecCharSpecRelDto cbSpecCharSpecRels1) {
		getCbSpecCharSpecRels1().remove(cbSpecCharSpecRels1);
		cbSpecCharSpecRels1.setCbSpecCharSpec1(null);
		return cbSpecCharSpecRels1;
	}
	public List<CbSpecCharSpecRelDto> getCbSpecCharSpecRels2() {
		return this.cbSpecCharSpecRels2;
	}
	public void setCbSpecCharSpecRels2(List<CbSpecCharSpecRelDto> cbSpecCharSpecRels2) {
		this.cbSpecCharSpecRels2 = cbSpecCharSpecRels2;
	}
	public CbSpecCharSpecRelDto addCbSpecCharSpecRels2(CbSpecCharSpecRelDto cbSpecCharSpecRels2) {
		getCbSpecCharSpecRels2().add(cbSpecCharSpecRels2);
		cbSpecCharSpecRels2.setCbSpecCharSpec2(this);
		return cbSpecCharSpecRels2;
	}
	public CbSpecCharSpecRelDto removeCbSpecCharSpecRels2(CbSpecCharSpecRelDto cbSpecCharSpecRels2) {
		getCbSpecCharSpecRels2().remove(cbSpecCharSpecRels2);
		cbSpecCharSpecRels2.setCbSpecCharSpec2(null);
		return cbSpecCharSpecRels2;
	}
}
