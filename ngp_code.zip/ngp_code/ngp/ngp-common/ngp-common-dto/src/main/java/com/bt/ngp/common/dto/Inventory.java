package com.bt.ngp.common.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Inventory {

	protected String entityName;
	@Valid
	@NotNull
	protected EntityDetailsDto details;
	protected Map<String, Object> entitySpecificDetails;
	protected SubComponents subComponents;

	// specific to line feature.
	protected String terminationType;

	protected AssociatedComponents associatedComponents;

	protected ConnectedInventories connectedInventories;

	protected Specifications specification;

	protected InventoryCharacteristics inventoryCharacteristics;

	private Geometry geometry;

	public static Inventory getInventoryInstance() {
		return new Inventory();
	}

	public Map<String, Object> getEntitySpecificDetails() {
		return entitySpecificDetails;
	}

	public void setEntitySpecificDetails(Map<String, Object> entitySpecificDetails) {
		this.entitySpecificDetails = entitySpecificDetails;
	}

	public void addEntitySpecificEntry(String key, Object value) {
		if (entitySpecificDetails == null)
			entitySpecificDetails = new HashMap<>();

		entitySpecificDetails.put(key, value);
	}

	public String getTerminationType() {
		return terminationType;
	}

	public void setTerminationType(String terminationType) {
		this.terminationType = terminationType;
	}

	public InventoryCharacteristics getInventoryCharacteristics() {
		return inventoryCharacteristics;
	}

	public void setInventoryCharacteristics(InventoryCharacteristics inventoryCharacteristics) {
		this.inventoryCharacteristics = inventoryCharacteristics;
	}

	public SubComponents getSubComponents() {
		return subComponents;
	}

	public AssociatedComponents getAssociatedComponents() {
		return associatedComponents;
	}

	public ConnectedInventories getConnectedInventories() {
		return connectedInventories;
	}

	public Specifications getSpecification() {
		return specification;
	}

	public void setSpecification(Specifications specification) {
		this.specification = specification;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public EntityDetailsDto getDetails() {
		return details;
	}

	public void setDetails(EntityDetailsDto details) {
		this.details = details;
	}

	public SubComponents addSubComponents(Inventory inventory) {
		if (null == subComponents) {
			subComponents = new SubComponents();
			subComponents.setInventories(new ArrayList<>());
		}
		subComponents.getInventories().add(inventory);
		return subComponents;
	}

	public AssociatedComponents addAssociatedComponents(Inventory inventory) {
		if (null == associatedComponents) {
			associatedComponents = new AssociatedComponents();
			associatedComponents.setInventories(new ArrayList<>());
		}
		associatedComponents.getInventories().add(inventory);
		return associatedComponents;
	}

	public ConnectedInventories addConnectedInventories(Inventory inventory) {
		if (null == connectedInventories) {
			connectedInventories = new ConnectedInventories();
			connectedInventories.setInventories(new ArrayList<>());
		}
		connectedInventories.getInventories().add(inventory);
		return connectedInventories;
	}

	public InventoryCharacteristics addInventoryCharacteristics(List<Characteristics> characteristics) {
		if (null == inventoryCharacteristics) {
			inventoryCharacteristics = new InventoryCharacteristics();
			inventoryCharacteristics.setCharacteristics(new ArrayList<>());
		}
		inventoryCharacteristics.getCharacteristics().addAll(characteristics);
		return inventoryCharacteristics;
	}

	/**
	 * @return the geometry
	 */
	public Geometry getGeometry() {
		return geometry;
	}

	/**
	 * @param geometry
	 *            the geometry to set
	 */
	public void setGeometry(Geometry geometry) {
		this.geometry = geometry;
	}

}
