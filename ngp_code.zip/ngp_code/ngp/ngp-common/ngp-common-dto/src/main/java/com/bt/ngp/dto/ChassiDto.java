package com.bt.ngp.dto;
import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CHASSIS database table.
 * 
 */

public class ChassiDto  {
	private String name;
	private String alternateName;
	private String assetIdentifier;
	private String ccpName;
	private String cpeName;
	private String createdBy;
	private Timestamp createdDate;
	private String dataQualityIndicator;
	private String faultState;
	private long id;
	private String jcName;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String mfnName;
	private String nteName;
	private String resource1141Code;
	private String resourceState;
	private String serialNumber;
	private String serviceState;
	private String userLabel;
	private String weqName;
	
	private List<CcpChassisPhAssocDto> ccpChassisPhAssocs;
	
	private List<CcpCsPortTermDto> ccpCsPortTerms;
	
	private List<CcpPortPortAssocDto> ccpPortPortAssocs1;
	
	private List<CcpPortPortAssocDto> ccpPortPortAssocs2;
	
	private DistributionPointDto distributionPoints;
	
		
	public DistributionPointDto getDistributionPoints() {
		return distributionPoints;
	}
	public void setDistributionPoints(DistributionPointDto distributionPoints) {
		this.distributionPoints = distributionPoints;
	}
	private EqSpecDto eqSpec;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	
	private StoreDto store;
	
	private SupplierDto supplier;
	
	private List<ChassisCharDto> chassisChars;
	
	private List<CpeChassisPhAssocDto> cpeChassisPhAssocs;
	
	private List<CpeCsPortTermDto> cpeCsPortTerms;
	
	private List<CpePortPortAssocDto> cpePortPortAssocs1;
	
	private List<CpePortPortAssocDto> cpePortPortAssocs2;
	
	private List<DfCsPortTermDto> dfCsPortTerms;
	
	private List<DfPortPortAssocDto> dfPortPortAssocs1;
	
	private List<DfPortPortAssocDto> dfPortPortAssocs2;
	
	private List<DpChassisPhAssocDto> dpChassisPhAssocs;
	
	private List<DpCsPortTermDto> dpCsPortTerms;
	
	private List<DpPortPortAssocDto> dpPortPortAssocs1;
	
	private List<DpPortPortAssocDto> dpPortPortAssocs2;
	
	private List<JcChassisPhAssocDto> jcChassisPhAssocs;
	
	private List<JcCsPortTermDto> jcCsPortTerms;
	
	private List<JcPortPortAssocDto> jcPortPortAssocs1;
	
	private List<JcPortPortAssocDto> jcPortPortAssocs2;
	
	private List<MfnChassisPhAssocDto> mfnChassisPhAssocs;
	
	private List<MfnCsPortTermDto> mfnCsPortTerms;
	
	private List<MfnPortPortAssocDto> mfnPortPortAssocs1;
	
	private List<MfnPortPortAssocDto> mfnPortPortAssocs2;
	
	private List<NteChassisPhAssocDto> nteChassisPhAssocs;
	
	private List<NteCsPortTermDto> nteCsPortTerms;
	
	private List<NtePortPortAssocDto> ntePortPortAssocs1;
	
	private List<NtePortPortAssocDto> ntePortPortAssocs2;
	
	private List<PluginHolderDto> pluginHolders;
	
	private List<WeChassisPhAssocDto> weChassisPhAssocs;
	
	private List<WeCsPortTermDto> weCsPortTerms;
	
	private List<WePortPortAssocDto> wePortPortAssocs1;
	
	private List<WePortPortAssocDto> wePortPortAssocs2;
	public ChassiDto() {
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAlternateName() {
		return this.alternateName;
	}
	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}
	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}
	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}
	public String getCcpName() {
		return this.ccpName;
	}
	public void setCcpName(String ccpName) {
		this.ccpName = ccpName;
	}
	public String getCpeName() {
		return this.cpeName;
	}
	public void setCpeName(String cpeName) {
		this.cpeName = cpeName;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}
	public String getFaultState() {
		return this.faultState;
	}
	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getJcName() {
		return this.jcName;
	}
	public void setJcName(String jcName) {
		this.jcName = jcName;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getMfnName() {
		return this.mfnName;
	}
	public void setMfnName(String mfnName) {
		this.mfnName = mfnName;
	}
	public String getNteName() {
		return this.nteName;
	}
	public void setNteName(String nteName) {
		this.nteName = nteName;
	}
	public String getResource1141Code() {
		return this.resource1141Code;
	}
	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}
	public String getResourceState() {
		return this.resourceState;
	}
	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}
	public String getSerialNumber() {
		return this.serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getServiceState() {
		return this.serviceState;
	}
	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}
	public String getUserLabel() {
		return this.userLabel;
	}
	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}
	public String getWeqName() {
		return this.weqName;
	}
	public void setWeqName(String weqName) {
		this.weqName = weqName;
	}
	public List<CcpChassisPhAssocDto> getCcpChassisPhAssocs() {
		return this.ccpChassisPhAssocs;
	}
	public void setCcpChassisPhAssocs(List<CcpChassisPhAssocDto> ccpChassisPhAssocs) {
		this.ccpChassisPhAssocs = ccpChassisPhAssocs;
	}
	public CcpChassisPhAssocDto addCcpChassisPhAssoc(CcpChassisPhAssocDto ccpChassisPhAssoc) {
		getCcpChassisPhAssocs().add(ccpChassisPhAssoc);
		ccpChassisPhAssoc.setChassi(this);
		return ccpChassisPhAssoc;
	}
	public CcpChassisPhAssocDto removeCcpChassisPhAssoc(CcpChassisPhAssocDto ccpChassisPhAssoc) {
		getCcpChassisPhAssocs().remove(ccpChassisPhAssoc);
		ccpChassisPhAssoc.setChassi(null);
		return ccpChassisPhAssoc;
	}
	public List<CcpCsPortTermDto> getCcpCsPortTerms() {
		return this.ccpCsPortTerms;
	}
	public void setCcpCsPortTerms(List<CcpCsPortTermDto> ccpCsPortTerms) {
		this.ccpCsPortTerms = ccpCsPortTerms;
	}
	public CcpCsPortTermDto addCcpCsPortTerm(CcpCsPortTermDto ccpCsPortTerm) {
		getCcpCsPortTerms().add(ccpCsPortTerm);
		ccpCsPortTerm.setChassi(this);
		return ccpCsPortTerm;
	}
	public CcpCsPortTermDto removeCcpCsPortTerm(CcpCsPortTermDto ccpCsPortTerm) {
		getCcpCsPortTerms().remove(ccpCsPortTerm);
		ccpCsPortTerm.setChassi(null);
		return ccpCsPortTerm;
	}
	public List<CcpPortPortAssocDto> getCcpPortPortAssocs1() {
		return this.ccpPortPortAssocs1;
	}
	public void setCcpPortPortAssocs1(List<CcpPortPortAssocDto> ccpPortPortAssocs1) {
		this.ccpPortPortAssocs1 = ccpPortPortAssocs1;
	}
	public CcpPortPortAssocDto addCcpPortPortAssocs1(CcpPortPortAssocDto ccpPortPortAssocs1) {
		getCcpPortPortAssocs1().add(ccpPortPortAssocs1);
		ccpPortPortAssocs1.setChassi1(this);
		return ccpPortPortAssocs1;
	}
	public CcpPortPortAssocDto removeCcpPortPortAssocs1(CcpPortPortAssocDto ccpPortPortAssocs1) {
		getCcpPortPortAssocs1().remove(ccpPortPortAssocs1);
		ccpPortPortAssocs1.setChassi1(null);
		return ccpPortPortAssocs1;
	}
	public List<CcpPortPortAssocDto> getCcpPortPortAssocs2() {
		return this.ccpPortPortAssocs2;
	}
	public void setCcpPortPortAssocs2(List<CcpPortPortAssocDto> ccpPortPortAssocs2) {
		this.ccpPortPortAssocs2 = ccpPortPortAssocs2;
	}
	public CcpPortPortAssocDto addCcpPortPortAssocs2(CcpPortPortAssocDto ccpPortPortAssocs2) {
		getCcpPortPortAssocs2().add(ccpPortPortAssocs2);
		ccpPortPortAssocs2.setChassi2(this);
		return ccpPortPortAssocs2;
	}
	public CcpPortPortAssocDto removeCcpPortPortAssocs2(CcpPortPortAssocDto ccpPortPortAssocs2) {
		getCcpPortPortAssocs2().remove(ccpPortPortAssocs2);
		ccpPortPortAssocs2.setChassi2(null);
		return ccpPortPortAssocs2;
	}

	public EqSpecDto getEqSpec() {
		return this.eqSpec;
	}
	public void setEqSpec(EqSpecDto eqSpec) {
		this.eqSpec = eqSpec;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
	public StoreDto getStore() {
		return this.store;
	}
	public void setStore(StoreDto store) {
		this.store = store;
	}
	public SupplierDto getSupplier() {
		return this.supplier;
	}
	public void setSupplier(SupplierDto supplier) {
		this.supplier = supplier;
	}
	public List<ChassisCharDto> getChassisChars() {
		return this.chassisChars;
	}
	public void setChassisChars(List<ChassisCharDto> chassisChars) {
		this.chassisChars = chassisChars;
	}
	public ChassisCharDto addChassisChar(ChassisCharDto chassisChar) {
		getChassisChars().add(chassisChar);
		chassisChar.setChassi(this);
		return chassisChar;
	}
	public ChassisCharDto removeChassisChar(ChassisCharDto chassisChar) {
		getChassisChars().remove(chassisChar);
		chassisChar.setChassi(null);
		return chassisChar;
	}
	public List<CpeChassisPhAssocDto> getCpeChassisPhAssocs() {
		return this.cpeChassisPhAssocs;
	}
	public void setCpeChassisPhAssocs(List<CpeChassisPhAssocDto> cpeChassisPhAssocs) {
		this.cpeChassisPhAssocs = cpeChassisPhAssocs;
	}
	public CpeChassisPhAssocDto addCpeChassisPhAssoc(CpeChassisPhAssocDto cpeChassisPhAssoc) {
		getCpeChassisPhAssocs().add(cpeChassisPhAssoc);
		cpeChassisPhAssoc.setChassi(this);
		return cpeChassisPhAssoc;
	}
	public CpeChassisPhAssocDto removeCpeChassisPhAssoc(CpeChassisPhAssocDto cpeChassisPhAssoc) {
		getCpeChassisPhAssocs().remove(cpeChassisPhAssoc);
		cpeChassisPhAssoc.setChassi(null);
		return cpeChassisPhAssoc;
	}
	public List<CpeCsPortTermDto> getCpeCsPortTerms() {
		return this.cpeCsPortTerms;
	}
	public void setCpeCsPortTerms(List<CpeCsPortTermDto> cpeCsPortTerms) {
		this.cpeCsPortTerms = cpeCsPortTerms;
	}
	public CpeCsPortTermDto addCpeCsPortTerm(CpeCsPortTermDto cpeCsPortTerm) {
		getCpeCsPortTerms().add(cpeCsPortTerm);
		cpeCsPortTerm.setChassi(this);
		return cpeCsPortTerm;
	}
	public CpeCsPortTermDto removeCpeCsPortTerm(CpeCsPortTermDto cpeCsPortTerm) {
		getCpeCsPortTerms().remove(cpeCsPortTerm);
		cpeCsPortTerm.setChassi(null);
		return cpeCsPortTerm;
	}
	public List<CpePortPortAssocDto> getCpePortPortAssocs1() {
		return this.cpePortPortAssocs1;
	}
	public void setCpePortPortAssocs1(List<CpePortPortAssocDto> cpePortPortAssocs1) {
		this.cpePortPortAssocs1 = cpePortPortAssocs1;
	}
	public CpePortPortAssocDto addCpePortPortAssocs1(CpePortPortAssocDto cpePortPortAssocs1) {
		getCpePortPortAssocs1().add(cpePortPortAssocs1);
		cpePortPortAssocs1.setChassi1(this);
		return cpePortPortAssocs1;
	}
	public CpePortPortAssocDto removeCpePortPortAssocs1(CpePortPortAssocDto cpePortPortAssocs1) {
		getCpePortPortAssocs1().remove(cpePortPortAssocs1);
		cpePortPortAssocs1.setChassi1(null);
		return cpePortPortAssocs1;
	}
	public List<CpePortPortAssocDto> getCpePortPortAssocs2() {
		return this.cpePortPortAssocs2;
	}
	public void setCpePortPortAssocs2(List<CpePortPortAssocDto> cpePortPortAssocs2) {
		this.cpePortPortAssocs2 = cpePortPortAssocs2;
	}
	public CpePortPortAssocDto addCpePortPortAssocs2(CpePortPortAssocDto cpePortPortAssocs2) {
		getCpePortPortAssocs2().add(cpePortPortAssocs2);
		cpePortPortAssocs2.setChassi2(this);
		return cpePortPortAssocs2;
	}
	public CpePortPortAssocDto removeCpePortPortAssocs2(CpePortPortAssocDto cpePortPortAssocs2) {
		getCpePortPortAssocs2().remove(cpePortPortAssocs2);
		cpePortPortAssocs2.setChassi2(null);
		return cpePortPortAssocs2;
	}
	public List<DfCsPortTermDto> getDfCsPortTerms() {
		return this.dfCsPortTerms;
	}
	public void setDfCsPortTerms(List<DfCsPortTermDto> dfCsPortTerms) {
		this.dfCsPortTerms = dfCsPortTerms;
	}
	public DfCsPortTermDto addDfCsPortTerm(DfCsPortTermDto dfCsPortTerm) {
		getDfCsPortTerms().add(dfCsPortTerm);
		dfCsPortTerm.setChassi(this);
		return dfCsPortTerm;
	}
	public DfCsPortTermDto removeDfCsPortTerm(DfCsPortTermDto dfCsPortTerm) {
		getDfCsPortTerms().remove(dfCsPortTerm);
		dfCsPortTerm.setChassi(null);
		return dfCsPortTerm;
	}
	public List<DfPortPortAssocDto> getDfPortPortAssocs1() {
		return this.dfPortPortAssocs1;
	}
	public void setDfPortPortAssocs1(List<DfPortPortAssocDto> dfPortPortAssocs1) {
		this.dfPortPortAssocs1 = dfPortPortAssocs1;
	}
	public DfPortPortAssocDto addDfPortPortAssocs1(DfPortPortAssocDto dfPortPortAssocs1) {
		getDfPortPortAssocs1().add(dfPortPortAssocs1);
		dfPortPortAssocs1.setChassi1(this);
		return dfPortPortAssocs1;
	}
	public DfPortPortAssocDto removeDfPortPortAssocs1(DfPortPortAssocDto dfPortPortAssocs1) {
		getDfPortPortAssocs1().remove(dfPortPortAssocs1);
		dfPortPortAssocs1.setChassi1(null);
		return dfPortPortAssocs1;
	}
	public List<DfPortPortAssocDto> getDfPortPortAssocs2() {
		return this.dfPortPortAssocs2;
	}
	public void setDfPortPortAssocs2(List<DfPortPortAssocDto> dfPortPortAssocs2) {
		this.dfPortPortAssocs2 = dfPortPortAssocs2;
	}
	public DfPortPortAssocDto addDfPortPortAssocs2(DfPortPortAssocDto dfPortPortAssocs2) {
		getDfPortPortAssocs2().add(dfPortPortAssocs2);
		dfPortPortAssocs2.setChassi2(this);
		return dfPortPortAssocs2;
	}
	public DfPortPortAssocDto removeDfPortPortAssocs2(DfPortPortAssocDto dfPortPortAssocs2) {
		getDfPortPortAssocs2().remove(dfPortPortAssocs2);
		dfPortPortAssocs2.setChassi2(null);
		return dfPortPortAssocs2;
	}
	public List<DpChassisPhAssocDto> getDpChassisPhAssocs() {
		return this.dpChassisPhAssocs;
	}
	public void setDpChassisPhAssocs(List<DpChassisPhAssocDto> dpChassisPhAssocs) {
		this.dpChassisPhAssocs = dpChassisPhAssocs;
	}
	public DpChassisPhAssocDto addDpChassisPhAssoc(DpChassisPhAssocDto dpChassisPhAssoc) {
		getDpChassisPhAssocs().add(dpChassisPhAssoc);
		dpChassisPhAssoc.setChassi(this);
		return dpChassisPhAssoc;
	}
	public DpChassisPhAssocDto removeDpChassisPhAssoc(DpChassisPhAssocDto dpChassisPhAssoc) {
		getDpChassisPhAssocs().remove(dpChassisPhAssoc);
		dpChassisPhAssoc.setChassi(null);
		return dpChassisPhAssoc;
	}
	public List<DpCsPortTermDto> getDpCsPortTerms() {
		return this.dpCsPortTerms;
	}
	public void setDpCsPortTerms(List<DpCsPortTermDto> dpCsPortTerms) {
		this.dpCsPortTerms = dpCsPortTerms;
	}
	public DpCsPortTermDto addDpCsPortTerm(DpCsPortTermDto dpCsPortTerm) {
		getDpCsPortTerms().add(dpCsPortTerm);
		dpCsPortTerm.setChassi(this);
		return dpCsPortTerm;
	}
	public DpCsPortTermDto removeDpCsPortTerm(DpCsPortTermDto dpCsPortTerm) {
		getDpCsPortTerms().remove(dpCsPortTerm);
		dpCsPortTerm.setChassi(null);
		return dpCsPortTerm;
	}
	public List<DpPortPortAssocDto> getDpPortPortAssocs1() {
		return this.dpPortPortAssocs1;
	}
	public void setDpPortPortAssocs1(List<DpPortPortAssocDto> dpPortPortAssocs1) {
		this.dpPortPortAssocs1 = dpPortPortAssocs1;
	}
	public DpPortPortAssocDto addDpPortPortAssocs1(DpPortPortAssocDto dpPortPortAssocs1) {
		getDpPortPortAssocs1().add(dpPortPortAssocs1);
		dpPortPortAssocs1.setChassi1(this);
		return dpPortPortAssocs1;
	}
	public DpPortPortAssocDto removeDpPortPortAssocs1(DpPortPortAssocDto dpPortPortAssocs1) {
		getDpPortPortAssocs1().remove(dpPortPortAssocs1);
		dpPortPortAssocs1.setChassi1(null);
		return dpPortPortAssocs1;
	}
	public List<DpPortPortAssocDto> getDpPortPortAssocs2() {
		return this.dpPortPortAssocs2;
	}
	public void setDpPortPortAssocs2(List<DpPortPortAssocDto> dpPortPortAssocs2) {
		this.dpPortPortAssocs2 = dpPortPortAssocs2;
	}
	public DpPortPortAssocDto addDpPortPortAssocs2(DpPortPortAssocDto dpPortPortAssocs2) {
		getDpPortPortAssocs2().add(dpPortPortAssocs2);
		dpPortPortAssocs2.setChassi2(this);
		return dpPortPortAssocs2;
	}
	public DpPortPortAssocDto removeDpPortPortAssocs2(DpPortPortAssocDto dpPortPortAssocs2) {
		getDpPortPortAssocs2().remove(dpPortPortAssocs2);
		dpPortPortAssocs2.setChassi2(null);
		return dpPortPortAssocs2;
	}
	public List<JcChassisPhAssocDto> getJcChassisPhAssocs() {
		return this.jcChassisPhAssocs;
	}
	public void setJcChassisPhAssocs(List<JcChassisPhAssocDto> jcChassisPhAssocs) {
		this.jcChassisPhAssocs = jcChassisPhAssocs;
	}
	public JcChassisPhAssocDto addJcChassisPhAssoc(JcChassisPhAssocDto jcChassisPhAssoc) {
		getJcChassisPhAssocs().add(jcChassisPhAssoc);
		jcChassisPhAssoc.setChassi(this);
		return jcChassisPhAssoc;
	}
	public JcChassisPhAssocDto removeJcChassisPhAssoc(JcChassisPhAssocDto jcChassisPhAssoc) {
		getJcChassisPhAssocs().remove(jcChassisPhAssoc);
		jcChassisPhAssoc.setChassi(null);
		return jcChassisPhAssoc;
	}
	public List<JcCsPortTermDto> getJcCsPortTerms() {
		return this.jcCsPortTerms;
	}
	public void setJcCsPortTerms(List<JcCsPortTermDto> jcCsPortTerms) {
		this.jcCsPortTerms = jcCsPortTerms;
	}
	public JcCsPortTermDto addJcCsPortTerm(JcCsPortTermDto jcCsPortTerm) {
		getJcCsPortTerms().add(jcCsPortTerm);
		jcCsPortTerm.setChassi(this);
		return jcCsPortTerm;
	}
	public JcCsPortTermDto removeJcCsPortTerm(JcCsPortTermDto jcCsPortTerm) {
		getJcCsPortTerms().remove(jcCsPortTerm);
		jcCsPortTerm.setChassi(null);
		return jcCsPortTerm;
	}
	public List<JcPortPortAssocDto> getJcPortPortAssocs1() {
		return this.jcPortPortAssocs1;
	}
	public void setJcPortPortAssocs1(List<JcPortPortAssocDto> jcPortPortAssocs1) {
		this.jcPortPortAssocs1 = jcPortPortAssocs1;
	}
	public JcPortPortAssocDto addJcPortPortAssocs1(JcPortPortAssocDto jcPortPortAssocs1) {
		getJcPortPortAssocs1().add(jcPortPortAssocs1);
		jcPortPortAssocs1.setChassi1(this);
		return jcPortPortAssocs1;
	}
	public JcPortPortAssocDto removeJcPortPortAssocs1(JcPortPortAssocDto jcPortPortAssocs1) {
		getJcPortPortAssocs1().remove(jcPortPortAssocs1);
		jcPortPortAssocs1.setChassi1(null);
		return jcPortPortAssocs1;
	}
	public List<JcPortPortAssocDto> getJcPortPortAssocs2() {
		return this.jcPortPortAssocs2;
	}
	public void setJcPortPortAssocs2(List<JcPortPortAssocDto> jcPortPortAssocs2) {
		this.jcPortPortAssocs2 = jcPortPortAssocs2;
	}
	public JcPortPortAssocDto addJcPortPortAssocs2(JcPortPortAssocDto jcPortPortAssocs2) {
		getJcPortPortAssocs2().add(jcPortPortAssocs2);
		jcPortPortAssocs2.setChassi2(this);
		return jcPortPortAssocs2;
	}
	public JcPortPortAssocDto removeJcPortPortAssocs2(JcPortPortAssocDto jcPortPortAssocs2) {
		getJcPortPortAssocs2().remove(jcPortPortAssocs2);
		jcPortPortAssocs2.setChassi2(null);
		return jcPortPortAssocs2;
	}
	public List<MfnChassisPhAssocDto> getMfnChassisPhAssocs() {
		return this.mfnChassisPhAssocs;
	}
	public void setMfnChassisPhAssocs(List<MfnChassisPhAssocDto> mfnChassisPhAssocs) {
		this.mfnChassisPhAssocs = mfnChassisPhAssocs;
	}
	public MfnChassisPhAssocDto addMfnChassisPhAssoc(MfnChassisPhAssocDto mfnChassisPhAssoc) {
		getMfnChassisPhAssocs().add(mfnChassisPhAssoc);
		mfnChassisPhAssoc.setChassi(this);
		return mfnChassisPhAssoc;
	}
	public MfnChassisPhAssocDto removeMfnChassisPhAssoc(MfnChassisPhAssocDto mfnChassisPhAssoc) {
		getMfnChassisPhAssocs().remove(mfnChassisPhAssoc);
		mfnChassisPhAssoc.setChassi(null);
		return mfnChassisPhAssoc;
	}
	public List<MfnCsPortTermDto> getMfnCsPortTerms() {
		return this.mfnCsPortTerms;
	}
	public void setMfnCsPortTerms(List<MfnCsPortTermDto> mfnCsPortTerms) {
		this.mfnCsPortTerms = mfnCsPortTerms;
	}
	public MfnCsPortTermDto addMfnCsPortTerm(MfnCsPortTermDto mfnCsPortTerm) {
		getMfnCsPortTerms().add(mfnCsPortTerm);
		mfnCsPortTerm.setChassi(this);
		return mfnCsPortTerm;
	}
	public MfnCsPortTermDto removeMfnCsPortTerm(MfnCsPortTermDto mfnCsPortTerm) {
		getMfnCsPortTerms().remove(mfnCsPortTerm);
		mfnCsPortTerm.setChassi(null);
		return mfnCsPortTerm;
	}
	public List<MfnPortPortAssocDto> getMfnPortPortAssocs1() {
		return this.mfnPortPortAssocs1;
	}
	public void setMfnPortPortAssocs1(List<MfnPortPortAssocDto> mfnPortPortAssocs1) {
		this.mfnPortPortAssocs1 = mfnPortPortAssocs1;
	}
	public MfnPortPortAssocDto addMfnPortPortAssocs1(MfnPortPortAssocDto mfnPortPortAssocs1) {
		getMfnPortPortAssocs1().add(mfnPortPortAssocs1);
		mfnPortPortAssocs1.setChassi1(this);
		return mfnPortPortAssocs1;
	}
	public MfnPortPortAssocDto removeMfnPortPortAssocs1(MfnPortPortAssocDto mfnPortPortAssocs1) {
		getMfnPortPortAssocs1().remove(mfnPortPortAssocs1);
		mfnPortPortAssocs1.setChassi1(null);
		return mfnPortPortAssocs1;
	}
	public List<MfnPortPortAssocDto> getMfnPortPortAssocs2() {
		return this.mfnPortPortAssocs2;
	}
	public void setMfnPortPortAssocs2(List<MfnPortPortAssocDto> mfnPortPortAssocs2) {
		this.mfnPortPortAssocs2 = mfnPortPortAssocs2;
	}
	public MfnPortPortAssocDto addMfnPortPortAssocs2(MfnPortPortAssocDto mfnPortPortAssocs2) {
		getMfnPortPortAssocs2().add(mfnPortPortAssocs2);
		mfnPortPortAssocs2.setChassi2(this);
		return mfnPortPortAssocs2;
	}
	public MfnPortPortAssocDto removeMfnPortPortAssocs2(MfnPortPortAssocDto mfnPortPortAssocs2) {
		getMfnPortPortAssocs2().remove(mfnPortPortAssocs2);
		mfnPortPortAssocs2.setChassi2(null);
		return mfnPortPortAssocs2;
	}
	public List<NteChassisPhAssocDto> getNteChassisPhAssocs() {
		return this.nteChassisPhAssocs;
	}
	public void setNteChassisPhAssocs(List<NteChassisPhAssocDto> nteChassisPhAssocs) {
		this.nteChassisPhAssocs = nteChassisPhAssocs;
	}
	public NteChassisPhAssocDto addNteChassisPhAssoc(NteChassisPhAssocDto nteChassisPhAssoc) {
		getNteChassisPhAssocs().add(nteChassisPhAssoc);
		nteChassisPhAssoc.setChassi(this);
		return nteChassisPhAssoc;
	}
	public NteChassisPhAssocDto removeNteChassisPhAssoc(NteChassisPhAssocDto nteChassisPhAssoc) {
		getNteChassisPhAssocs().remove(nteChassisPhAssoc);
		nteChassisPhAssoc.setChassi(null);
		return nteChassisPhAssoc;
	}
	public List<NteCsPortTermDto> getNteCsPortTerms() {
		return this.nteCsPortTerms;
	}
	public void setNteCsPortTerms(List<NteCsPortTermDto> nteCsPortTerms) {
		this.nteCsPortTerms = nteCsPortTerms;
	}
	public NteCsPortTermDto addNteCsPortTerm(NteCsPortTermDto nteCsPortTerm) {
		getNteCsPortTerms().add(nteCsPortTerm);
		nteCsPortTerm.setChassi(this);
		return nteCsPortTerm;
	}
	public NteCsPortTermDto removeNteCsPortTerm(NteCsPortTermDto nteCsPortTerm) {
		getNteCsPortTerms().remove(nteCsPortTerm);
		nteCsPortTerm.setChassi(null);
		return nteCsPortTerm;
	}
	public List<NtePortPortAssocDto> getNtePortPortAssocs1() {
		return this.ntePortPortAssocs1;
	}
	public void setNtePortPortAssocs1(List<NtePortPortAssocDto> ntePortPortAssocs1) {
		this.ntePortPortAssocs1 = ntePortPortAssocs1;
	}
	public NtePortPortAssocDto addNtePortPortAssocs1(NtePortPortAssocDto ntePortPortAssocs1) {
		getNtePortPortAssocs1().add(ntePortPortAssocs1);
		ntePortPortAssocs1.setChassi1(this);
		return ntePortPortAssocs1;
	}
	public NtePortPortAssocDto removeNtePortPortAssocs1(NtePortPortAssocDto ntePortPortAssocs1) {
		getNtePortPortAssocs1().remove(ntePortPortAssocs1);
		ntePortPortAssocs1.setChassi1(null);
		return ntePortPortAssocs1;
	}
	public List<NtePortPortAssocDto> getNtePortPortAssocs2() {
		return this.ntePortPortAssocs2;
	}
	public void setNtePortPortAssocs2(List<NtePortPortAssocDto> ntePortPortAssocs2) {
		this.ntePortPortAssocs2 = ntePortPortAssocs2;
	}
	public NtePortPortAssocDto addNtePortPortAssocs2(NtePortPortAssocDto ntePortPortAssocs2) {
		getNtePortPortAssocs2().add(ntePortPortAssocs2);
		ntePortPortAssocs2.setChassi2(this);
		return ntePortPortAssocs2;
	}
	public NtePortPortAssocDto removeNtePortPortAssocs2(NtePortPortAssocDto ntePortPortAssocs2) {
		getNtePortPortAssocs2().remove(ntePortPortAssocs2);
		ntePortPortAssocs2.setChassi2(null);
		return ntePortPortAssocs2;
	}
	public List<PluginHolderDto> getPluginHolders() {
		return this.pluginHolders;
	}
	public void setPluginHolders(List<PluginHolderDto> pluginHolders) {
		this.pluginHolders = pluginHolders;
	}
	public PluginHolderDto addPluginHolder(PluginHolderDto pluginHolder) {
		getPluginHolders().add(pluginHolder);
		pluginHolder.setChassi(this);
		return pluginHolder;
	}
	public PluginHolderDto removePluginHolder(PluginHolderDto pluginHolder) {
		getPluginHolders().remove(pluginHolder);
		pluginHolder.setChassi(null);
		return pluginHolder;
	}
	public List<WeChassisPhAssocDto> getWeChassisPhAssocs() {
		return this.weChassisPhAssocs;
	}
	public void setWeChassisPhAssocs(List<WeChassisPhAssocDto> weChassisPhAssocs) {
		this.weChassisPhAssocs = weChassisPhAssocs;
	}
	public WeChassisPhAssocDto addWeChassisPhAssoc(WeChassisPhAssocDto weChassisPhAssoc) {
		getWeChassisPhAssocs().add(weChassisPhAssoc);
		weChassisPhAssoc.setChassi(this);
		return weChassisPhAssoc;
	}
	public WeChassisPhAssocDto removeWeChassisPhAssoc(WeChassisPhAssocDto weChassisPhAssoc) {
		getWeChassisPhAssocs().remove(weChassisPhAssoc);
		weChassisPhAssoc.setChassi(null);
		return weChassisPhAssoc;
	}
	public List<WeCsPortTermDto> getWeCsPortTerms() {
		return this.weCsPortTerms;
	}
	public void setWeCsPortTerms(List<WeCsPortTermDto> weCsPortTerms) {
		this.weCsPortTerms = weCsPortTerms;
	}
	public WeCsPortTermDto addWeCsPortTerm(WeCsPortTermDto weCsPortTerm) {
		getWeCsPortTerms().add(weCsPortTerm);
		weCsPortTerm.setChassi(this);
		return weCsPortTerm;
	}
	public WeCsPortTermDto removeWeCsPortTerm(WeCsPortTermDto weCsPortTerm) {
		getWeCsPortTerms().remove(weCsPortTerm);
		weCsPortTerm.setChassi(null);
		return weCsPortTerm;
	}
	public List<WePortPortAssocDto> getWePortPortAssocs1() {
		return this.wePortPortAssocs1;
	}
	public void setWePortPortAssocs1(List<WePortPortAssocDto> wePortPortAssocs1) {
		this.wePortPortAssocs1 = wePortPortAssocs1;
	}
	public WePortPortAssocDto addWePortPortAssocs1(WePortPortAssocDto wePortPortAssocs1) {
		getWePortPortAssocs1().add(wePortPortAssocs1);
		wePortPortAssocs1.setChassi1(this);
		return wePortPortAssocs1;
	}
	public WePortPortAssocDto removeWePortPortAssocs1(WePortPortAssocDto wePortPortAssocs1) {
		getWePortPortAssocs1().remove(wePortPortAssocs1);
		wePortPortAssocs1.setChassi1(null);
		return wePortPortAssocs1;
	}
	public List<WePortPortAssocDto> getWePortPortAssocs2() {
		return this.wePortPortAssocs2;
	}
	public void setWePortPortAssocs2(List<WePortPortAssocDto> wePortPortAssocs2) {
		this.wePortPortAssocs2 = wePortPortAssocs2;
	}
	public WePortPortAssocDto addWePortPortAssocs2(WePortPortAssocDto wePortPortAssocs2) {
		getWePortPortAssocs2().add(wePortPortAssocs2);
		wePortPortAssocs2.setChassi2(this);
		return wePortPortAssocs2;
	}
	public WePortPortAssocDto removeWePortPortAssocs2(WePortPortAssocDto wePortPortAssocs2) {
		getWePortPortAssocs2().remove(wePortPortAssocs2);
		wePortPortAssocs2.setChassi2(null);
		return wePortPortAssocs2;
	}
}
