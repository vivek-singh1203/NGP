package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the CABLE_SECTION_SELF_ASSOC database table.
 * 
 */

public class CableSectionSelfAssocDto  {
	private long id;
	private String childCsName;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String parentCsName;
	
	private CableSelfAssocSpecDto cableSelfAssocSpec;
	public CableSectionSelfAssocDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getChildCsName() {
		return this.childCsName;
	}
	public void setChildCsName(String childCsName) {
		this.childCsName = childCsName;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getParentCsName() {
		return this.parentCsName;
	}
	public void setParentCsName(String parentCsName) {
		this.parentCsName = parentCsName;
	}
	public CableSelfAssocSpecDto getCableSelfAssocSpec() {
		return this.cableSelfAssocSpec;
	}
	public void setCableSelfAssocSpec(CableSelfAssocSpecDto cableSelfAssocSpec) {
		this.cableSelfAssocSpec = cableSelfAssocSpec;
	}
}
