package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the BLOCK_CHAR database table.
 * 
 */

public class BlockCharDto  {
	private long id;
	private String charName;
	private String charValue;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	
	private BlockDto block;
	
	private EqSpecCharSpecDto eqSpecCharSpec;
	
	private EqSpecCharValueSpecDto eqSpecCharValueSpec;
	public BlockCharDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCharName() {
		return this.charName;
	}
	public void setCharName(String charName) {
		this.charName = charName;
	}
	public String getCharValue() {
		return this.charValue;
	}
	public void setCharValue(String charValue) {
		this.charValue = charValue;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public BlockDto getBlock() {
		return this.block;
	}
	public void setBlock(BlockDto block) {
		this.block = block;
	}
	public EqSpecCharSpecDto getEqSpecCharSpec() {
		return this.eqSpecCharSpec;
	}
	public void setEqSpecCharSpec(EqSpecCharSpecDto eqSpecCharSpec) {
		this.eqSpecCharSpec = eqSpecCharSpec;
	}
	public EqSpecCharValueSpecDto getEqSpecCharValueSpec() {
		return this.eqSpecCharValueSpec;
	}
	public void setEqSpecCharValueSpec(EqSpecCharValueSpecDto eqSpecCharValueSpec) {
		this.eqSpecCharValueSpec = eqSpecCharValueSpec;
	}
}
