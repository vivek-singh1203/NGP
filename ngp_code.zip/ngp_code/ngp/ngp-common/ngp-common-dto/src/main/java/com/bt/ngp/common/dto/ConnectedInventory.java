package com.bt.ngp.common.dto;

public class ConnectedInventory {

}
