package com.bt.ngp.common.dto;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Specifications {

	private double depth;

	private String depthUnit;

	private double diameter;

	private String diameterUnit;

	private String entityName;

	private double height;

	private String heightUnit;

	private String isOrderable;

	private double length;

	private String lengthUnit;

	private String manufacturerName;
	
	private String manufacturerCode;

	private double materialCostPerUnit;

	private String materialCostUnit;

	private String materialType;
	
	private String name;

	private BigDecimal noOfPositions;

	private double powerConsumption;

	private String powerConsumptionUnit;

	private double powerDissipation;

	private String powerDissipationUnit;

	private double powerRating;

	private String powerRatingUnit;

	private String powerSupply;

	private String specRemarks;

	private String specStatus;

	private String splitRatio;
	
	private String specVersion;

	private BigDecimal startPositionNum;

	private double volume;

	private String volumeUnit;

	private double weight;

	private String weightUnit;

	private double width;

	private String widthUnit;

	private String positionToOccupy;

	private String portSignalType;

	public double getDepth() {
		return depth;
	}

	public void setDepth(double depth) {
		this.depth = depth;
	}

	public String getDepthUnit() {
		return depthUnit;
	}

	public void setDepthUnit(String depthUnit) {
		this.depthUnit = depthUnit;
	}

	public double getDiameter() {
		return diameter;
	}

	public void setDiameter(double diameter) {
		this.diameter = diameter;
	}

	public String getDiameterUnit() {
		return diameterUnit;
	}

	public void setDiameterUnit(String diameterUnit) {
		this.diameterUnit = diameterUnit;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public String getHeightUnit() {
		return heightUnit;
	}

	public void setHeightUnit(String heightUnit) {
		this.heightUnit = heightUnit;
	}

	public String getIsOrderable() {
		return isOrderable;
	}

	public void setIsOrderable(String isOrderable) {
		this.isOrderable = isOrderable;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public String getLengthUnit() {
		return lengthUnit;
	}

	public void setLengthUnit(String lengthUnit) {
		this.lengthUnit = lengthUnit;
	}

	public String getManufacturerName() {
		return manufacturerName;
	}

	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}

	public double getMaterialCostPerUnit() {
		return materialCostPerUnit;
	}

	public void setMaterialCostPerUnit(double materialCostPerUnit) {
		this.materialCostPerUnit = materialCostPerUnit;
	}

	public String getMaterialCostUnit() {
		return materialCostUnit;
	}

	public void setMaterialCostUnit(String materialCostUnit) {
		this.materialCostUnit = materialCostUnit;
	}

	public String getMaterialType() {
		return materialType;
	}

	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}

	public BigDecimal getNoOfPositions() {
		return noOfPositions;
	}

	public void setNoOfPositions(BigDecimal noOfPositions) {
		this.noOfPositions = noOfPositions;
	}

	public double getPowerConsumption() {
		return powerConsumption;
	}

	public void setPowerConsumption(double powerConsumption) {
		this.powerConsumption = powerConsumption;
	}

	public String getPowerConsumptionUnit() {
		return powerConsumptionUnit;
	}

	public void setPowerConsumptionUnit(String powerConsumptionUnit) {
		this.powerConsumptionUnit = powerConsumptionUnit;
	}

	public double getPowerDissipation() {
		return powerDissipation;
	}

	public void setPowerDissipation(double powerDissipation) {
		this.powerDissipation = powerDissipation;
	}

	public String getPowerDissipationUnit() {
		return powerDissipationUnit;
	}

	public void setPowerDissipationUnit(String powerDissipationUnit) {
		this.powerDissipationUnit = powerDissipationUnit;
	}

	public double getPowerRating() {
		return powerRating;
	}

	public void setPowerRating(double powerRating) {
		this.powerRating = powerRating;
	}

	public String getPowerRatingUnit() {
		return powerRatingUnit;
	}

	public void setPowerRatingUnit(String powerRatingUnit) {
		this.powerRatingUnit = powerRatingUnit;
	}

	public String getPowerSupply() {
		return powerSupply;
	}

	public void setPowerSupply(String powerSupply) {
		this.powerSupply = powerSupply;
	}

	public String getSpecRemarks() {
		return specRemarks;
	}

	public void setSpecRemarks(String specRemarks) {
		this.specRemarks = specRemarks;
	}

	public String getSpecStatus() {
		return specStatus;
	}

	public void setSpecStatus(String specStatus) {
		this.specStatus = specStatus;
	}

	public String getSplitRatio() {
		return splitRatio;
	}

	public void setSplitRatio(String splitRatio) {
		this.splitRatio = splitRatio;
	}

	public BigDecimal getStartPositionNum() {
		return startPositionNum;
	}

	public void setStartPositionNum(BigDecimal startPositionNum) {
		this.startPositionNum = startPositionNum;
	}

	public double getVolume() {
		return volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public String getVolumeUnit() {
		return volumeUnit;
	}

	public void setVolumeUnit(String volumeUnit) {
		this.volumeUnit = volumeUnit;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getWeightUnit() {
		return weightUnit;
	}

	public void setWeightUnit(String weightUnit) {
		this.weightUnit = weightUnit;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public String getWidthUnit() {
		return widthUnit;
	}

	public void setWidthUnit(String widthUnit) {
		this.widthUnit = widthUnit;
	}

	public String getPositionToOccupy() {
		return positionToOccupy;
	}

	public void setPositionToOccupy(String positionToOccupy) {
		this.positionToOccupy = positionToOccupy;
	}

	public String getPortSignalType() {
		return portSignalType;
	}

	public void setPortSignalType(String portSignalType) {
		this.portSignalType = portSignalType;
	}

	public String getSpecVersion() {
		return specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getManufacturerCode() {
		return manufacturerCode;
	}

	public void setManufacturerCode(String manufacturerCode) {
		this.manufacturerCode = manufacturerCode;
	}

}
