package com.bt.ngp.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CABINET_SELF_ASSOC_SPEC database table.
 * 
 */

public class CabinetSelfAssocSpecDto  {
	private long id;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String noOfChildInstances;
	
	private List<CabinetSelfAssocDto> cabinetSelfAssocs;
	
		
	private StructureSpecDto structureSpec1;
	
		
	private StructureSpecDto structureSpec2;
	public CabinetSelfAssocSpecDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getNoOfChildInstances() {
		return this.noOfChildInstances;
	}
	public void setNoOfChildInstances(String noOfChildInstances) {
		this.noOfChildInstances = noOfChildInstances;
	}
	public List<CabinetSelfAssocDto> getCabinetSelfAssocs() {
		return this.cabinetSelfAssocs;
	}
	public void setCabinetSelfAssocs(List<CabinetSelfAssocDto> cabinetSelfAssocs) {
		this.cabinetSelfAssocs = cabinetSelfAssocs;
	}
	public CabinetSelfAssocDto addCabinetSelfAssoc(CabinetSelfAssocDto cabinetSelfAssoc) {
		getCabinetSelfAssocs().add(cabinetSelfAssoc);
		cabinetSelfAssoc.setCabinetSelfAssocSpec(this);
		return cabinetSelfAssoc;
	}
	public CabinetSelfAssocDto removeCabinetSelfAssoc(CabinetSelfAssocDto cabinetSelfAssoc) {
		getCabinetSelfAssocs().remove(cabinetSelfAssoc);
		cabinetSelfAssoc.setCabinetSelfAssocSpec(null);
		return cabinetSelfAssoc;
	}
	public StructureSpecDto getStructureSpec1() {
		return this.structureSpec1;
	}
	public void setStructureSpec1(StructureSpecDto structureSpec1) {
		this.structureSpec1 = structureSpec1;
	}
	public StructureSpecDto getStructureSpec2() {
		return this.structureSpec2;
	}
	public void setStructureSpec2(StructureSpecDto structureSpec2) {
		this.structureSpec2 = structureSpec2;
	}
}
