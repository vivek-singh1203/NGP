package com.bt.ngp.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the BLOCK_SELF_ASSOC_SPEC database table.
 * 
 */

public class BlockSelfAssocSpecDto  {
	private long id;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String noOfChildInstances;
	
	private List<BlockSelfAssocDto> blockSelfAssocs;
	
		
	private EqSpecDto eqSpec1;
	
		
	private EqSpecDto eqSpec2;
	public BlockSelfAssocSpecDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getNoOfChildInstances() {
		return this.noOfChildInstances;
	}
	public void setNoOfChildInstances(String noOfChildInstances) {
		this.noOfChildInstances = noOfChildInstances;
	}
	public List<BlockSelfAssocDto> getBlockSelfAssocs() {
		return this.blockSelfAssocs;
	}
	public void setBlockSelfAssocs(List<BlockSelfAssocDto> blockSelfAssocs) {
		this.blockSelfAssocs = blockSelfAssocs;
	}
	public BlockSelfAssocDto addBlockSelfAssoc(BlockSelfAssocDto blockSelfAssoc) {
		getBlockSelfAssocs().add(blockSelfAssoc);
		blockSelfAssoc.setBlockSelfAssocSpec(this);
		return blockSelfAssoc;
	}
	public BlockSelfAssocDto removeBlockSelfAssoc(BlockSelfAssocDto blockSelfAssoc) {
		getBlockSelfAssocs().remove(blockSelfAssoc);
		blockSelfAssoc.setBlockSelfAssocSpec(null);
		return blockSelfAssoc;
	}
	public EqSpecDto getEqSpec1() {
		return this.eqSpec1;
	}
	public void setEqSpec1(EqSpecDto eqSpec1) {
		this.eqSpec1 = eqSpec1;
	}
	public EqSpecDto getEqSpec2() {
		return this.eqSpec2;
	}
	public void setEqSpec2(EqSpecDto eqSpec2) {
		this.eqSpec2 = eqSpec2;
	}
}
