package com.bt.ngp.common.dto;

import java.util.List;

public class InventoryCharacteristics {
	
   protected List <Characteristics> characteristics ;

	public List<Characteristics> getCharacteristics() {
		return characteristics;
	}
	
	public void setCharacteristics(List<Characteristics> characteristics) {
		this.characteristics = characteristics;
	}
}
