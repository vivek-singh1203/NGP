package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the CABINET_CHAR database table.
 * 
 */

public class CabinetCharDto  {
	private long id;
	private String cabinetName;
	private String charName;
	private String charValue;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	
	private StructureSpecCharSpecDto structureSpecCharSpec;
	
	private StructureSpecCharValueSpecDto structureSpecCharValueSpec;
	public CabinetCharDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCabinetName() {
		return this.cabinetName;
	}
	public void setCabinetName(String cabinetName) {
		this.cabinetName = cabinetName;
	}
	public String getCharName() {
		return this.charName;
	}
	public void setCharName(String charName) {
		this.charName = charName;
	}
	public String getCharValue() {
		return this.charValue;
	}
	public void setCharValue(String charValue) {
		this.charValue = charValue;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public StructureSpecCharSpecDto getStructureSpecCharSpec() {
		return this.structureSpecCharSpec;
	}
	public void setStructureSpecCharSpec(StructureSpecCharSpecDto structureSpecCharSpec) {
		this.structureSpecCharSpec = structureSpecCharSpec;
	}
	public StructureSpecCharValueSpecDto getStructureSpecCharValueSpec() {
		return this.structureSpecCharValueSpec;
	}
	public void setStructureSpecCharValueSpec(StructureSpecCharValueSpecDto structureSpecCharValueSpec) {
		this.structureSpecCharValueSpec = structureSpecCharValueSpec;
	}
}
