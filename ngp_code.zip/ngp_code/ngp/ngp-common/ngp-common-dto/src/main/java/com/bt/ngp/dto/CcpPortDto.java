package com.bt.ngp.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CCP_PORTS database table.
 * 
 */

public class CcpPortDto  {
	private String name;
	private String alternateName;
	private String assetIdentifier;
	private String ccpName;
	private String createdBy;
	private Timestamp createdDate;
	private String dataQualityIndicator;
	private String faultState;
	private long id;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String portSeqNum;
	private String resource1141Code;
	private String resourceState;
	private String serialNumber;
	private String serviceState;
	private String userLabel;
	
	private List<CcpCsPortTermDto> ccpCsPortTerms;
	
	private List<CcpPluginPortAssocDto> ccpPluginPortAssocs;
	
	private PluginDto plugin;
	
		
	private PortSpecDto portSpec;
	
	private SpecCategoryDto specCategory;
	
	private SpecTypeDto specType;
	
	private List<CcpPortCharDto> ccpPortChars;
	
	private List<CcpPortPortAssocDto> ccpPortPortAssocs1;
	
	private List<CcpPortPortAssocDto> ccpPortPortAssocs2;
	public CcpPortDto() {
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAlternateName() {
		return this.alternateName;
	}
	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}
	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}
	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}
	public String getCcpName() {
		return this.ccpName;
	}
	public void setCcpName(String ccpName) {
		this.ccpName = ccpName;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}
	public String getFaultState() {
		return this.faultState;
	}
	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getPortSeqNum() {
		return this.portSeqNum;
	}
	public void setPortSeqNum(String portSeqNum) {
		this.portSeqNum = portSeqNum;
	}
	public String getResource1141Code() {
		return this.resource1141Code;
	}
	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}
	public String getResourceState() {
		return this.resourceState;
	}
	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}
	public String getSerialNumber() {
		return this.serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getServiceState() {
		return this.serviceState;
	}
	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}
	public String getUserLabel() {
		return this.userLabel;
	}
	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}
	public List<CcpCsPortTermDto> getCcpCsPortTerms() {
		return this.ccpCsPortTerms;
	}
	public void setCcpCsPortTerms(List<CcpCsPortTermDto> ccpCsPortTerms) {
		this.ccpCsPortTerms = ccpCsPortTerms;
	}
	public CcpCsPortTermDto addCcpCsPortTerm(CcpCsPortTermDto ccpCsPortTerm) {
		getCcpCsPortTerms().add(ccpCsPortTerm);
		ccpCsPortTerm.setCcpPort(this);
		return ccpCsPortTerm;
	}
	public CcpCsPortTermDto removeCcpCsPortTerm(CcpCsPortTermDto ccpCsPortTerm) {
		getCcpCsPortTerms().remove(ccpCsPortTerm);
		ccpCsPortTerm.setCcpPort(null);
		return ccpCsPortTerm;
	}
	public List<CcpPluginPortAssocDto> getCcpPluginPortAssocs() {
		return this.ccpPluginPortAssocs;
	}
	public void setCcpPluginPortAssocs(List<CcpPluginPortAssocDto> ccpPluginPortAssocs) {
		this.ccpPluginPortAssocs = ccpPluginPortAssocs;
	}
	public CcpPluginPortAssocDto addCcpPluginPortAssoc(CcpPluginPortAssocDto ccpPluginPortAssoc) {
		getCcpPluginPortAssocs().add(ccpPluginPortAssoc);
		ccpPluginPortAssoc.setCcpPort(this);
		return ccpPluginPortAssoc;
	}
	public CcpPluginPortAssocDto removeCcpPluginPortAssoc(CcpPluginPortAssocDto ccpPluginPortAssoc) {
		getCcpPluginPortAssocs().remove(ccpPluginPortAssoc);
		ccpPluginPortAssoc.setCcpPort(null);
		return ccpPluginPortAssoc;
	}
	public PluginDto getPlugin() {
		return this.plugin;
	}
	public void setPlugin(PluginDto plugin) {
		this.plugin = plugin;
	}
	public PortSpecDto getPortSpec() {
		return this.portSpec;
	}
	public void setPortSpec(PortSpecDto portSpec) {
		this.portSpec = portSpec;
	}
	public SpecCategoryDto getSpecCategory() {
		return this.specCategory;
	}
	public void setSpecCategory(SpecCategoryDto specCategory) {
		this.specCategory = specCategory;
	}
	public SpecTypeDto getSpecType() {
		return this.specType;
	}
	public void setSpecType(SpecTypeDto specType) {
		this.specType = specType;
	}
	public List<CcpPortCharDto> getCcpPortChars() {
		return this.ccpPortChars;
	}
	public void setCcpPortChars(List<CcpPortCharDto> ccpPortChars) {
		this.ccpPortChars = ccpPortChars;
	}
	public CcpPortCharDto addCcpPortChar(CcpPortCharDto ccpPortChar) {
		getCcpPortChars().add(ccpPortChar);
		ccpPortChar.setCcpPort(this);
		return ccpPortChar;
	}
	public CcpPortCharDto removeCcpPortChar(CcpPortCharDto ccpPortChar) {
		getCcpPortChars().remove(ccpPortChar);
		ccpPortChar.setCcpPort(null);
		return ccpPortChar;
	}
	public List<CcpPortPortAssocDto> getCcpPortPortAssocs1() {
		return this.ccpPortPortAssocs1;
	}
	public void setCcpPortPortAssocs1(List<CcpPortPortAssocDto> ccpPortPortAssocs1) {
		this.ccpPortPortAssocs1 = ccpPortPortAssocs1;
	}
	public CcpPortPortAssocDto addCcpPortPortAssocs1(CcpPortPortAssocDto ccpPortPortAssocs1) {
		getCcpPortPortAssocs1().add(ccpPortPortAssocs1);
		ccpPortPortAssocs1.setCcpPort1(this);
		return ccpPortPortAssocs1;
	}
	public CcpPortPortAssocDto removeCcpPortPortAssocs1(CcpPortPortAssocDto ccpPortPortAssocs1) {
		getCcpPortPortAssocs1().remove(ccpPortPortAssocs1);
		ccpPortPortAssocs1.setCcpPort1(null);
		return ccpPortPortAssocs1;
	}
	public List<CcpPortPortAssocDto> getCcpPortPortAssocs2() {
		return this.ccpPortPortAssocs2;
	}
	public void setCcpPortPortAssocs2(List<CcpPortPortAssocDto> ccpPortPortAssocs2) {
		this.ccpPortPortAssocs2 = ccpPortPortAssocs2;
	}
	public CcpPortPortAssocDto addCcpPortPortAssocs2(CcpPortPortAssocDto ccpPortPortAssocs2) {
		getCcpPortPortAssocs2().add(ccpPortPortAssocs2);
		ccpPortPortAssocs2.setCcpPort2(this);
		return ccpPortPortAssocs2;
	}
	public CcpPortPortAssocDto removeCcpPortPortAssocs2(CcpPortPortAssocDto ccpPortPortAssocs2) {
		getCcpPortPortAssocs2().remove(ccpPortPortAssocs2);
		ccpPortPortAssocs2.setCcpPort2(null);
		return ccpPortPortAssocs2;
	}
}
