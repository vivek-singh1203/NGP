package com.bt.ngp.dto;

import java.sql.Timestamp;
import java.util.List;
/**
 * The persistent class for the CB_SELF_ASSOC_SPEC database table.
 * 
 */

public class CbSelfAssocSpecDto  {
	private long id;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	private String noOfChildInstances;
	
	private List<CbSelfAssocDto> cbSelfAssocs;
	
		
	private CbSpecDto cbSpec1;
	
		
	private CbSpecDto cbSpec2;
	public CbSelfAssocSpecDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public String getNoOfChildInstances() {
		return this.noOfChildInstances;
	}
	public void setNoOfChildInstances(String noOfChildInstances) {
		this.noOfChildInstances = noOfChildInstances;
	}
	public List<CbSelfAssocDto> getCbSelfAssocs() {
		return this.cbSelfAssocs;
	}
	public void setCbSelfAssocs(List<CbSelfAssocDto> cbSelfAssocs) {
		this.cbSelfAssocs = cbSelfAssocs;
	}
	public CbSelfAssocDto addCbSelfAssoc(CbSelfAssocDto cbSelfAssoc) {
		getCbSelfAssocs().add(cbSelfAssoc);
		cbSelfAssoc.setCbSelfAssocSpec(this);
		return cbSelfAssoc;
	}
	public CbSelfAssocDto removeCbSelfAssoc(CbSelfAssocDto cbSelfAssoc) {
		getCbSelfAssocs().remove(cbSelfAssoc);
		cbSelfAssoc.setCbSelfAssocSpec(null);
		return cbSelfAssoc;
	}
	public CbSpecDto getCbSpec1() {
		return this.cbSpec1;
	}
	public void setCbSpec1(CbSpecDto cbSpec1) {
		this.cbSpec1 = cbSpec1;
	}
	public CbSpecDto getCbSpec2() {
		return this.cbSpec2;
	}
	public void setCbSpec2(CbSpecDto cbSpec2) {
		this.cbSpec2 = cbSpec2;
	}
}
