package com.bt.ngp.dto;
import java.sql.Timestamp;
/**
 * The persistent class for the CB_CHAR database table.
 * 
 */

public class CbCharDto  {
	private long id;
	private String charName;
	private String charValue;
	private String createdBy;
	private Timestamp createdDate;
	private String lastModifiedBy;
	private Timestamp lastModifiedDate;
	
	private CbSpecCharSpecDto cbSpecCharSpec;
	
	private CbSpecCharValueSpecDto cbSpecCharValueSpec;
	
	private ConductorBundleDto conductorBundle;
	public CbCharDto() {
	}
	public long getId() {
		return this.id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCharName() {
		return this.charName;
	}
	public void setCharName(String charName) {
		this.charName = charName;
	}
	public String getCharValue() {
		return this.charValue;
	}
	public void setCharValue(String charValue) {
		this.charValue = charValue;
	}
	public String getCreatedBy() {
		return this.createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Timestamp getCreatedDate() {
		return this.createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}
	public CbSpecCharSpecDto getCbSpecCharSpec() {
		return this.cbSpecCharSpec;
	}
	public void setCbSpecCharSpec(CbSpecCharSpecDto cbSpecCharSpec) {
		this.cbSpecCharSpec = cbSpecCharSpec;
	}
	public CbSpecCharValueSpecDto getCbSpecCharValueSpec() {
		return this.cbSpecCharValueSpec;
	}
	public void setCbSpecCharValueSpec(CbSpecCharValueSpecDto cbSpecCharValueSpec) {
		this.cbSpecCharValueSpec = cbSpecCharValueSpec;
	}
	public ConductorBundleDto getConductorBundle() {
		return this.conductorBundle;
	}
	public void setConductorBundle(ConductorBundleDto conductorBundle) {
		this.conductorBundle = conductorBundle;
	}
}
