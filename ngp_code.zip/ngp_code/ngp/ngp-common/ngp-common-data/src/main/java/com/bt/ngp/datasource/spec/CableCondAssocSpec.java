package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the CABLE_COND_ASSOC_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CABLE_COND_ASSOC_SPEC")
@NamedQuery(name="CableCondAssocSpec.findAll", query="SELECT c FROM CableCondAssocSpec c")
public class CableCondAssocSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CABLE_ENTITY_NAME", length=30)
	private String cableEntityName;

	@Column(name="COND_ENTITY_NAME", length=30)
	private String condEntityName;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="NO_OF_COND_SPEC_INSTANCES", precision=38)
	private BigDecimal noOfCondSpecInstances;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="CABLE_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory1;

	//bi-directional many-to-one association to CableSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="CABLE_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="CABLE_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private CableSpec cableSpec;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="CABLE_SPEC_TYPE_NAME")
	private SpecType specType1;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="COND_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory2;

	//bi-directional many-to-one association to ConductorSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="COND_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="COND_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private ConductorSpec conductorSpec;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="COND_SPEC_TYPE_NAME")
	private SpecType specType2;

	//bi-directional many-to-one association to CableHierarchySpec
	@OneToMany(mappedBy="cableCondAssocSpec")
	private List<CableHierarchySpec> cableHierarchySpecs;

	public CableCondAssocSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCableEntityName() {
		return this.cableEntityName;
	}

	public void setCableEntityName(String cableEntityName) {
		this.cableEntityName = cableEntityName;
	}

	public String getCondEntityName() {
		return this.condEntityName;
	}

	public void setCondEntityName(String condEntityName) {
		this.condEntityName = condEntityName;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getNoOfCondSpecInstances() {
		return this.noOfCondSpecInstances;
	}

	public void setNoOfCondSpecInstances(BigDecimal noOfCondSpecInstances) {
		this.noOfCondSpecInstances = noOfCondSpecInstances;
	}

	public SpecCategory getSpecCategory1() {
		return this.specCategory1;
	}

	public void setSpecCategory1(SpecCategory specCategory1) {
		this.specCategory1 = specCategory1;
	}

	public CableSpec getCableSpec() {
		return this.cableSpec;
	}

	public void setCableSpec(CableSpec cableSpec) {
		this.cableSpec = cableSpec;
	}

	public SpecType getSpecType1() {
		return this.specType1;
	}

	public void setSpecType1(SpecType specType1) {
		this.specType1 = specType1;
	}

	public SpecCategory getSpecCategory2() {
		return this.specCategory2;
	}

	public void setSpecCategory2(SpecCategory specCategory2) {
		this.specCategory2 = specCategory2;
	}

	public ConductorSpec getConductorSpec() {
		return this.conductorSpec;
	}

	public void setConductorSpec(ConductorSpec conductorSpec) {
		this.conductorSpec = conductorSpec;
	}

	public SpecType getSpecType2() {
		return this.specType2;
	}

	public void setSpecType2(SpecType specType2) {
		this.specType2 = specType2;
	}

	public List<CableHierarchySpec> getCableHierarchySpecs() {
		return this.cableHierarchySpecs;
	}

	public void setCableHierarchySpecs(List<CableHierarchySpec> cableHierarchySpecs) {
		this.cableHierarchySpecs = cableHierarchySpecs;
	}

	public CableHierarchySpec addCableHierarchySpec(CableHierarchySpec cableHierarchySpec) {
		getCableHierarchySpecs().add(cableHierarchySpec);
		cableHierarchySpec.setCableCondAssocSpec(this);

		return cableHierarchySpec;
	}

	public CableHierarchySpec removeCableHierarchySpec(CableHierarchySpec cableHierarchySpec) {
		getCableHierarchySpecs().remove(cableHierarchySpec);
		cableHierarchySpec.setCableCondAssocSpec(null);

		return cableHierarchySpec;
	}

}