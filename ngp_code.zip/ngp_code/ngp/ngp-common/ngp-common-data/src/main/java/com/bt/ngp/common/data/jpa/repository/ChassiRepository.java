package com.bt.ngp.common.data.jpa.repository;

import com.bt.ngp.datasource.entities.Chassi;

public interface ChassiRepository extends CommonOperation<Chassi>{

}
