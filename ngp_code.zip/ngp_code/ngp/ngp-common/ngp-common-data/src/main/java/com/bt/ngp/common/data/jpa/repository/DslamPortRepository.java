package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.DslamPort;
import com.bt.ngp.userdefined.entities.PortStatisticsDslam;

@Repository
public interface DslamPortRepository extends CommonOperation<DslamPort> {
	@Query(name = "DslamPortRepository.fetchPortCountInPlugin", nativeQuery = false)
	public List<PortStatisticsDslam> fetchPortCount(
			@Param("dslamPort") DslamPort dslamPort);
}