/**
 * This package is for creating case specific classes which can be used for handling scenarios where we will get filtered or sql function based data
 *
 * @since 30 Jan 2018
 * @author Aditya Ajmera 609734641
 */

/**
 * @author 609734641
 *
 */
package com.bt.ngp.userdefined.entities;