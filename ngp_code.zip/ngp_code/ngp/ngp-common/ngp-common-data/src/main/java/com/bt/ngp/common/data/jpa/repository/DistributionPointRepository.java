package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.DistributionPoint;
import com.bt.ngp.datasource.entities.Exchange;


@Repository
public interface DistributionPointRepository extends CommonOperation<DistributionPoint>{

	@Query(name="DistributionPointRepository.findEquipmentWithoutCableSectionAssoc", nativeQuery=true)
	List<DistributionPoint> findEquipmentWithoutCableSectionAssoc(@Param("exchangeCode") String exchange1141Code);
	
	List<DistributionPoint> findByExchangeAndDpStructureAssocsIsNull(@Param("exchange") Exchange exchange);
}
