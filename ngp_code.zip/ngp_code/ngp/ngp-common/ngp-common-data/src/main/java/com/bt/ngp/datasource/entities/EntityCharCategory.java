package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the ENTITY_CHAR_CATEGORY database table.
 * 
 */
@javax.persistence.Entity
@Table(name="ENTITY_CHAR_CATEGORY")
@NamedQuery(name="EntityCharCategory.findAll", query="SELECT e FROM EntityCharCategory e")
public class EntityCharCategory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=30)
	private String name;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(length=50)
	private String description;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to EntityTypeCharSet
	@OneToMany(mappedBy="entityCharCategory")
	private List<EntityTypeCharSet> entityTypeCharSets;

	public EntityCharCategory() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public List<EntityTypeCharSet> getEntityTypeCharSets() {
		return this.entityTypeCharSets;
	}

	public void setEntityTypeCharSets(List<EntityTypeCharSet> entityTypeCharSets) {
		this.entityTypeCharSets = entityTypeCharSets;
	}

	public EntityTypeCharSet addEntityTypeCharSet(EntityTypeCharSet entityTypeCharSet) {
		getEntityTypeCharSets().add(entityTypeCharSet);
		entityTypeCharSet.setEntityCharCategory(this);

		return entityTypeCharSet;
	}

	public EntityTypeCharSet removeEntityTypeCharSet(EntityTypeCharSet entityTypeCharSet) {
		getEntityTypeCharSets().remove(entityTypeCharSet);
		entityTypeCharSet.setEntityCharCategory(null);

		return entityTypeCharSet;
	}

}