/**
 * This method is for mapping PortStatistics for Customer Premise EQuipment.
 *
 * @since 5 Feb 2018
 * @author Aditya Ajmera 609734641
 */

package com.bt.ngp.userdefined.entities;

import com.bt.ngp.datasource.entities.CustomerPremiseEquipment;
import com.bt.ngp.datasource.entities.Plugin;

/**
 * @author 609734641
 *
 */
public class PortStatisticsCpe {
	private CustomerPremiseEquipment customerPremiseEquipment;

	private Plugin plugin;

	private long portCount;

	/**
	 * default constructor
	 */
	public PortStatisticsCpe() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param customerPremiseEquipment
	 * @param plugin
	 * @param portCount
	 */
	public PortStatisticsCpe(CustomerPremiseEquipment customerPremiseEquipment,
			Plugin plugin, long portCount) {
		super();
		this.customerPremiseEquipment = customerPremiseEquipment;
		this.plugin = plugin;
		this.portCount = portCount;
	}

	/**
	 * @return the customerPremiseEquipment
	 */
	public CustomerPremiseEquipment getCustomerPremiseEquipment() {
		return customerPremiseEquipment;
	}

	/**
	 * @param customerPremiseEquipment the customerPremiseEquipment to set
	 */
	public void setCustomerPremiseEquipment(
			CustomerPremiseEquipment customerPremiseEquipment) {
		this.customerPremiseEquipment = customerPremiseEquipment;
	}

	/**
	 * @return the plugin
	 */
	public Plugin getPlugin() {
		return plugin;
	}

	/**
	 * @param plugin the plugin to set
	 */
	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

	/**
	 * @return the portCount
	 */
	public long getPortCount() {
		return portCount;
	}

	/**
	 * @param portCount the portCount to set
	 */
	public void setPortCount(long portCount) {
		this.portCount = portCount;
	}
}
