package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.WeCsCondSplicing;

@Repository
public interface WeCsCondSplicingRepository extends SqlRepository<WeCsCondSplicing> {
	public List<WeCsCondSplicing> findByOrigCsNameAndTermCsName(CableSection origCsName, CableSection termCsName);

	@Transactional
	@Modifying
	@Query(name = "WeCsCondSplicingRepository.deleteWeCableConductorSplicingByNameOfWiredEntities", nativeQuery = true)
	public int deleteWeCableConductorSplicing(@Param("weCsCondSplicing") WeCsCondSplicing weCsCondSplicing);

	@Query(name = "WeCsCondSplicingRepository.findConductorSplicingOriginating")
	public List<WeCsCondSplicing> findOriginatingConductorSplicing(
			@Param("weCsCondSplicing") WeCsCondSplicing weCsCondSplicing);

	@Query(name = "WeCsCondSplicingRepository.findConductorSplicingTerminating")
	public List<WeCsCondSplicing> findTerminatingConductorSplicing(
			@Param("weCsCondSplicing") WeCsCondSplicing weCsCondSplicing);

	public List<WeCsCondSplicing> findByOrigParCsName(CableSection origParCsName);

	public List<WeCsCondSplicing> findByTermParCsName(CableSection termParCsName);

	public WeCsCondSplicing findByOrigParCsNameAndOrigCsNameAndSplicingResource(CableSection origParCsName,
			CableSection origCsName, String splicingResource);

	public WeCsCondSplicing findByTermParCsNameAndTermCsNameAndSplicingResource(CableSection termParCsName,
			CableSection termCsName, String splicingResource);

}
