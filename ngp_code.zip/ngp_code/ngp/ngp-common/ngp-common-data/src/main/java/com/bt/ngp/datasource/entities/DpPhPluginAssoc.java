package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the DP_PH_PLUGIN_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DP_PH_PLUGIN_ASSOC")
@NamedQuery(name="DpPhPluginAssoc.findAll", query="SELECT d FROM DpPhPluginAssoc d")
public class DpPhPluginAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="HOLDER_COMP_ASSOC_SPEC_ID", length=50)
	private String holderCompAssocSpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to DpHierarchy
	@OneToMany(mappedBy="dpPhPluginAssoc")
	private List<DpHierarchy> dpHierarchies;

	//bi-directional many-to-one association to DistributionPoint
	@ManyToOne
	@JoinColumn(name="DP_NAME")
	private DistributionPoint distributionPoint;

	//bi-directional many-to-one association to PluginHolder
	@ManyToOne
	@JoinColumn(name="PH_NAME")
	private PluginHolder pluginHolder;

	//bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	public DpPhPluginAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getHolderCompAssocSpecId() {
		return this.holderCompAssocSpecId;
	}

	public void setHolderCompAssocSpecId(String holderCompAssocSpecId) {
		this.holderCompAssocSpecId = holderCompAssocSpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public List<DpHierarchy> getDpHierarchies() {
		return this.dpHierarchies;
	}

	public void setDpHierarchies(List<DpHierarchy> dpHierarchies) {
		this.dpHierarchies = dpHierarchies;
	}

	public DpHierarchy addDpHierarchy(DpHierarchy dpHierarchy) {
		getDpHierarchies().add(dpHierarchy);
		dpHierarchy.setDpPhPluginAssoc(this);

		return dpHierarchy;
	}

	public DpHierarchy removeDpHierarchy(DpHierarchy dpHierarchy) {
		getDpHierarchies().remove(dpHierarchy);
		dpHierarchy.setDpPhPluginAssoc(null);

		return dpHierarchy;
	}

	public DistributionPoint getDistributionPoint() {
		return this.distributionPoint;
	}

	public void setDistributionPoint(DistributionPoint distributionPoint) {
		this.distributionPoint = distributionPoint;
	}

	public PluginHolder getPluginHolder() {
		return this.pluginHolder;
	}

	public void setPluginHolder(PluginHolder pluginHolder) {
		this.pluginHolder = pluginHolder;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

}