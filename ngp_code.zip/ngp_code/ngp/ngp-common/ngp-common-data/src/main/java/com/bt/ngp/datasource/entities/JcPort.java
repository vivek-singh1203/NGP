package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the JC_PORTS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="JC_PORTS")
@NamedQuery(name="JcPort.findAll", query="SELECT j FROM JcPort j")
public class JcPort implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal portSeqNum;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to JcCsPortTerm
	@OneToMany(mappedBy="jcPort",fetch=FetchType.LAZY)
	private List<JcCsPortTerm> jcCsPortTerms;

	//bi-directional many-to-one association to JcPluginPortAssoc
	@OneToMany(mappedBy="jcPort",fetch=FetchType.LAZY)
	private List<JcPluginPortAssoc> jcPluginPortAssocs;

	//bi-directional many-to-one association to JointClosure
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="JC_NAME")
	private JointClosure jointClosure;

	//bi-directional many-to-one association to Plugin
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	//bi-directional many-to-one association to JcPortChar
	@OneToMany(mappedBy="jcPort" ,fetch=FetchType.LAZY)
	private List<JcPortChar> jcPortChars;

	//bi-directional many-to-one association to JcPortPortAssoc
	@OneToMany(mappedBy="jcPort1",fetch=FetchType.LAZY)
	private List<JcPortPortAssoc> jcPortPortAssocs1;

	//bi-directional many-to-one association to JcPortPortAssoc
	@OneToMany(mappedBy="jcPort2",fetch=FetchType.LAZY)
	private List<JcPortPortAssoc> jcPortPortAssocs2;

	public JcPort() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortSeqNum() {
		return this.portSeqNum;
	}

	public void setPortSeqNum(BigDecimal portSeqNum) {
		this.portSeqNum = portSeqNum;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<JcCsPortTerm> getJcCsPortTerms() {
		return this.jcCsPortTerms;
	}

	public void setJcCsPortTerms(List<JcCsPortTerm> jcCsPortTerms) {
		this.jcCsPortTerms = jcCsPortTerms;
	}

	public JcCsPortTerm addJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		getJcCsPortTerms().add(jcCsPortTerm);
		jcCsPortTerm.setJcPort(this);

		return jcCsPortTerm;
	}

	public JcCsPortTerm removeJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		getJcCsPortTerms().remove(jcCsPortTerm);
		jcCsPortTerm.setJcPort(null);

		return jcCsPortTerm;
	}

	public List<JcPluginPortAssoc> getJcPluginPortAssocs() {
		return this.jcPluginPortAssocs;
	}

	public void setJcPluginPortAssocs(List<JcPluginPortAssoc> jcPluginPortAssocs) {
		this.jcPluginPortAssocs = jcPluginPortAssocs;
	}

	public JcPluginPortAssoc addJcPluginPortAssoc(JcPluginPortAssoc jcPluginPortAssoc) {
		getJcPluginPortAssocs().add(jcPluginPortAssoc);
		jcPluginPortAssoc.setJcPort(this);

		return jcPluginPortAssoc;
	}

	public JcPluginPortAssoc removeJcPluginPortAssoc(JcPluginPortAssoc jcPluginPortAssoc) {
		getJcPluginPortAssocs().remove(jcPluginPortAssoc);
		jcPluginPortAssoc.setJcPort(null);

		return jcPluginPortAssoc;
	}

	public JointClosure getJointClosure() {
		return this.jointClosure;
	}

	public void setJointClosure(JointClosure jointClosure) {
		this.jointClosure = jointClosure;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

	public List<JcPortChar> getJcPortChars() {
		return this.jcPortChars;
	}

	public void setJcPortChars(List<JcPortChar> jcPortChars) {
		this.jcPortChars = jcPortChars;
	}

	public JcPortChar addJcPortChar(JcPortChar jcPortChar) {
		getJcPortChars().add(jcPortChar);
		jcPortChar.setJcPort(this);

		return jcPortChar;
	}

	public JcPortChar removeJcPortChar(JcPortChar jcPortChar) {
		getJcPortChars().remove(jcPortChar);
		jcPortChar.setJcPort(null);

		return jcPortChar;
	}

	public List<JcPortPortAssoc> getJcPortPortAssocs1() {
		return this.jcPortPortAssocs1;
	}

	public void setJcPortPortAssocs1(List<JcPortPortAssoc> jcPortPortAssocs1) {
		this.jcPortPortAssocs1 = jcPortPortAssocs1;
	}

	public JcPortPortAssoc addJcPortPortAssocs1(JcPortPortAssoc jcPortPortAssocs1) {
		getJcPortPortAssocs1().add(jcPortPortAssocs1);
		jcPortPortAssocs1.setJcPort1(this);

		return jcPortPortAssocs1;
	}

	public JcPortPortAssoc removeJcPortPortAssocs1(JcPortPortAssoc jcPortPortAssocs1) {
		getJcPortPortAssocs1().remove(jcPortPortAssocs1);
		jcPortPortAssocs1.setJcPort1(null);

		return jcPortPortAssocs1;
	}

	public List<JcPortPortAssoc> getJcPortPortAssocs2() {
		return this.jcPortPortAssocs2;
	}

	public void setJcPortPortAssocs2(List<JcPortPortAssoc> jcPortPortAssocs2) {
		this.jcPortPortAssocs2 = jcPortPortAssocs2;
	}

	public JcPortPortAssoc addJcPortPortAssocs2(JcPortPortAssoc jcPortPortAssocs2) {
		getJcPortPortAssocs2().add(jcPortPortAssocs2);
		jcPortPortAssocs2.setJcPort2(this);

		return jcPortPortAssocs2;
	}

	public JcPortPortAssoc removeJcPortPortAssocs2(JcPortPortAssoc jcPortPortAssocs2) {
		getJcPortPortAssocs2().remove(jcPortPortAssocs2);
		jcPortPortAssocs2.setJcPort2(null);

		return jcPortPortAssocs2;
	}

}