package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the JCHAMBER_SELF_ASSOC_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="JCHAMBER_SELF_ASSOC_SPEC")
@NamedQuery(name="JchamberSelfAssocSpec.findAll", query="SELECT j FROM JchamberSelfAssocSpec j")
public class JchamberSelfAssocSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="NO_OF_CHILD_INSTANCES", nullable=false, precision=38)
	private BigDecimal noOfChildInstances;

	//bi-directional many-to-one association to StructureSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="CHILD_JCHAMBER_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="CHILD_JCHAMBER_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private StructureSpec structureSpec1;

	//bi-directional many-to-one association to StructureSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="PARENT_JCHAMBER_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="PARENT_JCHAMBER_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private StructureSpec structureSpec2;

	public JchamberSelfAssocSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getNoOfChildInstances() {
		return this.noOfChildInstances;
	}

	public void setNoOfChildInstances(BigDecimal noOfChildInstances) {
		this.noOfChildInstances = noOfChildInstances;
	}

	public StructureSpec getStructureSpec1() {
		return this.structureSpec1;
	}

	public void setStructureSpec1(StructureSpec structureSpec1) {
		this.structureSpec1 = structureSpec1;
	}

	public StructureSpec getStructureSpec2() {
		return this.structureSpec2;
	}

	public void setStructureSpec2(StructureSpec structureSpec2) {
		this.structureSpec2 = structureSpec2;
	}

}