package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.Exchange;
import com.bt.ngp.datasource.entities.NetworkTerminatingEquipment;

@Repository
public interface NteRepository extends CommonOperation<NetworkTerminatingEquipment>{

	@Query(name="NteRepository.findEquipmentWithoutCableSectionAssoc", nativeQuery=true)
	List<NetworkTerminatingEquipment> findEquipmentWithoutCableSectionAssoc(@Param("exchangeCode") String exchange1141Code);
	
	List<NetworkTerminatingEquipment> findByExchangeAndNteStructureAssocsIsNull(@Param("exchange") Exchange exchange);
}
