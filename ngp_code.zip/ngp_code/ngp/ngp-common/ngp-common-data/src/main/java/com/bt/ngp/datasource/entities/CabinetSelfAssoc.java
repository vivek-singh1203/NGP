package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;


/**
 * The persistent class for the CABINET_SELF_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CABINET_SELF_ASSOC")
@NamedQuery(name="CabinetSelfAssoc.findAll", query="SELECT c FROM CabinetSelfAssoc c")
public class CabinetSelfAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private long id;

	@Column(name="CABINET_SELF_ASSOC_SPEC_ID", length=50)
	private java.math.BigDecimal cabinetSelfAssocSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to Cabinet
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CHILD_CABINET_NAME")
	private Cabinet childCabinet;

	//bi-directional many-to-one association to Cabinet
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PARENT_CABINET_NAME")
	private Cabinet parentCabinet;

	public CabinetSelfAssoc() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public java.math.BigDecimal getCabinetSelfAssocSpecId() {
		return this.cabinetSelfAssocSpecId;
	}

	public void setCabinetSelfAssocSpecId(java.math.BigDecimal cabinetSelfAssocSpecId) {
		this.cabinetSelfAssocSpecId = cabinetSelfAssocSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Cabinet getChildCabinet() {
		return this.childCabinet;
	}

	public void setChildCabinet(Cabinet childCabinet) {
		this.childCabinet = childCabinet;
	}

	public Cabinet getParentCabinet() {
		return this.parentCabinet;
	}

	public void setParentCabinet(Cabinet parentCabinet) {
		this.parentCabinet = parentCabinet;
	}

}