package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the EQ_SPEC_ROLE_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="EQ_SPEC_ROLE_SPEC")
@NamedQuery(name="EqSpecRoleSpec.findAll", query="SELECT e FROM EqSpecRoleSpec e")
public class EqSpecRoleSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to EqRoleSpec
	@ManyToOne
	@JoinColumn(name="ROLE_SPEC_NAME", nullable=false)
	private EqRoleSpec eqRoleSpec;

	//bi-directional many-to-one association to EqSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="EQ_SPEC_NAME", referencedColumnName="NAME", nullable=false),
		@JoinColumn(name="EQ_SPEC_VERSION", referencedColumnName="SPEC_VERSION", nullable=false)
		})
	private EqSpec eqSpec;

	public EqSpecRoleSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public EqRoleSpec getEqRoleSpec() {
		return this.eqRoleSpec;
	}

	public void setEqRoleSpec(EqRoleSpec eqRoleSpec) {
		this.eqRoleSpec = eqRoleSpec;
	}

	public EqSpec getEqSpec() {
		return this.eqSpec;
	}

	public void setEqSpec(EqSpec eqSpec) {
		this.eqSpec = eqSpec;
	}

}