package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.Chassi;
import com.bt.ngp.datasource.entities.Conductor;
import com.bt.ngp.datasource.entities.ConductorBundle;
import com.bt.ngp.datasource.entities.MfnCsPortTerm;
import com.bt.ngp.datasource.entities.MfnPort;
import com.bt.ngp.datasource.entities.MultiFunctionalNode;
import com.bt.ngp.datasource.entities.Plugin;

@Repository
public interface MfnCsPortTermRepository extends SqlRepository<MfnCsPortTerm> {

	public MfnCsPortTerm findByMultiFunctionalNodeAndChassiAndPluginAndMfnPortAndCableSectionAndConductorBundleAndConductor(
			MultiFunctionalNode multiFunctionalNode, Chassi chassi, Plugin plugin, MfnPort mfnPort,
			CableSection cableSection, ConductorBundle conductorBundle, Conductor conductor);

	@Query(name = "MfnCsPortTermRepository.findMfnCsPortTerm", nativeQuery = true)
	List<MfnCsPortTerm> findMfnCsPortTerm(@Param("termObj") MfnCsPortTerm termObj);

	@Query(name = "MfnCsPortTermRepository.fetchViaMfnCsCbCond", nativeQuery = true)
	public MfnCsPortTerm fetchMfnCsPortTerm(@Param("mfnCsPortTerm") MfnCsPortTerm mfnCsPortTerm);

	List<MfnCsPortTerm> findByMultiFunctionalNode(
			@Param("multiFunctionalNode") MultiFunctionalNode multiFunctionalNode);

	@Query(name = "MfnCsPortTermRepository.findByConductorAndTerminationType")
	List<MfnCsPortTerm> findByConductorAndTerminationType(@Param("mfnCsPortTermObj") MfnCsPortTerm mfnCsPortTermObj);

	@Query(name = "MfnCsPortTermRepository.findByCableSectionAndPort")
	List<MfnCsPortTerm> findByCableSectionAndPort(@Param("mfnCsPortTermObj") MfnCsPortTerm mfnCsPortTermObj);

	@Query(name = "MfnCsPortTermRepository.findByMfnCableAndConductor")
	List<MfnCsPortTerm> findByMfnCableAndConductor(@Param("mfnCsPortTerm") MfnCsPortTerm mfnCsPortTerm);
}
