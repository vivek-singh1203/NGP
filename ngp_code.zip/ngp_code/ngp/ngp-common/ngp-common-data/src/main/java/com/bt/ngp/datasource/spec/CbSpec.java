package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the CB_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CB_SPEC")
@NamedQuery(name="CbSpec.findAll", query="SELECT c FROM CbSpec c")
public class CbSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private CbSpecPK cbSpecPKId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DEPTH", precision=126)
	private Double depth;

	@Column(name="DEPTH_UNIT", length=10)
	private String depthUnit;

	@Column(name="DIAMETER",precision=126)
	private Double diameter;

	@Column(name="DIAMETER_UNIT", length=10)
	private String diameterUnit;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(name="HEIGHT",precision=126)
	private Double height;

	@Column(name="HEIGHT_UNIT", length=10)
	private String heightUnit;

	@Column(name="ID",nullable=false, length=50)
	private String id;

	@Column(name="IS_ORDERABLE")
	private String isOrderable;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LENGTH", precision=126)
	private Double length;

	@Column(name="LENGTH_UNIT", length=10)
	private String lengthUnit;

	@Column(name="MANUFACTURER_NAME", length=30)
	private String manufacturerName;

	@Column(name="MATERIAL_COST_PER_UNIT", precision=126)
	private Double materialCostPerUnit;

	@Column(name="MATERIAL_COST_UNIT", length=10)
	private String materialCostUnit;

	@Column(name="MATERIAL_TYPE", length=10)
	private String materialType;

	@Column(name="POWER_CONSUMPTION", precision=126)
	private Double powerConsumption;

	@Column(name="POWER_CONSUMPTION_UNIT", length=10)
	private String powerConsumptionUnit;

	@Column(name="POWER_DISSIPATION", precision=126)
	private Double powerDissipation;

	@Column(name="POWER_DISSIPATION_UNIT", length=10)
	private String powerDissipationUnit;

	@Column(name="POWER_RATING", precision=126)
	private Double powerRating;

	@Column(name="POWER_RATING_UNIT", length=10)
	private String powerRatingUnit;

	@Column(name="SPEC_REMARKS", length=50)
	private String specRemarks;

	@Column(name="SPEC_STATUS", nullable=false, length=10)
	private String specStatus;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	@Column(name="VOLUME",precision=126)
	private Double volume;

	@Column(name="VOLUME_UNIT", length=10)
	private String volumeUnit;

	@Column(name="WEIGHT",precision=126)
	private Double weight;

	@Column(name="WEIGHT_UNIT", length=10)
	private String weightUnit;

	@Column(name="WIDTH",precision=126)
	private Double width;

	@Column(name="WIDTH_UNIT", length=10)
	private String widthUnit;

	//bi-directional many-to-one association to CableCbAssocSpec
	@OneToMany(mappedBy="cbSpec")
	private List<CableCbAssocSpec> cableCbAssocSpecs;

	//bi-directional many-to-one association to CbCondAssocSpec
	@OneToMany(mappedBy="cbSpec")
	private List<CbCondAssocSpec> cbCondAssocSpecs;

	//bi-directional many-to-one association to CbSelfAssocSpec
	@OneToMany(mappedBy="cbSpec1")
	private List<CbSelfAssocSpec> cbSelfAssocSpecs1;

	//bi-directional many-to-one association to CbSelfAssocSpec
	@OneToMany(mappedBy="cbSpec2")
	private List<CbSelfAssocSpec> cbSelfAssocSpecs2;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to CbSpecCharSpec
	@OneToMany(mappedBy="cbSpec")
	private List<CbSpecCharSpec> cbSpecCharSpecs;

	//bi-directional many-to-one association to CbSpecCharSpecRel
	@OneToMany(mappedBy="cbSpec")
	private List<CbSpecCharSpecRel> cbSpecCharSpecRels;

	//bi-directional many-to-one association to CbSpecCharValueSpec
	@OneToMany(mappedBy="cbSpec")
	private List<CbSpecCharValueSpec> cbSpecCharValueSpecs;

	public CbSpec() {
	}

	
	public CableCbAssocSpec addCableCbAssocSpec(CableCbAssocSpec cableCbAssocSpec) {
		getCableCbAssocSpecs().add(cableCbAssocSpec);
		cableCbAssocSpec.setCbSpec(this);

		return cableCbAssocSpec;
	}

	public CableCbAssocSpec removeCableCbAssocSpec(CableCbAssocSpec cableCbAssocSpec) {
		getCableCbAssocSpecs().remove(cableCbAssocSpec);
		cableCbAssocSpec.setCbSpec(null);

		return cableCbAssocSpec;
	}

	
	public CbCondAssocSpec addCbCondAssocSpec(CbCondAssocSpec cbCondAssocSpec) {
		getCbCondAssocSpecs().add(cbCondAssocSpec);
		cbCondAssocSpec.setCbSpec(this);

		return cbCondAssocSpec;
	}

	public CbCondAssocSpec removeCbCondAssocSpec(CbCondAssocSpec cbCondAssocSpec) {
		getCbCondAssocSpecs().remove(cbCondAssocSpec);
		cbCondAssocSpec.setCbSpec(null);

		return cbCondAssocSpec;
	}

	
	public CbSelfAssocSpec addCbSelfAssocSpecs1(CbSelfAssocSpec cbSelfAssocSpecs1) {
		getCbSelfAssocSpecs1().add(cbSelfAssocSpecs1);
		cbSelfAssocSpecs1.setCbSpec1(this);

		return cbSelfAssocSpecs1;
	}

	public CbSelfAssocSpec removeCbSelfAssocSpecs1(CbSelfAssocSpec cbSelfAssocSpecs1) {
		getCbSelfAssocSpecs1().remove(cbSelfAssocSpecs1);
		cbSelfAssocSpecs1.setCbSpec1(null);

		return cbSelfAssocSpecs1;
	}

	
	public CbSelfAssocSpec addCbSelfAssocSpecs2(CbSelfAssocSpec cbSelfAssocSpecs2) {
		getCbSelfAssocSpecs2().add(cbSelfAssocSpecs2);
		cbSelfAssocSpecs2.setCbSpec2(this);

		return cbSelfAssocSpecs2;
	}

	public CbSelfAssocSpec removeCbSelfAssocSpecs2(CbSelfAssocSpec cbSelfAssocSpecs2) {
		getCbSelfAssocSpecs2().remove(cbSelfAssocSpecs2);
		cbSelfAssocSpecs2.setCbSpec2(null);

		return cbSelfAssocSpecs2;
	}

	
	public CbSpecCharSpec addCbSpecCharSpec(CbSpecCharSpec cbSpecCharSpec) {
		getCbSpecCharSpecs().add(cbSpecCharSpec);
		cbSpecCharSpec.setCbSpec(this);

		return cbSpecCharSpec;
	}

	public CbSpecCharSpec removeCbSpecCharSpec(CbSpecCharSpec cbSpecCharSpec) {
		getCbSpecCharSpecs().remove(cbSpecCharSpec);
		cbSpecCharSpec.setCbSpec(null);

		return cbSpecCharSpec;
	}

	
	public CbSpecCharSpecRel addCbSpecCharSpecRel(CbSpecCharSpecRel cbSpecCharSpecRel) {
		getCbSpecCharSpecRels().add(cbSpecCharSpecRel);
		cbSpecCharSpecRel.setCbSpec(this);

		return cbSpecCharSpecRel;
	}

	public CbSpecCharSpecRel removeCbSpecCharSpecRel(CbSpecCharSpecRel cbSpecCharSpecRel) {
		getCbSpecCharSpecRels().remove(cbSpecCharSpecRel);
		cbSpecCharSpecRel.setCbSpec(null);

		return cbSpecCharSpecRel;
	}

	
	/**
	 * @return the cbSpecPKId
	 */
	public CbSpecPK getCbSpecPKId() {
		return cbSpecPKId;
	}


	/**
	 * @param cbSpecPKId the cbSpecPKId to set
	 */
	public void setCbSpecPKId(CbSpecPK cbSpecPKId) {
		this.cbSpecPKId = cbSpecPKId;
	}


	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}


	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	/**
	 * @return the createdDate
	 */
	public Timestamp getCreatedDate() {
		return createdDate;
	}


	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}


	/**
	 * @return the depth
	 */
	public Double getDepth() {
		return depth;
	}


	/**
	 * @param depth the depth to set
	 */
	public void setDepth(Double depth) {
		this.depth = depth;
	}


	/**
	 * @return the depthUnit
	 */
	public String getDepthUnit() {
		return depthUnit;
	}


	/**
	 * @param depthUnit the depthUnit to set
	 */
	public void setDepthUnit(String depthUnit) {
		this.depthUnit = depthUnit;
	}


	/**
	 * @return the diameter
	 */
	public Double getDiameter() {
		return diameter;
	}


	/**
	 * @param diameter the diameter to set
	 */
	public void setDiameter(Double diameter) {
		this.diameter = diameter;
	}


	/**
	 * @return the diameterUnit
	 */
	public String getDiameterUnit() {
		return diameterUnit;
	}


	/**
	 * @param diameterUnit the diameterUnit to set
	 */
	public void setDiameterUnit(String diameterUnit) {
		this.diameterUnit = diameterUnit;
	}


	/**
	 * @return the entityName
	 */
	public String getEntityName() {
		return entityName;
	}


	/**
	 * @param entityName the entityName to set
	 */
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}


	/**
	 * @return the height
	 */
	public Double getHeight() {
		return height;
	}


	/**
	 * @param height the height to set
	 */
	public void setHeight(Double height) {
		this.height = height;
	}


	/**
	 * @return the heightUnit
	 */
	public String getHeightUnit() {
		return heightUnit;
	}


	/**
	 * @param heightUnit the heightUnit to set
	 */
	public void setHeightUnit(String heightUnit) {
		this.heightUnit = heightUnit;
	}


	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * @return the isOrderable
	 */
	public String getIsOrderable() {
		return isOrderable;
	}


	/**
	 * @param isOrderable the isOrderable to set
	 */
	public void setIsOrderable(String isOrderable) {
		this.isOrderable = isOrderable;
	}


	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}


	/**
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}


	/**
	 * @return the lastModifiedDate
	 */
	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}


	/**
	 * @param lastModifiedDate the lastModifiedDate to set
	 */
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}


	/**
	 * @return the length
	 */
	public Double getLength() {
		return length;
	}


	/**
	 * @param length the length to set
	 */
	public void setLength(Double length) {
		this.length = length;
	}


	/**
	 * @return the lengthUnit
	 */
	public String getLengthUnit() {
		return lengthUnit;
	}


	/**
	 * @param lengthUnit the lengthUnit to set
	 */
	public void setLengthUnit(String lengthUnit) {
		this.lengthUnit = lengthUnit;
	}


	/**
	 * @return the manufacturerName
	 */
	public String getManufacturerName() {
		return manufacturerName;
	}


	/**
	 * @param manufacturerName the manufacturerName to set
	 */
	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}


	/**
	 * @return the materialCostPerUnit
	 */
	public Double getMaterialCostPerUnit() {
		return materialCostPerUnit;
	}


	/**
	 * @param materialCostPerUnit the materialCostPerUnit to set
	 */
	public void setMaterialCostPerUnit(Double materialCostPerUnit) {
		this.materialCostPerUnit = materialCostPerUnit;
	}


	/**
	 * @return the materialCostUnit
	 */
	public String getMaterialCostUnit() {
		return materialCostUnit;
	}


	/**
	 * @param materialCostUnit the materialCostUnit to set
	 */
	public void setMaterialCostUnit(String materialCostUnit) {
		this.materialCostUnit = materialCostUnit;
	}


	/**
	 * @return the materialType
	 */
	public String getMaterialType() {
		return materialType;
	}


	/**
	 * @param materialType the materialType to set
	 */
	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}


	/**
	 * @return the powerConsumption
	 */
	public Double getPowerConsumption() {
		return powerConsumption;
	}


	/**
	 * @param powerConsumption the powerConsumption to set
	 */
	public void setPowerConsumption(Double powerConsumption) {
		this.powerConsumption = powerConsumption;
	}


	/**
	 * @return the powerConsumptionUnit
	 */
	public String getPowerConsumptionUnit() {
		return powerConsumptionUnit;
	}


	/**
	 * @param powerConsumptionUnit the powerConsumptionUnit to set
	 */
	public void setPowerConsumptionUnit(String powerConsumptionUnit) {
		this.powerConsumptionUnit = powerConsumptionUnit;
	}


	/**
	 * @return the powerDissipation
	 */
	public Double getPowerDissipation() {
		return powerDissipation;
	}


	/**
	 * @param powerDissipation the powerDissipation to set
	 */
	public void setPowerDissipation(Double powerDissipation) {
		this.powerDissipation = powerDissipation;
	}


	/**
	 * @return the powerDissipationUnit
	 */
	public String getPowerDissipationUnit() {
		return powerDissipationUnit;
	}


	/**
	 * @param powerDissipationUnit the powerDissipationUnit to set
	 */
	public void setPowerDissipationUnit(String powerDissipationUnit) {
		this.powerDissipationUnit = powerDissipationUnit;
	}


	/**
	 * @return the powerRating
	 */
	public Double getPowerRating() {
		return powerRating;
	}


	/**
	 * @param powerRating the powerRating to set
	 */
	public void setPowerRating(Double powerRating) {
		this.powerRating = powerRating;
	}


	/**
	 * @return the powerRatingUnit
	 */
	public String getPowerRatingUnit() {
		return powerRatingUnit;
	}


	/**
	 * @param powerRatingUnit the powerRatingUnit to set
	 */
	public void setPowerRatingUnit(String powerRatingUnit) {
		this.powerRatingUnit = powerRatingUnit;
	}


	/**
	 * @return the specRemarks
	 */
	public String getSpecRemarks() {
		return specRemarks;
	}


	/**
	 * @param specRemarks the specRemarks to set
	 */
	public void setSpecRemarks(String specRemarks) {
		this.specRemarks = specRemarks;
	}


	/**
	 * @return the specStatus
	 */
	public String getSpecStatus() {
		return specStatus;
	}


	/**
	 * @param specStatus the specStatus to set
	 */
	public void setSpecStatus(String specStatus) {
		this.specStatus = specStatus;
	}


	/**
	 * @return the validFrom
	 */
	public Timestamp getValidFrom() {
		return validFrom;
	}


	/**
	 * @param validFrom the validFrom to set
	 */
	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}


	/**
	 * @return the validTo
	 */
	public Timestamp getValidTo() {
		return validTo;
	}


	/**
	 * @param validTo the validTo to set
	 */
	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}


	/**
	 * @return the volume
	 */
	public Double getVolume() {
		return volume;
	}


	/**
	 * @param volume the volume to set
	 */
	public void setVolume(Double volume) {
		this.volume = volume;
	}


	/**
	 * @return the volumeUnit
	 */
	public String getVolumeUnit() {
		return volumeUnit;
	}


	/**
	 * @param volumeUnit the volumeUnit to set
	 */
	public void setVolumeUnit(String volumeUnit) {
		this.volumeUnit = volumeUnit;
	}


	/**
	 * @return the weight
	 */
	public Double getWeight() {
		return weight;
	}


	/**
	 * @param weight the weight to set
	 */
	public void setWeight(Double weight) {
		this.weight = weight;
	}


	/**
	 * @return the weightUnit
	 */
	public String getWeightUnit() {
		return weightUnit;
	}


	/**
	 * @param weightUnit the weightUnit to set
	 */
	public void setWeightUnit(String weightUnit) {
		this.weightUnit = weightUnit;
	}


	/**
	 * @return the width
	 */
	public Double getWidth() {
		return width;
	}


	/**
	 * @param width the width to set
	 */
	public void setWidth(Double width) {
		this.width = width;
	}


	/**
	 * @return the widthUnit
	 */
	public String getWidthUnit() {
		return widthUnit;
	}


	/**
	 * @param widthUnit the widthUnit to set
	 */
	public void setWidthUnit(String widthUnit) {
		this.widthUnit = widthUnit;
	}


	/**
	 * @return the cableCbAssocSpecs
	 */
	public List<CableCbAssocSpec> getCableCbAssocSpecs() {
		return cableCbAssocSpecs;
	}


	/**
	 * @param cableCbAssocSpecs the cableCbAssocSpecs to set
	 */
	public void setCableCbAssocSpecs(List<CableCbAssocSpec> cableCbAssocSpecs) {
		this.cableCbAssocSpecs = cableCbAssocSpecs;
	}


	/**
	 * @return the cbCondAssocSpecs
	 */
	public List<CbCondAssocSpec> getCbCondAssocSpecs() {
		return cbCondAssocSpecs;
	}


	/**
	 * @param cbCondAssocSpecs the cbCondAssocSpecs to set
	 */
	public void setCbCondAssocSpecs(List<CbCondAssocSpec> cbCondAssocSpecs) {
		this.cbCondAssocSpecs = cbCondAssocSpecs;
	}


	/**
	 * @return the cbSelfAssocSpecs1
	 */
	public List<CbSelfAssocSpec> getCbSelfAssocSpecs1() {
		return cbSelfAssocSpecs1;
	}


	/**
	 * @param cbSelfAssocSpecs1 the cbSelfAssocSpecs1 to set
	 */
	public void setCbSelfAssocSpecs1(List<CbSelfAssocSpec> cbSelfAssocSpecs1) {
		this.cbSelfAssocSpecs1 = cbSelfAssocSpecs1;
	}


	/**
	 * @return the cbSelfAssocSpecs2
	 */
	public List<CbSelfAssocSpec> getCbSelfAssocSpecs2() {
		return cbSelfAssocSpecs2;
	}


	/**
	 * @param cbSelfAssocSpecs2 the cbSelfAssocSpecs2 to set
	 */
	public void setCbSelfAssocSpecs2(List<CbSelfAssocSpec> cbSelfAssocSpecs2) {
		this.cbSelfAssocSpecs2 = cbSelfAssocSpecs2;
	}


	/**
	 * @return the specCategory
	 */
	public SpecCategory getSpecCategory() {
		return specCategory;
	}


	/**
	 * @param specCategory the specCategory to set
	 */
	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}


	/**
	 * @return the specType
	 */
	public SpecType getSpecType() {
		return specType;
	}


	/**
	 * @param specType the specType to set
	 */
	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}


	/**
	 * @return the cbSpecCharSpecs
	 */
	public List<CbSpecCharSpec> getCbSpecCharSpecs() {
		return cbSpecCharSpecs;
	}


	/**
	 * @param cbSpecCharSpecs the cbSpecCharSpecs to set
	 */
	public void setCbSpecCharSpecs(List<CbSpecCharSpec> cbSpecCharSpecs) {
		this.cbSpecCharSpecs = cbSpecCharSpecs;
	}


	/**
	 * @return the cbSpecCharSpecRels
	 */
	public List<CbSpecCharSpecRel> getCbSpecCharSpecRels() {
		return cbSpecCharSpecRels;
	}


	/**
	 * @param cbSpecCharSpecRels the cbSpecCharSpecRels to set
	 */
	public void setCbSpecCharSpecRels(List<CbSpecCharSpecRel> cbSpecCharSpecRels) {
		this.cbSpecCharSpecRels = cbSpecCharSpecRels;
	}


	/**
	 * @return the cbSpecCharValueSpecs
	 */
	public List<CbSpecCharValueSpec> getCbSpecCharValueSpecs() {
		return cbSpecCharValueSpecs;
	}


	/**
	 * @param cbSpecCharValueSpecs the cbSpecCharValueSpecs to set
	 */
	public void setCbSpecCharValueSpecs(List<CbSpecCharValueSpec> cbSpecCharValueSpecs) {
		this.cbSpecCharValueSpecs = cbSpecCharValueSpecs;
	}


	public CbSpecCharValueSpec addCbSpecCharValueSpec(CbSpecCharValueSpec cbSpecCharValueSpec) {
		getCbSpecCharValueSpecs().add(cbSpecCharValueSpec);
		cbSpecCharValueSpec.setCbSpec(this);

		return cbSpecCharValueSpec;
	}

	public CbSpecCharValueSpec removeCbSpecCharValueSpec(CbSpecCharValueSpec cbSpecCharValueSpec) {
		getCbSpecCharValueSpecs().remove(cbSpecCharValueSpec);
		cbSpecCharValueSpec.setCbSpec(null);

		return cbSpecCharValueSpec;
	}

}