package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the WE_HIERARCHY database table.
 * 
 */
@javax.persistence.Entity
@Table(name="WE_HIERARCHY")
@NamedQuery(name="WeHierarchy.findAll", query="SELECT w FROM WeHierarchy w")
public class WeHierarchy implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="EQ_HIERARCHY_SPEC_ID", length=50)
	private String eqHierarchySpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LEG_ID", precision=38)
	private BigDecimal legId;

	@Column(name="WEQ_POS_END_NUM", nullable=false, precision=38)
	private BigDecimal weqPosEndNum;

	@Column(name="WEQ_POS_START_NUM", nullable=false, precision=38)
	private BigDecimal weqPosStartNum;

	//bi-directional many-to-one association to WeChassisPhAssoc
	@ManyToOne
	@JoinColumn(name="CHASSIS_PH_ASSOC_ID")
	private WeChassisPhAssoc weChassisPhAssoc;

	//bi-directional many-to-one association to WirelessEquipment
	@ManyToOne
	@JoinColumn(name="WEQ_NAME")
	private WirelessEquipment wirelessEquipment;

	//bi-directional many-to-one association to WePhPluginAssoc
	@ManyToOne
	@JoinColumn(name="PH_PLUGIN_ASSOC_ID")
	private WePhPluginAssoc wePhPluginAssoc;

	//bi-directional many-to-one association to WePluginPortAssoc
	@ManyToOne
	@JoinColumn(name="PLUGIN_PORT_ASSOC_ID")
	private WePluginPortAssoc wePluginPortAssoc;

	public WeHierarchy() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEqHierarchySpecId() {
		return this.eqHierarchySpecId;
	}

	public void setEqHierarchySpecId(String eqHierarchySpecId) {
		this.eqHierarchySpecId = eqHierarchySpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getLegId() {
		return this.legId;
	}

	public void setLegId(BigDecimal legId) {
		this.legId = legId;
	}

	public BigDecimal getWeqPosEndNum() {
		return this.weqPosEndNum;
	}

	public void setWeqPosEndNum(BigDecimal weqPosEndNum) {
		this.weqPosEndNum = weqPosEndNum;
	}

	public BigDecimal getWeqPosStartNum() {
		return this.weqPosStartNum;
	}

	public void setWeqPosStartNum(BigDecimal weqPosStartNum) {
		this.weqPosStartNum = weqPosStartNum;
	}

	public WeChassisPhAssoc getWeChassisPhAssoc() {
		return this.weChassisPhAssoc;
	}

	public void setWeChassisPhAssoc(WeChassisPhAssoc weChassisPhAssoc) {
		this.weChassisPhAssoc = weChassisPhAssoc;
	}

	public WirelessEquipment getWirelessEquipment() {
		return this.wirelessEquipment;
	}

	public void setWirelessEquipment(WirelessEquipment wirelessEquipment) {
		this.wirelessEquipment = wirelessEquipment;
	}

	public WePhPluginAssoc getWePhPluginAssoc() {
		return this.wePhPluginAssoc;
	}

	public void setWePhPluginAssoc(WePhPluginAssoc wePhPluginAssoc) {
		this.wePhPluginAssoc = wePhPluginAssoc;
	}

	public WePluginPortAssoc getWePluginPortAssoc() {
		return this.wePluginPortAssoc;
	}

	public void setWePluginPortAssoc(WePluginPortAssoc wePluginPortAssoc) {
		this.wePluginPortAssoc = wePluginPortAssoc;
	}

}