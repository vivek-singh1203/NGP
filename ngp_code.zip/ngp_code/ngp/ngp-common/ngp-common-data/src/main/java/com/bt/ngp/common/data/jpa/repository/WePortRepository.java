package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.WePort;
import com.bt.ngp.userdefined.entities.PortStatisticsWe;

@Repository
public interface WePortRepository extends CommonOperation<WePort> {
	@Query(name = "WePortRepository.fetchPortCountInPlugin", nativeQuery = false)
	public List<PortStatisticsWe> fetchPortCount(
			@Param("wePort") WePort wePort);
}