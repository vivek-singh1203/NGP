package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the DEVICE_SPEC_CHAR_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DEVICE_SPEC_CHAR_SPEC")
@NamedQuery(name="DeviceSpecCharSpec.findAll", query="SELECT d FROM DeviceSpecCharSpec d")
public class DeviceSpecCharSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CAN_BE_OVERRIDEN", nullable=false)
	private BigDecimal canBeOverriden;

	@Column(name="CHAR_SPEC_CATEGORY_NAME", length=30)
	private String charSpecCategoryName;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(length=40)
	private String description;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(name="IS_UNIQUE_WHEN_PRESENT")
	private BigDecimal isUniqueWhenPresent;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="MAX_CARDINALITY")
	private BigDecimal maxCardinality;

	@Column(name="MIN_CARDINALITY")
	private BigDecimal minCardinality;

	@Column(nullable=false, length=30)
	private String name;

	@Column(length=50)
	private String remarks;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	@Column(name="VALUE_TYPE", nullable=false, length=30)
	private String valueType;

	//bi-directional many-to-one association to DeviceSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="DEVICE_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="DEVICE_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private DeviceSpec deviceSpec;

	//bi-directional many-to-one association to EntityCharSpec
	@ManyToOne
	@JoinColumn(name="ENTITY_CHAR_SPEC_NAME")
	private EntityCharSpec entityCharSpec;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to DeviceSpecCharValueSpec
	@ManyToOne
	@JoinColumn(name="CHAR_VALUE_SPEC_ID", nullable=false)
	private DeviceSpecCharValueSpec deviceSpecCharValueSpec;

	//bi-directional many-to-one association to DeviceSpecCharSpecRel
	@OneToMany(mappedBy="deviceSpecCharSpec1")
	private List<DeviceSpecCharSpecRel> deviceSpecCharSpecRels1;

	//bi-directional many-to-one association to DeviceSpecCharSpecRel
	@OneToMany(mappedBy="deviceSpecCharSpec2")
	private List<DeviceSpecCharSpecRel> deviceSpecCharSpecRels2;

	public DeviceSpecCharSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public BigDecimal getCanBeOverriden() {
		return this.canBeOverriden;
	}

	public void setCanBeOverriden(BigDecimal canBeOverriden) {
		this.canBeOverriden = canBeOverriden;
	}

	public String getCharSpecCategoryName() {
		return this.charSpecCategoryName;
	}

	public void setCharSpecCategoryName(String charSpecCategoryName) {
		this.charSpecCategoryName = charSpecCategoryName;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public BigDecimal getIsUniqueWhenPresent() {
		return this.isUniqueWhenPresent;
	}

	public void setIsUniqueWhenPresent(BigDecimal isUniqueWhenPresent) {
		this.isUniqueWhenPresent = isUniqueWhenPresent;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getMaxCardinality() {
		return this.maxCardinality;
	}

	public void setMaxCardinality(BigDecimal maxCardinality) {
		this.maxCardinality = maxCardinality;
	}

	public BigDecimal getMinCardinality() {
		return this.minCardinality;
	}

	public void setMinCardinality(BigDecimal minCardinality) {
		this.minCardinality = minCardinality;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public String getValueType() {
		return this.valueType;
	}

	public void setValueType(String valueType) {
		this.valueType = valueType;
	}

	public DeviceSpec getDeviceSpec() {
		return this.deviceSpec;
	}

	public void setDeviceSpec(DeviceSpec deviceSpec) {
		this.deviceSpec = deviceSpec;
	}

	public EntityCharSpec getEntityCharSpec() {
		return this.entityCharSpec;
	}

	public void setEntityCharSpec(EntityCharSpec entityCharSpec) {
		this.entityCharSpec = entityCharSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public DeviceSpecCharValueSpec getDeviceSpecCharValueSpec() {
		return this.deviceSpecCharValueSpec;
	}

	public void setDeviceSpecCharValueSpec(DeviceSpecCharValueSpec deviceSpecCharValueSpec) {
		this.deviceSpecCharValueSpec = deviceSpecCharValueSpec;
	}

	public List<DeviceSpecCharSpecRel> getDeviceSpecCharSpecRels1() {
		return this.deviceSpecCharSpecRels1;
	}

	public void setDeviceSpecCharSpecRels1(List<DeviceSpecCharSpecRel> deviceSpecCharSpecRels1) {
		this.deviceSpecCharSpecRels1 = deviceSpecCharSpecRels1;
	}

	public DeviceSpecCharSpecRel addDeviceSpecCharSpecRels1(DeviceSpecCharSpecRel deviceSpecCharSpecRels1) {
		getDeviceSpecCharSpecRels1().add(deviceSpecCharSpecRels1);
		deviceSpecCharSpecRels1.setDeviceSpecCharSpec1(this);

		return deviceSpecCharSpecRels1;
	}

	public DeviceSpecCharSpecRel removeDeviceSpecCharSpecRels1(DeviceSpecCharSpecRel deviceSpecCharSpecRels1) {
		getDeviceSpecCharSpecRels1().remove(deviceSpecCharSpecRels1);
		deviceSpecCharSpecRels1.setDeviceSpecCharSpec1(null);

		return deviceSpecCharSpecRels1;
	}

	public List<DeviceSpecCharSpecRel> getDeviceSpecCharSpecRels2() {
		return this.deviceSpecCharSpecRels2;
	}

	public void setDeviceSpecCharSpecRels2(List<DeviceSpecCharSpecRel> deviceSpecCharSpecRels2) {
		this.deviceSpecCharSpecRels2 = deviceSpecCharSpecRels2;
	}

	public DeviceSpecCharSpecRel addDeviceSpecCharSpecRels2(DeviceSpecCharSpecRel deviceSpecCharSpecRels2) {
		getDeviceSpecCharSpecRels2().add(deviceSpecCharSpecRels2);
		deviceSpecCharSpecRels2.setDeviceSpecCharSpec2(this);

		return deviceSpecCharSpecRels2;
	}

	public DeviceSpecCharSpecRel removeDeviceSpecCharSpecRels2(DeviceSpecCharSpecRel deviceSpecCharSpecRels2) {
		getDeviceSpecCharSpecRels2().remove(deviceSpecCharSpecRels2);
		deviceSpecCharSpecRels2.setDeviceSpecCharSpec2(null);

		return deviceSpecCharSpecRels2;
	}

}