package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the SPAN_SPEC_CHAR_SPEC_REL database table.
 * 
 */
@javax.persistence.Entity
@Table(name="SPAN_SPEC_CHAR_SPEC_REL")
@NamedQuery(name="SpanSpecCharSpecRel.findAll", query="SELECT s FROM SpanSpecCharSpecRel s")
public class SpanSpecCharSpecRel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CHAR_SPEC_RELATION_TYPE", length=10)
	private String charSpecRelationType;

	@Column(name="CHAR_VALUE_SPEC_RELATION_TYPE", length=10)
	private String charValueSpecRelationType;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to SpanSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="SPAN_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="SPAN_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private SpanSpec spanSpec;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to SpanSpecCharSpec
	@ManyToOne
	@JoinColumn(name="SOURCE_CHAR_SPEC_ID")
	private SpanSpecCharSpec spanSpecCharSpec1;

	//bi-directional many-to-one association to SpanSpecCharSpec
	@ManyToOne
	@JoinColumn(name="TARGET_CHAR_SPEC_ID")
	private SpanSpecCharSpec spanSpecCharSpec2;

	public SpanSpecCharSpecRel() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCharSpecRelationType() {
		return this.charSpecRelationType;
	}

	public void setCharSpecRelationType(String charSpecRelationType) {
		this.charSpecRelationType = charSpecRelationType;
	}

	public String getCharValueSpecRelationType() {
		return this.charValueSpecRelationType;
	}

	public void setCharValueSpecRelationType(String charValueSpecRelationType) {
		this.charValueSpecRelationType = charValueSpecRelationType;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public SpanSpec getSpanSpec() {
		return this.spanSpec;
	}

	public void setSpanSpec(SpanSpec spanSpec) {
		this.spanSpec = spanSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public SpanSpecCharSpec getSpanSpecCharSpec1() {
		return this.spanSpecCharSpec1;
	}

	public void setSpanSpecCharSpec1(SpanSpecCharSpec spanSpecCharSpec1) {
		this.spanSpecCharSpec1 = spanSpecCharSpec1;
	}

	public SpanSpecCharSpec getSpanSpecCharSpec2() {
		return this.spanSpecCharSpec2;
	}

	public void setSpanSpecCharSpec2(SpanSpecCharSpec spanSpecCharSpec2) {
		this.spanSpecCharSpec2 = spanSpecCharSpec2;
	}

}