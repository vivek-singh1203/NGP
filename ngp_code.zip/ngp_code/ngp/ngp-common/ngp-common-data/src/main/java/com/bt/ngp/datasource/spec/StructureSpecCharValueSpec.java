package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the STRUCTURE_SPEC_CHAR_VALUE_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="STRUCTURE_SPEC_CHAR_VALUE_SPEC")
@NamedQuery(name="StructureSpecCharValueSpec.findAll", query="SELECT s FROM StructureSpecCharValueSpec s")
public class StructureSpecCharValueSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DEFAULT_VALUE", nullable=false, length=30)
	private String defaultValue;

	@Column(length=40)
	private String description;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="MEASUREMENT_UNIT", length=10)
	private String measurementUnit;

	@Column(name="RANGE_INTERVAL", length=10)
	private String rangeInterval;

	@Column(length=50)
	private String remarks;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	@Column(name="VALUE_FROM", precision=38)
	private BigDecimal valueFrom;

	@Column(name="VALUE_TO", precision=38)
	private BigDecimal valueTo;

	//bi-directional many-to-one association to StructureSpecCharSpec
	@OneToMany(mappedBy="structureSpecCharValueSpec")
	private List<StructureSpecCharSpec> structureSpecCharSpecs;

	//bi-directional many-to-one association to EntityCharValueSpec
	@ManyToOne
	@JoinColumn(name="ENTITY_CHAR_VALUE_SPEC_ID")
	private EntityCharValueSpec entityCharValueSpec;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to StructureSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="STRUCTURE_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="STRUCTURE_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private StructureSpec structureSpec;

	public StructureSpecCharValueSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDefaultValue() {
		return this.defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getMeasurementUnit() {
		return this.measurementUnit;
	}

	public void setMeasurementUnit(String measurementUnit) {
		this.measurementUnit = measurementUnit;
	}

	public String getRangeInterval() {
		return this.rangeInterval;
	}

	public void setRangeInterval(String rangeInterval) {
		this.rangeInterval = rangeInterval;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public BigDecimal getValueFrom() {
		return this.valueFrom;
	}

	public void setValueFrom(BigDecimal valueFrom) {
		this.valueFrom = valueFrom;
	}

	public BigDecimal getValueTo() {
		return this.valueTo;
	}

	public void setValueTo(BigDecimal valueTo) {
		this.valueTo = valueTo;
	}

	public List<StructureSpecCharSpec> getStructureSpecCharSpecs() {
		return this.structureSpecCharSpecs;
	}

	public void setStructureSpecCharSpecs(List<StructureSpecCharSpec> structureSpecCharSpecs) {
		this.structureSpecCharSpecs = structureSpecCharSpecs;
	}

	public StructureSpecCharSpec addStructureSpecCharSpec(StructureSpecCharSpec structureSpecCharSpec) {
		getStructureSpecCharSpecs().add(structureSpecCharSpec);
		structureSpecCharSpec.setStructureSpecCharValueSpec(this);

		return structureSpecCharSpec;
	}

	public StructureSpecCharSpec removeStructureSpecCharSpec(StructureSpecCharSpec structureSpecCharSpec) {
		getStructureSpecCharSpecs().remove(structureSpecCharSpec);
		structureSpecCharSpec.setStructureSpecCharValueSpec(null);

		return structureSpecCharSpec;
	}

	public EntityCharValueSpec getEntityCharValueSpec() {
		return this.entityCharValueSpec;
	}

	public void setEntityCharValueSpec(EntityCharValueSpec entityCharValueSpec) {
		this.entityCharValueSpec = entityCharValueSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public StructureSpec getStructureSpec() {
		return this.structureSpec;
	}

	public void setStructureSpec(StructureSpec structureSpec) {
		this.structureSpec = structureSpec;
	}

}