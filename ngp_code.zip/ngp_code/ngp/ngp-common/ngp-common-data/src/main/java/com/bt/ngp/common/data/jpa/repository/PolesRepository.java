package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.Pole;

@Repository
public interface PolesRepository extends SqlRepository<Pole> {

	public Pole findByName(@Param("name") String name);
	
	public List<Pole> findByNameIn(List<String> structures);
	
	@Query(name="PolesRepository.findPoleWithoutSpanSectionAssoc", nativeQuery=true)
	public List<Pole> findPoleWithoutSpanSectionAssoc(@Param("exchangeCode") String exchangeCode);
	
	@Query(name="PolesRepository.PoleWithoutEquipment", nativeQuery=true)
	public List<Pole> findPoleWithoutEquipment(@Param("exchangeCode") String exchangeCode, @Param("physicalStructureType") String physicalStructureType);
	
}