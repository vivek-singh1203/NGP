package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the CONNECTOR_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CONNECTOR_SPEC")
@NamedQuery(name="ConnectorSpec.findAll", query="SELECT c FROM ConnectorSpec c")
public class ConnectorSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ConnectorSpecPK connectorSpecPKId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(precision=126)
	private double diameter;

	@Column(name="DIAMETER_UNIT", length=10)
	private String diameterUnit;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="IS_ORDERABLE")
	private BigDecimal isOrderable;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="POWER_CONSUMPTION", precision=126)
	private double powerConsumption;

	@Column(name="POWER_CONSUMPTION_UNIT", length=10)
	private String powerConsumptionUnit;

	@Column(name="POWER_DISSIPATION", precision=126)
	private double powerDissipation;

	@Column(name="POWER_DISSIPATION_UNIT", length=10)
	private String powerDissipationUnit;

	@Column(name="POWER_RATING", precision=126)
	private double powerRating;

	@Column(name="POWER_RATING_UNIT", length=10)
	private String powerRatingUnit;

	@Column(name="SPEC_REMARKS", length=50)
	private String specRemarks;

	@Column(name="SPEC_STATUS", nullable=false, length=10)
	private String specStatus;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to ConnectorSpecCharSpec
	@OneToMany(mappedBy="connectorSpec")
	private List<ConnectorSpecCharSpec> connectorSpecCharSpecs;

	//bi-directional many-to-one association to ConnectorSpecCharSpecRel
	@OneToMany(mappedBy="connectorSpec")
	private List<ConnectorSpecCharSpecRel> connectorSpecCharSpecRels;

	//bi-directional many-to-one association to ConnectorSpecCharValueSpec
	@OneToMany(mappedBy="connectorSpec")
	private List<ConnectorSpecCharValueSpec> connectorSpecCharValueSpecs;

	public ConnectorSpec() {
	}

	public ConnectorSpecPK getConnectorSpecPKId() {
		return this.connectorSpecPKId;
	}

	public void setId(ConnectorSpecPK connectorSpecPKId) {
		this.connectorSpecPKId = connectorSpecPKId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public double getDiameter() {
		return this.diameter;
	}

	public void setDiameter(double diameter) {
		this.diameter = diameter;
	}

	public String getDiameterUnit() {
		return this.diameterUnit;
	}

	public void setDiameterUnit(String diameterUnit) {
		this.diameterUnit = diameterUnit;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public BigDecimal getIsOrderable() {
		return this.isOrderable;
	}

	public void setIsOrderable(BigDecimal isOrderable) {
		this.isOrderable = isOrderable;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public double getPowerConsumption() {
		return this.powerConsumption;
	}

	public void setPowerConsumption(double powerConsumption) {
		this.powerConsumption = powerConsumption;
	}

	public String getPowerConsumptionUnit() {
		return this.powerConsumptionUnit;
	}

	public void setPowerConsumptionUnit(String powerConsumptionUnit) {
		this.powerConsumptionUnit = powerConsumptionUnit;
	}

	public double getPowerDissipation() {
		return this.powerDissipation;
	}

	public void setPowerDissipation(double powerDissipation) {
		this.powerDissipation = powerDissipation;
	}

	public String getPowerDissipationUnit() {
		return this.powerDissipationUnit;
	}

	public void setPowerDissipationUnit(String powerDissipationUnit) {
		this.powerDissipationUnit = powerDissipationUnit;
	}

	public double getPowerRating() {
		return this.powerRating;
	}

	public void setPowerRating(double powerRating) {
		this.powerRating = powerRating;
	}

	public String getPowerRatingUnit() {
		return this.powerRatingUnit;
	}

	public void setPowerRatingUnit(String powerRatingUnit) {
		this.powerRatingUnit = powerRatingUnit;
	}

	public String getSpecRemarks() {
		return this.specRemarks;
	}

	public void setSpecRemarks(String specRemarks) {
		this.specRemarks = specRemarks;
	}

	public String getSpecStatus() {
		return this.specStatus;
	}

	public void setSpecStatus(String specStatus) {
		this.specStatus = specStatus;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public List<ConnectorSpecCharSpec> getConnectorSpecCharSpecs() {
		return this.connectorSpecCharSpecs;
	}

	public void setConnectorSpecCharSpecs(List<ConnectorSpecCharSpec> connectorSpecCharSpecs) {
		this.connectorSpecCharSpecs = connectorSpecCharSpecs;
	}

	public ConnectorSpecCharSpec addConnectorSpecCharSpec(ConnectorSpecCharSpec connectorSpecCharSpec) {
		getConnectorSpecCharSpecs().add(connectorSpecCharSpec);
		connectorSpecCharSpec.setConnectorSpec(this);

		return connectorSpecCharSpec;
	}

	public ConnectorSpecCharSpec removeConnectorSpecCharSpec(ConnectorSpecCharSpec connectorSpecCharSpec) {
		getConnectorSpecCharSpecs().remove(connectorSpecCharSpec);
		connectorSpecCharSpec.setConnectorSpec(null);

		return connectorSpecCharSpec;
	}

	public List<ConnectorSpecCharSpecRel> getConnectorSpecCharSpecRels() {
		return this.connectorSpecCharSpecRels;
	}

	public void setConnectorSpecCharSpecRels(List<ConnectorSpecCharSpecRel> connectorSpecCharSpecRels) {
		this.connectorSpecCharSpecRels = connectorSpecCharSpecRels;
	}

	public ConnectorSpecCharSpecRel addConnectorSpecCharSpecRel(ConnectorSpecCharSpecRel connectorSpecCharSpecRel) {
		getConnectorSpecCharSpecRels().add(connectorSpecCharSpecRel);
		connectorSpecCharSpecRel.setConnectorSpec(this);

		return connectorSpecCharSpecRel;
	}

	public ConnectorSpecCharSpecRel removeConnectorSpecCharSpecRel(ConnectorSpecCharSpecRel connectorSpecCharSpecRel) {
		getConnectorSpecCharSpecRels().remove(connectorSpecCharSpecRel);
		connectorSpecCharSpecRel.setConnectorSpec(null);

		return connectorSpecCharSpecRel;
	}

	public List<ConnectorSpecCharValueSpec> getConnectorSpecCharValueSpecs() {
		return this.connectorSpecCharValueSpecs;
	}

	public void setConnectorSpecCharValueSpecs(List<ConnectorSpecCharValueSpec> connectorSpecCharValueSpecs) {
		this.connectorSpecCharValueSpecs = connectorSpecCharValueSpecs;
	}

	public ConnectorSpecCharValueSpec addConnectorSpecCharValueSpec(ConnectorSpecCharValueSpec connectorSpecCharValueSpec) {
		getConnectorSpecCharValueSpecs().add(connectorSpecCharValueSpec);
		connectorSpecCharValueSpec.setConnectorSpec(this);

		return connectorSpecCharValueSpec;
	}

	public ConnectorSpecCharValueSpec removeConnectorSpecCharValueSpec(ConnectorSpecCharValueSpec connectorSpecCharValueSpec) {
		getConnectorSpecCharValueSpecs().remove(connectorSpecCharValueSpec);
		connectorSpecCharValueSpec.setConnectorSpec(null);

		return connectorSpecCharValueSpec;
	}

}