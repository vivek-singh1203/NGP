package com.bt.ngp.common.data.jpa.repository;

import org.springframework.stereotype.Repository;
import com.bt.ngp.datasource.entities.MfnPortChar;

@Repository
public interface MfnPortCharRepository extends SqlRepository<MfnPortChar> {
	
}