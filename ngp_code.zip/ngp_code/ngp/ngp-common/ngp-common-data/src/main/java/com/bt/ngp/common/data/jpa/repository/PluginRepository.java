package com.bt.ngp.common.data.jpa.repository;

import com.bt.ngp.datasource.entities.CrossConnectPoint;
import com.bt.ngp.datasource.entities.Plugin;

public interface PluginRepository extends CommonOperation<Plugin>{

}
