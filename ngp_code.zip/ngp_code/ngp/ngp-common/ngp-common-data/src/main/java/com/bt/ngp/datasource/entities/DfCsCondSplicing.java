package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the DF_CS_COND_SPLICING database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DF_CS_COND_SPLICING")
@NamedQuery(name="DfCsCondSplicing.findAll", query="SELECT d FROM DfCsCondSplicing d")
public class DfCsCondSplicing implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SeqGen")
    @SequenceGenerator(name = "SeqGen", sequenceName = "DF_CS_COND_SPLICING_SEQ", allocationSize = 1)
	private long id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="ORIG_COND_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal origCondSeqNum;

	@Column(name="SPLICING_RESOURCE", nullable=false, length=20)
	private String splicingResource;

	@Column(name="SPLICING_STATE", length=20)
	private String splicingState;

	@Column(name="TERM_COND_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal termCondSeqNum;

	//bi-directional many-to-one association to DistributionFrame
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="FRAME_NAME")
	private DistributionFrame distributionFrame;

	//bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_CB_NAME")
	private ConductorBundle conductorBundleOrigCbName;

	//bi-directional many-to-one association to Conductor
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_COND_NAME")
	private Conductor conductorOrigCondName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_CS_NAME")
	private CableSection origCsName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_PARENT_CS_NAME")
	private CableSection origParentCsName;

	//bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_CB_NAME")
	private ConductorBundle conductorBundleTermCbName;

	//bi-directional many-to-one association to Conductor
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_COND_NAME")
	private Conductor conductorTermCondName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_CS_NAME")
	private CableSection termCsName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_PARENT_CS_NAME")
	private CableSection termParentCsName;
	
	public DfCsCondSplicing() {
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getOrigCondSeqNum() {
		return origCondSeqNum;
	}

	public void setOrigCondSeqNum(BigDecimal origCondSeqNum) {
		this.origCondSeqNum = origCondSeqNum;
	}

	public String getSplicingResource() {
		return splicingResource;
	}

	public void setSplicingResource(String splicingResource) {
		this.splicingResource = splicingResource;
	}

	public String getSplicingState() {
		return splicingState;
	}

	public void setSplicingState(String splicingState) {
		this.splicingState = splicingState;
	}

	public BigDecimal getTermCondSeqNum() {
		return termCondSeqNum;
	}

	public void setTermCondSeqNum(BigDecimal termCondSeqNum) {
		this.termCondSeqNum = termCondSeqNum;
	}

	public DistributionFrame getDistributionFrame() {
		return distributionFrame;
	}

	public void setDistributionFrame(DistributionFrame distributionFrame) {
		this.distributionFrame = distributionFrame;
	}

	public ConductorBundle getConductorBundleOrigCbName() {
		return conductorBundleOrigCbName;
	}

	public void setConductorBundleOrigCbName(ConductorBundle conductorBundleOrigCbName) {
		this.conductorBundleOrigCbName = conductorBundleOrigCbName;
	}

	public Conductor getConductorOrigCondName() {
		return conductorOrigCondName;
	}

	public void setConductorOrigCondName(Conductor conductorOrigCondName) {
		this.conductorOrigCondName = conductorOrigCondName;
	}

	public CableSection getOrigCsName() {
		return origCsName;
	}

	public void setOrigCsName(CableSection origCsName) {
		this.origCsName = origCsName;
	}

	public CableSection getOrigParentCsName() {
		return origParentCsName;
	}

	public void setOrigParentCsName(CableSection origParentCsName) {
		this.origParentCsName = origParentCsName;
	}

	public ConductorBundle getConductorBundleTermCbName() {
		return conductorBundleTermCbName;
	}

	public void setConductorBundleTermCbName(ConductorBundle conductorBundleTermCbName) {
		this.conductorBundleTermCbName = conductorBundleTermCbName;
	}

	public Conductor getConductorTermCondName() {
		return conductorTermCondName;
	}

	public void setConductorTermCondName(Conductor conductorTermCondName) {
		this.conductorTermCondName = conductorTermCondName;
	}

	public CableSection getTermCsName() {
		return termCsName;
	}

	public void setTermCsName(CableSection termCsName) {
		this.termCsName = termCsName;
	}

	public CableSection getTermParentCsName() {
		return termParentCsName;
	}

	public void setTermParentCsName(CableSection termParentCsName) {
		this.termParentCsName = termParentCsName;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}