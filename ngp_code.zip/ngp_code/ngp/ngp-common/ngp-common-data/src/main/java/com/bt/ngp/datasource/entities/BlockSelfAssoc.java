package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the BLOCK_SELF_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="BLOCK_SELF_ASSOC")
@NamedQuery(name="BlockSelfAssoc.findAll", query="SELECT b FROM BlockSelfAssoc b")
public class BlockSelfAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private long id;

	@Column(name="BLOCK_SELF_ASSOC_SPEC_ID", length=50)
	private java.math.BigDecimal blockSelfAssocSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to Block
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CHILD_BLOCK_NAME")
	private Block block1;

	//bi-directional many-to-one association to Block
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PARENT_BLOCK_NAME")
	private Block block2;

	public BlockSelfAssoc() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public java.math.BigDecimal getBlockSelfAssocSpecId() {
		return this.blockSelfAssocSpecId;
	}

	public void setBlockSelfAssocSpecId(java.math.BigDecimal blockSelfAssocSpecId) {
		this.blockSelfAssocSpecId = blockSelfAssocSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Block getBlock1() {
		return this.block1;
	}

	public void setBlock1(Block block1) {
		this.block1 = block1;
	}

	public Block getBlock2() {
		return this.block2;
	}

	public void setBlock2(Block block2) {
		this.block2 = block2;
	}

}