package com.bt.ngp.common.data.jpa.spec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.spec.SpanSpecPK;
import com.bt.ngp.datasource.spec.StructureSpec;

@Repository
public interface StructureSpecRepository extends JpaRepository<StructureSpec, SpanSpecPK> {
	
	public StructureSpec findByStructureSpecPKIdName(@Param("name") String name);
	
}