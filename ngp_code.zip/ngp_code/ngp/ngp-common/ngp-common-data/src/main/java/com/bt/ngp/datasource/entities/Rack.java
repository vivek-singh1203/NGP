package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the RACKS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="RACKS")
@NamedQuery(name="Rack.findAll", query="SELECT r FROM Rack r")
public class Rack implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to BlockHolder
	@OneToMany(mappedBy="rack")
	private List<BlockHolder> blockHolders;

	//bi-directional many-to-one association to CardHolder
	@OneToMany(mappedBy="rack")
	private List<CardHolder> cardHolders;

	//bi-directional many-to-one association to DfRackBhAssoc
	@OneToMany(mappedBy="rack")
	private List<DfRackBhAssoc> dfRackBhAssocs;

	//bi-directional many-to-one association to DslamCsPortTerm
	@OneToMany(mappedBy="rack")
	private List<DslamCsPortTerm> dslamCsPortTerms;

	//bi-directional many-to-one association to DslamPortPortAssoc
	@OneToMany(mappedBy="rack1")
	private List<DslamPortPortAssoc> dslamPortPortAssocs1;

	//bi-directional many-to-one association to DslamPortPortAssoc
	@OneToMany(mappedBy="rack2")
	private List<DslamPortPortAssoc> dslamPortPortAssocs2;

	//bi-directional many-to-one association to DslamRackChAssoc
	@OneToMany(mappedBy="rack")
	private List<DslamRackChAssoc> dslamRackChAssocs;

	//bi-directional many-to-one association to Dslam
	@ManyToOne
	@JoinColumn(name="DSLAM_NAME")
	private Dslam dslam;

	//bi-directional many-to-one association to DfCsPortTerm
	@OneToMany(mappedBy="rack")
	private List<DfCsPortTerm> dfCsPortTerms;

	//bi-directional many-to-one association to DfPortPortAssoc
	@OneToMany(mappedBy="rack1")
	private List<DfPortPortAssoc> dfPortPortAssocs1;

	//bi-directional many-to-one association to DfPortPortAssoc
	@OneToMany(mappedBy="rack2")
	private List<DfPortPortAssoc> dfPortPortAssocs2;


	//bi-directional many-to-one association to DistributionFrame
	@ManyToOne
	@JoinColumn(name="FRAME_NAME")
	private DistributionFrame distributionFrame;

	//bi-directional many-to-one association to Store
	@ManyToOne
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to RackChar
	@OneToMany(mappedBy="rack")
	private List<RackChar> rackChars;

	public Rack() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<BlockHolder> getBlockHolders() {
		return this.blockHolders;
	}

	public void setBlockHolders(List<BlockHolder> blockHolders) {
		this.blockHolders = blockHolders;
	}

	public BlockHolder addBlockHolder(BlockHolder blockHolder) {
		getBlockHolders().add(blockHolder);
		blockHolder.setRack(this);

		return blockHolder;
	}

	public BlockHolder removeBlockHolder(BlockHolder blockHolder) {
		getBlockHolders().remove(blockHolder);
		blockHolder.setRack(null);

		return blockHolder;
	}

	public List<CardHolder> getCardHolders() {
		return this.cardHolders;
	}

	public void setCardHolders(List<CardHolder> cardHolders) {
		this.cardHolders = cardHolders;
	}

	public CardHolder addCardHolder(CardHolder cardHolder) {
		getCardHolders().add(cardHolder);
		cardHolder.setRack(this);

		return cardHolder;
	}

	public CardHolder removeCardHolder(CardHolder cardHolder) {
		getCardHolders().remove(cardHolder);
		cardHolder.setRack(null);

		return cardHolder;
	}

	public List<DfRackBhAssoc> getDfRackBhAssocs() {
		return this.dfRackBhAssocs;
	}

	public void setDfRackBhAssocs(List<DfRackBhAssoc> dfRackBhAssocs) {
		this.dfRackBhAssocs = dfRackBhAssocs;
	}

	public DfRackBhAssoc addDfRackBhAssoc(DfRackBhAssoc dfRackBhAssoc) {
		getDfRackBhAssocs().add(dfRackBhAssoc);
		dfRackBhAssoc.setRack(this);

		return dfRackBhAssoc;
	}

	public DfRackBhAssoc removeDfRackBhAssoc(DfRackBhAssoc dfRackBhAssoc) {
		getDfRackBhAssocs().remove(dfRackBhAssoc);
		dfRackBhAssoc.setRack(null);

		return dfRackBhAssoc;
	}

	public List<DslamCsPortTerm> getDslamCsPortTerms() {
		return this.dslamCsPortTerms;
	}

	public void setDslamCsPortTerms(List<DslamCsPortTerm> dslamCsPortTerms) {
		this.dslamCsPortTerms = dslamCsPortTerms;
	}

	public DslamCsPortTerm addDslamCsPortTerm(DslamCsPortTerm dslamCsPortTerm) {
		getDslamCsPortTerms().add(dslamCsPortTerm);
		dslamCsPortTerm.setRack(this);

		return dslamCsPortTerm;
	}

	public DslamCsPortTerm removeDslamCsPortTerm(DslamCsPortTerm dslamCsPortTerm) {
		getDslamCsPortTerms().remove(dslamCsPortTerm);
		dslamCsPortTerm.setRack(null);

		return dslamCsPortTerm;
	}

	public List<DslamPortPortAssoc> getDslamPortPortAssocs1() {
		return this.dslamPortPortAssocs1;
	}

	public void setDslamPortPortAssocs1(List<DslamPortPortAssoc> dslamPortPortAssocs1) {
		this.dslamPortPortAssocs1 = dslamPortPortAssocs1;
	}

	public DslamPortPortAssoc addDslamPortPortAssocs1(DslamPortPortAssoc dslamPortPortAssocs1) {
		getDslamPortPortAssocs1().add(dslamPortPortAssocs1);
		dslamPortPortAssocs1.setRack1(this);

		return dslamPortPortAssocs1;
	}

	public DslamPortPortAssoc removeDslamPortPortAssocs1(DslamPortPortAssoc dslamPortPortAssocs1) {
		getDslamPortPortAssocs1().remove(dslamPortPortAssocs1);
		dslamPortPortAssocs1.setRack1(null);

		return dslamPortPortAssocs1;
	}

	public List<DslamPortPortAssoc> getDslamPortPortAssocs2() {
		return this.dslamPortPortAssocs2;
	}

	public void setDslamPortPortAssocs2(List<DslamPortPortAssoc> dslamPortPortAssocs2) {
		this.dslamPortPortAssocs2 = dslamPortPortAssocs2;
	}

	public DslamPortPortAssoc addDslamPortPortAssocs2(DslamPortPortAssoc dslamPortPortAssocs2) {
		getDslamPortPortAssocs2().add(dslamPortPortAssocs2);
		dslamPortPortAssocs2.setRack2(this);

		return dslamPortPortAssocs2;
	}

	public DslamPortPortAssoc removeDslamPortPortAssocs2(DslamPortPortAssoc dslamPortPortAssocs2) {
		getDslamPortPortAssocs2().remove(dslamPortPortAssocs2);
		dslamPortPortAssocs2.setRack2(null);

		return dslamPortPortAssocs2;
	}

	public List<DslamRackChAssoc> getDslamRackChAssocs() {
		return this.dslamRackChAssocs;
	}

	public void setDslamRackChAssocs(List<DslamRackChAssoc> dslamRackChAssocs) {
		this.dslamRackChAssocs = dslamRackChAssocs;
	}

	public DslamRackChAssoc addDslamRackChAssoc(DslamRackChAssoc dslamRackChAssoc) {
		getDslamRackChAssocs().add(dslamRackChAssoc);
		dslamRackChAssoc.setRack(this);

		return dslamRackChAssoc;
	}

	public DslamRackChAssoc removeDslamRackChAssoc(DslamRackChAssoc dslamRackChAssoc) {
		getDslamRackChAssocs().remove(dslamRackChAssoc);
		dslamRackChAssoc.setRack(null);

		return dslamRackChAssoc;
	}

	public Dslam getDslam() {
		return this.dslam;
	}

	public void setDslam(Dslam dslam) {
		this.dslam = dslam;
	}

	public DistributionFrame getDistributionFrame() {
		return this.distributionFrame;
	}

	public void setDistributionFrame(DistributionFrame distributionFrame) {
		this.distributionFrame = distributionFrame;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public List<RackChar> getRackChars() {
		return this.rackChars;
	}

	public void setRackChars(List<RackChar> rackChars) {
		this.rackChars = rackChars;
	}

	public RackChar addRackChar(RackChar rackChar) {
		getRackChars().add(rackChar);
		rackChar.setRack(this);

		return rackChar;
	}

	public RackChar removeRackChar(RackChar rackChar) {
		getRackChars().remove(rackChar);
		rackChar.setRack(null);

		return rackChar;
	}

	public List<DfCsPortTerm> getDfCsPortTerms() {
		return this.dfCsPortTerms;
	}

	public void setDfCsPortTerms(List<DfCsPortTerm> dfCsPortTerms) {
		this.dfCsPortTerms = dfCsPortTerms;
	}

	public DfCsPortTerm addDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().add(dfCsPortTerm);
		dfCsPortTerm.setRack(this);

		return dfCsPortTerm;
	}

	public DfCsPortTerm removeDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().remove(dfCsPortTerm);
		dfCsPortTerm.setRack(null);

		return dfCsPortTerm;
	}

	public List<DfPortPortAssoc> getDfPortPortAssocs1() {
		return this.dfPortPortAssocs1;
	}

	public void setDfPortPortAssocs1(List<DfPortPortAssoc> dfPortPortAssocs1) {
		this.dfPortPortAssocs1 = dfPortPortAssocs1;
	}

	public DfPortPortAssoc addDfPortPortAssocs1(DfPortPortAssoc dfPortPortAssocs1) {
		getDfPortPortAssocs1().add(dfPortPortAssocs1);
		dfPortPortAssocs1.setRack1(this);

		return dfPortPortAssocs1;
	}

	public DfPortPortAssoc removeDfPortPortAssocs1(DfPortPortAssoc dfPortPortAssocs1) {
		getDfPortPortAssocs1().remove(dfPortPortAssocs1);
		dfPortPortAssocs1.setRack1(null);

		return dfPortPortAssocs1;
	}

	public List<DfPortPortAssoc> getDfPortPortAssocs2() {
		return this.dfPortPortAssocs2;
	}

	public void setDfPortPortAssocs2(List<DfPortPortAssoc> dfPortPortAssocs2) {
		this.dfPortPortAssocs2 = dfPortPortAssocs2;
	}
	public DfPortPortAssoc addDfPortPortAssocs2(DfPortPortAssoc dfPortPortAssocs2) {
		getDfPortPortAssocs2().add(dfPortPortAssocs2);
		dfPortPortAssocs2.setRack2(this);

		return dfPortPortAssocs2;
	}

	public DfPortPortAssoc removeDfPortPortAssocs2(DfPortPortAssoc dfPortPortAssocs2) {
		getDfPortPortAssocs2().remove(dfPortPortAssocs2);
		dfPortPortAssocs2.setRack2(null);

		return dfPortPortAssocs2;
	}

}