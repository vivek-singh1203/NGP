package com.bt.ngp.common.data.jpa.repository;

import org.springframework.stereotype.Repository;
import com.bt.ngp.datasource.entities.DslamPortChar;

@Repository
public interface DslamPortCharRepository extends SqlRepository<DslamPortChar> {
	
}