package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the JC_CS_COND_SPLICING database table.
 * 
 */
@javax.persistence.Entity
@Table(name="JC_CS_COND_SPLICING")
@NamedQuery(name="JcCsCondSplicing.findAll", query="SELECT j FROM JcCsCondSplicing j")
public class JcCsCondSplicing implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
    @Column(unique=true, nullable=false, length=50)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SeqGen")
    @SequenceGenerator(name = "SeqGen", sequenceName = "JC_CS_COND_SPL_SEQ", allocationSize = 1)
    private long id;


	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="ORIG_COND_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal origCondSeqNum;

	@Column(name="SPLICING_RESOURCE", nullable=false, length=20)
	private String splicingResource;

	@Column(name="SPLICING_STATE", length=20)
	private String splicingState;

	@Column(name="TERM_COND_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal termCondSeqNum;

	@Column(length=25)
	private String xxe;
	
	//bi-directional many-to-one association to JointClosure
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="JC_NAME")
	private JointClosure jointClosure;

	//bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_CB_NAME")
	private ConductorBundle conductorBundleOrigCbName;

	//bi-directional many-to-one association to Conductor
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_COND_NAME")
	private Conductor conductorOrigCondName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_CS_NAME")
	private CableSection cableSectionOrigCsName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_PARENT_CS_NAME")
	private CableSection cableSectionOrigParentCsName;

	//bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_CB_NAME")
	private ConductorBundle conductorBundleTermCbName;

	//bi-directional many-to-one association to Conductor
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_COND_NAME")
	private Conductor conductorTermCondName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_CS_NAME")
	private CableSection cableSectionTermCsName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_PARENT_CS_NAME")
	private CableSection cableSectionTermParentCsName;

	public JcCsCondSplicing() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getOrigCondSeqNum() {
		return origCondSeqNum;
	}

	public void setOrigCondSeqNum(BigDecimal origCondSeqNum) {
		this.origCondSeqNum = origCondSeqNum;
	}

	public String getSplicingResource() {
		return splicingResource;
	}

	public void setSplicingResource(String splicingResource) {
		this.splicingResource = splicingResource;
	}

	public String getSplicingState() {
		return splicingState;
	}

	public void setSplicingState(String splicingState) {
		this.splicingState = splicingState;
	}

	public BigDecimal getTermCondSeqNum() {
		return termCondSeqNum;
	}

	public void setTermCondSeqNum(BigDecimal termCondSeqNum) {
		this.termCondSeqNum = termCondSeqNum;
	}

	public String getXxe() {
		return xxe;
	}

	public void setXxe(String xxe) {
		this.xxe = xxe;
	}

	public JointClosure getJointClosure() {
		return jointClosure;
	}

	public void setJointClosure(JointClosure jointClosure) {
		this.jointClosure = jointClosure;
	}

	public ConductorBundle getConductorBundleOrigCbName() {
		return conductorBundleOrigCbName;
	}

	public void setConductorBundleOrigCbName(ConductorBundle conductorBundleOrigCbName) {
		this.conductorBundleOrigCbName = conductorBundleOrigCbName;
	}

	public Conductor getConductorOrigCondName() {
		return conductorOrigCondName;
	}

	public void setConductorOrigCondName(Conductor conductorOrigCondName) {
		this.conductorOrigCondName = conductorOrigCondName;
	}

	public CableSection getCableSectionOrigCsName() {
		return cableSectionOrigCsName;
	}

	public void setCableSectionOrigCsName(CableSection cableSectionOrigCsName) {
		this.cableSectionOrigCsName = cableSectionOrigCsName;
	}

	public CableSection getCableSectionOrigParentCsName() {
		return cableSectionOrigParentCsName;
	}

	public void setCableSectionOrigParentCsName(CableSection cableSectionOrigParentCsName) {
		this.cableSectionOrigParentCsName = cableSectionOrigParentCsName;
	}

	public ConductorBundle getConductorBundleTermCbName() {
		return conductorBundleTermCbName;
	}

	public void setConductorBundleTermCbName(ConductorBundle conductorBundleTermCbName) {
		this.conductorBundleTermCbName = conductorBundleTermCbName;
	}

	public Conductor getConductorTermCondName() {
		return conductorTermCondName;
	}

	public void setConductorTermCondName(Conductor conductorTermCondName) {
		this.conductorTermCondName = conductorTermCondName;
	}

	public CableSection getCableSectionTermCsName() {
		return cableSectionTermCsName;
	}

	public void setCableSectionTermCsName(CableSection cableSectionTermCsName) {
		this.cableSectionTermCsName = cableSectionTermCsName;
	}

	public CableSection getCableSectionTermParentCsName() {
		return cableSectionTermParentCsName;
	}

	public void setCableSectionTermParentCsName(CableSection cableSectionTermParentCsName) {
		this.cableSectionTermParentCsName = cableSectionTermParentCsName;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}