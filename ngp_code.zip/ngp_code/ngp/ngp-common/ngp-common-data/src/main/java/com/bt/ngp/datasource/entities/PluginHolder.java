package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the PLUGIN_HOLDERS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="PLUGIN_HOLDERS")
@NamedQuery(name="PluginHolder.findAll", query="SELECT p FROM PluginHolder p")
public class PluginHolder implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to CcpChassisPhAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<CcpChassisPhAssoc> ccpChassisPhAssocs;

	//bi-directional many-to-one association to CcpPhPluginAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<CcpPhPluginAssoc> ccpPhPluginAssocs;

	//bi-directional many-to-one association to CpeChassisPhAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<CpeChassisPhAssoc> cpeChassisPhAssocs;

	//bi-directional many-to-one association to CpePhPluginAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<CpePhPluginAssoc> cpePhPluginAssocs;

	//bi-directional many-to-one association to DpChassisPhAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<DpChassisPhAssoc> dpChassisPhAssocs;

	//bi-directional many-to-one association to DpPhPluginAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<DpPhPluginAssoc> dpPhPluginAssocs;

	//bi-directional many-to-one association to JcChassisPhAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<JcChassisPhAssoc> jcChassisPhAssocs;

	//bi-directional many-to-one association to JcPhPluginAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<JcPhPluginAssoc> jcPhPluginAssocs;

	//bi-directional many-to-one association to MfnChassisPhAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<MfnChassisPhAssoc> mfnChassisPhAssocs;

	//bi-directional many-to-one association to MfnPhPluginAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<MfnPhPluginAssoc> mfnPhPluginAssocs;

	//bi-directional many-to-one association to NteChassisPhAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<NteChassisPhAssoc> nteChassisPhAssocs;

	//bi-directional many-to-one association to NtePhPluginAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<NtePhPluginAssoc> ntePhPluginAssocs;

	//bi-directional many-to-one association to Plugin
	@OneToMany(mappedBy="pluginHolder")
	private List<Plugin> plugins;

	//bi-directional many-to-one association to CrossConnectPoint
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="CCP_NAME")
	private CrossConnectPoint crossConnectPoint;

	//bi-directional many-to-one association to Chassi
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="CHASSIS_NAME")
	private Chassi chassi;

	//bi-directional many-to-one association to CustomerPremiseEquipment
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="CPE_NAME")
	private CustomerPremiseEquipment customerPremiseEquipment;

	//bi-directional many-to-one association to DistributionPoint
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="DP_NAME")
	private DistributionPoint distributionPoint;

	//bi-directional many-to-one association to JointClosure
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="JC_NAME")
	private JointClosure jointClosure;

	//bi-directional many-to-one association to MultiFunctionalNode
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="MFN_NAME")
	private MultiFunctionalNode multiFunctionalNode;

	//bi-directional many-to-one association to NetworkTerminatingEquipment
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="NTE_NAME")
	private NetworkTerminatingEquipment networkTerminatingEquipment;

	//bi-directional many-to-one association to WirelessEquipment
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="WEQ_NAME")
	private WirelessEquipment wirelessEquipment;

	//bi-directional many-to-one association to PluginHolderChar
	@OneToMany(mappedBy="pluginHolder")
	private List<PluginHolderChar> pluginHolderChars;

	//bi-directional many-to-one association to WeChassisPhAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<WeChassisPhAssoc> weChassisPhAssocs;

	//bi-directional many-to-one association to WePhPluginAssoc
	@OneToMany(mappedBy="pluginHolder")
	private List<WePhPluginAssoc> wePhPluginAssocs;

	public PluginHolder() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<CcpChassisPhAssoc> getCcpChassisPhAssocs() {
		return this.ccpChassisPhAssocs;
	}

	public void setCcpChassisPhAssocs(List<CcpChassisPhAssoc> ccpChassisPhAssocs) {
		this.ccpChassisPhAssocs = ccpChassisPhAssocs;
	}

	public CcpChassisPhAssoc addCcpChassisPhAssoc(CcpChassisPhAssoc ccpChassisPhAssoc) {
		getCcpChassisPhAssocs().add(ccpChassisPhAssoc);
		ccpChassisPhAssoc.setPluginHolder(this);

		return ccpChassisPhAssoc;
	}

	public CcpChassisPhAssoc removeCcpChassisPhAssoc(CcpChassisPhAssoc ccpChassisPhAssoc) {
		getCcpChassisPhAssocs().remove(ccpChassisPhAssoc);
		ccpChassisPhAssoc.setPluginHolder(null);

		return ccpChassisPhAssoc;
	}

	public List<CcpPhPluginAssoc> getCcpPhPluginAssocs() {
		return this.ccpPhPluginAssocs;
	}

	public void setCcpPhPluginAssocs(List<CcpPhPluginAssoc> ccpPhPluginAssocs) {
		this.ccpPhPluginAssocs = ccpPhPluginAssocs;
	}

	public CcpPhPluginAssoc addCcpPhPluginAssoc(CcpPhPluginAssoc ccpPhPluginAssoc) {
		getCcpPhPluginAssocs().add(ccpPhPluginAssoc);
		ccpPhPluginAssoc.setPluginHolder(this);

		return ccpPhPluginAssoc;
	}

	public CcpPhPluginAssoc removeCcpPhPluginAssoc(CcpPhPluginAssoc ccpPhPluginAssoc) {
		getCcpPhPluginAssocs().remove(ccpPhPluginAssoc);
		ccpPhPluginAssoc.setPluginHolder(null);

		return ccpPhPluginAssoc;
	}

	public List<CpeChassisPhAssoc> getCpeChassisPhAssocs() {
		return this.cpeChassisPhAssocs;
	}

	public void setCpeChassisPhAssocs(List<CpeChassisPhAssoc> cpeChassisPhAssocs) {
		this.cpeChassisPhAssocs = cpeChassisPhAssocs;
	}

	public CpeChassisPhAssoc addCpeChassisPhAssoc(CpeChassisPhAssoc cpeChassisPhAssoc) {
		getCpeChassisPhAssocs().add(cpeChassisPhAssoc);
		cpeChassisPhAssoc.setPluginHolder(this);

		return cpeChassisPhAssoc;
	}

	public CpeChassisPhAssoc removeCpeChassisPhAssoc(CpeChassisPhAssoc cpeChassisPhAssoc) {
		getCpeChassisPhAssocs().remove(cpeChassisPhAssoc);
		cpeChassisPhAssoc.setPluginHolder(null);

		return cpeChassisPhAssoc;
	}

	public List<CpePhPluginAssoc> getCpePhPluginAssocs() {
		return this.cpePhPluginAssocs;
	}

	public void setCpePhPluginAssocs(List<CpePhPluginAssoc> cpePhPluginAssocs) {
		this.cpePhPluginAssocs = cpePhPluginAssocs;
	}

	public CpePhPluginAssoc addCpePhPluginAssoc(CpePhPluginAssoc cpePhPluginAssoc) {
		getCpePhPluginAssocs().add(cpePhPluginAssoc);
		cpePhPluginAssoc.setPluginHolder(this);

		return cpePhPluginAssoc;
	}

	public CpePhPluginAssoc removeCpePhPluginAssoc(CpePhPluginAssoc cpePhPluginAssoc) {
		getCpePhPluginAssocs().remove(cpePhPluginAssoc);
		cpePhPluginAssoc.setPluginHolder(null);

		return cpePhPluginAssoc;
	}

	public List<DpChassisPhAssoc> getDpChassisPhAssocs() {
		return this.dpChassisPhAssocs;
	}

	public void setDpChassisPhAssocs(List<DpChassisPhAssoc> dpChassisPhAssocs) {
		this.dpChassisPhAssocs = dpChassisPhAssocs;
	}

	public DpChassisPhAssoc addDpChassisPhAssoc(DpChassisPhAssoc dpChassisPhAssoc) {
		getDpChassisPhAssocs().add(dpChassisPhAssoc);
		dpChassisPhAssoc.setPluginHolder(this);

		return dpChassisPhAssoc;
	}

	public DpChassisPhAssoc removeDpChassisPhAssoc(DpChassisPhAssoc dpChassisPhAssoc) {
		getDpChassisPhAssocs().remove(dpChassisPhAssoc);
		dpChassisPhAssoc.setPluginHolder(null);

		return dpChassisPhAssoc;
	}

	public List<DpPhPluginAssoc> getDpPhPluginAssocs() {
		return this.dpPhPluginAssocs;
	}

	public void setDpPhPluginAssocs(List<DpPhPluginAssoc> dpPhPluginAssocs) {
		this.dpPhPluginAssocs = dpPhPluginAssocs;
	}

	public DpPhPluginAssoc addDpPhPluginAssoc(DpPhPluginAssoc dpPhPluginAssoc) {
		getDpPhPluginAssocs().add(dpPhPluginAssoc);
		dpPhPluginAssoc.setPluginHolder(this);

		return dpPhPluginAssoc;
	}

	public DpPhPluginAssoc removeDpPhPluginAssoc(DpPhPluginAssoc dpPhPluginAssoc) {
		getDpPhPluginAssocs().remove(dpPhPluginAssoc);
		dpPhPluginAssoc.setPluginHolder(null);

		return dpPhPluginAssoc;
	}

	public List<JcChassisPhAssoc> getJcChassisPhAssocs() {
		return this.jcChassisPhAssocs;
	}

	public void setJcChassisPhAssocs(List<JcChassisPhAssoc> jcChassisPhAssocs) {
		this.jcChassisPhAssocs = jcChassisPhAssocs;
	}

	public JcChassisPhAssoc addJcChassisPhAssoc(JcChassisPhAssoc jcChassisPhAssoc) {
		getJcChassisPhAssocs().add(jcChassisPhAssoc);
		jcChassisPhAssoc.setPluginHolder(this);

		return jcChassisPhAssoc;
	}

	public JcChassisPhAssoc removeJcChassisPhAssoc(JcChassisPhAssoc jcChassisPhAssoc) {
		getJcChassisPhAssocs().remove(jcChassisPhAssoc);
		jcChassisPhAssoc.setPluginHolder(null);

		return jcChassisPhAssoc;
	}

	public List<JcPhPluginAssoc> getJcPhPluginAssocs() {
		return this.jcPhPluginAssocs;
	}

	public void setJcPhPluginAssocs(List<JcPhPluginAssoc> jcPhPluginAssocs) {
		this.jcPhPluginAssocs = jcPhPluginAssocs;
	}

	public JcPhPluginAssoc addJcPhPluginAssoc(JcPhPluginAssoc jcPhPluginAssoc) {
		getJcPhPluginAssocs().add(jcPhPluginAssoc);
		jcPhPluginAssoc.setPluginHolder(this);

		return jcPhPluginAssoc;
	}

	public JcPhPluginAssoc removeJcPhPluginAssoc(JcPhPluginAssoc jcPhPluginAssoc) {
		getJcPhPluginAssocs().remove(jcPhPluginAssoc);
		jcPhPluginAssoc.setPluginHolder(null);

		return jcPhPluginAssoc;
	}

	public List<MfnChassisPhAssoc> getMfnChassisPhAssocs() {
		return this.mfnChassisPhAssocs;
	}

	public void setMfnChassisPhAssocs(List<MfnChassisPhAssoc> mfnChassisPhAssocs) {
		this.mfnChassisPhAssocs = mfnChassisPhAssocs;
	}

	public MfnChassisPhAssoc addMfnChassisPhAssoc(MfnChassisPhAssoc mfnChassisPhAssoc) {
		getMfnChassisPhAssocs().add(mfnChassisPhAssoc);
		mfnChassisPhAssoc.setPluginHolder(this);

		return mfnChassisPhAssoc;
	}

	public MfnChassisPhAssoc removeMfnChassisPhAssoc(MfnChassisPhAssoc mfnChassisPhAssoc) {
		getMfnChassisPhAssocs().remove(mfnChassisPhAssoc);
		mfnChassisPhAssoc.setPluginHolder(null);

		return mfnChassisPhAssoc;
	}

	public List<MfnPhPluginAssoc> getMfnPhPluginAssocs() {
		return this.mfnPhPluginAssocs;
	}

	public void setMfnPhPluginAssocs(List<MfnPhPluginAssoc> mfnPhPluginAssocs) {
		this.mfnPhPluginAssocs = mfnPhPluginAssocs;
	}

	public MfnPhPluginAssoc addMfnPhPluginAssoc(MfnPhPluginAssoc mfnPhPluginAssoc) {
		getMfnPhPluginAssocs().add(mfnPhPluginAssoc);
		mfnPhPluginAssoc.setPluginHolder(this);

		return mfnPhPluginAssoc;
	}

	public MfnPhPluginAssoc removeMfnPhPluginAssoc(MfnPhPluginAssoc mfnPhPluginAssoc) {
		getMfnPhPluginAssocs().remove(mfnPhPluginAssoc);
		mfnPhPluginAssoc.setPluginHolder(null);

		return mfnPhPluginAssoc;
	}

	public List<NteChassisPhAssoc> getNteChassisPhAssocs() {
		return this.nteChassisPhAssocs;
	}

	public void setNteChassisPhAssocs(List<NteChassisPhAssoc> nteChassisPhAssocs) {
		this.nteChassisPhAssocs = nteChassisPhAssocs;
	}

	public NteChassisPhAssoc addNteChassisPhAssoc(NteChassisPhAssoc nteChassisPhAssoc) {
		getNteChassisPhAssocs().add(nteChassisPhAssoc);
		nteChassisPhAssoc.setPluginHolder(this);

		return nteChassisPhAssoc;
	}

	public NteChassisPhAssoc removeNteChassisPhAssoc(NteChassisPhAssoc nteChassisPhAssoc) {
		getNteChassisPhAssocs().remove(nteChassisPhAssoc);
		nteChassisPhAssoc.setPluginHolder(null);

		return nteChassisPhAssoc;
	}

	public List<NtePhPluginAssoc> getNtePhPluginAssocs() {
		return this.ntePhPluginAssocs;
	}

	public void setNtePhPluginAssocs(List<NtePhPluginAssoc> ntePhPluginAssocs) {
		this.ntePhPluginAssocs = ntePhPluginAssocs;
	}

	public NtePhPluginAssoc addNtePhPluginAssoc(NtePhPluginAssoc ntePhPluginAssoc) {
		getNtePhPluginAssocs().add(ntePhPluginAssoc);
		ntePhPluginAssoc.setPluginHolder(this);

		return ntePhPluginAssoc;
	}

	public NtePhPluginAssoc removeNtePhPluginAssoc(NtePhPluginAssoc ntePhPluginAssoc) {
		getNtePhPluginAssocs().remove(ntePhPluginAssoc);
		ntePhPluginAssoc.setPluginHolder(null);

		return ntePhPluginAssoc;
	}

	public List<Plugin> getPlugins() {
		return this.plugins;
	}

	public void setPlugins(List<Plugin> plugins) {
		this.plugins = plugins;
	}

	public Plugin addPlugin(Plugin plugin) {
		getPlugins().add(plugin);
		plugin.setPluginHolder(this);

		return plugin;
	}

	public Plugin removePlugin(Plugin plugin) {
		getPlugins().remove(plugin);
		plugin.setPluginHolder(null);

		return plugin;
	}

	public CrossConnectPoint getCrossConnectPoint() {
		return this.crossConnectPoint;
	}

	public void setCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		this.crossConnectPoint = crossConnectPoint;
	}

	public Chassi getChassi() {
		return this.chassi;
	}

	public void setChassi(Chassi chassi) {
		this.chassi = chassi;
	}

	public CustomerPremiseEquipment getCustomerPremiseEquipment() {
		return this.customerPremiseEquipment;
	}

	public void setCustomerPremiseEquipment(CustomerPremiseEquipment customerPremiseEquipment) {
		this.customerPremiseEquipment = customerPremiseEquipment;
	}

	public DistributionPoint getDistributionPoint() {
		return this.distributionPoint;
	}

	public void setDistributionPoint(DistributionPoint distributionPoint) {
		this.distributionPoint = distributionPoint;
	}

	public JointClosure getJointClosure() {
		return this.jointClosure;
	}

	public void setJointClosure(JointClosure jointClosure) {
		this.jointClosure = jointClosure;
	}

	public MultiFunctionalNode getMultiFunctionalNode() {
		return this.multiFunctionalNode;
	}

	public void setMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		this.multiFunctionalNode = multiFunctionalNode;
	}

	public NetworkTerminatingEquipment getNetworkTerminatingEquipment() {
		return this.networkTerminatingEquipment;
	}

	public void setNetworkTerminatingEquipment(NetworkTerminatingEquipment networkTerminatingEquipment) {
		this.networkTerminatingEquipment = networkTerminatingEquipment;
	}

	public WirelessEquipment getWirelessEquipment() {
		return this.wirelessEquipment;
	}

	public void setWirelessEquipment(WirelessEquipment wirelessEquipment) {
		this.wirelessEquipment = wirelessEquipment;
	}

	public List<PluginHolderChar> getPluginHolderChars() {
		return this.pluginHolderChars;
	}

	public void setPluginHolderChars(List<PluginHolderChar> pluginHolderChars) {
		this.pluginHolderChars = pluginHolderChars;
	}

	public PluginHolderChar addPluginHolderChar(PluginHolderChar pluginHolderChar) {
		getPluginHolderChars().add(pluginHolderChar);
		pluginHolderChar.setPluginHolder(this);

		return pluginHolderChar;
	}

	public PluginHolderChar removePluginHolderChar(PluginHolderChar pluginHolderChar) {
		getPluginHolderChars().remove(pluginHolderChar);
		pluginHolderChar.setPluginHolder(null);

		return pluginHolderChar;
	}

	public List<WeChassisPhAssoc> getWeChassisPhAssocs() {
		return this.weChassisPhAssocs;
	}

	public void setWeChassisPhAssocs(List<WeChassisPhAssoc> weChassisPhAssocs) {
		this.weChassisPhAssocs = weChassisPhAssocs;
	}

	public WeChassisPhAssoc addWeChassisPhAssoc(WeChassisPhAssoc weChassisPhAssoc) {
		getWeChassisPhAssocs().add(weChassisPhAssoc);
		weChassisPhAssoc.setPluginHolder(this);

		return weChassisPhAssoc;
	}

	public WeChassisPhAssoc removeWeChassisPhAssoc(WeChassisPhAssoc weChassisPhAssoc) {
		getWeChassisPhAssocs().remove(weChassisPhAssoc);
		weChassisPhAssoc.setPluginHolder(null);

		return weChassisPhAssoc;
	}

	public List<WePhPluginAssoc> getWePhPluginAssocs() {
		return this.wePhPluginAssocs;
	}

	public void setWePhPluginAssocs(List<WePhPluginAssoc> wePhPluginAssocs) {
		this.wePhPluginAssocs = wePhPluginAssocs;
	}

	public WePhPluginAssoc addWePhPluginAssoc(WePhPluginAssoc wePhPluginAssoc) {
		getWePhPluginAssocs().add(wePhPluginAssoc);
		wePhPluginAssoc.setPluginHolder(this);

		return wePhPluginAssoc;
	}

	public WePhPluginAssoc removeWePhPluginAssoc(WePhPluginAssoc wePhPluginAssoc) {
		getWePhPluginAssocs().remove(wePhPluginAssoc);
		wePhPluginAssoc.setPluginHolder(null);

		return wePhPluginAssoc;
	}

}