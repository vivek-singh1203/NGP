package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.SpanSectionEnd;

@Repository
public interface SpanSectionEndRepository extends SqlRepository<SpanSectionEnd> {

	public List<SpanSectionEnd> findByOrigEndNameOrTermEndName(@Param("origEndName") String origEndName,@Param("termEndName") String termEndName);
	
	public List<SpanSectionEnd> findByTermEndName(@Param("termEndName") String termEndName);
	
}