package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the MFN_PH_PLUGIN_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="MFN_PH_PLUGIN_ASSOC")
@NamedQuery(name="MfnPhPluginAssoc.findAll", query="SELECT m FROM MfnPhPluginAssoc m")
public class MfnPhPluginAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="HOLDER_COMP_ASSOC_SPEC_ID", length=50)
	private String holderCompAssocSpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to MfnHierarchy
	@OneToMany(mappedBy="mfnPhPluginAssoc")
	private List<MfnHierarchy> mfnHierarchies;

	//bi-directional many-to-one association to MultiFunctionalNode
	@ManyToOne
	@JoinColumn(name="MFN_NAME")
	private MultiFunctionalNode multiFunctionalNode;

	//bi-directional many-to-one association to PluginHolder
	@ManyToOne
	@JoinColumn(name="PH_NAME")
	private PluginHolder pluginHolder;

	//bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	public MfnPhPluginAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getHolderCompAssocSpecId() {
		return this.holderCompAssocSpecId;
	}

	public void setHolderCompAssocSpecId(String holderCompAssocSpecId) {
		this.holderCompAssocSpecId = holderCompAssocSpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public List<MfnHierarchy> getMfnHierarchies() {
		return this.mfnHierarchies;
	}

	public void setMfnHierarchies(List<MfnHierarchy> mfnHierarchies) {
		this.mfnHierarchies = mfnHierarchies;
	}

	public MfnHierarchy addMfnHierarchy(MfnHierarchy mfnHierarchy) {
		getMfnHierarchies().add(mfnHierarchy);
		mfnHierarchy.setMfnPhPluginAssoc(this);

		return mfnHierarchy;
	}

	public MfnHierarchy removeMfnHierarchy(MfnHierarchy mfnHierarchy) {
		getMfnHierarchies().remove(mfnHierarchy);
		mfnHierarchy.setMfnPhPluginAssoc(null);

		return mfnHierarchy;
	}

	public MultiFunctionalNode getMultiFunctionalNode() {
		return this.multiFunctionalNode;
	}

	public void setMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		this.multiFunctionalNode = multiFunctionalNode;
	}

	public PluginHolder getPluginHolder() {
		return this.pluginHolder;
	}

	public void setPluginHolder(PluginHolder pluginHolder) {
		this.pluginHolder = pluginHolder;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

}