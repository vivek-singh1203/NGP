package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.Chassi;
import com.bt.ngp.datasource.entities.Conductor;
import com.bt.ngp.datasource.entities.ConductorBundle;
import com.bt.ngp.datasource.entities.DistributionPoint;
import com.bt.ngp.datasource.entities.DpCsPortTerm;
import com.bt.ngp.datasource.entities.DpPort;
import com.bt.ngp.datasource.entities.Plugin;

@Repository
public interface DpCsPortTermRepository extends SqlRepository<DpCsPortTerm> {

	public DpCsPortTerm findByDistributionPointAndChassiAndPluginAndDpPortAndCableSectionAndConductorBundleAndConductor(
			DistributionPoint distributionPoint, Chassi chassi, Plugin plugin, DpPort dpPort, CableSection cableSection,
			ConductorBundle conductorBundle, Conductor conductor);

	@Query(name = "DpCsPortTermRepository.findDpCsPortTerm", nativeQuery = true)
	List<DpCsPortTerm> findDpCsPortTerm(@Param("termObj") DpCsPortTerm termObj);

	@Query(name = "DpCsPortTermRepository.fetchViaDpCsCbCond", nativeQuery = true)
	public DpCsPortTerm fetchDpCsPortTerm(@Param("dpCsPortTerm") DpCsPortTerm dpCsPortTerm);

	List<DpCsPortTerm> findByDistributionPoint(@Param("distributionPoint") DistributionPoint distributionPoint);

	@Query(name = "DpCsPortTermRepository.findByConductorAndTerminationType")
	List<DpCsPortTerm> findByConductorAndTerminationType(@Param("dpCsPortTermObj") DpCsPortTerm dpCsPortTermObj);

	@Query(name = "DpCsPortTermRepository.findByCableSectionAndPort")
	List<DpCsPortTerm> findByCableSectionAndPort(@Param("dpCsPortTermObj") DpCsPortTerm dpCsPortTermObj);

	@Query(name = "DpCsPortTermRepository.findByDpCableAndConductor")
	List<DpCsPortTerm> findByDpCableAndConductor(@Param("dpCsPortTerm") DpCsPortTerm dpCsPortTerm);
}
