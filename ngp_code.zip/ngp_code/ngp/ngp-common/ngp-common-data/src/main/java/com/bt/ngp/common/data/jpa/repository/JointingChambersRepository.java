package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.JointingChamber;

@Repository
public interface JointingChambersRepository extends SqlRepository<JointingChamber> {

	public JointingChamber findByName(@Param("name") String name);
	
	public List<JointingChamber> findByNameIn(List<String> structures);
	
	@Query(name="JointingChambersRepository.findJointingChamberWithoutSpanSectionAssoc", nativeQuery=true)
	public List<JointingChamber> findJointingChamberWithoutSpanSectionAssoc(@Param("exchangeCode") String exchangeCode);
	
	@Query(name="JointingChambersRepository.JcWithoutEquipment", nativeQuery=true)
	public List<JointingChamber> findJcWithoutEquipment(@Param("exchangeCode") String exchangeCode, @Param("physicalStructureType") String physicalStructureType);
	
}