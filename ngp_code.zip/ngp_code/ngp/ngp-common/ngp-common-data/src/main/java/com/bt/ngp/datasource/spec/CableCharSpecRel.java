package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the CABLE_CHAR_SPEC_REL database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CABLE_CHAR_SPEC_REL")
@NamedQuery(name="CableCharSpecRel.findAll", query="SELECT c FROM CableCharSpecRel c")
public class CableCharSpecRel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CHAR_SPEC_RELATION_TYPE", length=10)
	private String charSpecRelationType;

	@Column(name="CHAR_VALUE_SPEC_RELATION_TYPE", length=10)
	private String charValueSpecRelationType;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to CableSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="CABLE_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="CABLE_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private CableSpec cableSpec;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to CableSpecCharSpec
	@ManyToOne
	@JoinColumn(name="SOURCE_CHAR_SPEC_ID")
	private CableSpecCharSpec cableSpecCharSpec1;

	//bi-directional many-to-one association to CableSpecCharSpec
	@ManyToOne
	@JoinColumn(name="TARGET_CHAR_SPEC_ID")
	private CableSpecCharSpec cableSpecCharSpec2;

	public CableCharSpecRel() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCharSpecRelationType() {
		return this.charSpecRelationType;
	}

	public void setCharSpecRelationType(String charSpecRelationType) {
		this.charSpecRelationType = charSpecRelationType;
	}

	public String getCharValueSpecRelationType() {
		return this.charValueSpecRelationType;
	}

	public void setCharValueSpecRelationType(String charValueSpecRelationType) {
		this.charValueSpecRelationType = charValueSpecRelationType;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public CableSpec getCableSpec() {
		return this.cableSpec;
	}

	public void setCableSpec(CableSpec cableSpec) {
		this.cableSpec = cableSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public CableSpecCharSpec getCableSpecCharSpec1() {
		return this.cableSpecCharSpec1;
	}

	public void setCableSpecCharSpec1(CableSpecCharSpec cableSpecCharSpec1) {
		this.cableSpecCharSpec1 = cableSpecCharSpec1;
	}

	public CableSpecCharSpec getCableSpecCharSpec2() {
		return this.cableSpecCharSpec2;
	}

	public void setCableSpecCharSpec2(CableSpecCharSpec cableSpecCharSpec2) {
		this.cableSpecCharSpec2 = cableSpecCharSpec2;
	}

}