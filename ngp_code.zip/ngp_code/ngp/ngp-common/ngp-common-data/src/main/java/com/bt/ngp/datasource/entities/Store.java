package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the STORES database table.
 * 
 */
@javax.persistence.Entity
@Table(name="STORES")
@NamedQuery(name="Store.findAll", query="SELECT s FROM Store s")
public class Store implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=30)
	private String name;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	/*@Column(name="GEO_POSITION")
	 private Object geoPosition; */

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="POST_CODE", length=10)
	private String postCode;

	@Column(name="POST_TOWN", length=30)
	private String postTown;

	@Column(name="SKU_NUMBER", length=30)
	private String skuNumber;

	@Column(name="STREET_NAME", length=50)
	private String streetName;

	@Column(length=50)
	private String url;

	//bi-directional many-to-one association to AuxComponent
	@OneToMany(mappedBy="store")
	private List<AuxComponent> auxComponents;

	//bi-directional many-to-one association to Block
	@OneToMany(mappedBy="store")
	private List<Block> blocks;

	//bi-directional many-to-one association to Cabinet
	@OneToMany(mappedBy="store")
	private List<Cabinet> cabinets;

	//bi-directional many-to-one association to CableSection
	@OneToMany(mappedBy="store")
	private List<CableSection> cableSections;

	//bi-directional many-to-one association to Card
	@OneToMany(mappedBy="store")
	private List<Card> cards;

	//bi-directional many-to-one association to Chassi
	@OneToMany(mappedBy="store")
	private List<Chassi> chassis;

	//bi-directional many-to-one association to Conductor
	@OneToMany(mappedBy="store")
	private List<Conductor> conductors;

	//bi-directional many-to-one association to ConductorBundle
	@OneToMany(mappedBy="store")
	private List<ConductorBundle> conductorBundles;

	//bi-directional many-to-one association to Connector
	@OneToMany(mappedBy="store")
	private List<Connector> connectors;

	//bi-directional many-to-one association to CrossConnectPoint
	@OneToMany(mappedBy="store")
	private List<CrossConnectPoint> crossConnectPoints;

	//bi-directional many-to-one association to CustomerPremiseEquipment
	@OneToMany(mappedBy="store")
	private List<CustomerPremiseEquipment> customerPremiseEquipments;

	//bi-directional many-to-one association to DistributionFrame
	@OneToMany(mappedBy="store")
	private List<DistributionFrame> distributionFrames;

	//bi-directional many-to-one association to DistributionPoint
	@OneToMany(mappedBy="store")
	private List<DistributionPoint> distributionPoints;

	//bi-directional many-to-one association to Dslam
	@OneToMany(mappedBy="store")
	private List<Dslam> dslams;

	//bi-directional many-to-one association to Enclosure
	@OneToMany(mappedBy="store")
	private List<Enclosure> enclosures;

	//bi-directional many-to-one association to JointingChamber
	@OneToMany(mappedBy="store")
	private List<JointingChamber> jointingChambers;

	//bi-directional many-to-one association to JointClosure
	@OneToMany(mappedBy="store")
	private List<JointClosure> jointClosures;

	//bi-directional many-to-one association to MultiFunctionalNode
	@OneToMany(mappedBy="store")
	private List<MultiFunctionalNode> multiFunctionalNodes;

	//bi-directional many-to-one association to NetworkTerminatingEquipment
	@OneToMany(mappedBy="store")
	private List<NetworkTerminatingEquipment> networkTerminatingEquipments;

	//bi-directional many-to-one association to Plugin
	@OneToMany(mappedBy="store")
	private List<Plugin> plugins;

	//bi-directional many-to-one association to Pole
	@OneToMany(mappedBy="store")
	private List<Pole> poles;

	//bi-directional many-to-one association to Rack
	@OneToMany(mappedBy="store")
	private List<Rack> racks;

	//bi-directional many-to-one association to SpanSection
	@OneToMany(mappedBy="store")
	private List<SpanSection> spanSections;

	//bi-directional many-to-one association to Supplier
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to Structure
	@OneToMany(mappedBy="store")
	private List<Structure> structures;

	//bi-directional many-to-one association to WirelessEquipment
	@OneToMany(mappedBy="store")
	private List<WirelessEquipment> wirelessEquipments;

	public Store() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getPostCode() {
		return this.postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getPostTown() {
		return this.postTown;
	}

	public void setPostTown(String postTown) {
		this.postTown = postTown;
	}

	public String getSkuNumber() {
		return this.skuNumber;
	}

	public void setSkuNumber(String skuNumber) {
		this.skuNumber = skuNumber;
	}

	public String getStreetName() {
		return this.streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public List<AuxComponent> getAuxComponents() {
		return this.auxComponents;
	}

	public void setAuxComponents(List<AuxComponent> auxComponents) {
		this.auxComponents = auxComponents;
	}

	public AuxComponent addAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().add(auxComponent);
		auxComponent.setStore(this);

		return auxComponent;
	}

	public AuxComponent removeAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().remove(auxComponent);
		auxComponent.setStore(null);

		return auxComponent;
	}

	public List<Block> getBlocks() {
		return this.blocks;
	}

	public void setBlocks(List<Block> blocks) {
		this.blocks = blocks;
	}

	public Block addBlock(Block block) {
		getBlocks().add(block);
		block.setStore(this);

		return block;
	}

	public Block removeBlock(Block block) {
		getBlocks().remove(block);
		block.setStore(null);

		return block;
	}

	public List<Cabinet> getCabinets() {
		return this.cabinets;
	}

	public void setCabinets(List<Cabinet> cabinets) {
		this.cabinets = cabinets;
	}

	public Cabinet addCabinet(Cabinet cabinet) {
		getCabinets().add(cabinet);
		cabinet.setStore(this);

		return cabinet;
	}

	public Cabinet removeCabinet(Cabinet cabinet) {
		getCabinets().remove(cabinet);
		cabinet.setStore(null);

		return cabinet;
	}

	public List<CableSection> getCableSections() {
		return this.cableSections;
	}

	public void setCableSections(List<CableSection> cableSections) {
		this.cableSections = cableSections;
	}

	public CableSection addCableSection(CableSection cableSection) {
		getCableSections().add(cableSection);
		cableSection.setStore(this);

		return cableSection;
	}

	public CableSection removeCableSection(CableSection cableSection) {
		getCableSections().remove(cableSection);
		cableSection.setStore(null);

		return cableSection;
	}

	public List<Card> getCards() {
		return this.cards;
	}

	public void setCards(List<Card> cards) {
		this.cards = cards;
	}

	public Card addCard(Card card) {
		getCards().add(card);
		card.setStore(this);

		return card;
	}

	public Card removeCard(Card card) {
		getCards().remove(card);
		card.setStore(null);

		return card;
	}

	public List<Chassi> getChassis() {
		return this.chassis;
	}

	public void setChassis(List<Chassi> chassis) {
		this.chassis = chassis;
	}

	public Chassi addChassi(Chassi chassi) {
		getChassis().add(chassi);
		chassi.setStore(this);

		return chassi;
	}

	public Chassi removeChassi(Chassi chassi) {
		getChassis().remove(chassi);
		chassi.setStore(null);

		return chassi;
	}

	public List<Conductor> getConductors() {
		return this.conductors;
	}

	public void setConductors(List<Conductor> conductors) {
		this.conductors = conductors;
	}

	public Conductor addConductor(Conductor conductor) {
		getConductors().add(conductor);
		conductor.setStore(this);

		return conductor;
	}

	public Conductor removeConductor(Conductor conductor) {
		getConductors().remove(conductor);
		conductor.setStore(null);

		return conductor;
	}

	public List<ConductorBundle> getConductorBundles() {
		return this.conductorBundles;
	}

	public void setConductorBundles(List<ConductorBundle> conductorBundles) {
		this.conductorBundles = conductorBundles;
	}

	public ConductorBundle addConductorBundle(ConductorBundle conductorBundle) {
		getConductorBundles().add(conductorBundle);
		conductorBundle.setStore(this);

		return conductorBundle;
	}

	public ConductorBundle removeConductorBundle(ConductorBundle conductorBundle) {
		getConductorBundles().remove(conductorBundle);
		conductorBundle.setStore(null);

		return conductorBundle;
	}

	public List<Connector> getConnectors() {
		return this.connectors;
	}

	public void setConnectors(List<Connector> connectors) {
		this.connectors = connectors;
	}

	public Connector addConnector(Connector connector) {
		getConnectors().add(connector);
		connector.setStore(this);

		return connector;
	}

	public Connector removeConnector(Connector connector) {
		getConnectors().remove(connector);
		connector.setStore(null);

		return connector;
	}

	public List<CrossConnectPoint> getCrossConnectPoints() {
		return this.crossConnectPoints;
	}

	public void setCrossConnectPoints(List<CrossConnectPoint> crossConnectPoints) {
		this.crossConnectPoints = crossConnectPoints;
	}

	public CrossConnectPoint addCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		getCrossConnectPoints().add(crossConnectPoint);
		crossConnectPoint.setStore(this);

		return crossConnectPoint;
	}

	public CrossConnectPoint removeCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		getCrossConnectPoints().remove(crossConnectPoint);
		crossConnectPoint.setStore(null);

		return crossConnectPoint;
	}

	public List<CustomerPremiseEquipment> getCustomerPremiseEquipments() {
		return this.customerPremiseEquipments;
	}

	public void setCustomerPremiseEquipments(List<CustomerPremiseEquipment> customerPremiseEquipments) {
		this.customerPremiseEquipments = customerPremiseEquipments;
	}

	public CustomerPremiseEquipment addCustomerPremiseEquipment(CustomerPremiseEquipment customerPremiseEquipment) {
		getCustomerPremiseEquipments().add(customerPremiseEquipment);
		customerPremiseEquipment.setStore(this);

		return customerPremiseEquipment;
	}

	public CustomerPremiseEquipment removeCustomerPremiseEquipment(CustomerPremiseEquipment customerPremiseEquipment) {
		getCustomerPremiseEquipments().remove(customerPremiseEquipment);
		customerPremiseEquipment.setStore(null);

		return customerPremiseEquipment;
	}

	public List<DistributionFrame> getDistributionFrames() {
		return this.distributionFrames;
	}

	public void setDistributionFrames(List<DistributionFrame> distributionFrames) {
		this.distributionFrames = distributionFrames;
	}

	public DistributionFrame addDistributionFrame(DistributionFrame distributionFrame) {
		getDistributionFrames().add(distributionFrame);
		distributionFrame.setStore(this);

		return distributionFrame;
	}

	public DistributionFrame removeDistributionFrame(DistributionFrame distributionFrame) {
		getDistributionFrames().remove(distributionFrame);
		distributionFrame.setStore(null);

		return distributionFrame;
	}

	public List<DistributionPoint> getDistributionPoints() {
		return this.distributionPoints;
	}

	public void setDistributionPoints(List<DistributionPoint> distributionPoints) {
		this.distributionPoints = distributionPoints;
	}

	public DistributionPoint addDistributionPoint(DistributionPoint distributionPoint) {
		getDistributionPoints().add(distributionPoint);
		distributionPoint.setStore(this);

		return distributionPoint;
	}

	public DistributionPoint removeDistributionPoint(DistributionPoint distributionPoint) {
		getDistributionPoints().remove(distributionPoint);
		distributionPoint.setStore(null);

		return distributionPoint;
	}

	public List<Dslam> getDslams() {
		return this.dslams;
	}

	public void setDslams(List<Dslam> dslams) {
		this.dslams = dslams;
	}

	public Dslam addDslam(Dslam dslam) {
		getDslams().add(dslam);
		dslam.setStore(this);

		return dslam;
	}

	public Dslam removeDslam(Dslam dslam) {
		getDslams().remove(dslam);
		dslam.setStore(null);

		return dslam;
	}

	public List<Enclosure> getEnclosures() {
		return this.enclosures;
	}

	public void setEnclosures(List<Enclosure> enclosures) {
		this.enclosures = enclosures;
	}

	public Enclosure addEnclosure(Enclosure enclosure) {
		getEnclosures().add(enclosure);
		enclosure.setStore(this);

		return enclosure;
	}

	public Enclosure removeEnclosure(Enclosure enclosure) {
		getEnclosures().remove(enclosure);
		enclosure.setStore(null);

		return enclosure;
	}

	public List<JointingChamber> getJointingChambers() {
		return this.jointingChambers;
	}

	public void setJointingChambers(List<JointingChamber> jointingChambers) {
		this.jointingChambers = jointingChambers;
	}

	public JointingChamber addJointingChamber(JointingChamber jointingChamber) {
		getJointingChambers().add(jointingChamber);
		jointingChamber.setStore(this);

		return jointingChamber;
	}

	public JointingChamber removeJointingChamber(JointingChamber jointingChamber) {
		getJointingChambers().remove(jointingChamber);
		jointingChamber.setStore(null);

		return jointingChamber;
	}

	public List<JointClosure> getJointClosures() {
		return this.jointClosures;
	}

	public void setJointClosures(List<JointClosure> jointClosures) {
		this.jointClosures = jointClosures;
	}

	public JointClosure addJointClosure(JointClosure jointClosure) {
		getJointClosures().add(jointClosure);
		jointClosure.setStore(this);

		return jointClosure;
	}

	public JointClosure removeJointClosure(JointClosure jointClosure) {
		getJointClosures().remove(jointClosure);
		jointClosure.setStore(null);

		return jointClosure;
	}

	public List<MultiFunctionalNode> getMultiFunctionalNodes() {
		return this.multiFunctionalNodes;
	}

	public void setMultiFunctionalNodes(List<MultiFunctionalNode> multiFunctionalNodes) {
		this.multiFunctionalNodes = multiFunctionalNodes;
	}

	public MultiFunctionalNode addMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		getMultiFunctionalNodes().add(multiFunctionalNode);
		multiFunctionalNode.setStore(this);

		return multiFunctionalNode;
	}

	public MultiFunctionalNode removeMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		getMultiFunctionalNodes().remove(multiFunctionalNode);
		multiFunctionalNode.setStore(null);

		return multiFunctionalNode;
	}

	public List<NetworkTerminatingEquipment> getNetworkTerminatingEquipments() {
		return this.networkTerminatingEquipments;
	}

	public void setNetworkTerminatingEquipments(List<NetworkTerminatingEquipment> networkTerminatingEquipments) {
		this.networkTerminatingEquipments = networkTerminatingEquipments;
	}

	public NetworkTerminatingEquipment addNetworkTerminatingEquipment(NetworkTerminatingEquipment networkTerminatingEquipment) {
		getNetworkTerminatingEquipments().add(networkTerminatingEquipment);
		networkTerminatingEquipment.setStore(this);

		return networkTerminatingEquipment;
	}

	public NetworkTerminatingEquipment removeNetworkTerminatingEquipment(NetworkTerminatingEquipment networkTerminatingEquipment) {
		getNetworkTerminatingEquipments().remove(networkTerminatingEquipment);
		networkTerminatingEquipment.setStore(null);

		return networkTerminatingEquipment;
	}

	public List<Plugin> getPlugins() {
		return this.plugins;
	}

	public void setPlugins(List<Plugin> plugins) {
		this.plugins = plugins;
	}

	public Plugin addPlugin(Plugin plugin) {
		getPlugins().add(plugin);
		plugin.setStore(this);

		return plugin;
	}

	public Plugin removePlugin(Plugin plugin) {
		getPlugins().remove(plugin);
		plugin.setStore(null);

		return plugin;
	}

	public List<Pole> getPoles() {
		return this.poles;
	}

	public void setPoles(List<Pole> poles) {
		this.poles = poles;
	}

	public Pole addPole(Pole pole) {
		getPoles().add(pole);
		pole.setStore(this);

		return pole;
	}

	public Pole removePole(Pole pole) {
		getPoles().remove(pole);
		pole.setStore(null);

		return pole;
	}

	public List<Rack> getRacks() {
		return this.racks;
	}

	public void setRacks(List<Rack> racks) {
		this.racks = racks;
	}

	public Rack addRack(Rack rack) {
		getRacks().add(rack);
		rack.setStore(this);

		return rack;
	}

	public Rack removeRack(Rack rack) {
		getRacks().remove(rack);
		rack.setStore(null);

		return rack;
	}

	public List<SpanSection> getSpanSections() {
		return this.spanSections;
	}

	public void setSpanSections(List<SpanSection> spanSections) {
		this.spanSections = spanSections;
	}

	public SpanSection addSpanSection(SpanSection spanSection) {
		getSpanSections().add(spanSection);
		spanSection.setStore(this);

		return spanSection;
	}

	public SpanSection removeSpanSection(SpanSection spanSection) {
		getSpanSections().remove(spanSection);
		spanSection.setStore(null);

		return spanSection;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public List<Structure> getStructures() {
		return this.structures;
	}

	public void setStructures(List<Structure> structures) {
		this.structures = structures;
	}

	public Structure addStructure(Structure structure) {
		getStructures().add(structure);
		structure.setStore(this);

		return structure;
	}

	public Structure removeStructure(Structure structure) {
		getStructures().remove(structure);
		structure.setStore(null);

		return structure;
	}

	public List<WirelessEquipment> getWirelessEquipments() {
		return this.wirelessEquipments;
	}

	public void setWirelessEquipments(List<WirelessEquipment> wirelessEquipments) {
		this.wirelessEquipments = wirelessEquipments;
	}

	public WirelessEquipment addWirelessEquipment(WirelessEquipment wirelessEquipment) {
		getWirelessEquipments().add(wirelessEquipment);
		wirelessEquipment.setStore(this);

		return wirelessEquipment;
	}

	public WirelessEquipment removeWirelessEquipment(WirelessEquipment wirelessEquipment) {
		getWirelessEquipments().remove(wirelessEquipment);
		wirelessEquipment.setStore(null);

		return wirelessEquipment;
	}

}