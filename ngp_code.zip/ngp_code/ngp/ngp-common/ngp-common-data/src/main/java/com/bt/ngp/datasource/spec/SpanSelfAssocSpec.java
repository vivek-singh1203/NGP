package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the SPAN_SELF_ASSOC_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="SPAN_SELF_ASSOC_SPEC")
@NamedQuery(name="SpanSelfAssocSpec.findAll", query="SELECT s FROM SpanSelfAssocSpec s")
public class SpanSelfAssocSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, precision=38)
	private long id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="NO_OF_CHILD_INSTANCES", nullable=false, precision=38)
	private BigDecimal noOfChildInstances;

	//bi-directional many-to-one association to SpanSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="CHILD_SPAN_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="CHILD_SPAN_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private SpanSpec spanSpec1;

	//bi-directional many-to-one association to SpanSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="PARENT_SPAN_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="PARENT_SPAN_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private SpanSpec spanSpec2;

	public SpanSelfAssocSpec() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getNoOfChildInstances() {
		return this.noOfChildInstances;
	}

	public void setNoOfChildInstances(BigDecimal noOfChildInstances) {
		this.noOfChildInstances = noOfChildInstances;
	}

	public SpanSpec getSpanSpec1() {
		return this.spanSpec1;
	}

	public void setSpanSpec1(SpanSpec spanSpec1) {
		this.spanSpec1 = spanSpec1;
	}

	public SpanSpec getSpanSpec2() {
		return this.spanSpec2;
	}

	public void setSpanSpec2(SpanSpec spanSpec2) {
		this.spanSpec2 = spanSpec2;
	}

}