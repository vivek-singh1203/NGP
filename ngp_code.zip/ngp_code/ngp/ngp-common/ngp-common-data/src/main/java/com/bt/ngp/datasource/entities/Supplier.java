package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the SUPPLIERS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="SUPPLIERS")
@NamedQuery(name="Supplier.findAll", query="SELECT s FROM Supplier s")
public class Supplier implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=30)
	private String name;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	/*@Column(name="GEO_POSITION")
	 private Object geoPosition; */

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="POST_CODE", length=10)
	private String postCode;

	@Column(name="POST_TOWN", length=30)
	private String postTown;

	@Column(name="STREET_NAME", length=50)
	private String streetName;

	@Column(length=50)
	private String url;

	//bi-directional many-to-one association to AuxComponent
	@OneToMany(mappedBy="supplier")
	private List<AuxComponent> auxComponents;

	//bi-directional many-to-one association to Block
	@OneToMany(mappedBy="supplier")
	private List<Block> blocks;

	//bi-directional many-to-one association to Cabinet
	@OneToMany(mappedBy="supplier")
	private List<Cabinet> cabinets;

	//bi-directional many-to-one association to CableSection
	@OneToMany(mappedBy="supplier")
	private List<CableSection> cableSections;

	//bi-directional many-to-one association to Card
	@OneToMany(mappedBy="supplier")
	private List<Card> cards;

	//bi-directional many-to-one association to Chassi
	@OneToMany(mappedBy="supplier")
	private List<Chassi> chassis;

	//bi-directional many-to-one association to Conductor
	@OneToMany(mappedBy="supplier")
	private List<Conductor> conductors;

	//bi-directional many-to-one association to ConductorBundle
	@OneToMany(mappedBy="supplier")
	private List<ConductorBundle> conductorBundles;

	//bi-directional many-to-one association to Connector
	@OneToMany(mappedBy="supplier")
	private List<Connector> connectors;

	//bi-directional many-to-one association to CrossConnectPoint
	@OneToMany(mappedBy="supplier")
	private List<CrossConnectPoint> crossConnectPoints;

	//bi-directional many-to-one association to CustomerPremiseEquipment
	@OneToMany(mappedBy="supplier")
	private List<CustomerPremiseEquipment> customerPremiseEquipments;

	//bi-directional many-to-one association to DistributionFrame
	@OneToMany(mappedBy="supplier")
	private List<DistributionFrame> distributionFrames;

	//bi-directional many-to-one association to DistributionPoint
	@OneToMany(mappedBy="supplier")
	private List<DistributionPoint> distributionPoints;

	//bi-directional many-to-one association to Dslam
	@OneToMany(mappedBy="supplier")
	private List<Dslam> dslams;

	//bi-directional many-to-one association to Enclosure
	@OneToMany(mappedBy="supplier")
	private List<Enclosure> enclosures;

	//bi-directional many-to-one association to JointingChamber
	@OneToMany(mappedBy="supplier")
	private List<JointingChamber> jointingChambers;

	//bi-directional many-to-one association to JointClosure
	@OneToMany(mappedBy="supplier")
	private List<JointClosure> jointClosures;

	//bi-directional many-to-one association to MultiFunctionalNode
	@OneToMany(mappedBy="supplier")
	private List<MultiFunctionalNode> multiFunctionalNodes;

	//bi-directional many-to-one association to NetworkTerminatingEquipment
	@OneToMany(mappedBy="supplier")
	private List<NetworkTerminatingEquipment> networkTerminatingEquipments;

	//bi-directional many-to-one association to Plugin
	@OneToMany(mappedBy="supplier")
	private List<Plugin> plugins;

	//bi-directional many-to-one association to Pole
	@OneToMany(mappedBy="supplier")
	private List<Pole> poles;

	//bi-directional many-to-one association to Rack
	@OneToMany(mappedBy="supplier")
	private List<Rack> racks;

	//bi-directional many-to-one association to SpanSection
	@OneToMany(mappedBy="supplier")
	private List<SpanSection> spanSections;

	//bi-directional many-to-one association to Store
	@OneToMany(mappedBy="supplier")
	private List<Store> stores;

	//bi-directional many-to-one association to Structure
	@OneToMany(mappedBy="supplier")
	private List<Structure> structures;

	//bi-directional many-to-one association to WirelessEquipment
	@OneToMany(mappedBy="supplier")
	private List<WirelessEquipment> wirelessEquipments;

	public Supplier() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getPostCode() {
		return this.postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getPostTown() {
		return this.postTown;
	}

	public void setPostTown(String postTown) {
		this.postTown = postTown;
	}

	public String getStreetName() {
		return this.streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public List<AuxComponent> getAuxComponents() {
		return this.auxComponents;
	}

	public void setAuxComponents(List<AuxComponent> auxComponents) {
		this.auxComponents = auxComponents;
	}

	public AuxComponent addAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().add(auxComponent);
		auxComponent.setSupplier(this);

		return auxComponent;
	}

	public AuxComponent removeAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().remove(auxComponent);
		auxComponent.setSupplier(null);

		return auxComponent;
	}

	public List<Block> getBlocks() {
		return this.blocks;
	}

	public void setBlocks(List<Block> blocks) {
		this.blocks = blocks;
	}

	public Block addBlock(Block block) {
		getBlocks().add(block);
		block.setSupplier(this);

		return block;
	}

	public Block removeBlock(Block block) {
		getBlocks().remove(block);
		block.setSupplier(null);

		return block;
	}

	public List<Cabinet> getCabinets() {
		return this.cabinets;
	}

	public void setCabinets(List<Cabinet> cabinets) {
		this.cabinets = cabinets;
	}

	public Cabinet addCabinet(Cabinet cabinet) {
		getCabinets().add(cabinet);
		cabinet.setSupplier(this);

		return cabinet;
	}

	public Cabinet removeCabinet(Cabinet cabinet) {
		getCabinets().remove(cabinet);
		cabinet.setSupplier(null);

		return cabinet;
	}

	public List<CableSection> getCableSections() {
		return this.cableSections;
	}

	public void setCableSections(List<CableSection> cableSections) {
		this.cableSections = cableSections;
	}

	public CableSection addCableSection(CableSection cableSection) {
		getCableSections().add(cableSection);
		cableSection.setSupplier(this);

		return cableSection;
	}

	public CableSection removeCableSection(CableSection cableSection) {
		getCableSections().remove(cableSection);
		cableSection.setSupplier(null);

		return cableSection;
	}

	public List<Card> getCards() {
		return this.cards;
	}

	public void setCards(List<Card> cards) {
		this.cards = cards;
	}

	public Card addCard(Card card) {
		getCards().add(card);
		card.setSupplier(this);

		return card;
	}

	public Card removeCard(Card card) {
		getCards().remove(card);
		card.setSupplier(null);

		return card;
	}

	public List<Chassi> getChassis() {
		return this.chassis;
	}

	public void setChassis(List<Chassi> chassis) {
		this.chassis = chassis;
	}

	public Chassi addChassi(Chassi chassi) {
		getChassis().add(chassi);
		chassi.setSupplier(this);

		return chassi;
	}

	public Chassi removeChassi(Chassi chassi) {
		getChassis().remove(chassi);
		chassi.setSupplier(null);

		return chassi;
	}

	public List<Conductor> getConductors() {
		return this.conductors;
	}

	public void setConductors(List<Conductor> conductors) {
		this.conductors = conductors;
	}

	public Conductor addConductor(Conductor conductor) {
		getConductors().add(conductor);
		conductor.setSupplier(this);

		return conductor;
	}

	public Conductor removeConductor(Conductor conductor) {
		getConductors().remove(conductor);
		conductor.setSupplier(null);

		return conductor;
	}

	public List<ConductorBundle> getConductorBundles() {
		return this.conductorBundles;
	}

	public void setConductorBundles(List<ConductorBundle> conductorBundles) {
		this.conductorBundles = conductorBundles;
	}

	public ConductorBundle addConductorBundle(ConductorBundle conductorBundle) {
		getConductorBundles().add(conductorBundle);
		conductorBundle.setSupplier(this);

		return conductorBundle;
	}

	public ConductorBundle removeConductorBundle(ConductorBundle conductorBundle) {
		getConductorBundles().remove(conductorBundle);
		conductorBundle.setSupplier(null);

		return conductorBundle;
	}

	public List<Connector> getConnectors() {
		return this.connectors;
	}

	public void setConnectors(List<Connector> connectors) {
		this.connectors = connectors;
	}

	public Connector addConnector(Connector connector) {
		getConnectors().add(connector);
		connector.setSupplier(this);

		return connector;
	}

	public Connector removeConnector(Connector connector) {
		getConnectors().remove(connector);
		connector.setSupplier(null);

		return connector;
	}

	public List<CrossConnectPoint> getCrossConnectPoints() {
		return this.crossConnectPoints;
	}

	public void setCrossConnectPoints(List<CrossConnectPoint> crossConnectPoints) {
		this.crossConnectPoints = crossConnectPoints;
	}

	public CrossConnectPoint addCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		getCrossConnectPoints().add(crossConnectPoint);
		crossConnectPoint.setSupplier(this);

		return crossConnectPoint;
	}

	public CrossConnectPoint removeCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		getCrossConnectPoints().remove(crossConnectPoint);
		crossConnectPoint.setSupplier(null);

		return crossConnectPoint;
	}

	public List<CustomerPremiseEquipment> getCustomerPremiseEquipments() {
		return this.customerPremiseEquipments;
	}

	public void setCustomerPremiseEquipments(List<CustomerPremiseEquipment> customerPremiseEquipments) {
		this.customerPremiseEquipments = customerPremiseEquipments;
	}

	public CustomerPremiseEquipment addCustomerPremiseEquipment(CustomerPremiseEquipment customerPremiseEquipment) {
		getCustomerPremiseEquipments().add(customerPremiseEquipment);
		customerPremiseEquipment.setSupplier(this);

		return customerPremiseEquipment;
	}

	public CustomerPremiseEquipment removeCustomerPremiseEquipment(CustomerPremiseEquipment customerPremiseEquipment) {
		getCustomerPremiseEquipments().remove(customerPremiseEquipment);
		customerPremiseEquipment.setSupplier(null);

		return customerPremiseEquipment;
	}

	public List<DistributionFrame> getDistributionFrames() {
		return this.distributionFrames;
	}

	public void setDistributionFrames(List<DistributionFrame> distributionFrames) {
		this.distributionFrames = distributionFrames;
	}

	public DistributionFrame addDistributionFrame(DistributionFrame distributionFrame) {
		getDistributionFrames().add(distributionFrame);
		distributionFrame.setSupplier(this);

		return distributionFrame;
	}

	public DistributionFrame removeDistributionFrame(DistributionFrame distributionFrame) {
		getDistributionFrames().remove(distributionFrame);
		distributionFrame.setSupplier(null);

		return distributionFrame;
	}

	public List<DistributionPoint> getDistributionPoints() {
		return this.distributionPoints;
	}

	public void setDistributionPoints(List<DistributionPoint> distributionPoints) {
		this.distributionPoints = distributionPoints;
	}

	public DistributionPoint addDistributionPoint(DistributionPoint distributionPoint) {
		getDistributionPoints().add(distributionPoint);
		distributionPoint.setSupplier(this);

		return distributionPoint;
	}

	public DistributionPoint removeDistributionPoint(DistributionPoint distributionPoint) {
		getDistributionPoints().remove(distributionPoint);
		distributionPoint.setSupplier(null);

		return distributionPoint;
	}

	public List<Dslam> getDslams() {
		return this.dslams;
	}

	public void setDslams(List<Dslam> dslams) {
		this.dslams = dslams;
	}

	public Dslam addDslam(Dslam dslam) {
		getDslams().add(dslam);
		dslam.setSupplier(this);

		return dslam;
	}

	public Dslam removeDslam(Dslam dslam) {
		getDslams().remove(dslam);
		dslam.setSupplier(null);

		return dslam;
	}

	public List<Enclosure> getEnclosures() {
		return this.enclosures;
	}

	public void setEnclosures(List<Enclosure> enclosures) {
		this.enclosures = enclosures;
	}

	public Enclosure addEnclosure(Enclosure enclosure) {
		getEnclosures().add(enclosure);
		enclosure.setSupplier(this);

		return enclosure;
	}

	public Enclosure removeEnclosure(Enclosure enclosure) {
		getEnclosures().remove(enclosure);
		enclosure.setSupplier(null);

		return enclosure;
	}

	public List<JointingChamber> getJointingChambers() {
		return this.jointingChambers;
	}

	public void setJointingChambers(List<JointingChamber> jointingChambers) {
		this.jointingChambers = jointingChambers;
	}

	public JointingChamber addJointingChamber(JointingChamber jointingChamber) {
		getJointingChambers().add(jointingChamber);
		jointingChamber.setSupplier(this);

		return jointingChamber;
	}

	public JointingChamber removeJointingChamber(JointingChamber jointingChamber) {
		getJointingChambers().remove(jointingChamber);
		jointingChamber.setSupplier(null);

		return jointingChamber;
	}

	public List<JointClosure> getJointClosures() {
		return this.jointClosures;
	}

	public void setJointClosures(List<JointClosure> jointClosures) {
		this.jointClosures = jointClosures;
	}

	public JointClosure addJointClosure(JointClosure jointClosure) {
		getJointClosures().add(jointClosure);
		jointClosure.setSupplier(this);

		return jointClosure;
	}

	public JointClosure removeJointClosure(JointClosure jointClosure) {
		getJointClosures().remove(jointClosure);
		jointClosure.setSupplier(null);

		return jointClosure;
	}

	public List<MultiFunctionalNode> getMultiFunctionalNodes() {
		return this.multiFunctionalNodes;
	}

	public void setMultiFunctionalNodes(List<MultiFunctionalNode> multiFunctionalNodes) {
		this.multiFunctionalNodes = multiFunctionalNodes;
	}

	public MultiFunctionalNode addMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		getMultiFunctionalNodes().add(multiFunctionalNode);
		multiFunctionalNode.setSupplier(this);

		return multiFunctionalNode;
	}

	public MultiFunctionalNode removeMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		getMultiFunctionalNodes().remove(multiFunctionalNode);
		multiFunctionalNode.setSupplier(null);

		return multiFunctionalNode;
	}

	public List<NetworkTerminatingEquipment> getNetworkTerminatingEquipments() {
		return this.networkTerminatingEquipments;
	}

	public void setNetworkTerminatingEquipments(List<NetworkTerminatingEquipment> networkTerminatingEquipments) {
		this.networkTerminatingEquipments = networkTerminatingEquipments;
	}

	public NetworkTerminatingEquipment addNetworkTerminatingEquipment(NetworkTerminatingEquipment networkTerminatingEquipment) {
		getNetworkTerminatingEquipments().add(networkTerminatingEquipment);
		networkTerminatingEquipment.setSupplier(this);

		return networkTerminatingEquipment;
	}

	public NetworkTerminatingEquipment removeNetworkTerminatingEquipment(NetworkTerminatingEquipment networkTerminatingEquipment) {
		getNetworkTerminatingEquipments().remove(networkTerminatingEquipment);
		networkTerminatingEquipment.setSupplier(null);

		return networkTerminatingEquipment;
	}

	public List<Plugin> getPlugins() {
		return this.plugins;
	}

	public void setPlugins(List<Plugin> plugins) {
		this.plugins = plugins;
	}

	public Plugin addPlugin(Plugin plugin) {
		getPlugins().add(plugin);
		plugin.setSupplier(this);

		return plugin;
	}

	public Plugin removePlugin(Plugin plugin) {
		getPlugins().remove(plugin);
		plugin.setSupplier(null);

		return plugin;
	}

	public List<Pole> getPoles() {
		return this.poles;
	}

	public void setPoles(List<Pole> poles) {
		this.poles = poles;
	}

	public Pole addPole(Pole pole) {
		getPoles().add(pole);
		pole.setSupplier(this);

		return pole;
	}

	public Pole removePole(Pole pole) {
		getPoles().remove(pole);
		pole.setSupplier(null);

		return pole;
	}

	public List<Rack> getRacks() {
		return this.racks;
	}

	public void setRacks(List<Rack> racks) {
		this.racks = racks;
	}

	public Rack addRack(Rack rack) {
		getRacks().add(rack);
		rack.setSupplier(this);

		return rack;
	}

	public Rack removeRack(Rack rack) {
		getRacks().remove(rack);
		rack.setSupplier(null);

		return rack;
	}

	public List<SpanSection> getSpanSections() {
		return this.spanSections;
	}

	public void setSpanSections(List<SpanSection> spanSections) {
		this.spanSections = spanSections;
	}

	public SpanSection addSpanSection(SpanSection spanSection) {
		getSpanSections().add(spanSection);
		spanSection.setSupplier(this);

		return spanSection;
	}

	public SpanSection removeSpanSection(SpanSection spanSection) {
		getSpanSections().remove(spanSection);
		spanSection.setSupplier(null);

		return spanSection;
	}

	public List<Store> getStores() {
		return this.stores;
	}

	public void setStores(List<Store> stores) {
		this.stores = stores;
	}

	public Store addStore(Store store) {
		getStores().add(store);
		store.setSupplier(this);

		return store;
	}

	public Store removeStore(Store store) {
		getStores().remove(store);
		store.setSupplier(null);

		return store;
	}

	public List<Structure> getStructures() {
		return this.structures;
	}

	public void setStructures(List<Structure> structures) {
		this.structures = structures;
	}

	public Structure addStructure(Structure structure) {
		getStructures().add(structure);
		structure.setSupplier(this);

		return structure;
	}

	public Structure removeStructure(Structure structure) {
		getStructures().remove(structure);
		structure.setSupplier(null);

		return structure;
	}

	public List<WirelessEquipment> getWirelessEquipments() {
		return this.wirelessEquipments;
	}

	public void setWirelessEquipments(List<WirelessEquipment> wirelessEquipments) {
		this.wirelessEquipments = wirelessEquipments;
	}

	public WirelessEquipment addWirelessEquipment(WirelessEquipment wirelessEquipment) {
		getWirelessEquipments().add(wirelessEquipment);
		wirelessEquipment.setSupplier(this);

		return wirelessEquipment;
	}

	public WirelessEquipment removeWirelessEquipment(WirelessEquipment wirelessEquipment) {
		getWirelessEquipments().remove(wirelessEquipment);
		wirelessEquipment.setSupplier(null);

		return wirelessEquipment;
	}

}