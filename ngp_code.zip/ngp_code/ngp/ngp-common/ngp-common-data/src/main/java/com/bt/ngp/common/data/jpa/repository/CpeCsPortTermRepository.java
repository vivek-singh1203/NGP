package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.Chassi;
import com.bt.ngp.datasource.entities.Conductor;
import com.bt.ngp.datasource.entities.ConductorBundle;
import com.bt.ngp.datasource.entities.CpeCsPortTerm;
import com.bt.ngp.datasource.entities.CpePort;
import com.bt.ngp.datasource.entities.CustomerPremiseEquipment;
import com.bt.ngp.datasource.entities.Plugin;

@Repository
public interface CpeCsPortTermRepository extends SqlRepository<CpeCsPortTerm> {

	public CpeCsPortTerm findByCustomerPremiseEquipmentAndChassiAndPluginAndCpePortAndCableSectionAndConductorBundleAndConductor(
			CustomerPremiseEquipment customerPremiseEquipment, Chassi chassi, Plugin plugin, CpePort cpePort,
			CableSection cableSection, ConductorBundle conductorBundle, Conductor conductor);

	@Query(name = "CpeCsPortTermRepository.findCpeCsPortTerm", nativeQuery = true)
	List<CpeCsPortTerm> findCpeCsPortTerm(@Param("termObj") CpeCsPortTerm termObj);

	@Query(name = "CpeCsPortTermRepository.fetchViaCpeCsCbCond", nativeQuery = true)
	public CpeCsPortTerm fetchCpeCsPortTerm(@Param("cpeCsPortTerm") CpeCsPortTerm jcCsPortTerm);

	List<CpeCsPortTerm> findByCustomerPremiseEquipment(
			@Param("customerPremiseEquipment") CustomerPremiseEquipment customerPremiseEquipment);

	@Query(name = "CpeCsPortTermRepository.findByConductorAndTerminationType")
	List<CpeCsPortTerm> findByConductorAndTerminationType(@Param("cpeCsPortTermObj") CpeCsPortTerm cpeCsPortTermObj);

	@Query(name = "CpeCsPortTermRepository.findByCableSectionAndPort")
	List<CpeCsPortTerm> findByCableSectionAndPort(@Param("cpeCsPortTermObj") CpeCsPortTerm cpeCsPortTermObj);

	@Query(name = "CpeCsPortTermRepository.findByCpeCableAndConductor")
	List<CpeCsPortTerm> findByCpeCableAndConductor(@Param("cpeCsPortTerm") CpeCsPortTerm cpeCsPortTerm);
}
