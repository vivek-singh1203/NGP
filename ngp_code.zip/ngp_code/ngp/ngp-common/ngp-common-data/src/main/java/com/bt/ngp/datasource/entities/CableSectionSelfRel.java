package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the CABLE_SECTION_SELF_REL database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CABLE_SECTION_SELF_REL")
@NamedQuery(name="CableSectionSelfRel.findAll", query="SELECT c FROM CableSectionSelfRel c")
public class CableSectionSelfRel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SeqGen")
    @SequenceGenerator(name = "SeqGen", sequenceName = "CABLE_SECTION_SELF_REL_SEQ", allocationSize = 1)
	private long id;

	@Column(name="CABLE_SELF_REL_SPEC_ID", nullable=false, length=30)
	private String cableSelfRelSpecId;

	@Column(name="CREATED_BY", length=40)
	private String createdBy;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RELATION_TYPE", length=25)
	private String relationType;

	// bi-directional many-to-one association to CableSection
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CS_REL_FROM_NAME", nullable = false)
	private CableSection csRelFromName;

	// bi-directional many-to-one association to CableSection
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CS_REL_FROM_PARENT_CS_NAME", nullable = false)
	private CableSection csRelFromParentCsName;

	// bi-directional many-to-one association to CableSection
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CS_REL_TO_NAME", nullable = false)
	private CableSection csRelToName;

	// bi-directional many-to-one association to CableSection
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CS_REL_TO_PARENT_CS_NAME", nullable = false)
	private CableSection csRelToParentCsName;

	public CableSectionSelfRel() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCableSelfRelSpecId() {
		return this.cableSelfRelSpecId;
	}

	public void setCableSelfRelSpecId(String cableSelfRelSpecId) {
		this.cableSelfRelSpecId = cableSelfRelSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getRelationType() {
		return this.relationType;
	}

	public void setRelationType(String relationType) {
		this.relationType = relationType;
	}

	public CableSection getCsRelFromName() {
		return this.csRelFromName;
	}

	public void setCsRelFromName(CableSection csRelFromName) {
		this.csRelFromName = csRelFromName;
	}

	public CableSection getCsRelFromParentCsName() {
		return this.csRelFromParentCsName;
	}

	public void setCsRelFromParentCsName(CableSection csRelFromParentCsName) {
		this.csRelFromParentCsName = csRelFromParentCsName;
	}

	public CableSection getCsRelToName() {
		return this.csRelToName;
	}

	public void setCsRelToName(CableSection csRelToName) {
		this.csRelToName = csRelToName;
	}

	public CableSection getCsRelToParentCsName() {
		return this.csRelToParentCsName;
	}

	public void setCsRelToParentCsName(CableSection csRelToParentCsName) {
		this.csRelToParentCsName = csRelToParentCsName;
	}

}