/**
 * 
 */
package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.CableSpanAssoc;

/**
 * @author 611174701
 *
 */
@Repository
public interface CableSpanAssocRepository extends SqlRepository<com.bt.ngp.datasource.entities.CableSpanAssoc> {
	List<CableSpanAssoc> findByCableSection(CableSection cableSection);
}
