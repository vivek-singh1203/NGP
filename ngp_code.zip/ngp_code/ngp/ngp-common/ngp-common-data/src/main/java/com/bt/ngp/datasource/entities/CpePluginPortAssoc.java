package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the CPE_PLUGIN_PORT_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CPE_PLUGIN_PORT_ASSOC")
@NamedQuery(name="CpePluginPortAssoc.findAll", query="SELECT c FROM CpePluginPortAssoc c")
public class CpePluginPortAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="COMP_PORT_ASSOC_SPEC_ID", length=50)
	private String compPortAssocSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal portSeqNum;

	//bi-directional many-to-one association to CpeHierarchy
	@OneToMany(mappedBy="cpePluginPortAssoc")
	private List<CpeHierarchy> cpeHierarchies;

	//bi-directional many-to-one association to CustomerPremiseEquipment
	@ManyToOne
	@JoinColumn(name="CPE_NAME")
	private CustomerPremiseEquipment customerPremiseEquipment;

	//bi-directional many-to-one association to CpePort
	@ManyToOne
	@JoinColumn(name="PORT_NAME")
	private CpePort cpePort;

	//bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	public CpePluginPortAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompPortAssocSpecId() {
		return this.compPortAssocSpecId;
	}

	public void setCompPortAssocSpecId(String compPortAssocSpecId) {
		this.compPortAssocSpecId = compPortAssocSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortSeqNum() {
		return this.portSeqNum;
	}

	public void setPortSeqNum(BigDecimal portSeqNum) {
		this.portSeqNum = portSeqNum;
	}

	public List<CpeHierarchy> getCpeHierarchies() {
		return this.cpeHierarchies;
	}

	public void setCpeHierarchies(List<CpeHierarchy> cpeHierarchies) {
		this.cpeHierarchies = cpeHierarchies;
	}

	public CpeHierarchy addCpeHierarchy(CpeHierarchy cpeHierarchy) {
		getCpeHierarchies().add(cpeHierarchy);
		cpeHierarchy.setCpePluginPortAssoc(this);

		return cpeHierarchy;
	}

	public CpeHierarchy removeCpeHierarchy(CpeHierarchy cpeHierarchy) {
		getCpeHierarchies().remove(cpeHierarchy);
		cpeHierarchy.setCpePluginPortAssoc(null);

		return cpeHierarchy;
	}

	public CustomerPremiseEquipment getCustomerPremiseEquipment() {
		return this.customerPremiseEquipment;
	}

	public void setCustomerPremiseEquipment(CustomerPremiseEquipment customerPremiseEquipment) {
		this.customerPremiseEquipment = customerPremiseEquipment;
	}

	public CpePort getCpePort() {
		return this.cpePort;
	}

	public void setCpePort(CpePort cpePort) {
		this.cpePort = cpePort;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

}