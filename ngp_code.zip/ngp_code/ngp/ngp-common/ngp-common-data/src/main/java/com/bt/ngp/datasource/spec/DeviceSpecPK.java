package com.bt.ngp.datasource.spec;

import java.io.Serializable;

import javax.persistence.*;

/**
 * The primary key class for the DEVICE_SPEC database table.
 * 
 */
@Embeddable
public class DeviceSpecPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(unique=true, nullable=false, length=30)
	private String name;

	@Column(name="SPEC_VERSION", unique=true, nullable=false, length=5)
	private String specVersion;

	public DeviceSpecPK() {
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSpecVersion() {
		return this.specVersion;
	}
	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof DeviceSpecPK)) {
			return false;
		}
		DeviceSpecPK castOther = (DeviceSpecPK)other;
		return 
			this.name.equals(castOther.name)
			&& this.specVersion.equals(castOther.specVersion);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.name.hashCode();
		hash = hash * prime + this.specVersion.hashCode();
		
		return hash;
	}
}