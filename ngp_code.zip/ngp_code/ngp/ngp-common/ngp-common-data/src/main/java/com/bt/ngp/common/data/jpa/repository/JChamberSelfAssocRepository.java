package com.bt.ngp.common.data.jpa.repository;

import com.bt.ngp.datasource.entities.JchamberSelfAssoc;

public interface JChamberSelfAssocRepository extends SqlRepository<JchamberSelfAssoc> {

}
