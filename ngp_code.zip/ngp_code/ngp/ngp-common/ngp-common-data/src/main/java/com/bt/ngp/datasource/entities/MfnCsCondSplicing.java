package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the MFN_CS_COND_SPLICING database table.
 * 
 */
@javax.persistence.Entity
@Table(name="MFN_CS_COND_SPLICING")
@NamedQuery(name="MfnCsCondSplicing.findAll", query="SELECT m FROM MfnCsCondSplicing m")
public class MfnCsCondSplicing implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SeqGen")
    @SequenceGenerator(name = "SeqGen", sequenceName = "MFN_CS_COND_SPLICING_SEQ", allocationSize = 1)
	private long id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="ORIG_COND_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal origCondSeqNum;

	@Column(name="SPLICING_RESOURCE", nullable=false, length=20)
	private String splicingResource;

	@Column(name="SPLICING_STATE", length=20)
	private String splicingState;

	@Column(name="TERM_COND_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal termCondSeqNum;

	//bi-directional many-to-one association to MultiFunctionalNode
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="MFN_NAME")
	private MultiFunctionalNode multiFunctionalNode;

	//bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_CB_NAME")
	private ConductorBundle origCbName;

	//bi-directional many-to-one association to Conductor
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_CONDUCTOR_NAME")
	private Conductor origConductorName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_CS_NAME")
	private CableSection origCsName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_PAR_CS_NAME")
	private CableSection origParCsName;

	//bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_CB_NAME")
	private ConductorBundle termCbName;

	//bi-directional many-to-one association to Conductor
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_CONDUCTOR_NAME")
	private Conductor termConductorName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_CS_NAME")
	private CableSection termCsName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_PAR_CS_NAME")
	private CableSection termParCsName;

	
	public MfnCsCondSplicing() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getOrigCondSeqNum() {
		return origCondSeqNum;
	}

	public void setOrigCondSeqNum(BigDecimal origCondSeqNum) {
		this.origCondSeqNum = origCondSeqNum;
	}

	public String getSplicingResource() {
		return splicingResource;
	}

	public void setSplicingResource(String splicingResource) {
		this.splicingResource = splicingResource;
	}

	public String getSplicingState() {
		return splicingState;
	}

	public void setSplicingState(String splicingState) {
		this.splicingState = splicingState;
	}

	public BigDecimal getTermCondSeqNum() {
		return termCondSeqNum;
	}

	public void setTermCondSeqNum(BigDecimal termCondSeqNum) {
		this.termCondSeqNum = termCondSeqNum;
	}

	public MultiFunctionalNode getMultiFunctionalNode() {
		return multiFunctionalNode;
	}

	public void setMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		this.multiFunctionalNode = multiFunctionalNode;
	}

	public ConductorBundle getOrigCbName() {
		return origCbName;
	}

	public void setOrigCbName(ConductorBundle origCbName) {
		this.origCbName = origCbName;
	}

	public Conductor getOrigConductorName() {
		return origConductorName;
	}

	public void setOrigConductorName(Conductor origConductorName) {
		this.origConductorName = origConductorName;
	}

	public CableSection getOrigCsName() {
		return origCsName;
	}

	public void setOrigCsName(CableSection origCsName) {
		this.origCsName = origCsName;
	}

	public CableSection getOrigParCsName() {
		return origParCsName;
	}

	public void setOrigParCsName(CableSection origParCsName) {
		this.origParCsName = origParCsName;
	}

	public ConductorBundle getTermCbName() {
		return termCbName;
	}

	public void setTermCbName(ConductorBundle termCbName) {
		this.termCbName = termCbName;
	}

	public Conductor getTermConductorName() {
		return termConductorName;
	}

	public void setTermConductorName(Conductor termConductorName) {
		this.termConductorName = termConductorName;
	}

	public CableSection getTermCsName() {
		return termCsName;
	}

	public void setTermCsName(CableSection termCsName) {
		this.termCsName = termCsName;
	}

	public CableSection getTermParCsName() {
		return termParCsName;
	}

	public void setTermParCsName(CableSection termParCsName) {
		this.termParCsName = termParCsName;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}