/**
 * 
 */
package com.bt.ngp.common.constants;

/**
 * ERROR CODES STANDARD (to be strictly followed )
 * 
 * STRUCTURE AND ASSOCIATED ENTITIES : ERROR CODES FROM 10001 TO 11000
 * SPAN_SECTION AND ASSOCIATED ENTITIES : ERROR CODES FROM 11001 TO 12000
 * JOINT_CLOSURE AND ASSOCIATED ENTITIES : ERROR CODES FROM 12001 TO 14000
 * CABLE_SECTION AND ASSOCIATED ENTITIES : ERROR CODES FROM 14001 TO 15000
 * MANUFACTURER AND ASSOCIATED ENTITIES : ERROR CODES FROM 15001 TO 16000
 * 
 * @author 609375622
 * 
 */
public interface ErrorConstants {

	public static final String JC_CS_PORT_TERM_ERR_CODE = "12001";

	public static final String CPE_CS_PORT_TERM_ERR_CODE = "12002";

	public static final String DP_CS_PORT_TERM_ERR_CODE = "12003";

	public static final String NTE_CS_PORT_TERM_ERR_CODE = "12004";

	public static final String DF_CS_PORT_TERM_ERR_CODE = "12005";

	public static final String WE_CS_PORT_TERM_ERR_CODE = "12006";

	public static final String MFN_CS_PORT_TERM_ERR_CODE = "12007";

	public static final String CCP_CS_PORT_TERM_ERR_CODE = "12008";

	public static final String DSLAM_CS_PORT_TERM_ERR_CODE = "12009";

	public static final String EQ_CABLE_COMPAT_SPEC_ERR_CODE = "12010";

	public static final String HIERARCHY_CONFIGURATION_ERR_CODE = "12011";

	public static final String CHASSIS_PLUGIN_HOLDER_ERR_CODE = "12012";

	public static final String RACK_CARD_OR_BLOBK_HOLDER_ERR_CODE = "12013";

	public static final String PLUGIN_ERR_CODE = "12014";

	public static final String CARD_ERR_CODE = "12015";

	public static final String BLOCK_ERR_CODE = "12016";

	public static final String DP_PROP_ERR_CODE = "12017";

	public static final String CPE_PROP_ERR_CODE = "12018";

	public static final String NTE_PROP_ERR_CODE = "12019";

	public static final String DF_PROP_ERR_CODE = "12020";

	public static final String WE_PROP_ERR_CODE = "12021";

	public static final String DSLAM_PROP_ERR_CODE = "12022";

	public static final String CCP_PROP_ERR_CODE = "12023";

	public static final String MFN_PROP_ERR_CODE = "12024";

	public static final String JC_PROP_ERR_CODE = "12025";

	public static final String DUPLICATE_RECORD_JC_CS_PORT_TERM_ERR_CODE = "12026";

	public static final String DUPLICATE_RECORD_DSLAM_CS_PORT_TERM_ERR_CODE = "12027";

	public static final String DUPLICATE_RECORD_CCP_CS_PORT_TERM_ERR_CODE = "12028";

	public static final String DUPLICATE_RECORD_CPE_CS_PORT_TERM_ERR_CODE = "12029";

	public static final String DUPLICATE_RECORD_MFN_CS_PORT_TERM_ERR_CODE = "12030";

	public static final String DUPLICATE_RECORD_NTE_CS_PORT_TERM_ERR_CODE = "12031";

	public static final String DUPLICATE_RECORD_WE_CS_PORT_TERM_ERR_CODE = "12032";

	public static final String DUPLICATE_RECORD_DF_CS_PORT_TERM_ERR_CODE = "12033";

	public static final String DUPLICATE_RECORD_DP_CS_PORT_TERM_ERR_CODE = "12034";

	public static final String JC_MISMATCH_INCOMING_PORT_AND_PORT_IN_DB_ERR_CODE = "12035";

	public static final String DSLAM_MISMATCH_INCOMING_PORT_AND_PORT_IN_DB_ERR_CODE = "12036";

	public static final String CCP_MISMATCH_INCOMING_PORT_AND_PORT_IN_DB_ERR_CODE = "12037";

	public static final String CPE_MISMATCH_INCOMING_PORT_AND_PORT_IN_DB_ERR_CODE = "12038";

	public static final String MFN_MISMATCH_INCOMING_PORT_AND_PORT_IN_DB_ERR_CODE = "12039";

	public static final String NTE_MISMATCH_INCOMING_PORT_AND_PORT_IN_DB_ERR_CODE = "12040";

	public static final String WE_MISMATCH_INCOMING_PORT_AND_PORT_IN_DB_ERR_CODE = "12041";

	public static final String DF_MISMATCH_INCOMING_PORT_AND_PORT_IN_DB_ERR_CODE = "12042";

	public static final String DP_MISMATCH_INCOMING_PORT_AND_PORT_IN_DB_ERR_CODE = "12043";

	public static final String SPLICE_CONDUCTOR_IN_JC_ERR_CODE = "14001";

	public static final String SPLICE_CONDUCTOR_IN_CPE_ERR_CODE = "14002";

	public static final String SPLICE_CONDUCTOR_IN_DP_ERR_CODE = "14003";

	public static final String SPLICE_CONDUCTOR_IN_NTE_ERR_CODE = "14004";

	public static final String SPLICE_CONDUCTOR_IN_DF_ERR_CODE = "14005";

	public static final String SPLICE_CONDUCTOR_IN_DSLAM_ERR_CODE = "14006";

	public static final String SPLICE_CONDUCTOR_IN_CCP_ERR_CODE = "14007";

	public static final String SPLICE_CONDUCTOR_IN_WE_ERR_CODE = "14008";

	public static final String SPLICE_CONDUCTOR_IN_MFN_ERR_CODE = "14009";

	public static final String SPLICE_BFTS_IN_JC_ERR_CODE = "14010";

	public static final String SPLICE_BFTS_IN_CPE_ERR_CODE = "14011";

	public static final String SPLICE_BFTS_IN_DP_ERR_CODE = "14012";

	public static final String SPLICE_BFTS_IN_NTE_ERR_CODE = "14013";

	public static final String SPLICE_BFTS_IN_DF_ERR_CODE = "14014";

	public static final String SPLICE_BFTS_IN_DSLAM_ERR_CODE = "14015";

	public static final String SPLICE_BFTS_IN_CCP_ERR_CODE = "14016";

	public static final String SPLICE_BFTS_IN_WE_ERR_CODE = "14017";

	public static final String SPLICE_BFTS_IN_MFN_ERR_CODE = "14018";

	public static final String CABLE_SECTION_NOT_FOUND_ERR_CODE = "14019";

	public static final String CONDUCTOTR_INSTANCE_NOT_FOUND_ERR_CODE = "14020";

	public static final String CONDUCTOR_UTILIZATION_UPDATE_ERR_CODE = "14021";

	public static final String CABLE_SECTION_SELF_REL_ERR_CODE = "14022";

	public static final String CABLE_SECTION_ERR_CODE = "14023";

	public static final String CABLE_SECTION_NOT_TERMINATED_CODE = "14024";

	public static final String STRUCTURE_NOT_FOUND = "10001";

	public static final String POLE_NOT_FOUND = "10002";

	public static final String CABINET_NOT_FOUND = "10003";

	public static final String JOINTING_CHAMBER_NOT_FOUND = "10004";

	public static final String PHYSICAL_STRUCTURE_PROPERTIES_ERR_CODE = "10005";

	public static final String SPAN_SECTION_NOT_FOUND = "11001";

	public static final String SPAN_SECTION_PROPERTIES_ERR_CODE = "11002";

	public static final String MORE_THAN_ONE_CABLE_SECTION_SELECTED = "11003";
}
