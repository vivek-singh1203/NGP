package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.CableSectionSelfAssoc;

public interface CableSectionSelfAssocRepository extends SqlRepository<CableSectionSelfAssoc> {
	
	//Since Spring Data JPA 1.2.1,below API generating unnecessary  outer joins  when a single table is queried.
	List<CableSectionSelfAssoc> findByParentCsName(
			CableSection parentCableSection);
	
	@Query(name="CableSectionSelfAssocRepository.findCableSectionSelfAssocList",nativeQuery=true)
	List<CableSectionSelfAssoc> findCableSectionSelfAssocList(@Param("parentCableSection") CableSection parentCableSection);

}
