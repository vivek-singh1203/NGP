/**
 * 
 */
package com.bt.ngp.common.constants;

/**
 * @author 609375622
 *
 */
public interface ValidationConstants {

	public static final String REQUEST_INVALID = "100";

	public static final String ENTITY_DETAILS_INVALID = "101";

	public static final String SUB_COMPONENTS_INVALID = "102";

	public static final String CS_MISSING = "1001";

	public static final String JC_MISSING = "1002";

	public static final String DSLAM_MISSING = "1003";

	public static final String CCP_MISSING = "1004";

	public static final String MFN_MISSING = "1005";

	public static final String WE_MISSING = "1006";

	public static final String DF_MISSING = "1007";

	public static final String NTE_MISSING = "1008";

	public static final String DP_MISSING = "1009";

	public static final String CPE_MISSING = "1010";

	public static final String CHASSI_MISSING = "1011";

	public static final String PLUGIN_HLD_MISSING = "1012";

	public static final String PLUGIN_MISSING = "1013";

	public static final String CPE_PORT_MISSING = "1014";

	public static final String DP_PORT_MISSING = "1015";

	public static final String NTE_PORT_MISSING = "1016";

	public static final String DF_PORT_MISSING = "1017";

	public static final String WE_PORT_MISSING = "1018";

	public static final String MFN_PORT_MISSING = "1019";

	public static final String CCP_PORT_MISSING = "1020";

	public static final String DSLAM_PORT_MISSING = "1021";

	public static final String RACK_MISSING = "1022";

	public static final String CARD_HLD_MISSING = "1023";

	public static final String CARD_MISSING = "1024";

	public static final String BLOCK_HLD_MISSING = "1025";

	public static final String BLOCK_MISSING = "1026";

	public static final String JC_PORT_MISSING = "1027";

	public static final String CS_ALREADY_TERMINATED = "1028";

	public static final String EQ_CATG_TYPE_MISMATCH = "1029";

	public static final String EQ_MISSING = "1030";

	public static final String PORT_MISSING = "1031";

	public static final String PORT_SPEC_MISSING = "1034";

	public static final String GET_PORT_INPUT_VALIDATION = "1035";

	public static final String CONDUCTOR_UTILIZATION_INVALID_FOR_SPLICING = "1036";

	public static final String CONDUCTOR_UTILIZATION_MISMATCH_FOR_SPLICING = "1037";

	public static final String SRC_PORT_DEST_PORT_NUMBER_MISMATCH = "1038";

	public static final String EQ_ENTITY_SPEC_TYPE_CATEGORY_MISSING = "1039";

	public static final String CONDUCTOR_UTILIZATION_EMPTY_FOR_SPLICING = "1040";

	public static final String BFTS_ALREADY_SPLICED = "1041";

	public static final String BFTS_NOT_IN_SAME_STATE = "1042";

	public static final String BFTS_NOT_FOUND_IN_THE_TABLE = "1043";

	public static final String NO_CONDCUTOR_INVENTORY_IN_REQUEST = "1044";

	public static final String CS_HIERARCHY_MISSING = "1045";

	public static final String CONDUCTOR_NOT_PLACED_ON_PORT = "1046";

	public static final String CB_MISSING = "1047";

	public static final String CHASSI_OR_RACK_MISSING = "1048";

	public static final String HOLDER_MISSING = "1049";

	public static final String BLACK_OR_CARD_OR_PLUGIN_MISSING = "1050";

	public static final String CABLE_SECTION_NOT_PLACED_ON_PORT = "1051";

	public static final String CS_TERMINATION_MISSING = "1052";

	public static final String MULTIPLE_CS_TERMINATION_EXISTS = "1053";

	public static final String TERMINATION_TYPE_MISSING = "1054";

	public static final String CABLE_SECTION_ENDS_MISSING = "1055";

	public static final String SQL_VIEW_CREATION_ERR_CODE = "1056";

	public static final String PORT_MISSING_IN_DB = "1057";

	public static final String SRC_PORT_HIERARCHY_MISSING = "1058";

	public static final String DST_PORT_HIERARCHY_MISSING = "1059";

	public static final String PREPARE_STATEMENT_EXECUTION_FAILED_ERR_CODE = "1060";

	public static final String CONDUCTOR_ALREADY_TERMINATED = "1061";

	public static final String EXCHANGE_1141_CODE_MISSING = "1062";

	public static final String MORE_THAN_ONE_CABLE_SECTION_IN_REQUEST = "1063";

	public static final String MORE_THAN_ONE_CONDUCTOR_BUNDLE_IN_REQUEST = "1064";

	public static final String CONDUCTOR_MISSING_IN_REQUEST = "1065";

}
