/**
 * 
 */
package com.bt.ngp.common.data.jpa.repository;

import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSectionChar;

/**
 * Repository class for {@link CableSectionChar}
 *
 * @since 21 Feb 2018
 * @author Mahesh 611174701
 */
@Repository
public interface CableSectionCharRepository
		extends SqlRepository<CableSectionChar> {

}
