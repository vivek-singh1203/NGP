package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CcpPort;
import com.bt.ngp.datasource.entities.Conductor;
import com.bt.ngp.datasource.entities.Exchange;

@Repository
public interface ConductorRepository extends CommonOperation<Conductor>{

	List<Conductor> findByExchangeAndCableSectionHierarchiesIsNull(@Param("exchange") Exchange exchange);
}
