package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.Exchange;
import com.bt.ngp.datasource.entities.SpanSection;

@Repository
public interface SpanSectionRepository extends SqlRepository<SpanSection> {

	public SpanSection findByName(@Param("name") String name);
	
	public List<SpanSection> findByExchangeAndSpanSectionEndsTermEndNameIsNull(
			@Param("exchange") Exchange exchange);

	public List<SpanSection> findByExchangeAndCableSpanAssocsIsNull(
			@Param("exchange") Exchange exchange);

}