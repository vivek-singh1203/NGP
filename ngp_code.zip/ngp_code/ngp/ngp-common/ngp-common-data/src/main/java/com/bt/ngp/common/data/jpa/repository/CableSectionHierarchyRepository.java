package com.bt.ngp.common.data.jpa.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.CableSectionHierarchy;
import com.bt.ngp.datasource.entities.ConductorBundle;

@Repository
public interface CableSectionHierarchyRepository
		extends SqlRepository<CableSectionHierarchy> {

	@Query(name = "CableSectionHierarchyRepository.fetchByCableSection", nativeQuery = true)
	Optional<List<CableSectionHierarchy>> fetchByCableSection(
			@Param("cableSection") CableSection cableSection);

	List<CableSectionHierarchy> findByCableSection(@Param("cableSection") CableSection cableSection);

	Optional<List<CableSectionHierarchy>> findByConductorBundle(
			ConductorBundle conductorBundle);

	Optional<List<CableSectionHierarchy>> findByCableSectionAndConductorBundle(
			CableSection cableSection, ConductorBundle conductorBundle); 

}
