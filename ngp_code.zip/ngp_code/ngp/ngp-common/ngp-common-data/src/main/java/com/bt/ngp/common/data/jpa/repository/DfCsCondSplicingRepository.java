package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.DfCsCondSplicing;

@Repository
public interface DfCsCondSplicingRepository extends SqlRepository<DfCsCondSplicing> {

	public List<DfCsCondSplicing> findByOrigCsNameAndTermCsName(CableSection origCsName, CableSection termCsName);

	@Transactional
	@Modifying
	@Query(name = "DfCsCondSplicingRepository.deleteDfCsCondSplicingByNameOfWiredEntities", nativeQuery = true)
	public int deleteDfCsCondSplicing(@Param("dfCsCondSplicing") DfCsCondSplicing dfCsCondSplicing);

	@Query(name = "DfCsCondSplicingRepository.findConductorSplicingOriginating")
	public List<DfCsCondSplicing> findOriginatingConductorSplicing(
			@Param("dfCsCondSplicing") DfCsCondSplicing dfCsCondSplicing);

	@Query(name = "DfCsCondSplicingRepository.findConductorSplicingTerminating")
	public List<DfCsCondSplicing> findTerminatingConductorSplicing(
			@Param("dfCsCondSplicing") DfCsCondSplicing dfCsCondSplicing);

	public List<DfCsCondSplicing> findByOrigParentCsName(CableSection origParentCsName);

	public List<DfCsCondSplicing> findByTermParentCsName(CableSection termParentCsName);

	public DfCsCondSplicing findByOrigParentCsNameAndOrigCsNameAndSplicingResource(CableSection origParentCsName,
			CableSection origCsName, String splicingResource);

	public DfCsCondSplicing findByTermParentCsNameAndTermCsNameAndSplicingResource(CableSection termParentCsName,
			CableSection termCsName, String splicingResource);

}
