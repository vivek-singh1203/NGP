package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the CCP_CS_PORT_TERM database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CCP_CS_PORT_TERM")
@NamedQuery(name="CcpCsPortTerm.findAll", query="SELECT c FROM CcpCsPortTerm c")
public class CcpCsPortTerm implements Serializable,Cloneable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SeqGen")
	@SequenceGenerator(name = "SeqGen", sequenceName = "CCP_CS_PORT_TERM_SEQ", allocationSize = 1)
	private long id;

	@Column(name="COND_SEQ_NUM", precision=38)
	private BigDecimal condSeqNum;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="EQ_CABLE_COMPATIBILITY_SPEC_ID", length=50)
	private String eqCableCompatibilitySpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal portSeqNum;

	@Column(name="TERMINATING_RESOURCE", nullable=false, length=10)
	private String terminatingResource;

	@Column(name="TERMINATION_STATE", nullable=false, length=20)
	private String terminationState;

	@Column(name="TERMINATION_TYPE", nullable=false, length=20)
	private String terminationType;

	//bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="CB_NAME")
	private ConductorBundle conductorBundle;

	//bi-directional many-to-one association to CrossConnectPoint
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="CCP_NAME")
	private CrossConnectPoint crossConnectPoint;

	//bi-directional many-to-one association to Chassi
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="CHASSIS_NAME")
	private Chassi chassi;

	//bi-directional many-to-one association to Conductor
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="COND_NAME")
	private Conductor conductor;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="CS_NAME")
	private CableSection cableSection;

	//bi-directional many-to-one association to Plugin
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	//bi-directional many-to-one association to CcpPort
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="PORT_NAME")
	private CcpPort ccpPort;

	public CcpCsPortTerm() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public BigDecimal getCondSeqNum() {
		return this.condSeqNum;
	}

	public void setCondSeqNum(BigDecimal condSeqNum) {
		this.condSeqNum = condSeqNum;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getEqCableCompatibilitySpecId() {
		return this.eqCableCompatibilitySpecId;
	}

	public void setEqCableCompatibilitySpecId(String eqCableCompatibilitySpecId) {
		this.eqCableCompatibilitySpecId = eqCableCompatibilitySpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortSeqNum() {
		return this.portSeqNum;
	}

	public void setPortSeqNum(BigDecimal portSeqNum) {
		this.portSeqNum = portSeqNum;
	}

	public String getTerminatingResource() {
		return this.terminatingResource;
	}

	public void setTerminatingResource(String terminatingResource) {
		this.terminatingResource = terminatingResource;
	}

	public String getTerminationState() {
		return this.terminationState;
	}

	public void setTerminationState(String terminationState) {
		this.terminationState = terminationState;
	}

	public String getTerminationType() {
		return this.terminationType;
	}

	public void setTerminationType(String terminationType) {
		this.terminationType = terminationType;
	}

	public ConductorBundle getConductorBundle() {
		return this.conductorBundle;
	}

	public void setConductorBundle(ConductorBundle conductorBundle) {
		this.conductorBundle = conductorBundle;
	}

	public CrossConnectPoint getCrossConnectPoint() {
		return this.crossConnectPoint;
	}

	public void setCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		this.crossConnectPoint = crossConnectPoint;
	}

	public Chassi getChassi() {
		return this.chassi;
	}

	public void setChassi(Chassi chassi) {
		this.chassi = chassi;
	}

	public Conductor getConductor() {
		return this.conductor;
	}

	public void setConductor(Conductor conductor) {
		this.conductor = conductor;
	}

	public CableSection getCableSection() {
		return this.cableSection;
	}

	public void setCableSection(CableSection cableSection) {
		this.cableSection = cableSection;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

	public CcpPort getCcpPort() {
		return this.ccpPort;
	}

	public void setCcpPort(CcpPort ccpPort) {
		this.ccpPort = ccpPort;
	}
	
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

}