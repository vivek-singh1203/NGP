package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the CABLE_SECTION_HIERARCHY database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CABLE_SECTION_HIERARCHY")
@NamedQuery(name="CableSectionHierarchy.findAll", query="SELECT c FROM CableSectionHierarchy c")
public class CableSectionHierarchy implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
    @Column(unique=true, nullable=false, length=50)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SeqGen")
    @SequenceGenerator(name = "SeqGen", sequenceName = "CABLE_SECTION_HIERARCHY_SEQ", allocationSize = 1)
	private long id;

	@Column(name="CABLE_HIERARCHY_SPEC_ID", length=50)
	private String cableHierarchySpecId;

	@Column(name="COND_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal condSeqNum;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CB_NAME")
	private ConductorBundle conductorBundle;

	//bi-directional many-to-one association to Conductor
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="COND_NAME")
	private Conductor conductor;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CS_NAME")
	private CableSection cableSection;

	public CableSectionHierarchy() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCableHierarchySpecId() {
		return this.cableHierarchySpecId;
	}

	public void setCableHierarchySpecId(String cableHierarchySpecId) {
		this.cableHierarchySpecId = cableHierarchySpecId;
	}

	public BigDecimal getCondSeqNum() {
		return this.condSeqNum;
	}

	public void setCondSeqNum(BigDecimal condSeqNum) {
		this.condSeqNum = condSeqNum;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public ConductorBundle getConductorBundle() {
		return this.conductorBundle;
	}

	public void setConductorBundle(ConductorBundle conductorBundle) {
		this.conductorBundle = conductorBundle;
	}

	public Conductor getConductor() {
		return this.conductor;
	}

	public void setConductor(Conductor conductor) {
		this.conductor = conductor;
	}

	public CableSection getCableSection() {
		return this.cableSection;
	}

	public void setCableSection(CableSection cableSection) {
		this.cableSection = cableSection;
	}

}