/**
 * CableSectionSelfRel Repository
 *
 * @since 24 Jan 2018
 * @author Mrinal 611144926
 */
package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.CableSectionSelfRel;

@Repository
public interface CableSectionSelfRelRepository
		extends SqlRepository<CableSectionSelfRel> {

	public CableSectionSelfRel findByCsRelFromName(CableSection csRelFromName);

	public List<CableSectionSelfRel> findByCsRelToName(
			CableSection csRelToName);

}
