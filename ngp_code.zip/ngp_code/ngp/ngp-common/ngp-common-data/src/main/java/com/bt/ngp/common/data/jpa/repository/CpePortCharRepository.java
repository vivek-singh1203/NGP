package com.bt.ngp.common.data.jpa.repository;

import org.springframework.stereotype.Repository;
import com.bt.ngp.datasource.entities.CpePortChar;
@Repository
public interface CpePortCharRepository extends SqlRepository<CpePortChar> {
	
}