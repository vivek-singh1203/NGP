package com.bt.ngp.common.data.jpa.repository;

import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.WeStructureAssoc;

@Repository
public interface WeStructureAssocRepository extends EquipmentStructureAssocRepository<WeStructureAssoc> {

}