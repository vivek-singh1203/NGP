package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.DpPort;
import com.bt.ngp.userdefined.entities.PortStatisticsDp;

@Repository
public interface DpPortRepository extends CommonOperation<DpPort> {
	@Query(name = "DpPortRepository.fetchPortCountInPlugin", nativeQuery = false)
	public List<PortStatisticsDp> portCount(
			@Param("dpPort") DpPort dpPort);
}