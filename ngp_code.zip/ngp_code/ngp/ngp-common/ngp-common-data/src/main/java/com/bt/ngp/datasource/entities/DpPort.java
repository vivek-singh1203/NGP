package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the DP_PORTS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DP_PORTS")
@NamedQuery(name="DpPort.findAll", query="SELECT d FROM DpPort d")
public class DpPort implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal portSeqNum;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to DpCsPortTerm
	@OneToMany(mappedBy="dpPort")
	private List<DpCsPortTerm> dpCsPortTerms;

	//bi-directional many-to-one association to DpPluginPortAssoc
	@OneToMany(mappedBy="dpPort")
	private List<DpPluginPortAssoc> dpPluginPortAssocs;

	//bi-directional many-to-one association to DistributionPoint
	@ManyToOne
	@JoinColumn(name="DISTRIBUTION_POINT_NAME")
	private DistributionPoint distributionPoint;

	//bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	//bi-directional many-to-one association to DpPortChar
	@OneToMany(mappedBy="dpPort")
	private List<DpPortChar> dpPortChars;

	//bi-directional many-to-one association to DpPortPortAssoc
	@OneToMany(mappedBy="dpPort1")
	private List<DpPortPortAssoc> dpPortPortAssocs1;

	//bi-directional many-to-one association to DpPortPortAssoc
	@OneToMany(mappedBy="dpPort2")
	private List<DpPortPortAssoc> dpPortPortAssocs2;

	public DpPort() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortSeqNum() {
		return this.portSeqNum;
	}

	public void setPortSeqNum(BigDecimal portSeqNum) {
		this.portSeqNum = portSeqNum;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<DpCsPortTerm> getDpCsPortTerms() {
		return this.dpCsPortTerms;
	}

	public void setDpCsPortTerms(List<DpCsPortTerm> dpCsPortTerms) {
		this.dpCsPortTerms = dpCsPortTerms;
	}

	public DpCsPortTerm addDpCsPortTerm(DpCsPortTerm dpCsPortTerm) {
		getDpCsPortTerms().add(dpCsPortTerm);
		dpCsPortTerm.setDpPort(this);

		return dpCsPortTerm;
	}

	public DpCsPortTerm removeDpCsPortTerm(DpCsPortTerm dpCsPortTerm) {
		getDpCsPortTerms().remove(dpCsPortTerm);
		dpCsPortTerm.setDpPort(null);

		return dpCsPortTerm;
	}

	public List<DpPluginPortAssoc> getDpPluginPortAssocs() {
		return this.dpPluginPortAssocs;
	}

	public void setDpPluginPortAssocs(List<DpPluginPortAssoc> dpPluginPortAssocs) {
		this.dpPluginPortAssocs = dpPluginPortAssocs;
	}

	public DpPluginPortAssoc addDpPluginPortAssoc(DpPluginPortAssoc dpPluginPortAssoc) {
		getDpPluginPortAssocs().add(dpPluginPortAssoc);
		dpPluginPortAssoc.setDpPort(this);

		return dpPluginPortAssoc;
	}

	public DpPluginPortAssoc removeDpPluginPortAssoc(DpPluginPortAssoc dpPluginPortAssoc) {
		getDpPluginPortAssocs().remove(dpPluginPortAssoc);
		dpPluginPortAssoc.setDpPort(null);

		return dpPluginPortAssoc;
	}

	public DistributionPoint getDistributionPoint() {
		return this.distributionPoint;
	}

	public void setDistributionPoint(DistributionPoint distributionPoint) {
		this.distributionPoint = distributionPoint;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

	public List<DpPortChar> getDpPortChars() {
		return this.dpPortChars;
	}

	public void setDpPortChars(List<DpPortChar> dpPortChars) {
		this.dpPortChars = dpPortChars;
	}

	public DpPortChar addDpPortChar(DpPortChar dpPortChar) {
		getDpPortChars().add(dpPortChar);
		dpPortChar.setDpPort(this);

		return dpPortChar;
	}

	public DpPortChar removeDpPortChar(DpPortChar dpPortChar) {
		getDpPortChars().remove(dpPortChar);
		dpPortChar.setDpPort(null);

		return dpPortChar;
	}

	public List<DpPortPortAssoc> getDpPortPortAssocs1() {
		return this.dpPortPortAssocs1;
	}

	public void setDpPortPortAssocs1(List<DpPortPortAssoc> dpPortPortAssocs1) {
		this.dpPortPortAssocs1 = dpPortPortAssocs1;
	}

	public DpPortPortAssoc addDpPortPortAssocs1(DpPortPortAssoc dpPortPortAssocs1) {
		getDpPortPortAssocs1().add(dpPortPortAssocs1);
		dpPortPortAssocs1.setDpPort1(this);

		return dpPortPortAssocs1;
	}

	public DpPortPortAssoc removeDpPortPortAssocs1(DpPortPortAssoc dpPortPortAssocs1) {
		getDpPortPortAssocs1().remove(dpPortPortAssocs1);
		dpPortPortAssocs1.setDpPort1(null);

		return dpPortPortAssocs1;
	}

	public List<DpPortPortAssoc> getDpPortPortAssocs2() {
		return this.dpPortPortAssocs2;
	}

	public void setDpPortPortAssocs2(List<DpPortPortAssoc> dpPortPortAssocs2) {
		this.dpPortPortAssocs2 = dpPortPortAssocs2;
	}

	public DpPortPortAssoc addDpPortPortAssocs2(DpPortPortAssoc dpPortPortAssocs2) {
		getDpPortPortAssocs2().add(dpPortPortAssocs2);
		dpPortPortAssocs2.setDpPort2(this);

		return dpPortPortAssocs2;
	}

	public DpPortPortAssoc removeDpPortPortAssocs2(DpPortPortAssoc dpPortPortAssocs2) {
		getDpPortPortAssocs2().remove(dpPortPortAssocs2);
		dpPortPortAssocs2.setDpPort2(null);

		return dpPortPortAssocs2;
	}

}