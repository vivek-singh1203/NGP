package com.bt.ngp.common.data.jpa.spec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.spec.SpanSpec;
import com.bt.ngp.datasource.spec.SpanSpecPK;

@Repository
public interface SpanSpecRepository extends JpaRepository<SpanSpec, SpanSpecPK> {
	
	public SpanSpec findBySpanSpecPKIdName(@Param("name") String name);
	
}