package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the EQ_SPEC_CHAR_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="EQ_SPEC_CHAR_SPEC")
@NamedQuery(name="EqSpecCharSpec.findAll", query="SELECT e FROM EqSpecCharSpec e")
public class EqSpecCharSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CAN_BE_OVERRIDEN", nullable=false)
	private BigDecimal canBeOverriden;

	@Column(name="CHAR_SPEC_CATEGORY_NAME", length=30)
	private String charSpecCategoryName;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(length=40)
	private String description;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(name="IS_UNIQUE_WHEN_PRESENT")
	private BigDecimal isUniqueWhenPresent;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="MAX_CARDINALITY")
	private BigDecimal maxCardinality;

	@Column(name="MIN_CARDINALITY")
	private BigDecimal minCardinality;

	@Column(nullable=false, length=30)
	private String name;

	@Column(length=50)
	private String remarks;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	@Column(name="VALUE_TYPE", nullable=false, length=30)
	private String valueType;

	//bi-directional many-to-one association to EntityCharSpec
	@ManyToOne
	@JoinColumn(name="ENTITY_CHAR_SPEC_NAME")
	private EntityCharSpec entityCharSpec;

	//bi-directional many-to-one association to EqSpecCharValueSpec
	@ManyToOne
	@JoinColumn(name="CHAR_VALUE_SPEC_ID", nullable=false)
	private EqSpecCharValueSpec eqSpecCharValueSpec;

	//bi-directional many-to-one association to EqSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="EQ_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="EQ_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private EqSpec eqSpec;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to EqSpecCharSpecRel
	@OneToMany(mappedBy="eqSpecCharSpec1")
	private List<EqSpecCharSpecRel> eqSpecCharSpecRels1;

	//bi-directional many-to-one association to EqSpecCharSpecRel
	@OneToMany(mappedBy="eqSpecCharSpec2")
	private List<EqSpecCharSpecRel> eqSpecCharSpecRels2;

	public EqSpecCharSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public BigDecimal getCanBeOverriden() {
		return this.canBeOverriden;
	}

	public void setCanBeOverriden(BigDecimal canBeOverriden) {
		this.canBeOverriden = canBeOverriden;
	}

	public String getCharSpecCategoryName() {
		return this.charSpecCategoryName;
	}

	public void setCharSpecCategoryName(String charSpecCategoryName) {
		this.charSpecCategoryName = charSpecCategoryName;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public BigDecimal getIsUniqueWhenPresent() {
		return this.isUniqueWhenPresent;
	}

	public void setIsUniqueWhenPresent(BigDecimal isUniqueWhenPresent) {
		this.isUniqueWhenPresent = isUniqueWhenPresent;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getMaxCardinality() {
		return this.maxCardinality;
	}

	public void setMaxCardinality(BigDecimal maxCardinality) {
		this.maxCardinality = maxCardinality;
	}

	public BigDecimal getMinCardinality() {
		return this.minCardinality;
	}

	public void setMinCardinality(BigDecimal minCardinality) {
		this.minCardinality = minCardinality;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public String getValueType() {
		return this.valueType;
	}

	public void setValueType(String valueType) {
		this.valueType = valueType;
	}

	public EntityCharSpec getEntityCharSpec() {
		return this.entityCharSpec;
	}

	public void setEntityCharSpec(EntityCharSpec entityCharSpec) {
		this.entityCharSpec = entityCharSpec;
	}

	public EqSpecCharValueSpec getEqSpecCharValueSpec() {
		return this.eqSpecCharValueSpec;
	}

	public void setEqSpecCharValueSpec(EqSpecCharValueSpec eqSpecCharValueSpec) {
		this.eqSpecCharValueSpec = eqSpecCharValueSpec;
	}

	public EqSpec getEqSpec() {
		return this.eqSpec;
	}

	public void setEqSpec(EqSpec eqSpec) {
		this.eqSpec = eqSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public List<EqSpecCharSpecRel> getEqSpecCharSpecRels1() {
		return this.eqSpecCharSpecRels1;
	}

	public void setEqSpecCharSpecRels1(List<EqSpecCharSpecRel> eqSpecCharSpecRels1) {
		this.eqSpecCharSpecRels1 = eqSpecCharSpecRels1;
	}

	public EqSpecCharSpecRel addEqSpecCharSpecRels1(EqSpecCharSpecRel eqSpecCharSpecRels1) {
		getEqSpecCharSpecRels1().add(eqSpecCharSpecRels1);
		eqSpecCharSpecRels1.setEqSpecCharSpec1(this);

		return eqSpecCharSpecRels1;
	}

	public EqSpecCharSpecRel removeEqSpecCharSpecRels1(EqSpecCharSpecRel eqSpecCharSpecRels1) {
		getEqSpecCharSpecRels1().remove(eqSpecCharSpecRels1);
		eqSpecCharSpecRels1.setEqSpecCharSpec1(null);

		return eqSpecCharSpecRels1;
	}

	public List<EqSpecCharSpecRel> getEqSpecCharSpecRels2() {
		return this.eqSpecCharSpecRels2;
	}

	public void setEqSpecCharSpecRels2(List<EqSpecCharSpecRel> eqSpecCharSpecRels2) {
		this.eqSpecCharSpecRels2 = eqSpecCharSpecRels2;
	}

	public EqSpecCharSpecRel addEqSpecCharSpecRels2(EqSpecCharSpecRel eqSpecCharSpecRels2) {
		getEqSpecCharSpecRels2().add(eqSpecCharSpecRels2);
		eqSpecCharSpecRels2.setEqSpecCharSpec2(this);

		return eqSpecCharSpecRels2;
	}

	public EqSpecCharSpecRel removeEqSpecCharSpecRels2(EqSpecCharSpecRel eqSpecCharSpecRels2) {
		getEqSpecCharSpecRels2().remove(eqSpecCharSpecRels2);
		eqSpecCharSpecRels2.setEqSpecCharSpec2(null);

		return eqSpecCharSpecRels2;
	}

}