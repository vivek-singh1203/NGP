package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.Chassi;
import com.bt.ngp.datasource.entities.Conductor;
import com.bt.ngp.datasource.entities.ConductorBundle;
import com.bt.ngp.datasource.entities.Plugin;
import com.bt.ngp.datasource.entities.WeCsPortTerm;
import com.bt.ngp.datasource.entities.WePort;
import com.bt.ngp.datasource.entities.WirelessEquipment;

@Repository
public interface WeCsPortTermRepository extends SqlRepository<WeCsPortTerm> {

	public WeCsPortTerm findByWirelessEquipmentAndChassiAndPluginAndWePortAndCableSectionAndConductorBundleAndConductor(
			WirelessEquipment wirelessEquipment, Chassi chassi, Plugin plugin, WePort wePort, CableSection cableSection,
			ConductorBundle conductorBundle, Conductor conductor);

	@Query(name = "WeCsPortTermRepository.findWeCsPortTerm", nativeQuery = true)
	List<WeCsPortTerm> findWeCsPortTerm(@Param("termObj") WeCsPortTerm termObj);

	@Query(name = "WeCsPortTermRepository.fetchViaWeCsCbCond", nativeQuery = true)
	public WeCsPortTerm fetchWeCsPortTerm(@Param("weCsPortTerm") WeCsPortTerm weCsPortTerm);

	List<WeCsPortTerm> findByWirelessEquipment(@Param("wirelessEquipment") WirelessEquipment wirelessEquipment);

	@Query(name = "WeCsPortTermRepository.findByConductorAndTerminationType")
	List<WeCsPortTerm> findByConductorAndTerminationType(@Param("weCsPortTermObj") WeCsPortTerm weCsPortTermObj);

	@Query(name = "WeCsPortTermRepository.findByCableSectionAndPort")
	List<WeCsPortTerm> findByCableSectionAndPort(@Param("weCsPortTermObj") WeCsPortTerm weCsPortTermObj);

	@Query(name = "WeCsPortTermRepository.findByWeCableAndConductor")
	List<WeCsPortTerm> findByWeCableAndConductor(@Param("weCsPortTerm") WeCsPortTerm weCsPortTerm);
}
