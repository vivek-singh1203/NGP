package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.MfnCsCondSplicing;

public interface MfnCsCondSplicingRepository extends SqlRepository<MfnCsCondSplicing> {
	public List<MfnCsCondSplicing> findByOrigCsNameAndTermCsName(CableSection origCsName, CableSection termCsName);

	@Transactional
	@Modifying
	@Query(name = "MfnCsCondSplicingRepository.deleteMfnCableConductorSplicingByNameOfWiredEntities", nativeQuery = true)
	public int deleteMfnCableConductorSplicing(@Param("mfnCsCondSplicing") MfnCsCondSplicing mfnCsCondSplicing);

	@Query(name = "MfnCsCondSplicingRepository.findOriginatingConductorSplicing")
	public List<MfnCsCondSplicing> findOriginatingConductorSplicing(
			@Param("mfnCableConductorSplicing") MfnCsCondSplicing mfnCableConductorSplicing);

	@Query(name = "MfnCsCondSplicingRepository.findTerminatingConductorSplicing")
	public List<MfnCsCondSplicing> findTerminatingConductorSplicing(
			@Param("mfnCableConductorSplicing") MfnCsCondSplicing mfnCableConductorSplicing);

	public List<MfnCsCondSplicing> findByOrigParCsName(CableSection origParCsName);

	public List<MfnCsCondSplicing> findByTermParCsName(CableSection termParCsName);

	public MfnCsCondSplicing findByOrigParCsNameAndOrigCsNameAndSplicingResource(CableSection origParCsName,
			CableSection origCsName, String splicingResource);

	public MfnCsCondSplicing findByTermParCsNameAndTermCsNameAndSplicingResource(CableSection termParCsName,
			CableSection termCsName, String splicingResource);
}
