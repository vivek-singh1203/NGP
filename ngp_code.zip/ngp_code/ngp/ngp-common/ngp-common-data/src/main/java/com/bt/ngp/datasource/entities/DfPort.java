package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the DF_PORTS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DF_PORTS")
@NamedQuery(name="DfPort.findAll", query="SELECT d FROM DfPort d")
public class DfPort implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal portSeqNum;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to DfBlockPortAssoc
	@OneToMany(mappedBy="dfPort",fetch=FetchType.LAZY)
	private List<DfBlockPortAssoc> dfBlockPortAssocs;

	//bi-directional many-to-one association to DfCsPortTerm
	@OneToMany(mappedBy="dfPort",fetch=FetchType.LAZY)
	private List<DfCsPortTerm> dfCsPortTerms;

	//bi-directional many-to-one association to Block
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="BLOCK_NAME")
	private Block block;

	//bi-directional many-to-one association to DistributionFrame
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="FRAME_NAME")
	private DistributionFrame distributionFrame;

	//bi-directional many-to-one association to DfPortChar
	@OneToMany(mappedBy="dfPort",fetch=FetchType.LAZY)
	private List<DfPortChar> dfPortChars;

	//bi-directional many-to-one association to DfPortPortAssoc
	@OneToMany(mappedBy="dfPort1",fetch=FetchType.LAZY)
	private List<DfPortPortAssoc> dfPortPortAssocs1;

	//bi-directional many-to-one association to DfPortPortAssoc
	@OneToMany(mappedBy="dfPort2",fetch=FetchType.LAZY)
	private List<DfPortPortAssoc> dfPortPortAssocs2;

	public DfPort() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortSeqNum() {
		return this.portSeqNum;
	}

	public void setPortSeqNum(BigDecimal portSeqNum) {
		this.portSeqNum = portSeqNum;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<DfBlockPortAssoc> getDfBlockPortAssocs() {
		return this.dfBlockPortAssocs;
	}

	public void setDfBlockPortAssocs(List<DfBlockPortAssoc> dfBlockPortAssocs) {
		this.dfBlockPortAssocs = dfBlockPortAssocs;
	}

	public DfBlockPortAssoc addDfBlockPortAssoc(DfBlockPortAssoc dfBlockPortAssoc) {
		getDfBlockPortAssocs().add(dfBlockPortAssoc);
		dfBlockPortAssoc.setDfPort(this);

		return dfBlockPortAssoc;
	}

	public DfBlockPortAssoc removeDfBlockPortAssoc(DfBlockPortAssoc dfBlockPortAssoc) {
		getDfBlockPortAssocs().remove(dfBlockPortAssoc);
		dfBlockPortAssoc.setDfPort(null);

		return dfBlockPortAssoc;
	}

	public List<DfCsPortTerm> getDfCsPortTerms() {
		return this.dfCsPortTerms;
	}

	public void setDfCsPortTerms(List<DfCsPortTerm> dfCsPortTerms) {
		this.dfCsPortTerms = dfCsPortTerms;
	}

	public DfCsPortTerm addDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().add(dfCsPortTerm);
		dfCsPortTerm.setDfPort(this);

		return dfCsPortTerm;
	}

	public DfCsPortTerm removeDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().remove(dfCsPortTerm);
		dfCsPortTerm.setDfPort(null);

		return dfCsPortTerm;
	}

	public Block getBlock() {
		return this.block;
	}

	public void setBlock(Block block) {
		this.block = block;
	}

	public DistributionFrame getDistributionFrame() {
		return this.distributionFrame;
	}

	public void setDistributionFrame(DistributionFrame distributionFrame) {
		this.distributionFrame = distributionFrame;
	}

	public List<DfPortChar> getDfPortChars() {
		return this.dfPortChars;
	}

	public void setDfPortChars(List<DfPortChar> dfPortChars) {
		this.dfPortChars = dfPortChars;
	}

	public DfPortChar addDfPortChar(DfPortChar dfPortChar) {
		getDfPortChars().add(dfPortChar);
		dfPortChar.setDfPort(this);

		return dfPortChar;
	}

	public DfPortChar removeDfPortChar(DfPortChar dfPortChar) {
		getDfPortChars().remove(dfPortChar);
		dfPortChar.setDfPort(null);

		return dfPortChar;
	}

	public List<DfPortPortAssoc> getDfPortPortAssocs1() {
		return this.dfPortPortAssocs1;
	}

	public void setDfPortPortAssocs1(List<DfPortPortAssoc> dfPortPortAssocs1) {
		this.dfPortPortAssocs1 = dfPortPortAssocs1;
	}

	public DfPortPortAssoc addDfPortPortAssocs1(DfPortPortAssoc dfPortPortAssocs1) {
		getDfPortPortAssocs1().add(dfPortPortAssocs1);
		dfPortPortAssocs1.setDfPort1(this);

		return dfPortPortAssocs1;
	}

	public DfPortPortAssoc removeDfPortPortAssocs1(DfPortPortAssoc dfPortPortAssocs1) {
		getDfPortPortAssocs1().remove(dfPortPortAssocs1);
		dfPortPortAssocs1.setDfPort1(null);

		return dfPortPortAssocs1;
	}

	public List<DfPortPortAssoc> getDfPortPortAssocs2() {
		return this.dfPortPortAssocs2;
	}

	public void setDfPortPortAssocs2(List<DfPortPortAssoc> dfPortPortAssocs2) {
		this.dfPortPortAssocs2 = dfPortPortAssocs2;
	}

	public DfPortPortAssoc addDfPortPortAssocs2(DfPortPortAssoc dfPortPortAssocs2) {
		getDfPortPortAssocs2().add(dfPortPortAssocs2);
		dfPortPortAssocs2.setDfPort2(this);

		return dfPortPortAssocs2;
	}

	public DfPortPortAssoc removeDfPortPortAssocs2(DfPortPortAssoc dfPortPortAssocs2) {
		getDfPortPortAssocs2().remove(dfPortPortAssocs2);
		dfPortPortAssocs2.setDfPort2(null);

		return dfPortPortAssocs2;
	}

}