package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the DSLAM_CH_CARD_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DSLAM_CH_CARD_ASSOC")
@NamedQuery(name="DslamChCardAssoc.findAll", query="SELECT d FROM DslamChCardAssoc d")
public class DslamChCardAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="HOLDER_COMP_ASSOC_SPEC_ID", length=50)
	private String holderCompAssocSpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to CardHolder
	@ManyToOne
	@JoinColumn(name="CH_NAME")
	private CardHolder cardHolder;

	//bi-directional many-to-one association to Card
	@ManyToOne
	@JoinColumn(name="CARD_NAME")
	private Card card;

	//bi-directional many-to-one association to Dslam
	@ManyToOne
	@JoinColumn(name="DSLAM_NAME")
	private Dslam dslam;

	//bi-directional many-to-one association to DslamHierarchy
	@OneToMany(mappedBy="dslamChCardAssoc")
	private List<DslamHierarchy> dslamHierarchies;

	public DslamChCardAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getHolderCompAssocSpecId() {
		return this.holderCompAssocSpecId;
	}

	public void setHolderCompAssocSpecId(String holderCompAssocSpecId) {
		this.holderCompAssocSpecId = holderCompAssocSpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public CardHolder getCardHolder() {
		return this.cardHolder;
	}

	public void setCardHolder(CardHolder cardHolder) {
		this.cardHolder = cardHolder;
	}

	public Card getCard() {
		return this.card;
	}

	public void setCard(Card card) {
		this.card = card;
	}

	public Dslam getDslam() {
		return this.dslam;
	}

	public void setDslam(Dslam dslam) {
		this.dslam = dslam;
	}

	public List<DslamHierarchy> getDslamHierarchies() {
		return this.dslamHierarchies;
	}

	public void setDslamHierarchies(List<DslamHierarchy> dslamHierarchies) {
		this.dslamHierarchies = dslamHierarchies;
	}

	public DslamHierarchy addDslamHierarchy(DslamHierarchy dslamHierarchy) {
		getDslamHierarchies().add(dslamHierarchy);
		dslamHierarchy.setDslamChCardAssoc(this);

		return dslamHierarchy;
	}

	public DslamHierarchy removeDslamHierarchy(DslamHierarchy dslamHierarchy) {
		getDslamHierarchies().remove(dslamHierarchy);
		dslamHierarchy.setDslamChCardAssoc(null);

		return dslamHierarchy;
	}

}