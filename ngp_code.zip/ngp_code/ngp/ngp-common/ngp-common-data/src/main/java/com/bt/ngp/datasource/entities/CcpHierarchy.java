package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the CCP_HIERARCHY database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CCP_HIERARCHY")
@NamedQuery(name="CcpHierarchy.findAll", query="SELECT c FROM CcpHierarchy c")
public class CcpHierarchy implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CCP_POS_END_NUM", nullable=false, precision=38)
	private BigDecimal ccpPosEndNum;

	@Column(name="CCP_POS_START_NUM", nullable=false, precision=38)
	private BigDecimal ccpPosStartNum;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="EQ_HIERARCHY_SPEC_ID", length=50)
	private String eqHierarchySpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LEG_ID", precision=38)
	private BigDecimal legId;

	//bi-directional many-to-one association to CcpChassisPhAssoc
	@ManyToOne
	@JoinColumn(name="CHASSIS_PH_ASSOC_ID")
	private CcpChassisPhAssoc ccpChassisPhAssoc;

	//bi-directional many-to-one association to CrossConnectPoint
	@ManyToOne
	@JoinColumn(name="CCP_NAME")
	private CrossConnectPoint crossConnectPoint;

	//bi-directional many-to-one association to CcpPhPluginAssoc
	@ManyToOne
	@JoinColumn(name="PH_PLUGIN_ASSOC_ID")
	private CcpPhPluginAssoc ccpPhPluginAssoc;

	//bi-directional many-to-one association to CcpPluginPortAssoc
	@ManyToOne
	@JoinColumn(name="PLUGIN_PORT_ASSOC_ID")
	private CcpPluginPortAssoc ccpPluginPortAssoc;

	public CcpHierarchy() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public BigDecimal getCcpPosEndNum() {
		return this.ccpPosEndNum;
	}

	public void setCcpPosEndNum(BigDecimal ccpPosEndNum) {
		this.ccpPosEndNum = ccpPosEndNum;
	}

	public BigDecimal getCcpPosStartNum() {
		return this.ccpPosStartNum;
	}

	public void setCcpPosStartNum(BigDecimal ccpPosStartNum) {
		this.ccpPosStartNum = ccpPosStartNum;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEqHierarchySpecId() {
		return this.eqHierarchySpecId;
	}

	public void setEqHierarchySpecId(String eqHierarchySpecId) {
		this.eqHierarchySpecId = eqHierarchySpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getLegId() {
		return this.legId;
	}

	public void setLegId(BigDecimal legId) {
		this.legId = legId;
	}

	public CcpChassisPhAssoc getCcpChassisPhAssoc() {
		return this.ccpChassisPhAssoc;
	}

	public void setCcpChassisPhAssoc(CcpChassisPhAssoc ccpChassisPhAssoc) {
		this.ccpChassisPhAssoc = ccpChassisPhAssoc;
	}

	public CrossConnectPoint getCrossConnectPoint() {
		return this.crossConnectPoint;
	}

	public void setCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		this.crossConnectPoint = crossConnectPoint;
	}

	public CcpPhPluginAssoc getCcpPhPluginAssoc() {
		return this.ccpPhPluginAssoc;
	}

	public void setCcpPhPluginAssoc(CcpPhPluginAssoc ccpPhPluginAssoc) {
		this.ccpPhPluginAssoc = ccpPhPluginAssoc;
	}

	public CcpPluginPortAssoc getCcpPluginPortAssoc() {
		return this.ccpPluginPortAssoc;
	}

	public void setCcpPluginPortAssoc(CcpPluginPortAssoc ccpPluginPortAssoc) {
		this.ccpPluginPortAssoc = ccpPluginPortAssoc;
	}

}