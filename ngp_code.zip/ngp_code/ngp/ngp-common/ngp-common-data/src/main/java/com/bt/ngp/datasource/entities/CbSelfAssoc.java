package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the CB_SELF_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CB_SELF_ASSOC")
@NamedQuery(name="CbSelfAssoc.findAll", query="SELECT c FROM CbSelfAssoc c")
public class CbSelfAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private long id;

	@Column(name="CB_ASSOC_SPEC_ID", length=50)
	private java.math.BigDecimal cbAssocSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CHILD_CB_NAME")
	private ConductorBundle conductorBundle1;

	//bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PARENT_CB_NAME")
	private ConductorBundle conductorBundle2;

	public CbSelfAssoc() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public java.math.BigDecimal getCbAssocSpecId() {
		return this.cbAssocSpecId;
	}

	public void setCbAssocSpecId(java.math.BigDecimal cbAssocSpecId) {
		this.cbAssocSpecId = cbAssocSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public ConductorBundle getConductorBundle1() {
		return this.conductorBundle1;
	}

	public void setConductorBundle1(ConductorBundle conductorBundle1) {
		this.conductorBundle1 = conductorBundle1;
	}

	public ConductorBundle getConductorBundle2() {
		return this.conductorBundle2;
	}

	public void setConductorBundle2(ConductorBundle conductorBundle2) {
		this.conductorBundle2 = conductorBundle2;
	}

}