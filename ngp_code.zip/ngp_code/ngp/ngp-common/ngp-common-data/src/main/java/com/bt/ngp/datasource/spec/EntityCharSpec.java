package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the ENTITY_CHAR_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="ENTITY_CHAR_SPEC")
@NamedQuery(name="EntityCharSpec.findAll", query="SELECT e FROM EntityCharSpec e")
public class EntityCharSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=30)
	private String name;

	@Column(name="CHAR_CATEGORY_NAME", length=30)
	private String charCategoryName;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(length=40)
	private String description;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="IS_UNIQUE_WHEN_PRESENT")
	private BigDecimal isUniqueWhenPresent;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="MAX_CARDINALITY")
	private BigDecimal maxCardinality;

	@Column(name="MIN_CARDINALITY")
	private BigDecimal minCardinality;

	@Column(length=50)
	private String remarks;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	@Column(name="VALUE_TYPE", nullable=false, length=30)
	private String valueType;

	//bi-directional many-to-one association to CableSpecCharSpec
	@OneToMany(mappedBy="entityCharSpec")
	private List<CableSpecCharSpec> cableSpecCharSpecs;

	//bi-directional many-to-one association to CbSpecCharSpec
	@OneToMany(mappedBy="entityCharSpec")
	private List<CbSpecCharSpec> cbSpecCharSpecs;

	//bi-directional many-to-one association to CondSpecCharSpec
	@OneToMany(mappedBy="entityCharSpec")
	private List<CondSpecCharSpec> condSpecCharSpecs;

	//bi-directional many-to-one association to ConnectorSpecCharSpec
	@OneToMany(mappedBy="entityCharSpec")
	private List<ConnectorSpecCharSpec> connectorSpecCharSpecs;

	//bi-directional many-to-one association to DeviceSpecCharSpec
	@OneToMany(mappedBy="entityCharSpec")
	private List<DeviceSpecCharSpec> deviceSpecCharSpecs;

	//bi-directional many-to-one association to EntityCharValueSpec
	@ManyToOne
	@JoinColumn(name="CHAR_VALUE_SPEC_ID", nullable=false)
	private EntityCharValueSpec entityCharValueSpec;

	//bi-directional many-to-one association to EqSpecCharSpec
	@OneToMany(mappedBy="entityCharSpec")
	private List<EqSpecCharSpec> eqSpecCharSpecs;

	//bi-directional many-to-one association to HolderSpecCharSpec
	@OneToMany(mappedBy="entityCharSpec")
	private List<HolderSpecCharSpec> holderSpecCharSpecs;

	//bi-directional many-to-one association to PortSpecCharSpec
	@OneToMany(mappedBy="entityCharSpec")
	private List<PortSpecCharSpec> portSpecCharSpecs;

	//bi-directional many-to-one association to SpanSpecCharSpec
	@OneToMany(mappedBy="entityCharSpec")
	private List<SpanSpecCharSpec> spanSpecCharSpecs;

	//bi-directional many-to-one association to StructureSpecCharSpec
	@OneToMany(mappedBy="entityCharSpec")
	private List<StructureSpecCharSpec> structureSpecCharSpecs;

	public EntityCharSpec() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCharCategoryName() {
		return this.charCategoryName;
	}

	public void setCharCategoryName(String charCategoryName) {
		this.charCategoryName = charCategoryName;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public BigDecimal getIsUniqueWhenPresent() {
		return this.isUniqueWhenPresent;
	}

	public void setIsUniqueWhenPresent(BigDecimal isUniqueWhenPresent) {
		this.isUniqueWhenPresent = isUniqueWhenPresent;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getMaxCardinality() {
		return this.maxCardinality;
	}

	public void setMaxCardinality(BigDecimal maxCardinality) {
		this.maxCardinality = maxCardinality;
	}

	public BigDecimal getMinCardinality() {
		return this.minCardinality;
	}

	public void setMinCardinality(BigDecimal minCardinality) {
		this.minCardinality = minCardinality;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public String getValueType() {
		return this.valueType;
	}

	public void setValueType(String valueType) {
		this.valueType = valueType;
	}

	public List<CableSpecCharSpec> getCableSpecCharSpecs() {
		return this.cableSpecCharSpecs;
	}

	public void setCableSpecCharSpecs(List<CableSpecCharSpec> cableSpecCharSpecs) {
		this.cableSpecCharSpecs = cableSpecCharSpecs;
	}

	public CableSpecCharSpec addCableSpecCharSpec(CableSpecCharSpec cableSpecCharSpec) {
		getCableSpecCharSpecs().add(cableSpecCharSpec);
		cableSpecCharSpec.setEntityCharSpec(this);

		return cableSpecCharSpec;
	}

	public CableSpecCharSpec removeCableSpecCharSpec(CableSpecCharSpec cableSpecCharSpec) {
		getCableSpecCharSpecs().remove(cableSpecCharSpec);
		cableSpecCharSpec.setEntityCharSpec(null);

		return cableSpecCharSpec;
	}

	public List<CbSpecCharSpec> getCbSpecCharSpecs() {
		return this.cbSpecCharSpecs;
	}

	public void setCbSpecCharSpecs(List<CbSpecCharSpec> cbSpecCharSpecs) {
		this.cbSpecCharSpecs = cbSpecCharSpecs;
	}

	public CbSpecCharSpec addCbSpecCharSpec(CbSpecCharSpec cbSpecCharSpec) {
		getCbSpecCharSpecs().add(cbSpecCharSpec);
		cbSpecCharSpec.setEntityCharSpec(this);

		return cbSpecCharSpec;
	}

	public CbSpecCharSpec removeCbSpecCharSpec(CbSpecCharSpec cbSpecCharSpec) {
		getCbSpecCharSpecs().remove(cbSpecCharSpec);
		cbSpecCharSpec.setEntityCharSpec(null);

		return cbSpecCharSpec;
	}

	public List<CondSpecCharSpec> getCondSpecCharSpecs() {
		return this.condSpecCharSpecs;
	}

	public void setCondSpecCharSpecs(List<CondSpecCharSpec> condSpecCharSpecs) {
		this.condSpecCharSpecs = condSpecCharSpecs;
	}

	public CondSpecCharSpec addCondSpecCharSpec(CondSpecCharSpec condSpecCharSpec) {
		getCondSpecCharSpecs().add(condSpecCharSpec);
		condSpecCharSpec.setEntityCharSpec(this);

		return condSpecCharSpec;
	}

	public CondSpecCharSpec removeCondSpecCharSpec(CondSpecCharSpec condSpecCharSpec) {
		getCondSpecCharSpecs().remove(condSpecCharSpec);
		condSpecCharSpec.setEntityCharSpec(null);

		return condSpecCharSpec;
	}

	public List<ConnectorSpecCharSpec> getConnectorSpecCharSpecs() {
		return this.connectorSpecCharSpecs;
	}

	public void setConnectorSpecCharSpecs(List<ConnectorSpecCharSpec> connectorSpecCharSpecs) {
		this.connectorSpecCharSpecs = connectorSpecCharSpecs;
	}

	public ConnectorSpecCharSpec addConnectorSpecCharSpec(ConnectorSpecCharSpec connectorSpecCharSpec) {
		getConnectorSpecCharSpecs().add(connectorSpecCharSpec);
		connectorSpecCharSpec.setEntityCharSpec(this);

		return connectorSpecCharSpec;
	}

	public ConnectorSpecCharSpec removeConnectorSpecCharSpec(ConnectorSpecCharSpec connectorSpecCharSpec) {
		getConnectorSpecCharSpecs().remove(connectorSpecCharSpec);
		connectorSpecCharSpec.setEntityCharSpec(null);

		return connectorSpecCharSpec;
	}

	public List<DeviceSpecCharSpec> getDeviceSpecCharSpecs() {
		return this.deviceSpecCharSpecs;
	}

	public void setDeviceSpecCharSpecs(List<DeviceSpecCharSpec> deviceSpecCharSpecs) {
		this.deviceSpecCharSpecs = deviceSpecCharSpecs;
	}

	public DeviceSpecCharSpec addDeviceSpecCharSpec(DeviceSpecCharSpec deviceSpecCharSpec) {
		getDeviceSpecCharSpecs().add(deviceSpecCharSpec);
		deviceSpecCharSpec.setEntityCharSpec(this);

		return deviceSpecCharSpec;
	}

	public DeviceSpecCharSpec removeDeviceSpecCharSpec(DeviceSpecCharSpec deviceSpecCharSpec) {
		getDeviceSpecCharSpecs().remove(deviceSpecCharSpec);
		deviceSpecCharSpec.setEntityCharSpec(null);

		return deviceSpecCharSpec;
	}

	public EntityCharValueSpec getEntityCharValueSpec() {
		return this.entityCharValueSpec;
	}

	public void setEntityCharValueSpec(EntityCharValueSpec entityCharValueSpec) {
		this.entityCharValueSpec = entityCharValueSpec;
	}

	public List<EqSpecCharSpec> getEqSpecCharSpecs() {
		return this.eqSpecCharSpecs;
	}

	public void setEqSpecCharSpecs(List<EqSpecCharSpec> eqSpecCharSpecs) {
		this.eqSpecCharSpecs = eqSpecCharSpecs;
	}

	public EqSpecCharSpec addEqSpecCharSpec(EqSpecCharSpec eqSpecCharSpec) {
		getEqSpecCharSpecs().add(eqSpecCharSpec);
		eqSpecCharSpec.setEntityCharSpec(this);

		return eqSpecCharSpec;
	}

	public EqSpecCharSpec removeEqSpecCharSpec(EqSpecCharSpec eqSpecCharSpec) {
		getEqSpecCharSpecs().remove(eqSpecCharSpec);
		eqSpecCharSpec.setEntityCharSpec(null);

		return eqSpecCharSpec;
	}

	public List<HolderSpecCharSpec> getHolderSpecCharSpecs() {
		return this.holderSpecCharSpecs;
	}

	public void setHolderSpecCharSpecs(List<HolderSpecCharSpec> holderSpecCharSpecs) {
		this.holderSpecCharSpecs = holderSpecCharSpecs;
	}

	public HolderSpecCharSpec addHolderSpecCharSpec(HolderSpecCharSpec holderSpecCharSpec) {
		getHolderSpecCharSpecs().add(holderSpecCharSpec);
		holderSpecCharSpec.setEntityCharSpec(this);

		return holderSpecCharSpec;
	}

	public HolderSpecCharSpec removeHolderSpecCharSpec(HolderSpecCharSpec holderSpecCharSpec) {
		getHolderSpecCharSpecs().remove(holderSpecCharSpec);
		holderSpecCharSpec.setEntityCharSpec(null);

		return holderSpecCharSpec;
	}

	public List<PortSpecCharSpec> getPortSpecCharSpecs() {
		return this.portSpecCharSpecs;
	}

	public void setPortSpecCharSpecs(List<PortSpecCharSpec> portSpecCharSpecs) {
		this.portSpecCharSpecs = portSpecCharSpecs;
	}

	public PortSpecCharSpec addPortSpecCharSpec(PortSpecCharSpec portSpecCharSpec) {
		getPortSpecCharSpecs().add(portSpecCharSpec);
		portSpecCharSpec.setEntityCharSpec(this);

		return portSpecCharSpec;
	}

	public PortSpecCharSpec removePortSpecCharSpec(PortSpecCharSpec portSpecCharSpec) {
		getPortSpecCharSpecs().remove(portSpecCharSpec);
		portSpecCharSpec.setEntityCharSpec(null);

		return portSpecCharSpec;
	}

	public List<SpanSpecCharSpec> getSpanSpecCharSpecs() {
		return this.spanSpecCharSpecs;
	}

	public void setSpanSpecCharSpecs(List<SpanSpecCharSpec> spanSpecCharSpecs) {
		this.spanSpecCharSpecs = spanSpecCharSpecs;
	}

	public SpanSpecCharSpec addSpanSpecCharSpec(SpanSpecCharSpec spanSpecCharSpec) {
		getSpanSpecCharSpecs().add(spanSpecCharSpec);
		spanSpecCharSpec.setEntityCharSpec(this);

		return spanSpecCharSpec;
	}

	public SpanSpecCharSpec removeSpanSpecCharSpec(SpanSpecCharSpec spanSpecCharSpec) {
		getSpanSpecCharSpecs().remove(spanSpecCharSpec);
		spanSpecCharSpec.setEntityCharSpec(null);

		return spanSpecCharSpec;
	}

	public List<StructureSpecCharSpec> getStructureSpecCharSpecs() {
		return this.structureSpecCharSpecs;
	}

	public void setStructureSpecCharSpecs(List<StructureSpecCharSpec> structureSpecCharSpecs) {
		this.structureSpecCharSpecs = structureSpecCharSpecs;
	}

	public StructureSpecCharSpec addStructureSpecCharSpec(StructureSpecCharSpec structureSpecCharSpec) {
		getStructureSpecCharSpecs().add(structureSpecCharSpec);
		structureSpecCharSpec.setEntityCharSpec(this);

		return structureSpecCharSpec;
	}

	public StructureSpecCharSpec removeStructureSpecCharSpec(StructureSpecCharSpec structureSpecCharSpec) {
		getStructureSpecCharSpecs().remove(structureSpecCharSpec);
		structureSpecCharSpec.setEntityCharSpec(null);

		return structureSpecCharSpec;
	}

}