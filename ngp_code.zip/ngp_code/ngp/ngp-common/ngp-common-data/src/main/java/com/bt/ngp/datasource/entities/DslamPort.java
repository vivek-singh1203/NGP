package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the DSLAM_PORTS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DSLAM_PORTS")
@NamedQuery(name="DslamPort.findAll", query="SELECT d FROM DslamPort d")
public class DslamPort implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal portSeqNum;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to DslamCardPortAssoc
	@OneToMany(mappedBy="dslamPort",fetch=FetchType.LAZY)
	private List<DslamCardPortAssoc> dslamCardPortAssocs;

	//bi-directional many-to-one association to DslamCsPortTerm
	@OneToMany(mappedBy="dslamPort",fetch=FetchType.LAZY)
	private List<DslamCsPortTerm> dslamCsPortTerms;

	//bi-directional many-to-one association to Card
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CARD_NAME")
	private Card card;

	//bi-directional many-to-one association to Dslam
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DSLAM_NAME")
	private Dslam dslam;

	//bi-directional many-to-one association to DslamPortChar
	@OneToMany(mappedBy="dslamPort",fetch=FetchType.LAZY)
	private List<DslamPortChar> dslamPortChars;

	//bi-directional many-to-one association to DslamPortPortAssoc
	@OneToMany(mappedBy="dslamPort1",fetch=FetchType.LAZY)
	private List<DslamPortPortAssoc> dslamPortPortAssocs1;

	//bi-directional many-to-one association to DslamPortPortAssoc
	@OneToMany(mappedBy="dslamPort2",fetch=FetchType.LAZY)
	private List<DslamPortPortAssoc> dslamPortPortAssocs2;

	public DslamPort() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortSeqNum() {
		return this.portSeqNum;
	}

	public void setPortSeqNum(BigDecimal portSeqNum) {
		this.portSeqNum = portSeqNum;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<DslamCardPortAssoc> getDslamCardPortAssocs() {
		return this.dslamCardPortAssocs;
	}

	public void setDslamCardPortAssocs(List<DslamCardPortAssoc> dslamCardPortAssocs) {
		this.dslamCardPortAssocs = dslamCardPortAssocs;
	}

	public DslamCardPortAssoc addDslamCardPortAssoc(DslamCardPortAssoc dslamCardPortAssoc) {
		getDslamCardPortAssocs().add(dslamCardPortAssoc);
		dslamCardPortAssoc.setDslamPort(this);

		return dslamCardPortAssoc;
	}

	public DslamCardPortAssoc removeDslamCardPortAssoc(DslamCardPortAssoc dslamCardPortAssoc) {
		getDslamCardPortAssocs().remove(dslamCardPortAssoc);
		dslamCardPortAssoc.setDslamPort(null);

		return dslamCardPortAssoc;
	}

	public List<DslamCsPortTerm> getDslamCsPortTerms() {
		return this.dslamCsPortTerms;
	}

	public void setDslamCsPortTerms(List<DslamCsPortTerm> dslamCsPortTerms) {
		this.dslamCsPortTerms = dslamCsPortTerms;
	}

	public DslamCsPortTerm addDslamCsPortTerm(DslamCsPortTerm dslamCsPortTerm) {
		getDslamCsPortTerms().add(dslamCsPortTerm);
		dslamCsPortTerm.setDslamPort(this);

		return dslamCsPortTerm;
	}

	public DslamCsPortTerm removeDslamCsPortTerm(DslamCsPortTerm dslamCsPortTerm) {
		getDslamCsPortTerms().remove(dslamCsPortTerm);
		dslamCsPortTerm.setDslamPort(null);

		return dslamCsPortTerm;
	}

	public Card getCard() {
		return this.card;
	}

	public void setCard(Card card) {
		this.card = card;
	}

	public Dslam getDslam() {
		return this.dslam;
	}

	public void setDslam(Dslam dslam) {
		this.dslam = dslam;
	}

	public List<DslamPortChar> getDslamPortChars() {
		return this.dslamPortChars;
	}

	public void setDslamPortChars(List<DslamPortChar> dslamPortChars) {
		this.dslamPortChars = dslamPortChars;
	}

	public DslamPortChar addDslamPortChar(DslamPortChar dslamPortChar) {
		getDslamPortChars().add(dslamPortChar);
		dslamPortChar.setDslamPort(this);

		return dslamPortChar;
	}

	public DslamPortChar removeDslamPortChar(DslamPortChar dslamPortChar) {
		getDslamPortChars().remove(dslamPortChar);
		dslamPortChar.setDslamPort(null);

		return dslamPortChar;
	}

	public List<DslamPortPortAssoc> getDslamPortPortAssocs1() {
		return this.dslamPortPortAssocs1;
	}

	public void setDslamPortPortAssocs1(List<DslamPortPortAssoc> dslamPortPortAssocs1) {
		this.dslamPortPortAssocs1 = dslamPortPortAssocs1;
	}

	public DslamPortPortAssoc addDslamPortPortAssocs1(DslamPortPortAssoc dslamPortPortAssocs1) {
		getDslamPortPortAssocs1().add(dslamPortPortAssocs1);
		dslamPortPortAssocs1.setDslamPort1(this);

		return dslamPortPortAssocs1;
	}

	public DslamPortPortAssoc removeDslamPortPortAssocs1(DslamPortPortAssoc dslamPortPortAssocs1) {
		getDslamPortPortAssocs1().remove(dslamPortPortAssocs1);
		dslamPortPortAssocs1.setDslamPort1(null);

		return dslamPortPortAssocs1;
	}

	public List<DslamPortPortAssoc> getDslamPortPortAssocs2() {
		return this.dslamPortPortAssocs2;
	}

	public void setDslamPortPortAssocs2(List<DslamPortPortAssoc> dslamPortPortAssocs2) {
		this.dslamPortPortAssocs2 = dslamPortPortAssocs2;
	}

	public DslamPortPortAssoc addDslamPortPortAssocs2(DslamPortPortAssoc dslamPortPortAssocs2) {
		getDslamPortPortAssocs2().add(dslamPortPortAssocs2);
		dslamPortPortAssocs2.setDslamPort2(this);

		return dslamPortPortAssocs2;
	}

	public DslamPortPortAssoc removeDslamPortPortAssocs2(DslamPortPortAssoc dslamPortPortAssocs2) {
		getDslamPortPortAssocs2().remove(dslamPortPortAssocs2);
		dslamPortPortAssocs2.setDslamPort2(null);

		return dslamPortPortAssocs2;
	}

}