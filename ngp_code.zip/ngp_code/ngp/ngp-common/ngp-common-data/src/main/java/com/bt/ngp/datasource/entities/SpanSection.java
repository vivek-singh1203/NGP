package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.vividsolutions.jts.geom.LineString;


/**
 * The persistent class for the SPAN_SECTION database table.
 * 
 */
@javax.persistence.Entity
@Table(name="SPAN_SECTION")
@NamedQuery(name="SpanSection.findAll", query="SELECT s FROM SpanSection s")
public class SpanSection implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CALCULATED_LENGTH", precision=126)
	private double calculatedLength;

	@Column(name="CALCULATED_LENGTH_UNIT", length=10)
	private String calculatedLengthUnit;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="DESG_NAME", length=30)
	private String desgName;

	@Column(name="DESG_NUM", precision=38)
	private BigDecimal desgNum;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(name="FIELD_LABEL", length=30)
	private String fieldLabel;

	@Column(name = "GEO_POSITION", columnDefinition = "geometry(LineString,3857)")
	private LineString geoPosition;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="MEASURED_LENGTH", precision=126)
	private double measuredLength;

	@Column(name="MEASURED_LENGTH_UNIT", length=10)
	private String measuredLengthUnit;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to CableSpanAssoc
	@OneToMany(mappedBy="spanSection")
	private List<CableSpanAssoc> cableSpanAssocs;

	//bi-directional many-to-one association to Exchange
	@ManyToOne
	@JoinColumn(name="EXCHANGE_1141_CODE")
	private Exchange exchange;

	//bi-directional many-to-one association to Store
	@ManyToOne
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to SpanSectionChar
	@OneToMany(mappedBy="spanSection")
	private List<SpanSectionChar> spanSectionChars;

	//bi-directional many-to-one association to SpanSectionEnd
	@OneToMany(mappedBy="spanSection")
	private List<SpanSectionEnd> spanSectionEnds;

	//bi-directional many-to-one association to SpanSectionSelfAssoc
	@OneToMany(mappedBy="parentSpanSection")
	private List<SpanSectionSelfAssoc> parentSpanSections;

	//bi-directional many-to-one association to SpanSectionSelfAssoc
	@OneToMany(mappedBy="childSpanSection")
	private List<SpanSectionSelfAssoc> childSpanSections;

	public SpanSection() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public double getCalculatedLength() {
		return this.calculatedLength;
	}

	public void setCalculatedLength(double calculatedLength) {
		this.calculatedLength = calculatedLength;
	}

	public String getCalculatedLengthUnit() {
		return this.calculatedLengthUnit;
	}

	public void setCalculatedLengthUnit(String calculatedLengthUnit) {
		this.calculatedLengthUnit = calculatedLengthUnit;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getDesgName() {
		return this.desgName;
	}

	public void setDesgName(String desgName) {
		this.desgName = desgName;
	}

	public BigDecimal getDesgNum() {
		return this.desgNum;
	}

	public void setDesgNum(BigDecimal desgNum) {
		this.desgNum = desgNum;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getFieldLabel() {
		return this.fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}

	public LineString getGeoPosition() {
		return this.geoPosition;
	}

	public void setGeoPosition(LineString geoPosition) {
		this.geoPosition = geoPosition;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public double getMeasuredLength() {
		return this.measuredLength;
	}

	public void setMeasuredLength(double measuredLength) {
		this.measuredLength = measuredLength;
	}

	public String getMeasuredLengthUnit() {
		return this.measuredLengthUnit;
	}

	public void setMeasuredLengthUnit(String measuredLengthUnit) {
		this.measuredLengthUnit = measuredLengthUnit;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<CableSpanAssoc> getCableSpanAssocs() {
		return this.cableSpanAssocs;
	}

	public void setCableSpanAssocs(List<CableSpanAssoc> cableSpanAssocs) {
		this.cableSpanAssocs = cableSpanAssocs;
	}

	public CableSpanAssoc addCableSpanAssoc(CableSpanAssoc cableSpanAssoc) {
		getCableSpanAssocs().add(cableSpanAssoc);
		cableSpanAssoc.setSpanSection(this);

		return cableSpanAssoc;
	}

	public CableSpanAssoc removeCableSpanAssoc(CableSpanAssoc cableSpanAssoc) {
		getCableSpanAssocs().remove(cableSpanAssoc);
		cableSpanAssoc.setSpanSection(null);

		return cableSpanAssoc;
	}

	public Exchange getExchange() {
		return this.exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public List<SpanSectionChar> getSpanSectionChars() {
		return this.spanSectionChars;
	}

	public void setSpanSectionChars(List<SpanSectionChar> spanSectionChars) {
		this.spanSectionChars = spanSectionChars;
	}

	public SpanSectionChar addSpanSectionChar(SpanSectionChar spanSectionChar) {
		getSpanSectionChars().add(spanSectionChar);
		spanSectionChar.setSpanSection(this);

		return spanSectionChar;
	}

	public SpanSectionChar removeSpanSectionChar(SpanSectionChar spanSectionChar) {
		getSpanSectionChars().remove(spanSectionChar);
		spanSectionChar.setSpanSection(null);

		return spanSectionChar;
	}

	public List<SpanSectionEnd> getSpanSectionEnds() {
		return this.spanSectionEnds;
	}

	public void setSpanSectionEnds(List<SpanSectionEnd> spanSectionEnds) {
		this.spanSectionEnds = spanSectionEnds;
	}

	public SpanSectionEnd addSpanSectionEnd(SpanSectionEnd spanSectionEnd) {
		getSpanSectionEnds().add(spanSectionEnd);
		spanSectionEnd.setSpanSection(this);

		return spanSectionEnd;
	}

	public SpanSectionEnd removeSpanSectionEnd(SpanSectionEnd spanSectionEnd) {
		getSpanSectionEnds().remove(spanSectionEnd);
		spanSectionEnd.setSpanSection(null);

		return spanSectionEnd;
	}

	public List<SpanSectionSelfAssoc> getParentSpanSections() {
		return this.parentSpanSections;
	}

	public void setParentSpanSections(List<SpanSectionSelfAssoc> parentSpanSections) {
		this.parentSpanSections = parentSpanSections;
	}

	public SpanSectionSelfAssoc addparentSpanSection(SpanSectionSelfAssoc parentSpanSection) {
		getParentSpanSections().add(parentSpanSection);
		parentSpanSection.setParentSpanSection(this);

		return parentSpanSection;
	}

	public SpanSectionSelfAssoc removeSpanSectionSelfAssocs1(SpanSectionSelfAssoc parentSpanSection) {
		getParentSpanSections().remove(parentSpanSection);
		parentSpanSection.setParentSpanSection(null);

		return parentSpanSection;
	}

	public List<SpanSectionSelfAssoc> getChildSpanSections() {
		return this.childSpanSections;
	}

	public void setChildSpanSections(List<SpanSectionSelfAssoc> childSpanSections) {
		this.childSpanSections = childSpanSections;
	}

	public SpanSectionSelfAssoc addSpanSectionSelfAssocs2(SpanSectionSelfAssoc childSpanSection) {
		getChildSpanSections().add(childSpanSection);
		childSpanSection.setChildSpanSection(this);

		return childSpanSection;
	}

	public SpanSectionSelfAssoc removeChildSpanSections(SpanSectionSelfAssoc childSpanSection) {
		getChildSpanSections().remove(childSpanSection);
		childSpanSection.setChildSpanSection(null);

		return childSpanSection;
	}

}