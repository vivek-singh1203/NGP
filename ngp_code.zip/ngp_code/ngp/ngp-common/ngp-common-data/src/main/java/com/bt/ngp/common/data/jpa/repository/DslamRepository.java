package com.bt.ngp.common.data.jpa.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.bt.ngp.datasource.entities.Dslam;
import com.bt.ngp.datasource.entities.Exchange;


@Repository
public interface DslamRepository extends CommonOperation<Dslam>{
	
	@Query(name="DslamRepository.findEquipmentWithoutCableSectionAssoc", nativeQuery=true)
	List<Dslam> findEquipmentWithoutCableSectionAssoc(@Param("exchangeCode") String exchange1141Code);
	
	List<Dslam> findByExchangeAndDslamStructureAssocsIsNull(@Param("exchange") Exchange exchange);
}
