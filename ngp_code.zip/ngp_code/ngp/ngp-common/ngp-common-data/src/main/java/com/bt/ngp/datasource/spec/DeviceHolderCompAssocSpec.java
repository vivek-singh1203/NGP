package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the DEVICE_HOLDER_COMP_ASSOC_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DEVICE_HOLDER_COMP_ASSOC_SPEC")
@NamedQuery(name="DeviceHolderCompAssocSpec.findAll", query="SELECT d FROM DeviceHolderCompAssocSpec d")
public class DeviceHolderCompAssocSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="COMPONENT_ENTITY_NAME", length=30)
	private String componentEntityName;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DEVICE_ENTITY_NAME", length=30)
	private String deviceEntityName;

	@Column(name="HOLDER_ENTITY_NAME", length=30)
	private String holderEntityName;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="NO_OF_COMPONENT_SPEC_INSTANCES", precision=38)
	private BigDecimal noOfComponentSpecInstances;

	//bi-directional many-to-one association to DeviceHierarchySpec
	@OneToMany(mappedBy="deviceHolderCompAssocSpec")
	private List<DeviceHierarchySpec> deviceHierarchySpecs;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="COMPONENT_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory1;

	//bi-directional many-to-one association to EqSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="COMPONENT_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="COMPONENT_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private EqSpec eqSpec;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="COMPONENT_SPEC_TYPE_NAME")
	private SpecType specType1;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="DEVICE_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory2;

	//bi-directional many-to-one association to DeviceSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="DEVICE_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="DEVICE_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private DeviceSpec deviceSpec;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="DEVICE_SPEC_TYPE_NAME")
	private SpecType specType2;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="HOLDER_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory3;

	//bi-directional many-to-one association to HolderSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="HOLDER_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="HOLDER_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private HolderSpec holderSpec;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="HOLDER_SPEC_TYPE_NAME")
	private SpecType specType3;

	public DeviceHolderCompAssocSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getComponentEntityName() {
		return this.componentEntityName;
	}

	public void setComponentEntityName(String componentEntityName) {
		this.componentEntityName = componentEntityName;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDeviceEntityName() {
		return this.deviceEntityName;
	}

	public void setDeviceEntityName(String deviceEntityName) {
		this.deviceEntityName = deviceEntityName;
	}

	public String getHolderEntityName() {
		return this.holderEntityName;
	}

	public void setHolderEntityName(String holderEntityName) {
		this.holderEntityName = holderEntityName;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getNoOfComponentSpecInstances() {
		return this.noOfComponentSpecInstances;
	}

	public void setNoOfComponentSpecInstances(BigDecimal noOfComponentSpecInstances) {
		this.noOfComponentSpecInstances = noOfComponentSpecInstances;
	}

	public List<DeviceHierarchySpec> getDeviceHierarchySpecs() {
		return this.deviceHierarchySpecs;
	}

	public void setDeviceHierarchySpecs(List<DeviceHierarchySpec> deviceHierarchySpecs) {
		this.deviceHierarchySpecs = deviceHierarchySpecs;
	}

	public DeviceHierarchySpec addDeviceHierarchySpec(DeviceHierarchySpec deviceHierarchySpec) {
		getDeviceHierarchySpecs().add(deviceHierarchySpec);
		deviceHierarchySpec.setDeviceHolderCompAssocSpec(this);

		return deviceHierarchySpec;
	}

	public DeviceHierarchySpec removeDeviceHierarchySpec(DeviceHierarchySpec deviceHierarchySpec) {
		getDeviceHierarchySpecs().remove(deviceHierarchySpec);
		deviceHierarchySpec.setDeviceHolderCompAssocSpec(null);

		return deviceHierarchySpec;
	}

	public SpecCategory getSpecCategory1() {
		return this.specCategory1;
	}

	public void setSpecCategory1(SpecCategory specCategory1) {
		this.specCategory1 = specCategory1;
	}

	public EqSpec getEqSpec() {
		return this.eqSpec;
	}

	public void setEqSpec(EqSpec eqSpec) {
		this.eqSpec = eqSpec;
	}

	public SpecType getSpecType1() {
		return this.specType1;
	}

	public void setSpecType1(SpecType specType1) {
		this.specType1 = specType1;
	}

	public SpecCategory getSpecCategory2() {
		return this.specCategory2;
	}

	public void setSpecCategory2(SpecCategory specCategory2) {
		this.specCategory2 = specCategory2;
	}

	public DeviceSpec getDeviceSpec() {
		return this.deviceSpec;
	}

	public void setDeviceSpec(DeviceSpec deviceSpec) {
		this.deviceSpec = deviceSpec;
	}

	public SpecType getSpecType2() {
		return this.specType2;
	}

	public void setSpecType2(SpecType specType2) {
		this.specType2 = specType2;
	}

	public SpecCategory getSpecCategory3() {
		return this.specCategory3;
	}

	public void setSpecCategory3(SpecCategory specCategory3) {
		this.specCategory3 = specCategory3;
	}

	public HolderSpec getHolderSpec() {
		return this.holderSpec;
	}

	public void setHolderSpec(HolderSpec holderSpec) {
		this.holderSpec = holderSpec;
	}

	public SpecType getSpecType3() {
		return this.specType3;
	}

	public void setSpecType3(SpecType specType3) {
		this.specType3 = specType3;
	}

}