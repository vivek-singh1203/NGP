package com.bt.ngp.common.data.jpa.spec.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.bt.ngp.common.data.jpa.repository.CommonOperation;
import com.bt.ngp.datasource.spec.ConductorSpec;
import com.bt.ngp.datasource.spec.ConductorSpecPK;
import com.bt.ngp.datasource.spec.PortSpec;

@Repository
public interface ConductorSpecRepository extends JpaRepository<ConductorSpec,ConductorSpecPK>{
	public ConductorSpec findByConductorSpecPKIdName(String name);
}
