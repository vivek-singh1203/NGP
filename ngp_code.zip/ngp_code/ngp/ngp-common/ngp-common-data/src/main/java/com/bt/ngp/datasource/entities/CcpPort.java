package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the CCP_PORTS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CCP_PORTS")
@NamedQuery(name="CcpPort.findAll", query="SELECT c FROM CcpPort c")
public class CcpPort implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal portSeqNum;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", nullable=false, length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to CcpCsPortTerm
	@OneToMany(mappedBy="ccpPort",fetch=FetchType.LAZY)
	private List<CcpCsPortTerm> ccpCsPortTerms;

	//bi-directional many-to-one association to CcpPluginPortAssoc
	@OneToMany(mappedBy="ccpPort",fetch=FetchType.LAZY)
	private List<CcpPluginPortAssoc> ccpPluginPortAssocs;

	//bi-directional many-to-one association to CrossConnectPoint
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CCP_NAME")
	private CrossConnectPoint crossConnectPoint;

	//bi-directional many-to-one association to Plugin
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	//bi-directional many-to-one association to CcpPortChar
	@OneToMany(mappedBy="ccpPort",fetch=FetchType.LAZY)
	private List<CcpPortChar> ccpPortChars;

	//bi-directional many-to-one association to CcpPortPortAssoc
	@OneToMany(mappedBy="ccpPort1",fetch=FetchType.LAZY)
	private List<CcpPortPortAssoc> ccpPortPortAssocs1;

	//bi-directional many-to-one association to CcpPortPortAssoc
	@OneToMany(mappedBy="ccpPort2",fetch=FetchType.LAZY)
	private List<CcpPortPortAssoc> ccpPortPortAssocs2;

	public CcpPort() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortSeqNum() {
		return this.portSeqNum;
	}

	public void setPortSeqNum(BigDecimal portSeqNum) {
		this.portSeqNum = portSeqNum;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<CcpCsPortTerm> getCcpCsPortTerms() {
		return this.ccpCsPortTerms;
	}

	public void setCcpCsPortTerms(List<CcpCsPortTerm> ccpCsPortTerms) {
		this.ccpCsPortTerms = ccpCsPortTerms;
	}

	public CcpCsPortTerm addCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		getCcpCsPortTerms().add(ccpCsPortTerm);
		ccpCsPortTerm.setCcpPort(this);

		return ccpCsPortTerm;
	}

	public CcpCsPortTerm removeCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		getCcpCsPortTerms().remove(ccpCsPortTerm);
		ccpCsPortTerm.setCcpPort(null);

		return ccpCsPortTerm;
	}

	public List<CcpPluginPortAssoc> getCcpPluginPortAssocs() {
		return this.ccpPluginPortAssocs;
	}

	public void setCcpPluginPortAssocs(List<CcpPluginPortAssoc> ccpPluginPortAssocs) {
		this.ccpPluginPortAssocs = ccpPluginPortAssocs;
	}

	public CcpPluginPortAssoc addCcpPluginPortAssoc(CcpPluginPortAssoc ccpPluginPortAssoc) {
		getCcpPluginPortAssocs().add(ccpPluginPortAssoc);
		ccpPluginPortAssoc.setCcpPort(this);

		return ccpPluginPortAssoc;
	}

	public CcpPluginPortAssoc removeCcpPluginPortAssoc(CcpPluginPortAssoc ccpPluginPortAssoc) {
		getCcpPluginPortAssocs().remove(ccpPluginPortAssoc);
		ccpPluginPortAssoc.setCcpPort(null);

		return ccpPluginPortAssoc;
	}

	public CrossConnectPoint getCrossConnectPoint() {
		return this.crossConnectPoint;
	}

	public void setCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		this.crossConnectPoint = crossConnectPoint;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

	public List<CcpPortChar> getCcpPortChars() {
		return this.ccpPortChars;
	}

	public void setCcpPortChars(List<CcpPortChar> ccpPortChars) {
		this.ccpPortChars = ccpPortChars;
	}

	public CcpPortChar addCcpPortChar(CcpPortChar ccpPortChar) {
		getCcpPortChars().add(ccpPortChar);
		ccpPortChar.setCcpPort(this);

		return ccpPortChar;
	}

	public CcpPortChar removeCcpPortChar(CcpPortChar ccpPortChar) {
		getCcpPortChars().remove(ccpPortChar);
		ccpPortChar.setCcpPort(null);

		return ccpPortChar;
	}

	public List<CcpPortPortAssoc> getCcpPortPortAssocs1() {
		return this.ccpPortPortAssocs1;
	}

	public void setCcpPortPortAssocs1(List<CcpPortPortAssoc> ccpPortPortAssocs1) {
		this.ccpPortPortAssocs1 = ccpPortPortAssocs1;
	}

	public CcpPortPortAssoc addCcpPortPortAssocs1(CcpPortPortAssoc ccpPortPortAssocs1) {
		getCcpPortPortAssocs1().add(ccpPortPortAssocs1);
		ccpPortPortAssocs1.setCcpPort1(this);

		return ccpPortPortAssocs1;
	}

	public CcpPortPortAssoc removeCcpPortPortAssocs1(CcpPortPortAssoc ccpPortPortAssocs1) {
		getCcpPortPortAssocs1().remove(ccpPortPortAssocs1);
		ccpPortPortAssocs1.setCcpPort1(null);

		return ccpPortPortAssocs1;
	}

	public List<CcpPortPortAssoc> getCcpPortPortAssocs2() {
		return this.ccpPortPortAssocs2;
	}

	public void setCcpPortPortAssocs2(List<CcpPortPortAssoc> ccpPortPortAssocs2) {
		this.ccpPortPortAssocs2 = ccpPortPortAssocs2;
	}

	public CcpPortPortAssoc addCcpPortPortAssocs2(CcpPortPortAssoc ccpPortPortAssocs2) {
		getCcpPortPortAssocs2().add(ccpPortPortAssocs2);
		ccpPortPortAssocs2.setCcpPort2(this);

		return ccpPortPortAssocs2;
	}

	public CcpPortPortAssoc removeCcpPortPortAssocs2(CcpPortPortAssoc ccpPortPortAssocs2) {
		getCcpPortPortAssocs2().remove(ccpPortPortAssocs2);
		ccpPortPortAssocs2.setCcpPort2(null);

		return ccpPortPortAssocs2;
	}

	
}