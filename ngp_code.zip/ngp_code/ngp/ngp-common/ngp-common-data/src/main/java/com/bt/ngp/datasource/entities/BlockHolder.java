package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the BLOCK_HOLDERS database table.
 * 
 */
@javax.persistence.Entity
@Table(name = "BLOCK_HOLDERS")
@NamedQuery(name = "BlockHolder.findAll", query = "SELECT b FROM BlockHolder b")
public class BlockHolder implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique = true, nullable = false, length = 25)
	private String name;

	@Column(name = "ALTERNATE_NAME", length = 25)
	private String alternateName;

	@Column(name = "ASSET_IDENTIFIER", length = 30)
	private String assetIdentifier;

	@Column(name = "CREATED_BY", nullable = false, length = 40)
	private String createdBy;

	@Column(name = "CREATED_DATE", nullable = false)
	private Timestamp createdDate;

	@Column(name = "DATA_QUALITY_INDICATOR", length = 20)
	private String dataQualityIndicator;

	@Column(name = "FAULT_STATE", length = 25)
	private String faultState;

	@Column(name = "HOLDER_SPEC_NAME", length = 40)
	private String specName;

	@Column(name = "HOLDER_SPEC_VERSION", length = 10)
	private String holderSpecVersion;

	@Column(nullable = false, length = 50)
	private String id;

	@Column(name = "LAST_MODIFIED_BY", length = 40)
	private String lastModifiedBy;

	@Column(name = "LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name = "RESOURCE_1141_CODE", nullable = false, length = 30)
	private String resource1141Code;

	@Column(name = "RESOURCE_STATE", nullable = false, length = 25)
	private String resourceState;

	@Column(name = "SERIAL_NUMBER", length = 30)
	private String serialNumber;

	@Column(name = "SERVICE_STATE", length = 25)
	private String serviceState;

	@Column(name = "SPEC_CATEGORY_NAME", length = 30)
	private String specCategoryName;

	@Column(name = "SPEC_TYPE_NAME", length = 40)
	private String specTypeName;

	@Column(name = "USER_LABEL", length = 30)
	private String userLabel;

	// bi-directional many-to-one association to Block
	@OneToMany(mappedBy = "blockHolder")
	private List<Block> blocks;

	// bi-directional many-to-one association to Rack
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "RACK_NAME")
	private Rack rack;

	// bi-directional many-to-one association to DistributionFrame
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FRAME_NAME")
	private DistributionFrame distributionFrame;

	// bi-directional many-to-one association to BlockHolderChar
	@OneToMany(mappedBy = "blockHolder")
	private List<BlockHolderChar> blockHolderChars;

	// bi-directional many-to-one association to DfBhBlockAssoc
	@OneToMany(mappedBy = "blockHolder")
	private List<DfBhBlockAssoc> dfBhBlockAssocs;

	// bi-directional many-to-one association to DfRackBhAssoc
	@OneToMany(mappedBy = "blockHolder")
	private List<DfRackBhAssoc> dfRackBhAssocs;

	public BlockHolder() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getHolderSpecVersion() {
		return this.holderSpecVersion;
	}

	public void setHolderSpecVersion(String holderSpecVersion) {
		this.holderSpecVersion = holderSpecVersion;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<Block> getBlocks() {
		return this.blocks;
	}

	public void setBlocks(List<Block> blocks) {
		this.blocks = blocks;
	}

	public Block addBlock(Block block) {
		getBlocks().add(block);
		block.setBlockHolder(this);

		return block;
	}

	public Block removeBlock(Block block) {
		getBlocks().remove(block);
		block.setBlockHolder(null);

		return block;
	}

	public Rack getRack() {
		return this.rack;
	}

	public void setRack(Rack rack) {
		this.rack = rack;
	}

	public DistributionFrame getDistributionFrame() {
		return this.distributionFrame;
	}

	public void setDistributionFrame(DistributionFrame distributionFrame) {
		this.distributionFrame = distributionFrame;
	}

	public List<BlockHolderChar> getBlockHolderChars() {
		return this.blockHolderChars;
	}

	public void setBlockHolderChars(List<BlockHolderChar> blockHolderChars) {
		this.blockHolderChars = blockHolderChars;
	}

	public BlockHolderChar addBlockHolderChar(BlockHolderChar blockHolderChar) {
		getBlockHolderChars().add(blockHolderChar);
		blockHolderChar.setBlockHolder(this);

		return blockHolderChar;
	}

	public BlockHolderChar removeBlockHolderChar(BlockHolderChar blockHolderChar) {
		getBlockHolderChars().remove(blockHolderChar);
		blockHolderChar.setBlockHolder(null);

		return blockHolderChar;
	}

	public List<DfBhBlockAssoc> getDfBhBlockAssocs() {
		return this.dfBhBlockAssocs;
	}

	public void setDfBhBlockAssocs(List<DfBhBlockAssoc> dfBhBlockAssocs) {
		this.dfBhBlockAssocs = dfBhBlockAssocs;
	}

	public DfBhBlockAssoc addDfBhBlockAssoc(DfBhBlockAssoc dfBhBlockAssoc) {
		getDfBhBlockAssocs().add(dfBhBlockAssoc);
		dfBhBlockAssoc.setBlockHolder(this);

		return dfBhBlockAssoc;
	}

	public DfBhBlockAssoc removeDfBhBlockAssoc(DfBhBlockAssoc dfBhBlockAssoc) {
		getDfBhBlockAssocs().remove(dfBhBlockAssoc);
		dfBhBlockAssoc.setBlockHolder(null);

		return dfBhBlockAssoc;
	}

	public List<DfRackBhAssoc> getDfRackBhAssocs() {
		return this.dfRackBhAssocs;
	}

	public void setDfRackBhAssocs(List<DfRackBhAssoc> dfRackBhAssocs) {
		this.dfRackBhAssocs = dfRackBhAssocs;
	}

	public DfRackBhAssoc addDfRackBhAssoc(DfRackBhAssoc dfRackBhAssoc) {
		getDfRackBhAssocs().add(dfRackBhAssoc);
		dfRackBhAssoc.setBlockHolder(this);

		return dfRackBhAssoc;
	}

	public DfRackBhAssoc removeDfRackBhAssoc(DfRackBhAssoc dfRackBhAssoc) {
		getDfRackBhAssocs().remove(dfRackBhAssoc);
		dfRackBhAssoc.setBlockHolder(null);

		return dfRackBhAssoc;
	}

}