/**
 * This is for mapping port statistics for Cross connenct point.
 *
 * @since 5 Feb 2018
 * @author Aditya Ajmera 609734641
 */

package com.bt.ngp.userdefined.entities;

import com.bt.ngp.datasource.entities.CrossConnectPoint;
import com.bt.ngp.datasource.entities.Plugin;

/**
 * @author 609734641
 *
 */
public class PortStatisticsCcp {
	private CrossConnectPoint crossConnectPoint;

	private Plugin plugin;

	private long portCount;

	/**
	 * default constructor
	 */
	public PortStatisticsCcp() {
		super();
	}

	/**
	 * @param crossConnectPoint
	 * @param plugin
	 * @param portCount
	 */
	public PortStatisticsCcp(CrossConnectPoint crossConnectPoint, Plugin plugin,
			long portCount) {
		super();
		this.crossConnectPoint = crossConnectPoint;
		this.plugin = plugin;
		this.portCount = portCount;
	}

	/**
	 * @return the crossConnectPoint
	 */
	public CrossConnectPoint getCrossConnectPoint() {
		return crossConnectPoint;
	}

	/**
	 * @param crossConnectPoint the crossConnectPoint to set
	 */
	public void setCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		this.crossConnectPoint = crossConnectPoint;
	}

	/**
	 * @return the plugin
	 */
	public Plugin getPlugin() {
		return plugin;
	}

	/**
	 * @param plugin the plugin to set
	 */
	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

	/**
	 * @return the portCount
	 */
	public long getPortCount() {
		return portCount;
	}

	/**
	 * @param portCount the portCount to set
	 */
	public void setPortCount(long portCount) {
		this.portCount = portCount;
	}
}
