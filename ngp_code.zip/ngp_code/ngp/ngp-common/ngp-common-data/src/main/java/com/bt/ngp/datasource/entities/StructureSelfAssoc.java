package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import java.sql.Timestamp;


/**
 * The persistent class for the STRUCTURE_SELF_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="STRUCTURE_SELF_ASSOC")
@NamedQuery(name="StructureSelfAssoc.findAll", query="SELECT s FROM StructureSelfAssoc s")
public class StructureSelfAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, precision=38)
	private long id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="STRUCTURE_SELF_ASSOC_SPEC_ID", length=50)
	private String structureSelfAssocSpecId;

	//bi-directional many-to-one association to Structure
	@ManyToOne
	@JoinColumn(name="CHILD_STRUCTURE_NAME")
	@NotFound(action = NotFoundAction.IGNORE)
	private Structure childStructure;

	//bi-directional many-to-one association to Structure
	@ManyToOne
	@JoinColumn(name="PARENT_STRUCTURE_NAME")
	@NotFound(action = NotFoundAction.IGNORE)
	private Structure parentStructure;

	public StructureSelfAssoc() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getStructureSelfAssocSpecId() {
		return this.structureSelfAssocSpecId;
	}

	public void setStructureSelfAssocSpecId(String structureSelfAssocSpecId) {
		this.structureSelfAssocSpecId = structureSelfAssocSpecId;
	}

	public Structure getChildStructure() {
		return this.childStructure;
	}

	public void setChildStructure(Structure childStructure) {
		this.childStructure = childStructure;
	}

	public Structure getParentStructure() {
		return this.parentStructure;
	}

	public void setParentStructure(Structure parentStructure) {
		this.parentStructure = parentStructure;
	}

}