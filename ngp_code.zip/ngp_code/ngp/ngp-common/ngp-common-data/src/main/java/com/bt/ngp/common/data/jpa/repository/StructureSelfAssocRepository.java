package com.bt.ngp.common.data.jpa.repository;

import com.bt.ngp.datasource.entities.StructureSelfAssoc;

public interface StructureSelfAssocRepository extends SqlRepository<StructureSelfAssoc> {

}
