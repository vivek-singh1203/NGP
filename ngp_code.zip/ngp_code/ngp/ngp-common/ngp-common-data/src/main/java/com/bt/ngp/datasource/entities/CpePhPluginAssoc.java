package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the CPE_PH_PLUGIN_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CPE_PH_PLUGIN_ASSOC")
@NamedQuery(name="CpePhPluginAssoc.findAll", query="SELECT c FROM CpePhPluginAssoc c")
public class CpePhPluginAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="HOLDER_COMP_ASSOC_SPEC_ID", length=50)
	private String holderCompAssocSpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to CpeHierarchy
	@OneToMany(mappedBy="cpePhPluginAssoc")
	private List<CpeHierarchy> cpeHierarchies;

	//bi-directional many-to-one association to CustomerPremiseEquipment
	@ManyToOne
	@JoinColumn(name="CPE_NAME")
	private CustomerPremiseEquipment customerPremiseEquipment;

	//bi-directional many-to-one association to PluginHolder
	@ManyToOne
	@JoinColumn(name="PH_NAME")
	private PluginHolder pluginHolder;

	//bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	public CpePhPluginAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getHolderCompAssocSpecId() {
		return this.holderCompAssocSpecId;
	}

	public void setHolderCompAssocSpecId(String holderCompAssocSpecId) {
		this.holderCompAssocSpecId = holderCompAssocSpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public List<CpeHierarchy> getCpeHierarchies() {
		return this.cpeHierarchies;
	}

	public void setCpeHierarchies(List<CpeHierarchy> cpeHierarchies) {
		this.cpeHierarchies = cpeHierarchies;
	}

	public CpeHierarchy addCpeHierarchy(CpeHierarchy cpeHierarchy) {
		getCpeHierarchies().add(cpeHierarchy);
		cpeHierarchy.setCpePhPluginAssoc(this);

		return cpeHierarchy;
	}

	public CpeHierarchy removeCpeHierarchy(CpeHierarchy cpeHierarchy) {
		getCpeHierarchies().remove(cpeHierarchy);
		cpeHierarchy.setCpePhPluginAssoc(null);

		return cpeHierarchy;
	}

	public CustomerPremiseEquipment getCustomerPremiseEquipment() {
		return this.customerPremiseEquipment;
	}

	public void setCustomerPremiseEquipment(CustomerPremiseEquipment customerPremiseEquipment) {
		this.customerPremiseEquipment = customerPremiseEquipment;
	}

	public PluginHolder getPluginHolder() {
		return this.pluginHolder;
	}

	public void setPluginHolder(PluginHolder pluginHolder) {
		this.pluginHolder = pluginHolder;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

}