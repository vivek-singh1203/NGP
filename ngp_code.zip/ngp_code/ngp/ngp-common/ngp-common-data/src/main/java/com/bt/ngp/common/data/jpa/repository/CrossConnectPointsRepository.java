package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bt.ngp.datasource.entities.CrossConnectPoint;
import com.bt.ngp.datasource.entities.Exchange;

public interface CrossConnectPointsRepository extends CommonOperation<CrossConnectPoint>{

	@Query(name="CcpRepository.findEquipmentWithoutCableSectionAssoc", nativeQuery=true)
	List<CrossConnectPoint> findEquipmentWithoutCableSectionAssoc(@Param("exchangeCode") String exchange1141Code);
	
	List<CrossConnectPoint> findByExchangeAndCcpStructureAssocsIsNull(@Param("exchange") Exchange exchange);
}
