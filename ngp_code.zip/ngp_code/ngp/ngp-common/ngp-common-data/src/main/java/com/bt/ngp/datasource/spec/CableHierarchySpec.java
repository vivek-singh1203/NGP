package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the CABLE_HIERARCHY_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CABLE_HIERARCHY_SPEC")
@NamedQuery(name="CableHierarchySpec.findAll", query="SELECT c FROM CableHierarchySpec c")
public class CableHierarchySpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CABLE_ENTITY_NAME", length=30)
	private String cableEntityName;

	@Column(name="COND_START_SEQ_NO", nullable=false, precision=38)
	private BigDecimal condStartSeqNo;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="HIERARCHY_LEG_ID", nullable=false, precision=38)
	private BigDecimal hierarchyLegId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to CableCbAssocSpec
	@ManyToOne
	@JoinColumn(name="CABLE_CB_ASSOC_SPEC_ID")
	private CableCbAssocSpec cableCbAssocSpec;

	//bi-directional many-to-one association to CableCondAssocSpec
	@ManyToOne
	@JoinColumn(name="CABLE_COND_ASSOC_SPEC_ID")
	private CableCondAssocSpec cableCondAssocSpec;

	//bi-directional many-to-one association to CableSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="CABLE_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="CABLE_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private CableSpec cableSpec;

	//bi-directional many-to-one association to CbCondAssocSpec
	@ManyToOne
	@JoinColumn(name="CB_COND_ASSOC_SPEC_ID")
	private CbCondAssocSpec cbCondAssocSpec;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="CABLE_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="CABLE_SPEC_TYPE_NAME")
	private SpecType specType;

	public CableHierarchySpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCableEntityName() {
		return this.cableEntityName;
	}

	public void setCableEntityName(String cableEntityName) {
		this.cableEntityName = cableEntityName;
	}

	public BigDecimal getCondStartSeqNo() {
		return this.condStartSeqNo;
	}

	public void setCondStartSeqNo(BigDecimal condStartSeqNo) {
		this.condStartSeqNo = condStartSeqNo;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public BigDecimal getHierarchyLegId() {
		return this.hierarchyLegId;
	}

	public void setHierarchyLegId(BigDecimal hierarchyLegId) {
		this.hierarchyLegId = hierarchyLegId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public CableCbAssocSpec getCableCbAssocSpec() {
		return this.cableCbAssocSpec;
	}

	public void setCableCbAssocSpec(CableCbAssocSpec cableCbAssocSpec) {
		this.cableCbAssocSpec = cableCbAssocSpec;
	}

	public CableCondAssocSpec getCableCondAssocSpec() {
		return this.cableCondAssocSpec;
	}

	public void setCableCondAssocSpec(CableCondAssocSpec cableCondAssocSpec) {
		this.cableCondAssocSpec = cableCondAssocSpec;
	}

	public CableSpec getCableSpec() {
		return this.cableSpec;
	}

	public void setCableSpec(CableSpec cableSpec) {
		this.cableSpec = cableSpec;
	}

	public CbCondAssocSpec getCbCondAssocSpec() {
		return this.cbCondAssocSpec;
	}

	public void setCbCondAssocSpec(CbCondAssocSpec cbCondAssocSpec) {
		this.cbCondAssocSpec = cbCondAssocSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

}