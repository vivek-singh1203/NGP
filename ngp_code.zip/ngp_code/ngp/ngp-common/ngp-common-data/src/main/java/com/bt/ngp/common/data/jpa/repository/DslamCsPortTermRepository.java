package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.Card;
import com.bt.ngp.datasource.entities.Conductor;
import com.bt.ngp.datasource.entities.ConductorBundle;
import com.bt.ngp.datasource.entities.Dslam;
import com.bt.ngp.datasource.entities.DslamCsPortTerm;
import com.bt.ngp.datasource.entities.DslamPort;
import com.bt.ngp.datasource.entities.Rack;

@Repository
public interface DslamCsPortTermRepository extends SqlRepository<DslamCsPortTerm> {

	public DslamCsPortTerm findByDslamAndRackAndCardAndDslamPortAndCableSectionAndConductorBundleAndConductor(
			Dslam dslam, Rack rack, Card card, DslamPort dslamPort, CableSection cableSection,
			ConductorBundle conductorBundle, Conductor conductor);

	@Query(name = "DslamCsPortTermRepository.findDslamCsPortTerm", nativeQuery = true)
	List<DslamCsPortTerm> findDslamCsPortTerm(@Param("termObj") DslamCsPortTerm termObj);

	@Query(name = "DslamCsPortTermRepository.fetchViaDslamCsCbCond", nativeQuery = true)
	public DslamCsPortTerm fetchDslamCsPortTerm(@Param("dslamCsPortTerm") DslamCsPortTerm dslamCsPortTerm);

	List<DslamCsPortTerm> findByDslam(@Param("dslam") Dslam dslam);

	@Query(name = "DslamCsPortTermRepository.findByConductorAndTerminationType")
	List<DslamCsPortTerm> findByConductorAndTerminationType(
			@Param("dslamCsPortTermObj") DslamCsPortTerm dslamCsPortTermObj);

	@Query(name = "DslamCsPortTermRepository.findByCableSectionAndPort")
	List<DslamCsPortTerm> findByCableSectionAndPort(@Param("dslamCsPortTermObj") DslamCsPortTerm dslamCsPortTermObj);

	@Query(name = "DslamCsPortTermRepository.findByDslamCableAndConductor")
	List<DslamCsPortTerm> findByDslamCableAndConductor(@Param("dslamCsPortTerm") DslamCsPortTerm dslamCsPortTerm);
}
