package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.MfnPort;
import com.bt.ngp.userdefined.entities.PortStatisticsMfn;

@Repository
public interface MfnPortRepository extends CommonOperation<MfnPort> {
	@Query(name = "MfnPortRepository.fetchPortCountInPlugin", nativeQuery = false)
	public List<PortStatisticsMfn> fetchPortCount(
			@Param("mfnPort") MfnPort mfnPort);
}