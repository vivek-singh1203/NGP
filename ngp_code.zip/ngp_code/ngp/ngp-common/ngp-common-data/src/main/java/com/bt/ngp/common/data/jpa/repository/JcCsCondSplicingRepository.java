package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.JcCsCondSplicing;

@Repository
public interface JcCsCondSplicingRepository extends SqlRepository<JcCsCondSplicing> {

	public List<JcCsCondSplicing> findByCableSectionOrigCsNameAndCableSectionTermCsName(
			CableSection cableSectionOrigCsName, CableSection cableSectionTermCsName);

	@Transactional
	@Modifying
	@Query(name = "JcCsCondSplicingRepository.deleteJcCsCondSplicingByNameOfWiredEntities", nativeQuery = true)
	public int deleteJcCsCondSplicing(@Param("jcCsCondSplicing") JcCsCondSplicing jcCsCondSplicing);

	@Query(name = "JcCsCondSplicingRepository.findConductorSplicingOriginating")
	public List<JcCsCondSplicing> findOriginatingConductorSplicing(
			@Param("jcCsCondSplicing") JcCsCondSplicing jcCsCondSplicing);

	@Query(name = "JcCsCondSplicingRepository.findConductorSplicingTerminating")
	public List<JcCsCondSplicing> findTerminatingConductorSplicing(
			@Param("jcCsCondSplicing") JcCsCondSplicing jcCsCondSplicing);

	public List<JcCsCondSplicing> findByCableSectionTermParentCsName(CableSection cableSectionTermParentCsName);

	public List<JcCsCondSplicing> findByCableSectionOrigParentCsName(CableSection cableSectionOrigParentCsName);

	public JcCsCondSplicing findByCableSectionOrigParentCsNameAndCableSectionOrigCsNameAndSplicingResource(
			CableSection cableSectionOrigParentCsName, CableSection cableSectionOrigCsName, String splicingResource);

	public JcCsCondSplicing findByCableSectionTermParentCsNameAndCableSectionTermCsNameAndSplicingResource(
			CableSection cableSectionTermParentCsName, CableSection cableSectionTermCsName, String splicingResource);

}
