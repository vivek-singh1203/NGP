package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.NteCsCondSplicing;

@Repository
public interface NteCsCondSplicingRepository extends SqlRepository<NteCsCondSplicing> {

	List<NteCsCondSplicing> findByCableSectionOrigCsNameAndCableSectionTermCsName(CableSection cableSectionOrigCsName,
			CableSection cableSectionTermCsName);

	@Transactional
	@Modifying
	@Query(name = "NteCsCondSplicingRepository.deleteNteCsCondSplicingByNameOfWiredEntities", nativeQuery = true)
	public int deleteNteCsCondSplicing(@Param("nteCsCondSplicing") NteCsCondSplicing nteCsCondSplicing);

	@Query(name = "NteCsCondSplicingRepository.findConductorSplicingOriginating")
	public List<NteCsCondSplicing> findOriginatingConductorSplicing(
			@Param("nteCsCondSplicing") NteCsCondSplicing nteCsCondSplicing);

	@Query(name = "NteCsCondSplicingRepository.findConductorSplicingTerminating")
	public List<NteCsCondSplicing> findTerminatingConductorSplicing(
			@Param("nteCsCondSplicing") NteCsCondSplicing nteCsCondSplicing);

	public List<NteCsCondSplicing> findByCableSectionOrigParentCsName(CableSection cableSectionOrigParentCsName);

	public List<NteCsCondSplicing> findByCableSectionTermParentCsName(CableSection cableSectionTermParentCsName);

	public NteCsCondSplicing findByCableSectionOrigParentCsNameAndCableSectionOrigCsNameAndSplicingResource(
			CableSection cableSectionOrigParentCsName, CableSection cableSectionOrigCsName, String splicingResource);

	public NteCsCondSplicing findByCableSectionTermParentCsNameAndCableSectionTermCsNameAndSplicingResource(
			CableSection cableSectionTermParentCsName, CableSection cableSectionTermCsName, String splicingResource);
}
