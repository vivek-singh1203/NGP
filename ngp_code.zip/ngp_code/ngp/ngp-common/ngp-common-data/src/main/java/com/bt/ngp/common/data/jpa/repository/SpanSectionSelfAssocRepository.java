package com.bt.ngp.common.data.jpa.repository;

import com.bt.ngp.datasource.entities.SpanSectionSelfAssoc;

public interface SpanSectionSelfAssocRepository extends SqlRepository<SpanSectionSelfAssoc> {

}
