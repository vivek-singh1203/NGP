package com.bt.ngp.common.data.jpa.repository;

import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.DslamPortPortAssoc;

@Repository
public interface DslamPortPortAssocRepository extends SqlRepository<DslamPortPortAssoc> {

}
