package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the CONDUCTOR_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CONDUCTOR_SPEC")
@NamedQuery(name="ConductorSpec.findAll", query="SELECT c FROM ConductorSpec c")
public class ConductorSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ConductorSpecPK conductorSpecPKId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DEPTH", precision=126)
	private double depth;

	@Column(name="DEPTH_UNIT", length=10)
	private String depthUnit;

	@Column(precision=126)
	private double diameter;

	@Column(name="DIAMETER_UNIT", length=10)
	private String diameterUnit;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(precision=126)
	private double height;

	@Column(name="HEIGHT_UNIT", length=10)
	private String heightUnit;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="IS_ORDERABLE")
	private String isOrderable;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LENGTH", precision=126)
	private double length;

	@Column(name="LENGTH_UNIT", length=10)
	private String lengthUnit;

	@Column(name="MANUFACTURER_NAME", length=30)
	private String manufacturerName;

	@Column(name="MATERIAL_COST_PER_UNIT", precision=126)
	private double materialCostPerUnit;

	@Column(name="MATERIAL_COST_UNIT", length=10)
	private String materialCostUnit;

	@Column(name="MATERIAL_TYPE", length=10)
	private String materialType;

	@Column(name="POWER_CONSUMPTION", precision=126)
	private double powerConsumption;

	@Column(name="POWER_CONSUMPTION_UNIT", length=10)
	private String powerConsumptionUnit;

	@Column(name="POWER_DISSIPATION", precision=126)
	private double powerDissipation;

	@Column(name="POWER_DISSIPATION_UNIT", length=10)
	private String powerDissipationUnit;

	@Column(name="POWER_RATING", precision=126)
	private double powerRating;

	@Column(name="POWER_RATING_UNIT", length=10)
	private String powerRatingUnit;

	@Column(name="SPEC_REMARKS", length=50)
	private String specRemarks;

	@Column(name="SPEC_STATUS", nullable=false, length=10)
	private String specStatus;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	@Column(precision=126)
	private double volume;

	@Column(name="VOLUME_UNIT", length=10)
	private String volumeUnit;

	@Column(precision=126)
	private double weight;

	@Column(name="WEIGHT_UNIT", length=10)
	private String weightUnit;

	@Column(precision=126)
	private double width;

	@Column(name="WIDTH_UNIT", length=10)
	private String widthUnit;

	//bi-directional many-to-one association to CableCondAssocSpec
	@OneToMany(mappedBy="conductorSpec",fetch=FetchType.LAZY)
	private List<CableCondAssocSpec> cableCondAssocSpecs;

	//bi-directional many-to-one association to CbCondAssocSpec
	@OneToMany(mappedBy="conductorSpec",fetch=FetchType.LAZY)
	private List<CbCondAssocSpec> cbCondAssocSpecs;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to CondSpecCharSpec
	@OneToMany(mappedBy="conductorSpec",fetch=FetchType.LAZY)
	private List<CondSpecCharSpec> condSpecCharSpecs;

	//bi-directional many-to-one association to CondSpecCharSpecRel
	@OneToMany(mappedBy="conductorSpec",fetch=FetchType.LAZY)
	private List<CondSpecCharSpecRel> condSpecCharSpecRels;

	//bi-directional many-to-one association to CondSpecCharValueSpec
	@OneToMany(mappedBy="conductorSpec",fetch=FetchType.LAZY)
	private List<CondSpecCharValueSpec> condSpecCharValueSpecs;

	public ConductorSpec() {
	}

	public ConductorSpecPK getConductorSpecPKId() {
		return this.conductorSpecPKId;
	}

	public void setId(ConductorSpecPK conductorSpecPKId) {
		this.conductorSpecPKId = conductorSpecPKId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public double getDepth() {
		return this.depth;
	}

	public void setDepth(double depth) {
		this.depth = depth;
	}

	public String getDepthUnit() {
		return this.depthUnit;
	}

	public void setDepthUnit(String depthUnit) {
		this.depthUnit = depthUnit;
	}

	public double getDiameter() {
		return this.diameter;
	}

	public void setDiameter(double diameter) {
		this.diameter = diameter;
	}

	public String getDiameterUnit() {
		return this.diameterUnit;
	}

	public void setDiameterUnit(String diameterUnit) {
		this.diameterUnit = diameterUnit;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public double getHeight() {
		return this.height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public String getHeightUnit() {
		return this.heightUnit;
	}

	public void setHeightUnit(String heightUnit) {
		this.heightUnit = heightUnit;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIsOrderable() {
		return this.isOrderable;
	}

	public void setIsOrderable(String isOrderable) {
		this.isOrderable = isOrderable;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public double getLength() {
		return this.length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public String getLengthUnit() {
		return this.lengthUnit;
	}

	public void setLengthUnit(String lengthUnit) {
		this.lengthUnit = lengthUnit;
	}

	public String getManufacturerName() {
		return this.manufacturerName;
	}

	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}

	public double getMaterialCostPerUnit() {
		return this.materialCostPerUnit;
	}

	public void setMaterialCostPerUnit(double materialCostPerUnit) {
		this.materialCostPerUnit = materialCostPerUnit;
	}

	public String getMaterialCostUnit() {
		return this.materialCostUnit;
	}

	public void setMaterialCostUnit(String materialCostUnit) {
		this.materialCostUnit = materialCostUnit;
	}

	public String getMaterialType() {
		return this.materialType;
	}

	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}

	public double getPowerConsumption() {
		return this.powerConsumption;
	}

	public void setPowerConsumption(double powerConsumption) {
		this.powerConsumption = powerConsumption;
	}

	public String getPowerConsumptionUnit() {
		return this.powerConsumptionUnit;
	}

	public void setPowerConsumptionUnit(String powerConsumptionUnit) {
		this.powerConsumptionUnit = powerConsumptionUnit;
	}

	public double getPowerDissipation() {
		return this.powerDissipation;
	}

	public void setPowerDissipation(double powerDissipation) {
		this.powerDissipation = powerDissipation;
	}

	public String getPowerDissipationUnit() {
		return this.powerDissipationUnit;
	}

	public void setPowerDissipationUnit(String powerDissipationUnit) {
		this.powerDissipationUnit = powerDissipationUnit;
	}

	public double getPowerRating() {
		return this.powerRating;
	}

	public void setPowerRating(double powerRating) {
		this.powerRating = powerRating;
	}

	public String getPowerRatingUnit() {
		return this.powerRatingUnit;
	}

	public void setPowerRatingUnit(String powerRatingUnit) {
		this.powerRatingUnit = powerRatingUnit;
	}

	public String getSpecRemarks() {
		return this.specRemarks;
	}

	public void setSpecRemarks(String specRemarks) {
		this.specRemarks = specRemarks;
	}

	public String getSpecStatus() {
		return this.specStatus;
	}

	public void setSpecStatus(String specStatus) {
		this.specStatus = specStatus;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public double getVolume() {
		return this.volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public String getVolumeUnit() {
		return this.volumeUnit;
	}

	public void setVolumeUnit(String volumeUnit) {
		this.volumeUnit = volumeUnit;
	}

	public double getWeight() {
		return this.weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getWeightUnit() {
		return this.weightUnit;
	}

	public void setWeightUnit(String weightUnit) {
		this.weightUnit = weightUnit;
	}

	public double getWidth() {
		return this.width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public String getWidthUnit() {
		return this.widthUnit;
	}

	public void setWidthUnit(String widthUnit) {
		this.widthUnit = widthUnit;
	}

	public List<CableCondAssocSpec> getCableCondAssocSpecs() {
		return this.cableCondAssocSpecs;
	}

	public void setCableCondAssocSpecs(List<CableCondAssocSpec> cableCondAssocSpecs) {
		this.cableCondAssocSpecs = cableCondAssocSpecs;
	}

	public CableCondAssocSpec addCableCondAssocSpec(CableCondAssocSpec cableCondAssocSpec) {
		getCableCondAssocSpecs().add(cableCondAssocSpec);
		cableCondAssocSpec.setConductorSpec(this);

		return cableCondAssocSpec;
	}

	public CableCondAssocSpec removeCableCondAssocSpec(CableCondAssocSpec cableCondAssocSpec) {
		getCableCondAssocSpecs().remove(cableCondAssocSpec);
		cableCondAssocSpec.setConductorSpec(null);

		return cableCondAssocSpec;
	}

	public List<CbCondAssocSpec> getCbCondAssocSpecs() {
		return this.cbCondAssocSpecs;
	}

	public void setCbCondAssocSpecs(List<CbCondAssocSpec> cbCondAssocSpecs) {
		this.cbCondAssocSpecs = cbCondAssocSpecs;
	}

	public CbCondAssocSpec addCbCondAssocSpec(CbCondAssocSpec cbCondAssocSpec) {
		getCbCondAssocSpecs().add(cbCondAssocSpec);
		cbCondAssocSpec.setConductorSpec(this);

		return cbCondAssocSpec;
	}

	public CbCondAssocSpec removeCbCondAssocSpec(CbCondAssocSpec cbCondAssocSpec) {
		getCbCondAssocSpecs().remove(cbCondAssocSpec);
		cbCondAssocSpec.setConductorSpec(null);

		return cbCondAssocSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public List<CondSpecCharSpec> getCondSpecCharSpecs() {
		return this.condSpecCharSpecs;
	}

	public void setCondSpecCharSpecs(List<CondSpecCharSpec> condSpecCharSpecs) {
		this.condSpecCharSpecs = condSpecCharSpecs;
	}

	public CondSpecCharSpec addCondSpecCharSpec(CondSpecCharSpec condSpecCharSpec) {
		getCondSpecCharSpecs().add(condSpecCharSpec);
		condSpecCharSpec.setConductorSpec(this);

		return condSpecCharSpec;
	}

	public CondSpecCharSpec removeCondSpecCharSpec(CondSpecCharSpec condSpecCharSpec) {
		getCondSpecCharSpecs().remove(condSpecCharSpec);
		condSpecCharSpec.setConductorSpec(null);

		return condSpecCharSpec;
	}

	public List<CondSpecCharSpecRel> getCondSpecCharSpecRels() {
		return this.condSpecCharSpecRels;
	}

	public void setCondSpecCharSpecRels(List<CondSpecCharSpecRel> condSpecCharSpecRels) {
		this.condSpecCharSpecRels = condSpecCharSpecRels;
	}

	public CondSpecCharSpecRel addCondSpecCharSpecRel(CondSpecCharSpecRel condSpecCharSpecRel) {
		getCondSpecCharSpecRels().add(condSpecCharSpecRel);
		condSpecCharSpecRel.setConductorSpec(this);

		return condSpecCharSpecRel;
	}

	public CondSpecCharSpecRel removeCondSpecCharSpecRel(CondSpecCharSpecRel condSpecCharSpecRel) {
		getCondSpecCharSpecRels().remove(condSpecCharSpecRel);
		condSpecCharSpecRel.setConductorSpec(null);

		return condSpecCharSpecRel;
	}

	public List<CondSpecCharValueSpec> getCondSpecCharValueSpecs() {
		return this.condSpecCharValueSpecs;
	}

	public void setCondSpecCharValueSpecs(List<CondSpecCharValueSpec> condSpecCharValueSpecs) {
		this.condSpecCharValueSpecs = condSpecCharValueSpecs;
	}

	public CondSpecCharValueSpec addCondSpecCharValueSpec(CondSpecCharValueSpec condSpecCharValueSpec) {
		getCondSpecCharValueSpecs().add(condSpecCharValueSpec);
		condSpecCharValueSpec.setConductorSpec(this);

		return condSpecCharValueSpec;
	}

	public CondSpecCharValueSpec removeCondSpecCharValueSpec(CondSpecCharValueSpec condSpecCharValueSpec) {
		getCondSpecCharValueSpecs().remove(condSpecCharValueSpec);
		condSpecCharValueSpec.setConductorSpec(null);

		return condSpecCharValueSpec;
	}

}