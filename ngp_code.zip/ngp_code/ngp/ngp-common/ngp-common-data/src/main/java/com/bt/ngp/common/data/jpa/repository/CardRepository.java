package com.bt.ngp.common.data.jpa.repository;

import com.bt.ngp.datasource.entities.Card;

public interface CardRepository extends CommonOperation<Card>{

}
