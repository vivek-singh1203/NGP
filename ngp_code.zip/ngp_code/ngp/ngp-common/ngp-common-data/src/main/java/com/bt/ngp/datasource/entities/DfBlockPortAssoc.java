package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the DF_BLOCK_PORT_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DF_BLOCK_PORT_ASSOC")
@NamedQuery(name="DfBlockPortAssoc.findAll", query="SELECT d FROM DfBlockPortAssoc d")
public class DfBlockPortAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="COMP_PORT_ASSOC_SPEC_ID", length=50)
	private String compPortAssocSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal portSeqNum;

	//bi-directional many-to-one association to Block
	@ManyToOne
	@JoinColumn(name="BLOCK_NAME")
	private Block block;

	//bi-directional many-to-one association to DistributionFrame
	@ManyToOne
	@JoinColumn(name="FRAME_NAME")
	private DistributionFrame distributionFrame;

	//bi-directional many-to-one association to DfPort
	@ManyToOne
	@JoinColumn(name="PORT_NAME")
	private DfPort dfPort;

	//bi-directional many-to-one association to DfHierarchy
	@OneToMany(mappedBy="dfBlockPortAssoc")
	private List<DfHierarchy> dfHierarchies;

	public DfBlockPortAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompPortAssocSpecId() {
		return this.compPortAssocSpecId;
	}

	public void setCompPortAssocSpecId(String compPortAssocSpecId) {
		this.compPortAssocSpecId = compPortAssocSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortSeqNum() {
		return this.portSeqNum;
	}

	public void setPortSeqNum(BigDecimal portSeqNum) {
		this.portSeqNum = portSeqNum;
	}

	public Block getBlock() {
		return this.block;
	}

	public void setBlock(Block block) {
		this.block = block;
	}

	public DistributionFrame getDistributionFrame() {
		return this.distributionFrame;
	}

	public void setDistributionFrame(DistributionFrame distributionFrame) {
		this.distributionFrame = distributionFrame;
	}

	public DfPort getDfPort() {
		return this.dfPort;
	}

	public void setDfPort(DfPort dfPort) {
		this.dfPort = dfPort;
	}

	public List<DfHierarchy> getDfHierarchies() {
		return this.dfHierarchies;
	}

	public void setDfHierarchies(List<DfHierarchy> dfHierarchies) {
		this.dfHierarchies = dfHierarchies;
	}

	public DfHierarchy addDfHierarchy(DfHierarchy dfHierarchy) {
		getDfHierarchies().add(dfHierarchy);
		dfHierarchy.setDfBlockPortAssoc(this);

		return dfHierarchy;
	}

	public DfHierarchy removeDfHierarchy(DfHierarchy dfHierarchy) {
		getDfHierarchies().remove(dfHierarchy);
		dfHierarchy.setDfBlockPortAssoc(null);

		return dfHierarchy;
	}

}