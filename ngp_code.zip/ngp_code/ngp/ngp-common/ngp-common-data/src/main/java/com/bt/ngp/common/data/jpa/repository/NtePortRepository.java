package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.NtePort;
import com.bt.ngp.userdefined.entities.PortStatisticsNte;

@Repository
public interface NtePortRepository extends CommonOperation<NtePort> {
	@Query(name = "NtePortRepository.fetchPortCountInPlugin", nativeQuery = false)
	public List<PortStatisticsNte> fetchPortCount(
			@Param("ntePort") NtePort ntePort);
}