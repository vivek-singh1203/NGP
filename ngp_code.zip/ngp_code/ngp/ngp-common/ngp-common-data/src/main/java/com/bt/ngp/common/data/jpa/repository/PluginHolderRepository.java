package com.bt.ngp.common.data.jpa.repository;

import com.bt.ngp.datasource.entities.PluginHolder;

public interface PluginHolderRepository extends CommonOperation<PluginHolder>{

}
