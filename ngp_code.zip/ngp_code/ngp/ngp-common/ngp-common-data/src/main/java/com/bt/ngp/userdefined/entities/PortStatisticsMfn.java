/**
 * This file is for mapping PortStatistics for MultifunctionalNode.
 *
 * @since 5 Feb 2018
 * @author Aditya Ajmera 609734641
 */

package com.bt.ngp.userdefined.entities;

import com.bt.ngp.datasource.entities.MultiFunctionalNode;
import com.bt.ngp.datasource.entities.Plugin;

/**
 * @author 609734641
 *
 */
public class PortStatisticsMfn {
	private MultiFunctionalNode multiFunctionalNode;

	private Plugin plugin;

	private long portCount;

	/**
	 * default constructor
	 */
	public PortStatisticsMfn() {
		super();
	}

	/**
	 * @param multiFunctionalNode
	 * @param plugin
	 * @param portCount
	 */
	public PortStatisticsMfn(MultiFunctionalNode multiFunctionalNode,
			Plugin plugin, long portCount) {
		super();
		this.multiFunctionalNode = multiFunctionalNode;
		this.plugin = plugin;
		this.portCount = portCount;
	}

	/**
	 * @return the multiFunctionalNode
	 */
	public MultiFunctionalNode getMultiFunctionalNode() {
		return multiFunctionalNode;
	}

	/**
	 * @param multiFunctionalNode the multiFunctionalNode to set
	 */
	public void setMultiFunctionalNode(
			MultiFunctionalNode multiFunctionalNode) {
		this.multiFunctionalNode = multiFunctionalNode;
	}

	/**
	 * @return the plugin
	 */
	public Plugin getPlugin() {
		return plugin;
	}

	/**
	 * @param plugin the plugin to set
	 */
	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

	/**
	 * @return the portCount
	 */
	public long getPortCount() {
		return portCount;
	}

	/**
	 * @param portCount the portCount to set
	 */
	public void setPortCount(long portCount) {
		this.portCount = portCount;
	}
}
