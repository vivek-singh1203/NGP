package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.vividsolutions.jts.geom.Point;


/**
 * The persistent class for the NETWORK_TERMINATING_EQUIPMENT database table.
 * 
 */
@javax.persistence.Entity
@Table(name="NETWORK_TERMINATING_EQUIPMENT")
@NamedQuery(name="NetworkTerminatingEquipment.findAll", query="SELECT n FROM NetworkTerminatingEquipment n")
public class NetworkTerminatingEquipment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="DESG_NAME", length=30)
	private String desgName;

	@Column(name="DESG_NUM", precision=38)
	private String desgNum;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(name="FIELD_LABEL", length=30)
	private String fieldLabel;

	@Column(name = "GEO_POSITION", columnDefinition = "geometry(Point,3857)")
	private Point geoPosition;

	public Point getGeoPosition() {
		return geoPosition;
	}

	public void setGeoPosition(Point geoPosition) {
		this.geoPosition = geoPosition;
	}

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to AuxComponent
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<AuxComponent> auxComponents;

	//bi-directional many-to-one association to Chassi
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<Chassi> chassis;

	//bi-directional many-to-one association to Connector
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<Connector> connectors;

	//bi-directional many-to-one association to Exchange
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="EXCHANGE_1141_CODE")
	private Exchange exchange;

	//bi-directional many-to-one association to Store
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to NteChar
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<NteChar> nteChars;

	//bi-directional many-to-one association to NteChassisPhAssoc
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<NteChassisPhAssoc> nteChassisPhAssocs;

	//bi-directional many-to-one association to NteCsCondSplicing
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<NteCsCondSplicing> nteCsCondSplicings;

	//bi-directional many-to-one association to NteCsPortTerm
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<NteCsPortTerm> nteCsPortTerms;

	//bi-directional many-to-one association to NteHierarchy
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<NteHierarchy> nteHierarchies;

	//bi-directional many-to-one association to NtePhPluginAssoc
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<NtePhPluginAssoc> ntePhPluginAssocs;

	//bi-directional many-to-one association to NtePluginPortAssoc
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<NtePluginPortAssoc> ntePluginPortAssocs;

	//bi-directional many-to-one association to NtePort
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<NtePort> ntePorts;

	//bi-directional many-to-one association to NtePortChar
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<NtePortChar> ntePortChars;

	//bi-directional many-to-one association to NtePortPortAssoc
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<NtePortPortAssoc> ntePortPortAssocs;

	//bi-directional many-to-one association to NteStructureAssoc
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<NteStructureAssoc> nteStructureAssocs;

	//bi-directional many-to-one association to Plugin
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<Plugin> plugins;

	//bi-directional many-to-one association to PluginHolder
	@OneToMany(mappedBy="networkTerminatingEquipment")
	private List<PluginHolder> pluginHolders;

	public NetworkTerminatingEquipment() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getDesgName() {
		return this.desgName;
	}

	public void setDesgName(String desgName) {
		this.desgName = desgName;
	}

	public String getDesgNum() {
		return this.desgNum;
	}

	public void setDesgNum(String desgNum) {
		this.desgNum = desgNum;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getFieldLabel() {
		return this.fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<AuxComponent> getAuxComponents() {
		return this.auxComponents;
	}

	public void setAuxComponents(List<AuxComponent> auxComponents) {
		this.auxComponents = auxComponents;
	}

	public AuxComponent addAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().add(auxComponent);
		auxComponent.setNetworkTerminatingEquipment(this);

		return auxComponent;
	}

	public AuxComponent removeAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().remove(auxComponent);
		auxComponent.setNetworkTerminatingEquipment(null);

		return auxComponent;
	}

	public List<Chassi> getChassis() {
		return this.chassis;
	}

	public void setChassis(List<Chassi> chassis) {
		this.chassis = chassis;
	}

	public Chassi addChassi(Chassi chassi) {
		getChassis().add(chassi);
		chassi.setNetworkTerminatingEquipment(this);

		return chassi;
	}

	public Chassi removeChassi(Chassi chassi) {
		getChassis().remove(chassi);
		chassi.setNetworkTerminatingEquipment(null);

		return chassi;
	}

	public List<Connector> getConnectors() {
		return this.connectors;
	}

	public void setConnectors(List<Connector> connectors) {
		this.connectors = connectors;
	}

	public Connector addConnector(Connector connector) {
		getConnectors().add(connector);
		connector.setNetworkTerminatingEquipment(this);

		return connector;
	}

	public Connector removeConnector(Connector connector) {
		getConnectors().remove(connector);
		connector.setNetworkTerminatingEquipment(null);

		return connector;
	}

	public Exchange getExchange() {
		return this.exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public List<NteChar> getNteChars() {
		return this.nteChars;
	}

	public void setNteChars(List<NteChar> nteChars) {
		this.nteChars = nteChars;
	}

	public NteChar addNteChar(NteChar nteChar) {
		getNteChars().add(nteChar);
		nteChar.setNetworkTerminatingEquipment(this);

		return nteChar;
	}

	public NteChar removeNteChar(NteChar nteChar) {
		getNteChars().remove(nteChar);
		nteChar.setNetworkTerminatingEquipment(null);

		return nteChar;
	}

	public List<NteChassisPhAssoc> getNteChassisPhAssocs() {
		return this.nteChassisPhAssocs;
	}

	public void setNteChassisPhAssocs(List<NteChassisPhAssoc> nteChassisPhAssocs) {
		this.nteChassisPhAssocs = nteChassisPhAssocs;
	}

	public NteChassisPhAssoc addNteChassisPhAssoc(NteChassisPhAssoc nteChassisPhAssoc) {
		getNteChassisPhAssocs().add(nteChassisPhAssoc);
		nteChassisPhAssoc.setNetworkTerminatingEquipment(this);

		return nteChassisPhAssoc;
	}

	public NteChassisPhAssoc removeNteChassisPhAssoc(NteChassisPhAssoc nteChassisPhAssoc) {
		getNteChassisPhAssocs().remove(nteChassisPhAssoc);
		nteChassisPhAssoc.setNetworkTerminatingEquipment(null);

		return nteChassisPhAssoc;
	}

	public List<NteCsCondSplicing> getNteCsCondSplicings() {
		return this.nteCsCondSplicings;
	}

	public void setNteCsCondSplicings(List<NteCsCondSplicing> nteCsCondSplicings) {
		this.nteCsCondSplicings = nteCsCondSplicings;
	}

	public NteCsCondSplicing addNteCsCondSplicing(NteCsCondSplicing nteCsCondSplicing) {
		getNteCsCondSplicings().add(nteCsCondSplicing);
		nteCsCondSplicing.setNetworkTerminatingEquipment(this);

		return nteCsCondSplicing;
	}

	public NteCsCondSplicing removeNteCsCondSplicing(NteCsCondSplicing nteCsCondSplicing) {
		getNteCsCondSplicings().remove(nteCsCondSplicing);
		nteCsCondSplicing.setNetworkTerminatingEquipment(null);

		return nteCsCondSplicing;
	}

	public List<NteCsPortTerm> getNteCsPortTerms() {
		return this.nteCsPortTerms;
	}

	public void setNteCsPortTerms(List<NteCsPortTerm> nteCsPortTerms) {
		this.nteCsPortTerms = nteCsPortTerms;
	}

	public NteCsPortTerm addNteCsPortTerm(NteCsPortTerm nteCsPortTerm) {
		getNteCsPortTerms().add(nteCsPortTerm);
		nteCsPortTerm.setNetworkTerminatingEquipment(this);

		return nteCsPortTerm;
	}

	public NteCsPortTerm removeNteCsPortTerm(NteCsPortTerm nteCsPortTerm) {
		getNteCsPortTerms().remove(nteCsPortTerm);
		nteCsPortTerm.setNetworkTerminatingEquipment(null);

		return nteCsPortTerm;
	}

	public List<NteHierarchy> getNteHierarchies() {
		return this.nteHierarchies;
	}

	public void setNteHierarchies(List<NteHierarchy> nteHierarchies) {
		this.nteHierarchies = nteHierarchies;
	}

	public NteHierarchy addNteHierarchy(NteHierarchy nteHierarchy) {
		getNteHierarchies().add(nteHierarchy);
		nteHierarchy.setNetworkTerminatingEquipment(this);

		return nteHierarchy;
	}

	public NteHierarchy removeNteHierarchy(NteHierarchy nteHierarchy) {
		getNteHierarchies().remove(nteHierarchy);
		nteHierarchy.setNetworkTerminatingEquipment(null);

		return nteHierarchy;
	}

	public List<NtePhPluginAssoc> getNtePhPluginAssocs() {
		return this.ntePhPluginAssocs;
	}

	public void setNtePhPluginAssocs(List<NtePhPluginAssoc> ntePhPluginAssocs) {
		this.ntePhPluginAssocs = ntePhPluginAssocs;
	}

	public NtePhPluginAssoc addNtePhPluginAssoc(NtePhPluginAssoc ntePhPluginAssoc) {
		getNtePhPluginAssocs().add(ntePhPluginAssoc);
		ntePhPluginAssoc.setNetworkTerminatingEquipment(this);

		return ntePhPluginAssoc;
	}

	public NtePhPluginAssoc removeNtePhPluginAssoc(NtePhPluginAssoc ntePhPluginAssoc) {
		getNtePhPluginAssocs().remove(ntePhPluginAssoc);
		ntePhPluginAssoc.setNetworkTerminatingEquipment(null);

		return ntePhPluginAssoc;
	}

	public List<NtePluginPortAssoc> getNtePluginPortAssocs() {
		return this.ntePluginPortAssocs;
	}

	public void setNtePluginPortAssocs(List<NtePluginPortAssoc> ntePluginPortAssocs) {
		this.ntePluginPortAssocs = ntePluginPortAssocs;
	}

	public NtePluginPortAssoc addNtePluginPortAssoc(NtePluginPortAssoc ntePluginPortAssoc) {
		getNtePluginPortAssocs().add(ntePluginPortAssoc);
		ntePluginPortAssoc.setNetworkTerminatingEquipment(this);

		return ntePluginPortAssoc;
	}

	public NtePluginPortAssoc removeNtePluginPortAssoc(NtePluginPortAssoc ntePluginPortAssoc) {
		getNtePluginPortAssocs().remove(ntePluginPortAssoc);
		ntePluginPortAssoc.setNetworkTerminatingEquipment(null);

		return ntePluginPortAssoc;
	}

	public List<NtePort> getNtePorts() {
		return this.ntePorts;
	}

	public void setNtePorts(List<NtePort> ntePorts) {
		this.ntePorts = ntePorts;
	}

	public NtePort addNtePort(NtePort ntePort) {
		getNtePorts().add(ntePort);
		ntePort.setNetworkTerminatingEquipment(this);

		return ntePort;
	}

	public NtePort removeNtePort(NtePort ntePort) {
		getNtePorts().remove(ntePort);
		ntePort.setNetworkTerminatingEquipment(null);

		return ntePort;
	}

	public List<NtePortChar> getNtePortChars() {
		return this.ntePortChars;
	}

	public void setNtePortChars(List<NtePortChar> ntePortChars) {
		this.ntePortChars = ntePortChars;
	}

	public NtePortChar addNtePortChar(NtePortChar ntePortChar) {
		getNtePortChars().add(ntePortChar);
		ntePortChar.setNetworkTerminatingEquipment(this);

		return ntePortChar;
	}

	public NtePortChar removeNtePortChar(NtePortChar ntePortChar) {
		getNtePortChars().remove(ntePortChar);
		ntePortChar.setNetworkTerminatingEquipment(null);

		return ntePortChar;
	}

	public List<NtePortPortAssoc> getNtePortPortAssocs() {
		return this.ntePortPortAssocs;
	}

	public void setNtePortPortAssocs(List<NtePortPortAssoc> ntePortPortAssocs) {
		this.ntePortPortAssocs = ntePortPortAssocs;
	}

	public NtePortPortAssoc addNtePortPortAssoc(NtePortPortAssoc ntePortPortAssoc) {
		getNtePortPortAssocs().add(ntePortPortAssoc);
		ntePortPortAssoc.setNetworkTerminatingEquipment(this);

		return ntePortPortAssoc;
	}

	public NtePortPortAssoc removeNtePortPortAssoc(NtePortPortAssoc ntePortPortAssoc) {
		getNtePortPortAssocs().remove(ntePortPortAssoc);
		ntePortPortAssoc.setNetworkTerminatingEquipment(null);

		return ntePortPortAssoc;
	}

	public List<NteStructureAssoc> getNteStructureAssocs() {
		return this.nteStructureAssocs;
	}

	public void setNteStructureAssocs(List<NteStructureAssoc> nteStructureAssocs) {
		this.nteStructureAssocs = nteStructureAssocs;
	}

	public NteStructureAssoc addNteStructureAssoc(NteStructureAssoc nteStructureAssoc) {
		getNteStructureAssocs().add(nteStructureAssoc);
		nteStructureAssoc.setNetworkTerminatingEquipment(this);

		return nteStructureAssoc;
	}

	public NteStructureAssoc removeNteStructureAssoc(NteStructureAssoc nteStructureAssoc) {
		getNteStructureAssocs().remove(nteStructureAssoc);
		nteStructureAssoc.setNetworkTerminatingEquipment(null);

		return nteStructureAssoc;
	}

	public List<Plugin> getPlugins() {
		return this.plugins;
	}

	public void setPlugins(List<Plugin> plugins) {
		this.plugins = plugins;
	}

	public Plugin addPlugin(Plugin plugin) {
		getPlugins().add(plugin);
		plugin.setNetworkTerminatingEquipment(this);

		return plugin;
	}

	public Plugin removePlugin(Plugin plugin) {
		getPlugins().remove(plugin);
		plugin.setNetworkTerminatingEquipment(null);

		return plugin;
	}

	public List<PluginHolder> getPluginHolders() {
		return this.pluginHolders;
	}

	public void setPluginHolders(List<PluginHolder> pluginHolders) {
		this.pluginHolders = pluginHolders;
	}

	public PluginHolder addPluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().add(pluginHolder);
		pluginHolder.setNetworkTerminatingEquipment(this);

		return pluginHolder;
	}

	public PluginHolder removePluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().remove(pluginHolder);
		pluginHolder.setNetworkTerminatingEquipment(null);

		return pluginHolder;
	}

}