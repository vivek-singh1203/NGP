
package com.bt.ngp.common.data.jpa.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.bt.ngp.datasource.spec.CbSpec;
import com.bt.ngp.datasource.spec.CbSpecPK;

/**
 * Please write File comments here TODO
 *
 * @since 15 Jan 2018
 * @author Mahesh 611174701
 */

public interface CbSpecRepository extends JpaRepository<CbSpec, CbSpecPK> {
	public Optional<CbSpec> findByCbSpecPKIdName(@Param("name") String name);
}
