package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the WE_PH_PLUGIN_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="WE_PH_PLUGIN_ASSOC")
@NamedQuery(name="WePhPluginAssoc.findAll", query="SELECT w FROM WePhPluginAssoc w")
public class WePhPluginAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="HOLDER_COMP_ASSOC_SPEC_ID", length=50)
	private String holderCompAssocSpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to WeHierarchy
	@OneToMany(mappedBy="wePhPluginAssoc")
	private List<WeHierarchy> weHierarchies;

	//bi-directional many-to-one association to PluginHolder
	@ManyToOne
	@JoinColumn(name="PH_NAME")
	private PluginHolder pluginHolder;

	//bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	//bi-directional many-to-one association to WirelessEquipment
	@ManyToOne
	@JoinColumn(name="WEQ_NAME")
	private WirelessEquipment wirelessEquipment;

	public WePhPluginAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getHolderCompAssocSpecId() {
		return this.holderCompAssocSpecId;
	}

	public void setHolderCompAssocSpecId(String holderCompAssocSpecId) {
		this.holderCompAssocSpecId = holderCompAssocSpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public List<WeHierarchy> getWeHierarchies() {
		return this.weHierarchies;
	}

	public void setWeHierarchies(List<WeHierarchy> weHierarchies) {
		this.weHierarchies = weHierarchies;
	}

	public WeHierarchy addWeHierarchy(WeHierarchy weHierarchy) {
		getWeHierarchies().add(weHierarchy);
		weHierarchy.setWePhPluginAssoc(this);

		return weHierarchy;
	}

	public WeHierarchy removeWeHierarchy(WeHierarchy weHierarchy) {
		getWeHierarchies().remove(weHierarchy);
		weHierarchy.setWePhPluginAssoc(null);

		return weHierarchy;
	}

	public PluginHolder getPluginHolder() {
		return this.pluginHolder;
	}

	public void setPluginHolder(PluginHolder pluginHolder) {
		this.pluginHolder = pluginHolder;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

	public WirelessEquipment getWirelessEquipment() {
		return this.wirelessEquipment;
	}

	public void setWirelessEquipment(WirelessEquipment wirelessEquipment) {
		this.wirelessEquipment = wirelessEquipment;
	}

}