package com.bt.ngp.common.data.jpa.repository;

import com.bt.ngp.datasource.entities.BlockHolder;

public interface BlockHolderRepository extends CommonOperation<BlockHolder>{

}

