package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the WE_CS_COND_SPLICING database table.
 * 
 */
@javax.persistence.Entity
@Table(name="WE_CS_COND_SPLICING")
@NamedQuery(name="WeCsCondSplicing.findAll", query="SELECT w FROM WeCsCondSplicing w")
public class WeCsCondSplicing implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SeqGen")
    @SequenceGenerator(name = "SeqGen", sequenceName = "WE_CS_COND_SPLICING_SEQ", allocationSize = 1)
	private long id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="ORIG_COND_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal origCondSeqNum;

	@Column(name="SPLICING_RESOURCE", nullable=false, length=20)
	private String splicingResource;

	@Column(name="SPLICING_STATE", length=20)
	private String splicingState;

	@Column(name="TERM_COND_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal termCondSeqNum;

	//bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_CB_NAME")
	private ConductorBundle origCbName;

	//bi-directional many-to-one association to Conductor
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_CONDUCTOR_NAME")
	private Conductor origConductorName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_CS_NAME")
	private CableSection origCsName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_PAR_CS_NAME")
	private CableSection origParCsName;

	//bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_CB_NAME")
	private ConductorBundle termCbName;

	//bi-directional many-to-one association to Conductor
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_CONDUCTOR_NAME")
	private Conductor termConductorName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_CS_NAME")
	private CableSection termCsName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="TERM_PAR_CS_NAME")
	private CableSection termParCsName;

	//bi-directional many-to-one association to WirelessEquipment
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="WEQ_NAME")
	private WirelessEquipment wirelessEquipment;
	
	public WeCsCondSplicing() {
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the dataQualityIndicator
	 */
	public String getDataQualityIndicator() {
		return dataQualityIndicator;
	}

	/**
	 * @param dataQualityIndicator the dataQualityIndicator to set
	 */
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	/**
	 * @param lastModifiedBy the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	/**
	 * @return the lastModifiedDate
	 */
	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * @param lastModifiedDate the lastModifiedDate to set
	 */
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/**
	 * @return the origCondSeqNum
	 */
	public BigDecimal getOrigCondSeqNum() {
		return origCondSeqNum;
	}

	/**
	 * @param origCondSeqNum the origCondSeqNum to set
	 */
	public void setOrigCondSeqNum(BigDecimal origCondSeqNum) {
		this.origCondSeqNum = origCondSeqNum;
	}

	/**
	 * @return the splicingResource
	 */
	public String getSplicingResource() {
		return splicingResource;
	}

	/**
	 * @param splicingResource the splicingResource to set
	 */
	public void setSplicingResource(String splicingResource) {
		this.splicingResource = splicingResource;
	}

	/**
	 * @return the splicingState
	 */
	public String getSplicingState() {
		return splicingState;
	}

	/**
	 * @param splicingState the splicingState to set
	 */
	public void setSplicingState(String splicingState) {
		this.splicingState = splicingState;
	}

	/**
	 * @return the termCondSeqNum
	 */
	public BigDecimal getTermCondSeqNum() {
		return termCondSeqNum;
	}

	/**
	 * @param termCondSeqNum the termCondSeqNum to set
	 */
	public void setTermCondSeqNum(BigDecimal termCondSeqNum) {
		this.termCondSeqNum = termCondSeqNum;
	}

	/**
	 * @return the origCbName
	 */
	public ConductorBundle getOrigCbName() {
		return origCbName;
	}

	/**
	 * @param origCbName the origCbName to set
	 */
	public void setOrigCbName(ConductorBundle origCbName) {
		this.origCbName = origCbName;
	}

	/**
	 * @return the origConductorName
	 */
	public Conductor getOrigConductorName() {
		return origConductorName;
	}

	/**
	 * @param origConductorName the origConductorName to set
	 */
	public void setOrigConductorName(Conductor origConductorName) {
		this.origConductorName = origConductorName;
	}

	/**
	 * @return the origCsName
	 */
	public CableSection getOrigCsName() {
		return origCsName;
	}

	/**
	 * @param origCsName the origCsName to set
	 */
	public void setOrigCsName(CableSection origCsName) {
		this.origCsName = origCsName;
	}

	/**
	 * @return the origParCsName
	 */
	public CableSection getOrigParCsName() {
		return origParCsName;
	}

	/**
	 * @param origParCsName the origParCsName to set
	 */
	public void setOrigParCsName(CableSection origParCsName) {
		this.origParCsName = origParCsName;
	}

	/**
	 * @return the termCbName
	 */
	public ConductorBundle getTermCbName() {
		return termCbName;
	}

	/**
	 * @param termCbName the termCbName to set
	 */
	public void setTermCbName(ConductorBundle termCbName) {
		this.termCbName = termCbName;
	}

	/**
	 * @return the termConductorName
	 */
	public Conductor getTermConductorName() {
		return termConductorName;
	}

	/**
	 * @param termConductorName the termConductorName to set
	 */
	public void setTermConductorName(Conductor termConductorName) {
		this.termConductorName = termConductorName;
	}

	/**
	 * @return the termCsName
	 */
	public CableSection getTermCsName() {
		return termCsName;
	}

	/**
	 * @param termCsName the termCsName to set
	 */
	public void setTermCsName(CableSection termCsName) {
		this.termCsName = termCsName;
	}

	/**
	 * @return the termParCsName
	 */
	public CableSection getTermParCsName() {
		return termParCsName;
	}

	/**
	 * @param termParCsName the termParCsName to set
	 */
	public void setTermParCsName(CableSection termParCsName) {
		this.termParCsName = termParCsName;
	}

	/**
	 * @return the wirelessEquipment
	 */
	public WirelessEquipment getWirelessEquipment() {
		return wirelessEquipment;
	}

	/**
	 * @param wirelessEquipment the wirelessEquipment to set
	 */
	public void setWirelessEquipment(WirelessEquipment wirelessEquipment) {
		this.wirelessEquipment = wirelessEquipment;
	}
	
}