package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.CcpCsPortTerm;
import com.bt.ngp.datasource.entities.CcpPort;
import com.bt.ngp.datasource.entities.Chassi;
import com.bt.ngp.datasource.entities.Conductor;
import com.bt.ngp.datasource.entities.ConductorBundle;
import com.bt.ngp.datasource.entities.CrossConnectPoint;
import com.bt.ngp.datasource.entities.Plugin;

@Repository
public interface CcpCsPortTermRepository extends SqlRepository<CcpCsPortTerm> {

	public CcpCsPortTerm findByCrossConnectPointAndChassiAndPluginAndCcpPortAndCableSectionAndConductorBundleAndConductor(
			CrossConnectPoint crossConnectPoint, Chassi chassi, Plugin plugin, CcpPort ccpPort,
			CableSection cableSection, ConductorBundle conductorBundle, Conductor conductor);

	@Query(name = "CcpCsPortTermRepository.findCcpCsPortTerm", nativeQuery = true)
	List<CcpCsPortTerm> findCcpCsPortTerm(@Param("termObj") CcpCsPortTerm termObj);

	@Query(name = "CcpCsPortTermRepository.fetchViaCcpCsCbCond", nativeQuery = true)
	public CcpCsPortTerm fetchCcpCsPortTerm(@Param("ccpCsPortTerm") CcpCsPortTerm ccpCsPortTerm);

	List<CcpCsPortTerm> findByCrossConnectPoint(@Param("crossConnectPoint") CrossConnectPoint crossConnectPoint);

	@Query(name = "CcpCsPortTermRepository.findByConductorAndTerminationType")
	List<CcpCsPortTerm> findByConductorAndTerminationType(@Param("ccpCsPortTermObj") CcpCsPortTerm jcCsPortTermTermObj);

	@Query(name = "CcpCsPortTermRepository.findByCableSectionAndPort")
	List<CcpCsPortTerm> findByCableSectionAndPort(@Param("ccpCsPortTermObj") CcpCsPortTerm ccpCsPortTermTermObj);

	@Query(name = "CcpCsPortTermRepository.findByCcpCableAndConductor")
	List<CcpCsPortTerm> findByCcpCableAndConductor(@Param("ccpCsPortTerm") CcpCsPortTerm ccpCsPortTerm);
}
