package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.vividsolutions.jts.geom.Point;


/**
 * The persistent class for the DSLAM database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DSLAM")
@NamedQuery(name="Dslam.findAll", query="SELECT d FROM Dslam d")
public class Dslam implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="DESG_NAME", length=30)
	private String desgName;

	@Column(name="DESG_NUM", precision=38)
	private String desgNum;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(name="FIELD_LABEL", length=30)
	private String fieldLabel;

	@Column(name = "GEO_POSITION", columnDefinition = "geometry(Point,3857)")
	private Point geoPosition;

	public Point getGeoPosition() {
		return geoPosition;
	}

	public void setGeoPosition(Point geoPosition) {
		this.geoPosition = geoPosition;
	}

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	@Column(name="XX_DDD", length=25)
	private String xx_ddd;

	//bi-directional many-to-one association to AuxComponent
	@OneToMany(mappedBy="dslam")
	private List<AuxComponent> auxComponents;

	//bi-directional many-to-one association to Card
	@OneToMany(mappedBy="dslam")
	private List<Card> cards;

	//bi-directional many-to-one association to CardHolder
	@OneToMany(mappedBy="dslam")
	private List<CardHolder> cardHolders;

	//bi-directional many-to-one association to Connector
	@OneToMany(mappedBy="dslam")
	private List<Connector> connectors;

	//bi-directional many-to-one association to Exchange
	@ManyToOne
	@JoinColumn(name="EXCHANGE_1141_CODE")
	private Exchange exchange;

	//bi-directional many-to-one association to Store
	@ManyToOne
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to DslamCardPortAssoc
	@OneToMany(mappedBy="dslam")
	private List<DslamCardPortAssoc> dslamCardPortAssocs;

	//bi-directional many-to-one association to DslamChar
	@OneToMany(mappedBy="dslam")
	private List<DslamChar> dslamChars;

	//bi-directional many-to-one association to DslamChCardAssoc
	@OneToMany(mappedBy="dslam")
	private List<DslamChCardAssoc> dslamChCardAssocs;

	//bi-directional many-to-one association to DslamCsCondSplicing
	@OneToMany(mappedBy="dslam")
	private List<DslamCsCondSplicing> dslamCsCondSplicings;

	//bi-directional many-to-one association to DslamCsPortTerm
	@OneToMany(mappedBy="dslam")
	private List<DslamCsPortTerm> dslamCsPortTerms;

	//bi-directional many-to-one association to DslamHierarchy
	@OneToMany(mappedBy="dslam")
	private List<DslamHierarchy> dslamHierarchies;

	//bi-directional many-to-one association to DslamPort
	@OneToMany(mappedBy="dslam")
	private List<DslamPort> dslamPorts;

	//bi-directional many-to-one association to DslamPortChar
	@OneToMany(mappedBy="dslam")
	private List<DslamPortChar> dslamPortChars;

	//bi-directional many-to-one association to DslamPortPortAssoc
	@OneToMany(mappedBy="dslam")
	private List<DslamPortPortAssoc> dslamPortPortAssocs;

	//bi-directional many-to-one association to DslamRackChAssoc
	@OneToMany(mappedBy="dslam")
	private List<DslamRackChAssoc> dslamRackChAssocs;

	//bi-directional many-to-one association to DslamStructureAssoc
	@OneToMany(mappedBy="dslam")
	private List<DslamStructureAssoc> dslamStructureAssocs;

	//bi-directional many-to-one association to Rack
	@OneToMany(mappedBy="dslam")
	private List<Rack> racks;

	public Dslam() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getDesgName() {
		return this.desgName;
	}

	public void setDesgName(String desgName) {
		this.desgName = desgName;
	}

	public String getDesgNum() {
		return this.desgNum;
	}

	public void setDesgNum(String desgNum) {
		this.desgNum = desgNum;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getFieldLabel() {
		return this.fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public String getXx_ddd() {
		return this.xx_ddd;
	}

	public void setXx_ddd(String xx_ddd) {
		this.xx_ddd = xx_ddd;
	}

	public List<AuxComponent> getAuxComponents() {
		return this.auxComponents;
	}

	public void setAuxComponents(List<AuxComponent> auxComponents) {
		this.auxComponents = auxComponents;
	}

	public AuxComponent addAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().add(auxComponent);
		auxComponent.setDslam(this);

		return auxComponent;
	}

	public AuxComponent removeAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().remove(auxComponent);
		auxComponent.setDslam(null);

		return auxComponent;
	}

	public List<Card> getCards() {
		return this.cards;
	}

	public void setCards(List<Card> cards) {
		this.cards = cards;
	}

	public Card addCard(Card card) {
		getCards().add(card);
		card.setDslam(this);

		return card;
	}

	public Card removeCard(Card card) {
		getCards().remove(card);
		card.setDslam(null);

		return card;
	}

	public List<CardHolder> getCardHolders() {
		return this.cardHolders;
	}

	public void setCardHolders(List<CardHolder> cardHolders) {
		this.cardHolders = cardHolders;
	}

	public CardHolder addCardHolder(CardHolder cardHolder) {
		getCardHolders().add(cardHolder);
		cardHolder.setDslam(this);

		return cardHolder;
	}

	public CardHolder removeCardHolder(CardHolder cardHolder) {
		getCardHolders().remove(cardHolder);
		cardHolder.setDslam(null);

		return cardHolder;
	}

	public List<Connector> getConnectors() {
		return this.connectors;
	}

	public void setConnectors(List<Connector> connectors) {
		this.connectors = connectors;
	}

	public Connector addConnector(Connector connector) {
		getConnectors().add(connector);
		connector.setDslam(this);

		return connector;
	}

	public Connector removeConnector(Connector connector) {
		getConnectors().remove(connector);
		connector.setDslam(null);

		return connector;
	}

	public Exchange getExchange() {
		return this.exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public List<DslamCardPortAssoc> getDslamCardPortAssocs() {
		return this.dslamCardPortAssocs;
	}

	public void setDslamCardPortAssocs(List<DslamCardPortAssoc> dslamCardPortAssocs) {
		this.dslamCardPortAssocs = dslamCardPortAssocs;
	}

	public DslamCardPortAssoc addDslamCardPortAssoc(DslamCardPortAssoc dslamCardPortAssoc) {
		getDslamCardPortAssocs().add(dslamCardPortAssoc);
		dslamCardPortAssoc.setDslam(this);

		return dslamCardPortAssoc;
	}

	public DslamCardPortAssoc removeDslamCardPortAssoc(DslamCardPortAssoc dslamCardPortAssoc) {
		getDslamCardPortAssocs().remove(dslamCardPortAssoc);
		dslamCardPortAssoc.setDslam(null);

		return dslamCardPortAssoc;
	}

	public List<DslamChar> getDslamChars() {
		return this.dslamChars;
	}

	public void setDslamChars(List<DslamChar> dslamChars) {
		this.dslamChars = dslamChars;
	}

	public DslamChar addDslamChar(DslamChar dslamChar) {
		getDslamChars().add(dslamChar);
		dslamChar.setDslam(this);

		return dslamChar;
	}

	public DslamChar removeDslamChar(DslamChar dslamChar) {
		getDslamChars().remove(dslamChar);
		dslamChar.setDslam(null);

		return dslamChar;
	}

	public List<DslamChCardAssoc> getDslamChCardAssocs() {
		return this.dslamChCardAssocs;
	}

	public void setDslamChCardAssocs(List<DslamChCardAssoc> dslamChCardAssocs) {
		this.dslamChCardAssocs = dslamChCardAssocs;
	}

	public DslamChCardAssoc addDslamChCardAssoc(DslamChCardAssoc dslamChCardAssoc) {
		getDslamChCardAssocs().add(dslamChCardAssoc);
		dslamChCardAssoc.setDslam(this);

		return dslamChCardAssoc;
	}

	public DslamChCardAssoc removeDslamChCardAssoc(DslamChCardAssoc dslamChCardAssoc) {
		getDslamChCardAssocs().remove(dslamChCardAssoc);
		dslamChCardAssoc.setDslam(null);

		return dslamChCardAssoc;
	}

	public List<DslamCsCondSplicing> getDslamCsCondSplicings() {
		return this.dslamCsCondSplicings;
	}

	public void setDslamCsCondSplicings(List<DslamCsCondSplicing> dslamCsCondSplicings) {
		this.dslamCsCondSplicings = dslamCsCondSplicings;
	}

	public DslamCsCondSplicing addDslamCsCondSplicing(DslamCsCondSplicing dslamCsCondSplicing) {
		getDslamCsCondSplicings().add(dslamCsCondSplicing);
		dslamCsCondSplicing.setDslam(this);

		return dslamCsCondSplicing;
	}

	public DslamCsCondSplicing removeDslamCsCondSplicing(DslamCsCondSplicing dslamCsCondSplicing) {
		getDslamCsCondSplicings().remove(dslamCsCondSplicing);
		dslamCsCondSplicing.setDslam(null);

		return dslamCsCondSplicing;
	}

	public List<DslamCsPortTerm> getDslamCsPortTerms() {
		return this.dslamCsPortTerms;
	}

	public void setDslamCsPortTerms(List<DslamCsPortTerm> dslamCsPortTerms) {
		this.dslamCsPortTerms = dslamCsPortTerms;
	}

	public DslamCsPortTerm addDslamCsPortTerm(DslamCsPortTerm dslamCsPortTerm) {
		getDslamCsPortTerms().add(dslamCsPortTerm);
		dslamCsPortTerm.setDslam(this);

		return dslamCsPortTerm;
	}

	public DslamCsPortTerm removeDslamCsPortTerm(DslamCsPortTerm dslamCsPortTerm) {
		getDslamCsPortTerms().remove(dslamCsPortTerm);
		dslamCsPortTerm.setDslam(null);

		return dslamCsPortTerm;
	}

	public List<DslamHierarchy> getDslamHierarchies() {
		return this.dslamHierarchies;
	}

	public void setDslamHierarchies(List<DslamHierarchy> dslamHierarchies) {
		this.dslamHierarchies = dslamHierarchies;
	}

	public DslamHierarchy addDslamHierarchy(DslamHierarchy dslamHierarchy) {
		getDslamHierarchies().add(dslamHierarchy);
		dslamHierarchy.setDslam(this);

		return dslamHierarchy;
	}

	public DslamHierarchy removeDslamHierarchy(DslamHierarchy dslamHierarchy) {
		getDslamHierarchies().remove(dslamHierarchy);
		dslamHierarchy.setDslam(null);

		return dslamHierarchy;
	}

	public List<DslamPort> getDslamPorts() {
		return this.dslamPorts;
	}

	public void setDslamPorts(List<DslamPort> dslamPorts) {
		this.dslamPorts = dslamPorts;
	}

	public DslamPort addDslamPort(DslamPort dslamPort) {
		getDslamPorts().add(dslamPort);
		dslamPort.setDslam(this);

		return dslamPort;
	}

	public DslamPort removeDslamPort(DslamPort dslamPort) {
		getDslamPorts().remove(dslamPort);
		dslamPort.setDslam(null);

		return dslamPort;
	}

	public List<DslamPortChar> getDslamPortChars() {
		return this.dslamPortChars;
	}

	public void setDslamPortChars(List<DslamPortChar> dslamPortChars) {
		this.dslamPortChars = dslamPortChars;
	}

	public DslamPortChar addDslamPortChar(DslamPortChar dslamPortChar) {
		getDslamPortChars().add(dslamPortChar);
		dslamPortChar.setDslam(this);

		return dslamPortChar;
	}

	public DslamPortChar removeDslamPortChar(DslamPortChar dslamPortChar) {
		getDslamPortChars().remove(dslamPortChar);
		dslamPortChar.setDslam(null);

		return dslamPortChar;
	}

	public List<DslamPortPortAssoc> getDslamPortPortAssocs() {
		return this.dslamPortPortAssocs;
	}

	public void setDslamPortPortAssocs(List<DslamPortPortAssoc> dslamPortPortAssocs) {
		this.dslamPortPortAssocs = dslamPortPortAssocs;
	}

	public DslamPortPortAssoc addDslamPortPortAssoc(DslamPortPortAssoc dslamPortPortAssoc) {
		getDslamPortPortAssocs().add(dslamPortPortAssoc);
		dslamPortPortAssoc.setDslam(this);

		return dslamPortPortAssoc;
	}

	public DslamPortPortAssoc removeDslamPortPortAssoc(DslamPortPortAssoc dslamPortPortAssoc) {
		getDslamPortPortAssocs().remove(dslamPortPortAssoc);
		dslamPortPortAssoc.setDslam(null);

		return dslamPortPortAssoc;
	}

	public List<DslamRackChAssoc> getDslamRackChAssocs() {
		return this.dslamRackChAssocs;
	}

	public void setDslamRackChAssocs(List<DslamRackChAssoc> dslamRackChAssocs) {
		this.dslamRackChAssocs = dslamRackChAssocs;
	}

	public DslamRackChAssoc addDslamRackChAssoc(DslamRackChAssoc dslamRackChAssoc) {
		getDslamRackChAssocs().add(dslamRackChAssoc);
		dslamRackChAssoc.setDslam(this);

		return dslamRackChAssoc;
	}

	public DslamRackChAssoc removeDslamRackChAssoc(DslamRackChAssoc dslamRackChAssoc) {
		getDslamRackChAssocs().remove(dslamRackChAssoc);
		dslamRackChAssoc.setDslam(null);

		return dslamRackChAssoc;
	}

	public List<DslamStructureAssoc> getDslamStructureAssocs() {
		return this.dslamStructureAssocs;
	}

	public void setDslamStructureAssocs(List<DslamStructureAssoc> dslamStructureAssocs) {
		this.dslamStructureAssocs = dslamStructureAssocs;
	}

	public DslamStructureAssoc addDslamStructureAssoc(DslamStructureAssoc dslamStructureAssoc) {
		getDslamStructureAssocs().add(dslamStructureAssoc);
		dslamStructureAssoc.setDslam(this);

		return dslamStructureAssoc;
	}

	public DslamStructureAssoc removeDslamStructureAssoc(DslamStructureAssoc dslamStructureAssoc) {
		getDslamStructureAssocs().remove(dslamStructureAssoc);
		dslamStructureAssoc.setDslam(null);

		return dslamStructureAssoc;
	}

	public List<Rack> getRacks() {
		return this.racks;
	}

	public void setRacks(List<Rack> racks) {
		this.racks = racks;
	}

	public Rack addRack(Rack rack) {
		getRacks().add(rack);
		rack.setDslam(this);

		return rack;
	}

	public Rack removeRack(Rack rack) {
		getRacks().remove(rack);
		rack.setDslam(null);

		return rack;
	}

}