package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the DEVICE_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DEVICE_SPEC")
@NamedQuery(name="DeviceSpec.findAll", query="SELECT d FROM DeviceSpec d")
public class DeviceSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private DeviceSpecPK deviceSpecPKId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="\"DEPTH\"", precision=126)
	private double depth;

	@Column(name="DEPTH_UNIT", length=10)
	private String depthUnit;

	@Column(precision=126)
	private double diameter;

	@Column(name="DIAMETER_UNIT", length=10)
	private String diameterUnit;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(precision=126)
	private double height;

	@Column(name="HEIGHT_UNIT", length=10)
	private String heightUnit;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="IS_ORDERABLE")
	private BigDecimal isOrderable;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="\"LENGTH\"", precision=126)
	private double length;

	@Column(name="LENGTH_UNIT", length=10)
	private String lengthUnit;

	@Column(name="MANUFACTURER_NAME", length=30)
	private String manufacturerName;

	@Column(name="MATERIAL_COST_PER_UNIT", precision=126)
	private double materialCostPerUnit;

	@Column(name="MATERIAL_COST_UNIT", length=10)
	private String materialCostUnit;

	@Column(name="MATERIAL_TYPE", length=10)
	private String materialType;

	@Column(name="NO_OF_POSITIONS", precision=38)
	private BigDecimal noOfPositions;

	@Column(name="POWER_CONSUMPTION", precision=126)
	private double powerConsumption;

	@Column(name="POWER_CONSUMPTION_UNIT", length=10)
	private String powerConsumptionUnit;

	@Column(name="POWER_DISSIPATION", precision=126)
	private double powerDissipation;

	@Column(name="POWER_DISSIPATION_UNIT", length=10)
	private String powerDissipationUnit;

	@Column(name="POWER_RATING", precision=126)
	private double powerRating;

	@Column(name="POWER_RATING_UNIT", length=10)
	private String powerRatingUnit;

	@Column(name="POWER_SUPPLY", length=10)
	private String powerSupply;

	@Column(name="SPEC_REMARKS", length=50)
	private String specRemarks;

	@Column(name="SPEC_STATUS", nullable=false, length=10)
	private String specStatus;

	@Column(name="SPLIT_RATIO", length=10)
	private String splitRatio;

	@Column(name="START_POSITION_NUM", precision=38)
	private BigDecimal startPositionNum;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	@Column(precision=126)
	private double volume;

	@Column(name="VOLUME_UNIT", length=10)
	private String volumeUnit;

	@Column(precision=126)
	private double weight;

	@Column(name="WEIGHT_UNIT", length=10)
	private String weightUnit;

	@Column(precision=126)
	private double width;

	@Column(name="WIDTH_UNIT", length=10)
	private String widthUnit;

	//bi-directional many-to-one association to DeviceCableCompatSpec
	@OneToMany(mappedBy="deviceSpec")
	private List<DeviceCableCompatSpec> deviceCableCompatSpecs;

	//bi-directional many-to-one association to DeviceCompHolderAssocSpec
	@OneToMany(mappedBy="deviceSpec")
	private List<DeviceCompHolderAssocSpec> deviceCompHolderAssocSpecs;

	//bi-directional many-to-one association to DeviceCompPortAssocSpec
	@OneToMany(mappedBy="deviceSpec")
	private List<DeviceCompPortAssocSpec> deviceCompPortAssocSpecs;

	//bi-directional many-to-one association to DeviceHierarchySpec
	@OneToMany(mappedBy="deviceSpec")
	private List<DeviceHierarchySpec> deviceHierarchySpecs;

	//bi-directional many-to-one association to DeviceHolderCompAssocSpec
	@OneToMany(mappedBy="deviceSpec")
	private List<DeviceHolderCompAssocSpec> deviceHolderCompAssocSpecs;

	//bi-directional many-to-one association to DevicePortPortAssocSpec
	@OneToMany(mappedBy="deviceSpec")
	private List<DevicePortPortAssocSpec> devicePortPortAssocSpecs;

	//bi-directional many-to-one association to DeviceCapacitySpec
	@ManyToOne
	@JoinColumn(name="CAPACITY_SPEC_NAME", nullable=false)
	private DeviceCapacitySpec deviceCapacitySpec;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME", nullable=false)
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to DeviceSpecCharSpec
	@OneToMany(mappedBy="deviceSpec")
	private List<DeviceSpecCharSpec> deviceSpecCharSpecs;

	//bi-directional many-to-one association to DeviceSpecCharSpecRel
	@OneToMany(mappedBy="deviceSpec")
	private List<DeviceSpecCharSpecRel> deviceSpecCharSpecRels;

	//bi-directional many-to-one association to DeviceSpecCharValueSpec
	@OneToMany(mappedBy="deviceSpec")
	private List<DeviceSpecCharValueSpec> deviceSpecCharValueSpecs;

	//bi-directional many-to-one association to DeviceSpecRoleSpec
	@OneToMany(mappedBy="deviceSpec")
	private List<DeviceSpecRoleSpec> deviceSpecRoleSpecs;

	public DeviceSpec() {
	}

	public DeviceSpecPK getDeviceSpecPKId() {
		return this.deviceSpecPKId;
	}

	public void setId(DeviceSpecPK deviceSpecPKId) {
		this.deviceSpecPKId = deviceSpecPKId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public double getDepth() {
		return this.depth;
	}

	public void setDepth(double depth) {
		this.depth = depth;
	}

	public String getDepthUnit() {
		return this.depthUnit;
	}

	public void setDepthUnit(String depthUnit) {
		this.depthUnit = depthUnit;
	}

	public double getDiameter() {
		return this.diameter;
	}

	public void setDiameter(double diameter) {
		this.diameter = diameter;
	}

	public String getDiameterUnit() {
		return this.diameterUnit;
	}

	public void setDiameterUnit(String diameterUnit) {
		this.diameterUnit = diameterUnit;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public double getHeight() {
		return this.height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public String getHeightUnit() {
		return this.heightUnit;
	}

	public void setHeightUnit(String heightUnit) {
		this.heightUnit = heightUnit;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public BigDecimal getIsOrderable() {
		return this.isOrderable;
	}

	public void setIsOrderable(BigDecimal isOrderable) {
		this.isOrderable = isOrderable;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public double getLength() {
		return this.length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public String getLengthUnit() {
		return this.lengthUnit;
	}

	public void setLengthUnit(String lengthUnit) {
		this.lengthUnit = lengthUnit;
	}

	public String getManufacturerName() {
		return this.manufacturerName;
	}

	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}

	public double getMaterialCostPerUnit() {
		return this.materialCostPerUnit;
	}

	public void setMaterialCostPerUnit(double materialCostPerUnit) {
		this.materialCostPerUnit = materialCostPerUnit;
	}

	public String getMaterialCostUnit() {
		return this.materialCostUnit;
	}

	public void setMaterialCostUnit(String materialCostUnit) {
		this.materialCostUnit = materialCostUnit;
	}

	public String getMaterialType() {
		return this.materialType;
	}

	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}

	public BigDecimal getNoOfPositions() {
		return this.noOfPositions;
	}

	public void setNoOfPositions(BigDecimal noOfPositions) {
		this.noOfPositions = noOfPositions;
	}

	public double getPowerConsumption() {
		return this.powerConsumption;
	}

	public void setPowerConsumption(double powerConsumption) {
		this.powerConsumption = powerConsumption;
	}

	public String getPowerConsumptionUnit() {
		return this.powerConsumptionUnit;
	}

	public void setPowerConsumptionUnit(String powerConsumptionUnit) {
		this.powerConsumptionUnit = powerConsumptionUnit;
	}

	public double getPowerDissipation() {
		return this.powerDissipation;
	}

	public void setPowerDissipation(double powerDissipation) {
		this.powerDissipation = powerDissipation;
	}

	public String getPowerDissipationUnit() {
		return this.powerDissipationUnit;
	}

	public void setPowerDissipationUnit(String powerDissipationUnit) {
		this.powerDissipationUnit = powerDissipationUnit;
	}

	public double getPowerRating() {
		return this.powerRating;
	}

	public void setPowerRating(double powerRating) {
		this.powerRating = powerRating;
	}

	public String getPowerRatingUnit() {
		return this.powerRatingUnit;
	}

	public void setPowerRatingUnit(String powerRatingUnit) {
		this.powerRatingUnit = powerRatingUnit;
	}

	public String getPowerSupply() {
		return this.powerSupply;
	}

	public void setPowerSupply(String powerSupply) {
		this.powerSupply = powerSupply;
	}

	public String getSpecRemarks() {
		return this.specRemarks;
	}

	public void setSpecRemarks(String specRemarks) {
		this.specRemarks = specRemarks;
	}

	public String getSpecStatus() {
		return this.specStatus;
	}

	public void setSpecStatus(String specStatus) {
		this.specStatus = specStatus;
	}

	public String getSplitRatio() {
		return this.splitRatio;
	}

	public void setSplitRatio(String splitRatio) {
		this.splitRatio = splitRatio;
	}

	public BigDecimal getStartPositionNum() {
		return this.startPositionNum;
	}

	public void setStartPositionNum(BigDecimal startPositionNum) {
		this.startPositionNum = startPositionNum;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public double getVolume() {
		return this.volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public String getVolumeUnit() {
		return this.volumeUnit;
	}

	public void setVolumeUnit(String volumeUnit) {
		this.volumeUnit = volumeUnit;
	}

	public double getWeight() {
		return this.weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getWeightUnit() {
		return this.weightUnit;
	}

	public void setWeightUnit(String weightUnit) {
		this.weightUnit = weightUnit;
	}

	public double getWidth() {
		return this.width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public String getWidthUnit() {
		return this.widthUnit;
	}

	public void setWidthUnit(String widthUnit) {
		this.widthUnit = widthUnit;
	}

	public List<DeviceCableCompatSpec> getDeviceCableCompatSpecs() {
		return this.deviceCableCompatSpecs;
	}

	public void setDeviceCableCompatSpecs(List<DeviceCableCompatSpec> deviceCableCompatSpecs) {
		this.deviceCableCompatSpecs = deviceCableCompatSpecs;
	}

	public DeviceCableCompatSpec addDeviceCableCompatSpec(DeviceCableCompatSpec deviceCableCompatSpec) {
		getDeviceCableCompatSpecs().add(deviceCableCompatSpec);
		deviceCableCompatSpec.setDeviceSpec(this);

		return deviceCableCompatSpec;
	}

	public DeviceCableCompatSpec removeDeviceCableCompatSpec(DeviceCableCompatSpec deviceCableCompatSpec) {
		getDeviceCableCompatSpecs().remove(deviceCableCompatSpec);
		deviceCableCompatSpec.setDeviceSpec(null);

		return deviceCableCompatSpec;
	}

	public List<DeviceCompHolderAssocSpec> getDeviceCompHolderAssocSpecs() {
		return this.deviceCompHolderAssocSpecs;
	}

	public void setDeviceCompHolderAssocSpecs(List<DeviceCompHolderAssocSpec> deviceCompHolderAssocSpecs) {
		this.deviceCompHolderAssocSpecs = deviceCompHolderAssocSpecs;
	}

	public DeviceCompHolderAssocSpec addDeviceCompHolderAssocSpec(DeviceCompHolderAssocSpec deviceCompHolderAssocSpec) {
		getDeviceCompHolderAssocSpecs().add(deviceCompHolderAssocSpec);
		deviceCompHolderAssocSpec.setDeviceSpec(this);

		return deviceCompHolderAssocSpec;
	}

	public DeviceCompHolderAssocSpec removeDeviceCompHolderAssocSpec(DeviceCompHolderAssocSpec deviceCompHolderAssocSpec) {
		getDeviceCompHolderAssocSpecs().remove(deviceCompHolderAssocSpec);
		deviceCompHolderAssocSpec.setDeviceSpec(null);

		return deviceCompHolderAssocSpec;
	}

	public List<DeviceCompPortAssocSpec> getDeviceCompPortAssocSpecs() {
		return this.deviceCompPortAssocSpecs;
	}

	public void setDeviceCompPortAssocSpecs(List<DeviceCompPortAssocSpec> deviceCompPortAssocSpecs) {
		this.deviceCompPortAssocSpecs = deviceCompPortAssocSpecs;
	}

	public DeviceCompPortAssocSpec addDeviceCompPortAssocSpec(DeviceCompPortAssocSpec deviceCompPortAssocSpec) {
		getDeviceCompPortAssocSpecs().add(deviceCompPortAssocSpec);
		deviceCompPortAssocSpec.setDeviceSpec(this);

		return deviceCompPortAssocSpec;
	}

	public DeviceCompPortAssocSpec removeDeviceCompPortAssocSpec(DeviceCompPortAssocSpec deviceCompPortAssocSpec) {
		getDeviceCompPortAssocSpecs().remove(deviceCompPortAssocSpec);
		deviceCompPortAssocSpec.setDeviceSpec(null);

		return deviceCompPortAssocSpec;
	}

	public List<DeviceHierarchySpec> getDeviceHierarchySpecs() {
		return this.deviceHierarchySpecs;
	}

	public void setDeviceHierarchySpecs(List<DeviceHierarchySpec> deviceHierarchySpecs) {
		this.deviceHierarchySpecs = deviceHierarchySpecs;
	}

	public DeviceHierarchySpec addDeviceHierarchySpec(DeviceHierarchySpec deviceHierarchySpec) {
		getDeviceHierarchySpecs().add(deviceHierarchySpec);
		deviceHierarchySpec.setDeviceSpec(this);

		return deviceHierarchySpec;
	}

	public DeviceHierarchySpec removeDeviceHierarchySpec(DeviceHierarchySpec deviceHierarchySpec) {
		getDeviceHierarchySpecs().remove(deviceHierarchySpec);
		deviceHierarchySpec.setDeviceSpec(null);

		return deviceHierarchySpec;
	}

	public List<DeviceHolderCompAssocSpec> getDeviceHolderCompAssocSpecs() {
		return this.deviceHolderCompAssocSpecs;
	}

	public void setDeviceHolderCompAssocSpecs(List<DeviceHolderCompAssocSpec> deviceHolderCompAssocSpecs) {
		this.deviceHolderCompAssocSpecs = deviceHolderCompAssocSpecs;
	}

	public DeviceHolderCompAssocSpec addDeviceHolderCompAssocSpec(DeviceHolderCompAssocSpec deviceHolderCompAssocSpec) {
		getDeviceHolderCompAssocSpecs().add(deviceHolderCompAssocSpec);
		deviceHolderCompAssocSpec.setDeviceSpec(this);

		return deviceHolderCompAssocSpec;
	}

	public DeviceHolderCompAssocSpec removeDeviceHolderCompAssocSpec(DeviceHolderCompAssocSpec deviceHolderCompAssocSpec) {
		getDeviceHolderCompAssocSpecs().remove(deviceHolderCompAssocSpec);
		deviceHolderCompAssocSpec.setDeviceSpec(null);

		return deviceHolderCompAssocSpec;
	}

	public List<DevicePortPortAssocSpec> getDevicePortPortAssocSpecs() {
		return this.devicePortPortAssocSpecs;
	}

	public void setDevicePortPortAssocSpecs(List<DevicePortPortAssocSpec> devicePortPortAssocSpecs) {
		this.devicePortPortAssocSpecs = devicePortPortAssocSpecs;
	}

	public DevicePortPortAssocSpec addDevicePortPortAssocSpec(DevicePortPortAssocSpec devicePortPortAssocSpec) {
		getDevicePortPortAssocSpecs().add(devicePortPortAssocSpec);
		devicePortPortAssocSpec.setDeviceSpec(this);

		return devicePortPortAssocSpec;
	}

	public DevicePortPortAssocSpec removeDevicePortPortAssocSpec(DevicePortPortAssocSpec devicePortPortAssocSpec) {
		getDevicePortPortAssocSpecs().remove(devicePortPortAssocSpec);
		devicePortPortAssocSpec.setDeviceSpec(null);

		return devicePortPortAssocSpec;
	}

	public DeviceCapacitySpec getDeviceCapacitySpec() {
		return this.deviceCapacitySpec;
	}

	public void setDeviceCapacitySpec(DeviceCapacitySpec deviceCapacitySpec) {
		this.deviceCapacitySpec = deviceCapacitySpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public List<DeviceSpecCharSpec> getDeviceSpecCharSpecs() {
		return this.deviceSpecCharSpecs;
	}

	public void setDeviceSpecCharSpecs(List<DeviceSpecCharSpec> deviceSpecCharSpecs) {
		this.deviceSpecCharSpecs = deviceSpecCharSpecs;
	}

	public DeviceSpecCharSpec addDeviceSpecCharSpec(DeviceSpecCharSpec deviceSpecCharSpec) {
		getDeviceSpecCharSpecs().add(deviceSpecCharSpec);
		deviceSpecCharSpec.setDeviceSpec(this);

		return deviceSpecCharSpec;
	}

	public DeviceSpecCharSpec removeDeviceSpecCharSpec(DeviceSpecCharSpec deviceSpecCharSpec) {
		getDeviceSpecCharSpecs().remove(deviceSpecCharSpec);
		deviceSpecCharSpec.setDeviceSpec(null);

		return deviceSpecCharSpec;
	}

	public List<DeviceSpecCharSpecRel> getDeviceSpecCharSpecRels() {
		return this.deviceSpecCharSpecRels;
	}

	public void setDeviceSpecCharSpecRels(List<DeviceSpecCharSpecRel> deviceSpecCharSpecRels) {
		this.deviceSpecCharSpecRels = deviceSpecCharSpecRels;
	}

	public DeviceSpecCharSpecRel addDeviceSpecCharSpecRel(DeviceSpecCharSpecRel deviceSpecCharSpecRel) {
		getDeviceSpecCharSpecRels().add(deviceSpecCharSpecRel);
		deviceSpecCharSpecRel.setDeviceSpec(this);

		return deviceSpecCharSpecRel;
	}

	public DeviceSpecCharSpecRel removeDeviceSpecCharSpecRel(DeviceSpecCharSpecRel deviceSpecCharSpecRel) {
		getDeviceSpecCharSpecRels().remove(deviceSpecCharSpecRel);
		deviceSpecCharSpecRel.setDeviceSpec(null);

		return deviceSpecCharSpecRel;
	}

	public List<DeviceSpecCharValueSpec> getDeviceSpecCharValueSpecs() {
		return this.deviceSpecCharValueSpecs;
	}

	public void setDeviceSpecCharValueSpecs(List<DeviceSpecCharValueSpec> deviceSpecCharValueSpecs) {
		this.deviceSpecCharValueSpecs = deviceSpecCharValueSpecs;
	}

	public DeviceSpecCharValueSpec addDeviceSpecCharValueSpec(DeviceSpecCharValueSpec deviceSpecCharValueSpec) {
		getDeviceSpecCharValueSpecs().add(deviceSpecCharValueSpec);
		deviceSpecCharValueSpec.setDeviceSpec(this);

		return deviceSpecCharValueSpec;
	}

	public DeviceSpecCharValueSpec removeDeviceSpecCharValueSpec(DeviceSpecCharValueSpec deviceSpecCharValueSpec) {
		getDeviceSpecCharValueSpecs().remove(deviceSpecCharValueSpec);
		deviceSpecCharValueSpec.setDeviceSpec(null);

		return deviceSpecCharValueSpec;
	}

	public List<DeviceSpecRoleSpec> getDeviceSpecRoleSpecs() {
		return this.deviceSpecRoleSpecs;
	}

	public void setDeviceSpecRoleSpecs(List<DeviceSpecRoleSpec> deviceSpecRoleSpecs) {
		this.deviceSpecRoleSpecs = deviceSpecRoleSpecs;
	}

	public DeviceSpecRoleSpec addDeviceSpecRoleSpec(DeviceSpecRoleSpec deviceSpecRoleSpec) {
		getDeviceSpecRoleSpecs().add(deviceSpecRoleSpec);
		deviceSpecRoleSpec.setDeviceSpec(this);

		return deviceSpecRoleSpec;
	}

	public DeviceSpecRoleSpec removeDeviceSpecRoleSpec(DeviceSpecRoleSpec deviceSpecRoleSpec) {
		getDeviceSpecRoleSpecs().remove(deviceSpecRoleSpec);
		deviceSpecRoleSpec.setDeviceSpec(null);

		return deviceSpecRoleSpec;
	}

}