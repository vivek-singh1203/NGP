package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the CPE_PORTS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CPE_PORTS")
@NamedQuery(name="CpePort.findAll", query="SELECT c FROM CpePort c")
public class CpePort implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal portSeqNum;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to CpeCsPortTerm
	@OneToMany(mappedBy="cpePort")
	private List<CpeCsPortTerm> cpeCsPortTerms;

	//bi-directional many-to-one association to CpePluginPortAssoc
	@OneToMany(mappedBy="cpePort")
	private List<CpePluginPortAssoc> cpePluginPortAssocs;

	//bi-directional many-to-one association to CustomerPremiseEquipment
	@ManyToOne
	@JoinColumn(name="CPE_NAME")
	private CustomerPremiseEquipment customerPremiseEquipment;

	//bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	//bi-directional many-to-one association to CpePortChar
	@OneToMany(mappedBy="cpePort")
	private List<CpePortChar> cpePortChars;

	//bi-directional many-to-one association to CpePortPortAssoc
	@OneToMany(mappedBy="cpePort1")
	private List<CpePortPortAssoc> cpePortPortAssocs1;

	//bi-directional many-to-one association to CpePortPortAssoc
	@OneToMany(mappedBy="cpePort2")
	private List<CpePortPortAssoc> cpePortPortAssocs2;

	public CpePort() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortSeqNum() {
		return this.portSeqNum;
	}

	public void setPortSeqNum(BigDecimal portSeqNum) {
		this.portSeqNum = portSeqNum;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<CpeCsPortTerm> getCpeCsPortTerms() {
		return this.cpeCsPortTerms;
	}

	public void setCpeCsPortTerms(List<CpeCsPortTerm> cpeCsPortTerms) {
		this.cpeCsPortTerms = cpeCsPortTerms;
	}

	public CpeCsPortTerm addCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		getCpeCsPortTerms().add(cpeCsPortTerm);
		cpeCsPortTerm.setCpePort(this);

		return cpeCsPortTerm;
	}

	public CpeCsPortTerm removeCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		getCpeCsPortTerms().remove(cpeCsPortTerm);
		cpeCsPortTerm.setCpePort(null);

		return cpeCsPortTerm;
	}

	public List<CpePluginPortAssoc> getCpePluginPortAssocs() {
		return this.cpePluginPortAssocs;
	}

	public void setCpePluginPortAssocs(List<CpePluginPortAssoc> cpePluginPortAssocs) {
		this.cpePluginPortAssocs = cpePluginPortAssocs;
	}

	public CpePluginPortAssoc addCpePluginPortAssoc(CpePluginPortAssoc cpePluginPortAssoc) {
		getCpePluginPortAssocs().add(cpePluginPortAssoc);
		cpePluginPortAssoc.setCpePort(this);

		return cpePluginPortAssoc;
	}

	public CpePluginPortAssoc removeCpePluginPortAssoc(CpePluginPortAssoc cpePluginPortAssoc) {
		getCpePluginPortAssocs().remove(cpePluginPortAssoc);
		cpePluginPortAssoc.setCpePort(null);

		return cpePluginPortAssoc;
	}

	public CustomerPremiseEquipment getCustomerPremiseEquipment() {
		return this.customerPremiseEquipment;
	}

	public void setCustomerPremiseEquipment(CustomerPremiseEquipment customerPremiseEquipment) {
		this.customerPremiseEquipment = customerPremiseEquipment;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

	public List<CpePortChar> getCpePortChars() {
		return this.cpePortChars;
	}

	public void setCpePortChars(List<CpePortChar> cpePortChars) {
		this.cpePortChars = cpePortChars;
	}

	public CpePortChar addCpePortChar(CpePortChar cpePortChar) {
		getCpePortChars().add(cpePortChar);
		cpePortChar.setCpePort(this);

		return cpePortChar;
	}

	public CpePortChar removeCpePortChar(CpePortChar cpePortChar) {
		getCpePortChars().remove(cpePortChar);
		cpePortChar.setCpePort(null);

		return cpePortChar;
	}

	public List<CpePortPortAssoc> getCpePortPortAssocs1() {
		return this.cpePortPortAssocs1;
	}

	public void setCpePortPortAssocs1(List<CpePortPortAssoc> cpePortPortAssocs1) {
		this.cpePortPortAssocs1 = cpePortPortAssocs1;
	}

	public CpePortPortAssoc addCpePortPortAssocs1(CpePortPortAssoc cpePortPortAssocs1) {
		getCpePortPortAssocs1().add(cpePortPortAssocs1);
		cpePortPortAssocs1.setCpePort1(this);

		return cpePortPortAssocs1;
	}

	public CpePortPortAssoc removeCpePortPortAssocs1(CpePortPortAssoc cpePortPortAssocs1) {
		getCpePortPortAssocs1().remove(cpePortPortAssocs1);
		cpePortPortAssocs1.setCpePort1(null);

		return cpePortPortAssocs1;
	}

	public List<CpePortPortAssoc> getCpePortPortAssocs2() {
		return this.cpePortPortAssocs2;
	}

	public void setCpePortPortAssocs2(List<CpePortPortAssoc> cpePortPortAssocs2) {
		this.cpePortPortAssocs2 = cpePortPortAssocs2;
	}

	public CpePortPortAssoc addCpePortPortAssocs2(CpePortPortAssoc cpePortPortAssocs2) {
		getCpePortPortAssocs2().add(cpePortPortAssocs2);
		cpePortPortAssocs2.setCpePort2(this);

		return cpePortPortAssocs2;
	}

	public CpePortPortAssoc removeCpePortPortAssocs2(CpePortPortAssoc cpePortPortAssocs2) {
		getCpePortPortAssocs2().remove(cpePortPortAssocs2);
		cpePortPortAssocs2.setCpePort2(null);

		return cpePortPortAssocs2;
	}

}