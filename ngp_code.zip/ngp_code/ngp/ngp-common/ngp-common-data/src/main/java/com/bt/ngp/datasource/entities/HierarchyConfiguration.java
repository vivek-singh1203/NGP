package com.bt.ngp.datasource.entities;
import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;

/**
 * The persistent class for the HIERARCHY_CONFIGURATION database table.
 * 
 */
@javax.persistence.Entity
@Table(name="HIERARCHY_CONFIGURATION")
@NamedQuery(name="HierarchyConfiguration.findAll", query="SELECT h FROM HierarchyConfiguration h")
public class HierarchyConfiguration implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="ASSOC_2_3")
	private String assoc23;

	@Column(name="ASSOC_3_4")
	private String assoc34;

	@Column(name="ASSOC_4_5")
	private String assoc45;

	@Column(name="CREATED_BY")
	private String createdBy;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="ENTITY_NAME")
	private String entityName;

	@Column(name="HIERARCHY_1")
	private String hierarchy1;

	@Column(name="HIERARCHY_2")
	private String hierarchy2;

	@Column(name="HIERARCHY_3")
	private String hierarchy3;

	@Column(name="HIERARCHY_4")
	private String hierarchy4;

	@Column(name="HIERARCHY_5")
	private String hierarchy5;

	@Id
	@Column(name="ID")
	private String id;

	@Column(name="LAST_MODIFIED_BY")
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="SELF_ASSOC")
	private String selfAssoc;

	@Column(name="SHORT_NAME")
	private String shortName;

	@Column(name="SPEC_CATEGORY_NAME")
	private String specCategoryName;

	@Column(name="SPEC_TYPE_NAME")
	private String specTypeName;
	
	@Column(name="LAYER_NAME")
	private String layerName;

	public HierarchyConfiguration() {
	}

	public String getAssoc23() {
		return this.assoc23;
	}

	public void setAssoc23(String assoc23) {
		this.assoc23 = assoc23;
	}

	public String getAssoc34() {
		return this.assoc34;
	}

	public void setAssoc34(String assoc34) {
		this.assoc34 = assoc34;
	}

	public String getAssoc45() {
		return this.assoc45;
	}

	public void setAssoc45(String assoc45) {
		this.assoc45 = assoc45;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getHierarchy1() {
		return this.hierarchy1;
	}

	public void setHierarchy1(String hierarchy1) {
		this.hierarchy1 = hierarchy1;
	}

	public String getHierarchy2() {
		return this.hierarchy2;
	}

	public void setHierarchy2(String hierarchy2) {
		this.hierarchy2 = hierarchy2;
	}

	public String getHierarchy3() {
		return this.hierarchy3;
	}

	public void setHierarchy3(String hierarchy3) {
		this.hierarchy3 = hierarchy3;
	}

	public String getHierarchy4() {
		return this.hierarchy4;
	}

	public void setHierarchy4(String hierarchy4) {
		this.hierarchy4 = hierarchy4;
	}

	public String getHierarchy5() {
		return this.hierarchy5;
	}

	public void setHierarchy5(String hierarchy5) {
		this.hierarchy5 = hierarchy5;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getSelfAssoc() {
		return this.selfAssoc;
	}

	public void setSelfAssoc(String selfAssoc) {
		this.selfAssoc = selfAssoc;
	}

	public String getShortName() {
		return this.shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getLayerName() {
		return layerName;
	}

	public void setLayerName(String layerName) {
		this.layerName = layerName;
	}

	@Override
	public String toString() {
		return "HierarchyConfiguration [assoc23=" + assoc23 + ", assoc34=" + assoc34 + ", assoc45=" + assoc45
				+ ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", entityName=" + entityName
				+ ", hierarchy1=" + hierarchy1 + ", hierarchy2=" + hierarchy2 + ", hierarchy3=" + hierarchy3
				+ ", hierarchy4=" + hierarchy4 + ", hierarchy5=" + hierarchy5 + ", id=" + id + ", lastModifiedBy="
				+ lastModifiedBy + ", lastModifiedDate=" + lastModifiedDate + ", selfAssoc=" + selfAssoc
				+ ", shortName=" + shortName + ", specCategoryName=" + specCategoryName + ", specTypeName="
				+ specTypeName + "]";
	}

}