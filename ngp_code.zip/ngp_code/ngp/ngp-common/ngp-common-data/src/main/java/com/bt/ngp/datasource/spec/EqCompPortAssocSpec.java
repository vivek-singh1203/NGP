package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the EQ_COMP_PORT_ASSOC_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="EQ_COMP_PORT_ASSOC_SPEC")
@NamedQuery(name="EqCompPortAssocSpec.findAll", query="SELECT e FROM EqCompPortAssocSpec e")
public class EqCompPortAssocSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="COMP_ENTITY_NAME", length=30)
	private String compEntityName;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="EQ_ENTITY_NAME", length=30)
	private String eqEntityName;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="NO_OF_PORT_SPEC_INSTANCES", nullable=false, precision=38)
	private BigDecimal noOfPortSpecInstances;

	@Column(name="PORT_ENTITY_NAME", length=30)
	private String portEntityName;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="COMP_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory1;

	//bi-directional many-to-one association to EqSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="COMP_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="COMP_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private EqSpec eqSpec1;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="COMP_SPEC_TYPE_NAME")
	private SpecType specType1;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="EQ_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory2;

	//bi-directional many-to-one association to EqSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="EQ_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="EQ_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private EqSpec eqSpec2;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="EQ_SPEC_TYPE_NAME")
	private SpecType specType2;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="PORT_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory3;

	//bi-directional many-to-one association to PortSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="PORT_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="PORT_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private PortSpec portSpec;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="PORT_SPEC_TYPE_NAME")
	private SpecType specType3;

	//bi-directional many-to-one association to EqHierarchySpec
	@OneToMany(mappedBy="eqCompPortAssocSpec")
	private List<EqHierarchySpec> eqHierarchySpecs;

	public EqCompPortAssocSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompEntityName() {
		return this.compEntityName;
	}

	public void setCompEntityName(String compEntityName) {
		this.compEntityName = compEntityName;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEqEntityName() {
		return this.eqEntityName;
	}

	public void setEqEntityName(String eqEntityName) {
		this.eqEntityName = eqEntityName;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getNoOfPortSpecInstances() {
		return this.noOfPortSpecInstances;
	}

	public void setNoOfPortSpecInstances(BigDecimal noOfPortSpecInstances) {
		this.noOfPortSpecInstances = noOfPortSpecInstances;
	}

	public String getPortEntityName() {
		return this.portEntityName;
	}

	public void setPortEntityName(String portEntityName) {
		this.portEntityName = portEntityName;
	}

	public SpecCategory getSpecCategory1() {
		return this.specCategory1;
	}

	public void setSpecCategory1(SpecCategory specCategory1) {
		this.specCategory1 = specCategory1;
	}

	public EqSpec getEqSpec1() {
		return this.eqSpec1;
	}

	public void setEqSpec1(EqSpec eqSpec1) {
		this.eqSpec1 = eqSpec1;
	}

	public SpecType getSpecType1() {
		return this.specType1;
	}

	public void setSpecType1(SpecType specType1) {
		this.specType1 = specType1;
	}

	public SpecCategory getSpecCategory2() {
		return this.specCategory2;
	}

	public void setSpecCategory2(SpecCategory specCategory2) {
		this.specCategory2 = specCategory2;
	}

	public EqSpec getEqSpec2() {
		return this.eqSpec2;
	}

	public void setEqSpec2(EqSpec eqSpec2) {
		this.eqSpec2 = eqSpec2;
	}

	public SpecType getSpecType2() {
		return this.specType2;
	}

	public void setSpecType2(SpecType specType2) {
		this.specType2 = specType2;
	}

	public SpecCategory getSpecCategory3() {
		return this.specCategory3;
	}

	public void setSpecCategory3(SpecCategory specCategory3) {
		this.specCategory3 = specCategory3;
	}

	public PortSpec getPortSpec() {
		return this.portSpec;
	}

	public void setPortSpec(PortSpec portSpec) {
		this.portSpec = portSpec;
	}

	public SpecType getSpecType3() {
		return this.specType3;
	}

	public void setSpecType3(SpecType specType3) {
		this.specType3 = specType3;
	}

	public List<EqHierarchySpec> getEqHierarchySpecs() {
		return this.eqHierarchySpecs;
	}

	public void setEqHierarchySpecs(List<EqHierarchySpec> eqHierarchySpecs) {
		this.eqHierarchySpecs = eqHierarchySpecs;
	}

	public EqHierarchySpec addEqHierarchySpec(EqHierarchySpec eqHierarchySpec) {
		getEqHierarchySpecs().add(eqHierarchySpec);
		eqHierarchySpec.setEqCompPortAssocSpec(this);

		return eqHierarchySpec;
	}

	public EqHierarchySpec removeEqHierarchySpec(EqHierarchySpec eqHierarchySpec) {
		getEqHierarchySpecs().remove(eqHierarchySpec);
		eqHierarchySpec.setEqCompPortAssocSpec(null);

		return eqHierarchySpec;
	}

}