package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the CPE_HIERARCHY database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CPE_HIERARCHY")
@NamedQuery(name="CpeHierarchy.findAll", query="SELECT c FROM CpeHierarchy c")
public class CpeHierarchy implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CPE_POS_END_NUM", nullable=false, precision=38)
	private BigDecimal cpePosEndNum;

	@Column(name="CPE_POS_START_NUM", nullable=false, precision=38)
	private BigDecimal cpePosStartNum;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="EQ_HIERARCHY_SPEC_ID", length=50)
	private String eqHierarchySpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LEG_ID", precision=38)
	private BigDecimal legId;

	//bi-directional many-to-one association to CpeChassisPhAssoc
	@ManyToOne
	@JoinColumn(name="CHASSIS_PH_ASSOC_ID")
	private CpeChassisPhAssoc cpeChassisPhAssoc;

	//bi-directional many-to-one association to CustomerPremiseEquipment
	@ManyToOne
	@JoinColumn(name="CPE_NAME")
	private CustomerPremiseEquipment customerPremiseEquipment;

	//bi-directional many-to-one association to CpePhPluginAssoc
	@ManyToOne
	@JoinColumn(name="PH_PLUGIN_ASSOC_ID")
	private CpePhPluginAssoc cpePhPluginAssoc;

	//bi-directional many-to-one association to CpePluginPortAssoc
	@ManyToOne
	@JoinColumn(name="PLUGIN_PORT_ASSOC_ID")
	private CpePluginPortAssoc cpePluginPortAssoc;

	public CpeHierarchy() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public BigDecimal getCpePosEndNum() {
		return this.cpePosEndNum;
	}

	public void setCpePosEndNum(BigDecimal cpePosEndNum) {
		this.cpePosEndNum = cpePosEndNum;
	}

	public BigDecimal getCpePosStartNum() {
		return this.cpePosStartNum;
	}

	public void setCpePosStartNum(BigDecimal cpePosStartNum) {
		this.cpePosStartNum = cpePosStartNum;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEqHierarchySpecId() {
		return this.eqHierarchySpecId;
	}

	public void setEqHierarchySpecId(String eqHierarchySpecId) {
		this.eqHierarchySpecId = eqHierarchySpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getLegId() {
		return this.legId;
	}

	public void setLegId(BigDecimal legId) {
		this.legId = legId;
	}

	public CpeChassisPhAssoc getCpeChassisPhAssoc() {
		return this.cpeChassisPhAssoc;
	}

	public void setCpeChassisPhAssoc(CpeChassisPhAssoc cpeChassisPhAssoc) {
		this.cpeChassisPhAssoc = cpeChassisPhAssoc;
	}

	public CustomerPremiseEquipment getCustomerPremiseEquipment() {
		return this.customerPremiseEquipment;
	}

	public void setCustomerPremiseEquipment(CustomerPremiseEquipment customerPremiseEquipment) {
		this.customerPremiseEquipment = customerPremiseEquipment;
	}

	public CpePhPluginAssoc getCpePhPluginAssoc() {
		return this.cpePhPluginAssoc;
	}

	public void setCpePhPluginAssoc(CpePhPluginAssoc cpePhPluginAssoc) {
		this.cpePhPluginAssoc = cpePhPluginAssoc;
	}

	public CpePluginPortAssoc getCpePluginPortAssoc() {
		return this.cpePluginPortAssoc;
	}

	public void setCpePluginPortAssoc(CpePluginPortAssoc cpePluginPortAssoc) {
		this.cpePluginPortAssoc = cpePluginPortAssoc;
	}

}