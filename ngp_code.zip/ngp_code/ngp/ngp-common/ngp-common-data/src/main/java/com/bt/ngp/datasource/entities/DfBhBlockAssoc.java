package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the DF_BH_BLOCK_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DF_BH_BLOCK_ASSOC")
@NamedQuery(name="DfBhBlockAssoc.findAll", query="SELECT d FROM DfBhBlockAssoc d")
public class DfBhBlockAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="HOLDER_COMP_ASSOC_SPEC_ID", length=50)
	private String holderCompAssocSpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to DistributionFrame
	@ManyToOne
	@JoinColumn(name="FRAME_NAME")
	private DistributionFrame distributionFrame;

	//bi-directional many-to-one association to BlockHolder
	@ManyToOne
	@JoinColumn(name="BH_NAME")
	private BlockHolder blockHolder;

	//bi-directional many-to-one association to Block
	@ManyToOne
	@JoinColumn(name="BLOCK_NAME")
	private Block block;

	//bi-directional many-to-one association to DfHierarchy
	@OneToMany(mappedBy="dfBhBlockAssoc")
	private List<DfHierarchy> dfHierarchies;

	public DfBhBlockAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getHolderCompAssocSpecId() {
		return this.holderCompAssocSpecId;
	}

	public void setHolderCompAssocSpecId(String holderCompAssocSpecId) {
		this.holderCompAssocSpecId = holderCompAssocSpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public DistributionFrame getDistributionFrame() {
		return this.distributionFrame;
	}

	public void setDistributionFrame(DistributionFrame distributionFrame) {
		this.distributionFrame = distributionFrame;
	}

	public BlockHolder getBlockHolder() {
		return this.blockHolder;
	}

	public void setBlockHolder(BlockHolder blockHolder) {
		this.blockHolder = blockHolder;
	}

	public Block getBlock() {
		return this.block;
	}

	public void setBlock(Block block) {
		this.block = block;
	}

	public List<DfHierarchy> getDfHierarchies() {
		return this.dfHierarchies;
	}

	public void setDfHierarchies(List<DfHierarchy> dfHierarchies) {
		this.dfHierarchies = dfHierarchies;
	}

	public DfHierarchy addDfHierarchy(DfHierarchy dfHierarchy) {
		getDfHierarchies().add(dfHierarchy);
		dfHierarchy.setDfBhBlockAssoc(this);

		return dfHierarchy;
	}

	public DfHierarchy removeDfHierarchy(DfHierarchy dfHierarchy) {
		getDfHierarchies().remove(dfHierarchy);
		dfHierarchy.setDfBhBlockAssoc(null);

		return dfHierarchy;
	}

}