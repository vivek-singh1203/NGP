package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the MFN_PLUGIN_PORT_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="MFN_PLUGIN_PORT_ASSOC")
@NamedQuery(name="MfnPluginPortAssoc.findAll", query="SELECT m FROM MfnPluginPortAssoc m")
public class MfnPluginPortAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="COMP_PORT_ASSOC_SPEC_ID", length=50)
	private String compPortAssocSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal portSeqNum;

	//bi-directional many-to-one association to MfnHierarchy
	@OneToMany(mappedBy="mfnPluginPortAssoc")
	private List<MfnHierarchy> mfnHierarchies;

	//bi-directional many-to-one association to MultiFunctionalNode
	@ManyToOne
	@JoinColumn(name="MFN_NAME")
	private MultiFunctionalNode multiFunctionalNode;

	//bi-directional many-to-one association to MfnPort
	@ManyToOne
	@JoinColumn(name="PORT_NAME")
	private MfnPort mfnPort;

	//bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	public MfnPluginPortAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompPortAssocSpecId() {
		return this.compPortAssocSpecId;
	}

	public void setCompPortAssocSpecId(String compPortAssocSpecId) {
		this.compPortAssocSpecId = compPortAssocSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortSeqNum() {
		return this.portSeqNum;
	}

	public void setPortSeqNum(BigDecimal portSeqNum) {
		this.portSeqNum = portSeqNum;
	}

	public List<MfnHierarchy> getMfnHierarchies() {
		return this.mfnHierarchies;
	}

	public void setMfnHierarchies(List<MfnHierarchy> mfnHierarchies) {
		this.mfnHierarchies = mfnHierarchies;
	}

	public MfnHierarchy addMfnHierarchy(MfnHierarchy mfnHierarchy) {
		getMfnHierarchies().add(mfnHierarchy);
		mfnHierarchy.setMfnPluginPortAssoc(this);

		return mfnHierarchy;
	}

	public MfnHierarchy removeMfnHierarchy(MfnHierarchy mfnHierarchy) {
		getMfnHierarchies().remove(mfnHierarchy);
		mfnHierarchy.setMfnPluginPortAssoc(null);

		return mfnHierarchy;
	}

	public MultiFunctionalNode getMultiFunctionalNode() {
		return this.multiFunctionalNode;
	}

	public void setMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		this.multiFunctionalNode = multiFunctionalNode;
	}

	public MfnPort getMfnPort() {
		return this.mfnPort;
	}

	public void setMfnPort(MfnPort mfnPort) {
		this.mfnPort = mfnPort;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

}