package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the DSLAM_RACK_CH_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DSLAM_RACK_CH_ASSOC")
@NamedQuery(name="DslamRackChAssoc.findAll", query="SELECT d FROM DslamRackChAssoc d")
public class DslamRackChAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="COMP_HOLDER_ASSOC_SPEC_ID", length=50)
	private String compHolderAssocSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RACK_END_POS_NUM", nullable=false, precision=38)
	private BigDecimal rackEndPosNum;

	@Column(name="RACK_START_POS_NUM", nullable=false, precision=38)
	private BigDecimal rackStartPosNum;

	//bi-directional many-to-one association to DslamHierarchy
	@OneToMany(mappedBy="dslamRackChAssoc")
	private List<DslamHierarchy> dslamHierarchies;

	//bi-directional many-to-one association to CardHolder
	@ManyToOne
	@JoinColumn(name="CH_NAME")
	private CardHolder cardHolder;

	//bi-directional many-to-one association to Dslam
	@ManyToOne
	@JoinColumn(name="DSLAM_NAME")
	private Dslam dslam;

	//bi-directional many-to-one association to Rack
	@ManyToOne
	@JoinColumn(name="RACK_NAME")
	private Rack rack;

	public DslamRackChAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompHolderAssocSpecId() {
		return this.compHolderAssocSpecId;
	}

	public void setCompHolderAssocSpecId(String compHolderAssocSpecId) {
		this.compHolderAssocSpecId = compHolderAssocSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getRackEndPosNum() {
		return this.rackEndPosNum;
	}

	public void setRackEndPosNum(BigDecimal rackEndPosNum) {
		this.rackEndPosNum = rackEndPosNum;
	}

	public BigDecimal getRackStartPosNum() {
		return this.rackStartPosNum;
	}

	public void setRackStartPosNum(BigDecimal rackStartPosNum) {
		this.rackStartPosNum = rackStartPosNum;
	}

	public List<DslamHierarchy> getDslamHierarchies() {
		return this.dslamHierarchies;
	}

	public void setDslamHierarchies(List<DslamHierarchy> dslamHierarchies) {
		this.dslamHierarchies = dslamHierarchies;
	}

	public DslamHierarchy addDslamHierarchy(DslamHierarchy dslamHierarchy) {
		getDslamHierarchies().add(dslamHierarchy);
		dslamHierarchy.setDslamRackChAssoc(this);

		return dslamHierarchy;
	}

	public DslamHierarchy removeDslamHierarchy(DslamHierarchy dslamHierarchy) {
		getDslamHierarchies().remove(dslamHierarchy);
		dslamHierarchy.setDslamRackChAssoc(null);

		return dslamHierarchy;
	}

	public CardHolder getCardHolder() {
		return this.cardHolder;
	}

	public void setCardHolder(CardHolder cardHolder) {
		this.cardHolder = cardHolder;
	}

	public Dslam getDslam() {
		return this.dslam;
	}

	public void setDslam(Dslam dslam) {
		this.dslam = dslam;
	}

	public Rack getRack() {
		return this.rack;
	}

	public void setRack(Rack rack) {
		this.rack = rack;
	}

}