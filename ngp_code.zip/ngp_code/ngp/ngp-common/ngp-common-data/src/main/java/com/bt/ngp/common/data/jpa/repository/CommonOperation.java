package com.bt.ngp.common.data.jpa.repository;


import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface CommonOperation<T> extends SqlRepository<T> {
 public T findByName(String name); 
}
