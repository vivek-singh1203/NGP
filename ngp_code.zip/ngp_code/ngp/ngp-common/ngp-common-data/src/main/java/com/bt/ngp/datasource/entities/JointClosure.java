package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.vividsolutions.jts.geom.Point;

/**
 * The persistent class for the JOINT_CLOSURE database table.
 * 
 */
@javax.persistence.Entity
@Table(name="JOINT_CLOSURE")
@NamedQuery(name="JointClosure.findAll", query="SELECT j FROM JointClosure j")
public class JointClosure implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="DESG_NAME", length=30)
	private String desgName;

	@Column(name="DESG_NUM", precision=38)
	private String desgNum;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(name="FIELD_LABEL", length=30)
	private String fieldLabel;

	@Column(name = "GEO_POSITION", columnDefinition = "geometry(Point,3857)")
	private Point geoPosition;

	public Point getGeoPosition() {
		return geoPosition;
	}

	public void setGeoPosition(Point geoPosition) {
		this.geoPosition = geoPosition;
	}

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to AuxComponent
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<AuxComponent> auxComponents;

	//bi-directional many-to-one association to Chassi
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<Chassi> chassis;

	//bi-directional many-to-one association to Connector
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<Connector> connectors;

	//bi-directional many-to-one association to JcChar
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<JcChar> jcChars;

	//bi-directional many-to-one association to JcChassisPhAssoc
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<JcChassisPhAssoc> jcChassisPhAssocs;

	//bi-directional many-to-one association to JcCsCondSplicing
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<JcCsCondSplicing> jcCsCondSplicings;

	//bi-directional many-to-one association to JcCsPortTerm
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<JcCsPortTerm> jcCsPortTerms;

	//bi-directional many-to-one association to JcHierarchy
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<JcHierarchy> jcHierarchies;

	//bi-directional many-to-one association to JcPhPluginAssoc
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<JcPhPluginAssoc> jcPhPluginAssocs;

	//bi-directional many-to-one association to JcPluginPortAssoc
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<JcPluginPortAssoc> jcPluginPortAssocs;

	//bi-directional many-to-one association to JcPort
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<JcPort> jcPorts;

	//bi-directional many-to-one association to JcPortChar
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<JcPortChar> jcPortChars;

	//bi-directional many-to-one association to JcPortPortAssoc
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<JcPortPortAssoc> jcPortPortAssocs;

	//bi-directional many-to-one association to JcStructureAssoc
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<JcStructureAssoc> jcStructureAssocs;

	//bi-directional many-to-one association to Exchange
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="EXCHANGE_1141_CODE")
	private Exchange exchange;

	//bi-directional many-to-one association to Store
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to Plugin
	@OneToMany(mappedBy="jointClosure")
	private List<Plugin> plugins;

	//bi-directional many-to-one association to PluginHolder
	@OneToMany(mappedBy="jointClosure",fetch=FetchType.LAZY)
	private List<PluginHolder> pluginHolders;

	public JointClosure() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getDesgName() {
		return this.desgName;
	}

	public void setDesgName(String desgName) {
		this.desgName = desgName;
	}

	public String getDesgNum() {
		return this.desgNum;
	}

	public void setDesgNum(String desgNum) {
		this.desgNum = desgNum;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getFieldLabel() {
		return this.fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<AuxComponent> getAuxComponents() {
		return this.auxComponents;
	}

	public void setAuxComponents(List<AuxComponent> auxComponents) {
		this.auxComponents = auxComponents;
	}

	public AuxComponent addAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().add(auxComponent);
		auxComponent.setJointClosure(this);

		return auxComponent;
	}

	public AuxComponent removeAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().remove(auxComponent);
		auxComponent.setJointClosure(null);

		return auxComponent;
	}

	public List<Chassi> getChassis() {
		return this.chassis;
	}

	public void setChassis(List<Chassi> chassis) {
		this.chassis = chassis;
	}

	public Chassi addChassi(Chassi chassi) {
		getChassis().add(chassi);
		chassi.setJointClosure(this);

		return chassi;
	}

	public Chassi removeChassi(Chassi chassi) {
		getChassis().remove(chassi);
		chassi.setJointClosure(null);

		return chassi;
	}

	public List<Connector> getConnectors() {
		return this.connectors;
	}

	public void setConnectors(List<Connector> connectors) {
		this.connectors = connectors;
	}

	public Connector addConnector(Connector connector) {
		getConnectors().add(connector);
		connector.setJointClosure(this);

		return connector;
	}

	public Connector removeConnector(Connector connector) {
		getConnectors().remove(connector);
		connector.setJointClosure(null);

		return connector;
	}

	public List<JcChar> getJcChars() {
		return this.jcChars;
	}

	public void setJcChars(List<JcChar> jcChars) {
		this.jcChars = jcChars;
	}

	public JcChar addJcChar(JcChar jcChar) {
		getJcChars().add(jcChar);
		jcChar.setJointClosure(this);

		return jcChar;
	}

	public JcChar removeJcChar(JcChar jcChar) {
		getJcChars().remove(jcChar);
		jcChar.setJointClosure(null);

		return jcChar;
	}

	public List<JcChassisPhAssoc> getJcChassisPhAssocs() {
		return this.jcChassisPhAssocs;
	}

	public void setJcChassisPhAssocs(List<JcChassisPhAssoc> jcChassisPhAssocs) {
		this.jcChassisPhAssocs = jcChassisPhAssocs;
	}

	public JcChassisPhAssoc addJcChassisPhAssoc(JcChassisPhAssoc jcChassisPhAssoc) {
		getJcChassisPhAssocs().add(jcChassisPhAssoc);
		jcChassisPhAssoc.setJointClosure(this);

		return jcChassisPhAssoc;
	}

	public JcChassisPhAssoc removeJcChassisPhAssoc(JcChassisPhAssoc jcChassisPhAssoc) {
		getJcChassisPhAssocs().remove(jcChassisPhAssoc);
		jcChassisPhAssoc.setJointClosure(null);

		return jcChassisPhAssoc;
	}

	public List<JcCsCondSplicing> getJcCsCondSplicings() {
		return this.jcCsCondSplicings;
	}

	public void setJcCsCondSplicings(List<JcCsCondSplicing> jcCsCondSplicings) {
		this.jcCsCondSplicings = jcCsCondSplicings;
	}

	public JcCsCondSplicing addJcCsCondSplicing(JcCsCondSplicing jcCsCondSplicing) {
		getJcCsCondSplicings().add(jcCsCondSplicing);
		jcCsCondSplicing.setJointClosure(this);

		return jcCsCondSplicing;
	}

	public JcCsCondSplicing removeJcCsCondSplicing(JcCsCondSplicing jcCsCondSplicing) {
		getJcCsCondSplicings().remove(jcCsCondSplicing);
		jcCsCondSplicing.setJointClosure(null);

		return jcCsCondSplicing;
	}

	public List<JcCsPortTerm> getJcCsPortTerms() {
		return this.jcCsPortTerms;
	}

	public void setJcCsPortTerms(List<JcCsPortTerm> jcCsPortTerms) {
		this.jcCsPortTerms = jcCsPortTerms;
	}

	public JcCsPortTerm addJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		getJcCsPortTerms().add(jcCsPortTerm);
		jcCsPortTerm.setJointClosure(this);

		return jcCsPortTerm;
	}

	public JcCsPortTerm removeJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		getJcCsPortTerms().remove(jcCsPortTerm);
		jcCsPortTerm.setJointClosure(null);

		return jcCsPortTerm;
	}

	public List<JcHierarchy> getJcHierarchies() {
		return this.jcHierarchies;
	}

	public void setJcHierarchies(List<JcHierarchy> jcHierarchies) {
		this.jcHierarchies = jcHierarchies;
	}

	public JcHierarchy addJcHierarchy(JcHierarchy jcHierarchy) {
		getJcHierarchies().add(jcHierarchy);
		jcHierarchy.setJointClosure(this);

		return jcHierarchy;
	}

	public JcHierarchy removeJcHierarchy(JcHierarchy jcHierarchy) {
		getJcHierarchies().remove(jcHierarchy);
		jcHierarchy.setJointClosure(null);

		return jcHierarchy;
	}

	public List<JcPhPluginAssoc> getJcPhPluginAssocs() {
		return this.jcPhPluginAssocs;
	}

	public void setJcPhPluginAssocs(List<JcPhPluginAssoc> jcPhPluginAssocs) {
		this.jcPhPluginAssocs = jcPhPluginAssocs;
	}

	public JcPhPluginAssoc addJcPhPluginAssoc(JcPhPluginAssoc jcPhPluginAssoc) {
		getJcPhPluginAssocs().add(jcPhPluginAssoc);
		jcPhPluginAssoc.setJointClosure(this);

		return jcPhPluginAssoc;
	}

	public JcPhPluginAssoc removeJcPhPluginAssoc(JcPhPluginAssoc jcPhPluginAssoc) {
		getJcPhPluginAssocs().remove(jcPhPluginAssoc);
		jcPhPluginAssoc.setJointClosure(null);

		return jcPhPluginAssoc;
	}

	public List<JcPluginPortAssoc> getJcPluginPortAssocs() {
		return this.jcPluginPortAssocs;
	}

	public void setJcPluginPortAssocs(List<JcPluginPortAssoc> jcPluginPortAssocs) {
		this.jcPluginPortAssocs = jcPluginPortAssocs;
	}

	public JcPluginPortAssoc addJcPluginPortAssoc(JcPluginPortAssoc jcPluginPortAssoc) {
		getJcPluginPortAssocs().add(jcPluginPortAssoc);
		jcPluginPortAssoc.setJointClosure(this);

		return jcPluginPortAssoc;
	}

	public JcPluginPortAssoc removeJcPluginPortAssoc(JcPluginPortAssoc jcPluginPortAssoc) {
		getJcPluginPortAssocs().remove(jcPluginPortAssoc);
		jcPluginPortAssoc.setJointClosure(null);

		return jcPluginPortAssoc;
	}

	public List<JcPort> getJcPorts() {
		return this.jcPorts;
	}

	public void setJcPorts(List<JcPort> jcPorts) {
		this.jcPorts = jcPorts;
	}

	public JcPort addJcPort(JcPort jcPort) {
		getJcPorts().add(jcPort);
		jcPort.setJointClosure(this);

		return jcPort;
	}

	public JcPort removeJcPort(JcPort jcPort) {
		getJcPorts().remove(jcPort);
		jcPort.setJointClosure(null);

		return jcPort;
	}

	public List<JcPortChar> getJcPortChars() {
		return this.jcPortChars;
	}

	public void setJcPortChars(List<JcPortChar> jcPortChars) {
		this.jcPortChars = jcPortChars;
	}

	public JcPortChar addJcPortChar(JcPortChar jcPortChar) {
		getJcPortChars().add(jcPortChar);
		jcPortChar.setJointClosure(this);

		return jcPortChar;
	}

	public JcPortChar removeJcPortChar(JcPortChar jcPortChar) {
		getJcPortChars().remove(jcPortChar);
		jcPortChar.setJointClosure(null);

		return jcPortChar;
	}

	public List<JcPortPortAssoc> getJcPortPortAssocs() {
		return this.jcPortPortAssocs;
	}

	public void setJcPortPortAssocs(List<JcPortPortAssoc> jcPortPortAssocs) {
		this.jcPortPortAssocs = jcPortPortAssocs;
	}

	public JcPortPortAssoc addJcPortPortAssoc(JcPortPortAssoc jcPortPortAssoc) {
		getJcPortPortAssocs().add(jcPortPortAssoc);
		jcPortPortAssoc.setJointClosure(this);

		return jcPortPortAssoc;
	}

	public JcPortPortAssoc removeJcPortPortAssoc(JcPortPortAssoc jcPortPortAssoc) {
		getJcPortPortAssocs().remove(jcPortPortAssoc);
		jcPortPortAssoc.setJointClosure(null);

		return jcPortPortAssoc;
	}

	public List<JcStructureAssoc> getJcStructureAssocs() {
		return this.jcStructureAssocs;
	}

	public void setJcStructureAssocs(List<JcStructureAssoc> jcStructureAssocs) {
		this.jcStructureAssocs = jcStructureAssocs;
	}

	public JcStructureAssoc addJcStructureAssoc(JcStructureAssoc jcStructureAssoc) {
		getJcStructureAssocs().add(jcStructureAssoc);
		jcStructureAssoc.setJointClosure(this);

		return jcStructureAssoc;
	}

	public JcStructureAssoc removeJcStructureAssoc(JcStructureAssoc jcStructureAssoc) {
		getJcStructureAssocs().remove(jcStructureAssoc);
		jcStructureAssoc.setJointClosure(null);

		return jcStructureAssoc;
	}

	public Exchange getExchange() {
		return this.exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public List<Plugin> getPlugins() {
		return this.plugins;
	}

	public void setPlugins(List<Plugin> plugins) {
		this.plugins = plugins;
	}

	public Plugin addPlugin(Plugin plugin) {
		getPlugins().add(plugin);
		plugin.setJointClosure(this);

		return plugin;
	}

	public Plugin removePlugin(Plugin plugin) {
		getPlugins().remove(plugin);
		plugin.setJointClosure(null);

		return plugin;
	}

	public List<PluginHolder> getPluginHolders() {
		return this.pluginHolders;
	}

	public void setPluginHolders(List<PluginHolder> pluginHolders) {
		this.pluginHolders = pluginHolders;
	}

	public PluginHolder addPluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().add(pluginHolder);
		pluginHolder.setJointClosure(this);

		return pluginHolder;
	}

	public PluginHolder removePluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().remove(pluginHolder);
		pluginHolder.setJointClosure(null);

		return pluginHolder;
	}

}