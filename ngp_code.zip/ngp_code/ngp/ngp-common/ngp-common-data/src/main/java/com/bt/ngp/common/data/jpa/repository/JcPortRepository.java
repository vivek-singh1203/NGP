package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.JcPort;
import com.bt.ngp.userdefined.entities.PortStatisticsJc;

@Repository
public interface JcPortRepository extends CommonOperation<JcPort> {
	@Query(name = "JcPortRepository.fetchPortCountInPlugin", nativeQuery = false)
	public List<PortStatisticsJc> fetchPortCount(
			@Param("jcPort") JcPort jcPort);
}