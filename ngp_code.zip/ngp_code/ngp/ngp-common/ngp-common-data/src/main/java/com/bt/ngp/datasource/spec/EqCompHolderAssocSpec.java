package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the EQ_COMP_HOLDER_ASSOC_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="EQ_COMP_HOLDER_ASSOC_SPEC")
@NamedQuery(name="EqCompHolderAssocSpec.findAll", query="SELECT e FROM EqCompHolderAssocSpec e")
public class EqCompHolderAssocSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="COMP_ENTITY_NAME", length=30)
	private String compEntityName;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="EQ_ENTITY_NAME", length=30)
	private String eqEntityName;

	@Column(name="HOLDER_ENTITY_NAME", length=30)
	private String holderEntityName;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="NO_OF_HOLDER_SPEC_INSTANCES", precision=38)
	private BigDecimal noOfHolderSpecInstances;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="COMP_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory1;

	//bi-directional many-to-one association to EqSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="COMP_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="COMP_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private EqSpec eqSpec1;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="COMP_SPEC_TYPE_NAME")
	private SpecType specType1;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="EQ_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory2;

	//bi-directional many-to-one association to EqSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="EQ_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="EQ_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private EqSpec eqSpec2;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="EQ_SPEC_TYPE_NAME")
	private SpecType specType2;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="HOLDER_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory3;

	//bi-directional many-to-one association to HolderSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="HOLDER_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="HOLDER_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private HolderSpec holderSpec;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="HOLDER_SPEC_TYPE_NAME")
	private SpecType specType3;

	//bi-directional many-to-one association to EqHierarchySpec
	@OneToMany(mappedBy="eqCompHolderAssocSpec")
	private List<EqHierarchySpec> eqHierarchySpecs;

	public EqCompHolderAssocSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompEntityName() {
		return this.compEntityName;
	}

	public void setCompEntityName(String compEntityName) {
		this.compEntityName = compEntityName;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEqEntityName() {
		return this.eqEntityName;
	}

	public void setEqEntityName(String eqEntityName) {
		this.eqEntityName = eqEntityName;
	}

	public String getHolderEntityName() {
		return this.holderEntityName;
	}

	public void setHolderEntityName(String holderEntityName) {
		this.holderEntityName = holderEntityName;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getNoOfHolderSpecInstances() {
		return this.noOfHolderSpecInstances;
	}

	public void setNoOfHolderSpecInstances(BigDecimal noOfHolderSpecInstances) {
		this.noOfHolderSpecInstances = noOfHolderSpecInstances;
	}

	public SpecCategory getSpecCategory1() {
		return this.specCategory1;
	}

	public void setSpecCategory1(SpecCategory specCategory1) {
		this.specCategory1 = specCategory1;
	}

	public EqSpec getEqSpec1() {
		return this.eqSpec1;
	}

	public void setEqSpec1(EqSpec eqSpec1) {
		this.eqSpec1 = eqSpec1;
	}

	public SpecType getSpecType1() {
		return this.specType1;
	}

	public void setSpecType1(SpecType specType1) {
		this.specType1 = specType1;
	}

	public SpecCategory getSpecCategory2() {
		return this.specCategory2;
	}

	public void setSpecCategory2(SpecCategory specCategory2) {
		this.specCategory2 = specCategory2;
	}

	public EqSpec getEqSpec2() {
		return this.eqSpec2;
	}

	public void setEqSpec2(EqSpec eqSpec2) {
		this.eqSpec2 = eqSpec2;
	}

	public SpecType getSpecType2() {
		return this.specType2;
	}

	public void setSpecType2(SpecType specType2) {
		this.specType2 = specType2;
	}

	public SpecCategory getSpecCategory3() {
		return this.specCategory3;
	}

	public void setSpecCategory3(SpecCategory specCategory3) {
		this.specCategory3 = specCategory3;
	}

	public HolderSpec getHolderSpec() {
		return this.holderSpec;
	}

	public void setHolderSpec(HolderSpec holderSpec) {
		this.holderSpec = holderSpec;
	}

	public SpecType getSpecType3() {
		return this.specType3;
	}

	public void setSpecType3(SpecType specType3) {
		this.specType3 = specType3;
	}

	public List<EqHierarchySpec> getEqHierarchySpecs() {
		return this.eqHierarchySpecs;
	}

	public void setEqHierarchySpecs(List<EqHierarchySpec> eqHierarchySpecs) {
		this.eqHierarchySpecs = eqHierarchySpecs;
	}

	public EqHierarchySpec addEqHierarchySpec(EqHierarchySpec eqHierarchySpec) {
		getEqHierarchySpecs().add(eqHierarchySpec);
		eqHierarchySpec.setEqCompHolderAssocSpec(this);

		return eqHierarchySpec;
	}

	public EqHierarchySpec removeEqHierarchySpec(EqHierarchySpec eqHierarchySpec) {
		getEqHierarchySpecs().remove(eqHierarchySpec);
		eqHierarchySpec.setEqCompHolderAssocSpec(null);

		return eqHierarchySpec;
	}

}