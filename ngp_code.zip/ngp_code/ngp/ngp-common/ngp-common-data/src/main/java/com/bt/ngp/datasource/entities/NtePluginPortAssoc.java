package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the NTE_PLUGIN_PORT_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="NTE_PLUGIN_PORT_ASSOC")
@NamedQuery(name="NtePluginPortAssoc.findAll", query="SELECT n FROM NtePluginPortAssoc n")
public class NtePluginPortAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="COMP_PORT_ASSOC_SPEC_ID", length=50)
	private String compPortAssocSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal portSeqNum;

	//bi-directional many-to-one association to NteHierarchy
	@OneToMany(mappedBy="ntePluginPortAssoc")
	private List<NteHierarchy> nteHierarchies;

	//bi-directional many-to-one association to NetworkTerminatingEquipment
	@ManyToOne
	@JoinColumn(name="NTE_NAME")
	private NetworkTerminatingEquipment networkTerminatingEquipment;

	//bi-directional many-to-one association to NtePort
	@ManyToOne
	@JoinColumn(name="PORT_NAME")
	private NtePort ntePort;

	//bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	public NtePluginPortAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompPortAssocSpecId() {
		return this.compPortAssocSpecId;
	}

	public void setCompPortAssocSpecId(String compPortAssocSpecId) {
		this.compPortAssocSpecId = compPortAssocSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortSeqNum() {
		return this.portSeqNum;
	}

	public void setPortSeqNum(BigDecimal portSeqNum) {
		this.portSeqNum = portSeqNum;
	}

	public List<NteHierarchy> getNteHierarchies() {
		return this.nteHierarchies;
	}

	public void setNteHierarchies(List<NteHierarchy> nteHierarchies) {
		this.nteHierarchies = nteHierarchies;
	}

	public NteHierarchy addNteHierarchy(NteHierarchy nteHierarchy) {
		getNteHierarchies().add(nteHierarchy);
		nteHierarchy.setNtePluginPortAssoc(this);

		return nteHierarchy;
	}

	public NteHierarchy removeNteHierarchy(NteHierarchy nteHierarchy) {
		getNteHierarchies().remove(nteHierarchy);
		nteHierarchy.setNtePluginPortAssoc(null);

		return nteHierarchy;
	}

	public NetworkTerminatingEquipment getNetworkTerminatingEquipment() {
		return this.networkTerminatingEquipment;
	}

	public void setNetworkTerminatingEquipment(NetworkTerminatingEquipment networkTerminatingEquipment) {
		this.networkTerminatingEquipment = networkTerminatingEquipment;
	}

	public NtePort getNtePort() {
		return this.ntePort;
	}

	public void setNtePort(NtePort ntePort) {
		this.ntePort = ntePort;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

}