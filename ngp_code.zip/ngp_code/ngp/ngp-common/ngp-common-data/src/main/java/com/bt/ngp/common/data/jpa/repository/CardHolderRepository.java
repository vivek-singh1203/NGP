package com.bt.ngp.common.data.jpa.repository;

import com.bt.ngp.datasource.entities.CardHolder;

public interface CardHolderRepository extends CommonOperation<CardHolder>{

}
