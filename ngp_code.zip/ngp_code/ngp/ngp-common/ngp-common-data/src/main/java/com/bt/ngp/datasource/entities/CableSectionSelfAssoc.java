package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the CABLE_SECTION_SELF_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name = "CABLE_SECTION_SELF_ASSOC")
@NamedQuery(name = "CableSectionSelfAssoc.findAll", query = "SELECT c FROM CableSectionSelfAssoc c")
public class CableSectionSelfAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique = true, nullable = false, length = 50)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SeqGen")
    @SequenceGenerator(name = "SeqGen", sequenceName = "CABLE_SECTION_SELF_ASSOC_SEQ", allocationSize = 1)
	private long id;

	@Column(name = "CABLE_SELF_ASSOC_SPEC_ID", length = 50)
	private java.math.BigDecimal cableSelfAssocSpecId;

	@Column(name = "CREATED_BY", nullable = false, length = 40)
	private String createdBy;

	@Column(name = "CREATED_DATE", nullable = false)
	private Timestamp createdDate;

	@Column(name = "LAST_MODIFIED_BY", length = 40)
	private String lastModifiedBy;

	@Column(name = "LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	// bi-directional many-to-one association to CableSection
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CHILD_CS_NAME")
	private CableSection childCsName;

	// bi-directional many-to-one association to CableSection
	@ManyToOne
	@JoinColumn(name = "PARENT_CS_NAME")
	private CableSection parentCsName;

	public CableSectionSelfAssoc() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public java.math.BigDecimal getCableSelfAssocSpecId() {
		return this.cableSelfAssocSpecId;
	}

	public void setCableSelfAssocSpecId(
			java.math.BigDecimal cableSelfAssocSpecId) {
		this.cableSelfAssocSpecId = cableSelfAssocSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public CableSection getChildCsName() {
		return childCsName;
	}

	public void setChildCsName(CableSection childCsName) {
		this.childCsName = childCsName;
	}

	public CableSection getParentCsName() {
		return parentCsName;
	}

	public void setParentCsName(CableSection parentCsName) {
		this.parentCsName = parentCsName;
	}

}