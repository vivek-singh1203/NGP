package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the ENTITY_TYPE_CHAR_SET database table.
 * 
 */
@javax.persistence.Entity
@Table(name="ENTITY_TYPE_CHAR_SET")
@NamedQuery(name="EntityTypeCharSet.findAll", query="SELECT e FROM EntityTypeCharSet e")
public class EntityTypeCharSet implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CHAR_SPEC_NAME", length=30)
	private String charSpecName;

	@Column(name="CHAR_VALUE_SPEC_ID", length=50)
	private String charValueSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	//bi-directional many-to-one association to EntityCharCategory
	@ManyToOne
	@JoinColumn(name="CHAR_CATEGORY_NAME")
	private EntityCharCategory entityCharCategory;

	//bi-directional many-to-one association to Entity
	@ManyToOne
	@JoinColumn(name="ENTITY_NAME")
	private Entity entity;

	public EntityTypeCharSet() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCharSpecName() {
		return this.charSpecName;
	}

	public void setCharSpecName(String charSpecName) {
		this.charSpecName = charSpecName;
	}

	public String getCharValueSpecId() {
		return this.charValueSpecId;
	}

	public void setCharValueSpecId(String charValueSpecId) {
		this.charValueSpecId = charValueSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public EntityCharCategory getEntityCharCategory() {
		return this.entityCharCategory;
	}

	public void setEntityCharCategory(EntityCharCategory entityCharCategory) {
		this.entityCharCategory = entityCharCategory;
	}

	public Entity getEntity() {
		return this.entity;
	}

	public void setEntity(Entity entity) {
		this.entity = entity;
	}

}