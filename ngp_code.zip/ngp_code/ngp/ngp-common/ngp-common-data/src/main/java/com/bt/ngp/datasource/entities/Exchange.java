package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the EXCHANGES database table.
 * 
 */
@javax.persistence.Entity
@Table(name="EXCHANGES")
@NamedQuery(name="Exchange.findAll", query="SELECT e FROM Exchange e")
public class Exchange implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="EXCHANGE_1141_CODE", unique=true, nullable=false, length=25)
	private String exchange1141Code;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DISTRICT_ID", length=10)
	private String districtId;

	@Column(name="DISTRICT_NAME", length=30)
	private String districtName;

	@Column(name="EXCHANGE_CODE", length=10)
	private String exchangeCode;

	@Column(name="EXCHANGE_NAME", nullable=false, length=30)
	private String exchangeName;

	@Column(name="EXCHANGE_TYPE", length=10)
	private String exchangeType;

	/*@Column(name="GEO_POSITION")
 private Object geoPosition; */

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(length=30)
	private String region;

	//bi-directional many-to-one association to Cabinet
	@OneToMany(mappedBy="exchange")
	private List<Cabinet> cabinets;

	//bi-directional many-to-one association to CableSection
	@OneToMany(mappedBy="exchange")
	private List<CableSection> cableSections;

	//bi-directional many-to-one association to Conductor
	@OneToMany(mappedBy="exchange")
	private List<Conductor> conductors;

	//bi-directional many-to-one association to ConductorBundle
	@OneToMany(mappedBy="exchange")
	private List<ConductorBundle> conductorBundles;

	//bi-directional many-to-one association to CrossConnectPoint
	@OneToMany(mappedBy="exchange")
	private List<CrossConnectPoint> crossConnectPoints;

	//bi-directional many-to-one association to CustomerPremiseEquipment
	@OneToMany(mappedBy="exchange")
	private List<CustomerPremiseEquipment> customerPremiseEquipments;

	//bi-directional many-to-one association to DistributionFrame
	@OneToMany(mappedBy="exchange")
	private List<DistributionFrame> distributionFrames;

	//bi-directional many-to-one association to DistributionPoint
	@OneToMany(mappedBy="exchange")
	private List<DistributionPoint> distributionPoints;

	//bi-directional many-to-one association to Dslam
	@OneToMany(mappedBy="exchange")
	private List<Dslam> dslams;

	//bi-directional many-to-one association to Enclosure
	@OneToMany(mappedBy="exchange")
	private List<Enclosure> enclosures;

	//bi-directional many-to-one association to JointingChamber
	@OneToMany(mappedBy="exchange")
	private List<JointingChamber> jointingChambers;

	//bi-directional many-to-one association to JointClosure
	@OneToMany(mappedBy="exchange")
	private List<JointClosure> jointClosures;

	//bi-directional many-to-one association to MultiFunctionalNode
	@OneToMany(mappedBy="exchange")
	private List<MultiFunctionalNode> multiFunctionalNodes;

	//bi-directional many-to-one association to NetworkTerminatingEquipment
	@OneToMany(mappedBy="exchange")
	private List<NetworkTerminatingEquipment> networkTerminatingEquipments;

	//bi-directional many-to-one association to SpanSection
	@OneToMany(mappedBy="exchange")
	private List<SpanSection> spanSections;

	//bi-directional many-to-one association to Structure
	@OneToMany(mappedBy="exchange")
	private List<Structure> structures;
	
	//bi-directional many-to-one association to Structure
	@OneToMany(mappedBy="exchange")
	private List<Pole> poles;

	//bi-directional many-to-one association to WirelessEquipment
	@OneToMany(mappedBy="exchange")
	private List<WirelessEquipment> wirelessEquipments;

	public Exchange() {
	}

	public String getExchange1141Code() {
		return this.exchange1141Code;
	}

	public void setExchange1141Code(String exchange1141Code) {
		this.exchange1141Code = exchange1141Code;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDistrictId() {
		return this.districtId;
	}

	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}

	public String getDistrictName() {
		return this.districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	public String getExchangeCode() {
		return this.exchangeCode;
	}

	public void setExchangeCode(String exchangeCode) {
		this.exchangeCode = exchangeCode;
	}

	public String getExchangeName() {
		return this.exchangeName;
	}

	public void setExchangeName(String exchangeName) {
		this.exchangeName = exchangeName;
	}

	public String getExchangeType() {
		return this.exchangeType;
	}

	public void setExchangeType(String exchangeType) {
		this.exchangeType = exchangeType;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getRegion() {
		return this.region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public List<Cabinet> getCabinets() {
		return this.cabinets;
	}

	public void setCabinets(List<Cabinet> cabinets) {
		this.cabinets = cabinets;
	}

	public Cabinet addCabinet(Cabinet cabinet) {
		getCabinets().add(cabinet);
		cabinet.setExchange(this);

		return cabinet;
	}

	public List<Pole> getPoles() {
		return poles;
	}

	public void setPoles(List<Pole> poles) {
		this.poles = poles;
	}

	public Cabinet removeCabinet(Cabinet cabinet) {
		getCabinets().remove(cabinet);
		cabinet.setExchange(null);

		return cabinet;
	}

	public List<CableSection> getCableSections() {
		return this.cableSections;
	}

	public void setCableSections(List<CableSection> cableSections) {
		this.cableSections = cableSections;
	}

	public CableSection addCableSection(CableSection cableSection) {
		getCableSections().add(cableSection);
		cableSection.setExchange(this);

		return cableSection;
	}

	public CableSection removeCableSection(CableSection cableSection) {
		getCableSections().remove(cableSection);
		cableSection.setExchange(null);

		return cableSection;
	}

	public List<Conductor> getConductors() {
		return this.conductors;
	}

	public void setConductors(List<Conductor> conductors) {
		this.conductors = conductors;
	}

	public Conductor addConductor(Conductor conductor) {
		getConductors().add(conductor);
		conductor.setExchange(this);

		return conductor;
	}

	public Conductor removeConductor(Conductor conductor) {
		getConductors().remove(conductor);
		conductor.setExchange(null);

		return conductor;
	}

	public List<ConductorBundle> getConductorBundles() {
		return this.conductorBundles;
	}

	public void setConductorBundles(List<ConductorBundle> conductorBundles) {
		this.conductorBundles = conductorBundles;
	}

	public ConductorBundle addConductorBundle(ConductorBundle conductorBundle) {
		getConductorBundles().add(conductorBundle);
		conductorBundle.setExchange(this);

		return conductorBundle;
	}

	public ConductorBundle removeConductorBundle(ConductorBundle conductorBundle) {
		getConductorBundles().remove(conductorBundle);
		conductorBundle.setExchange(null);

		return conductorBundle;
	}

	public List<CrossConnectPoint> getCrossConnectPoints() {
		return this.crossConnectPoints;
	}

	public void setCrossConnectPoints(List<CrossConnectPoint> crossConnectPoints) {
		this.crossConnectPoints = crossConnectPoints;
	}

	public CrossConnectPoint addCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		getCrossConnectPoints().add(crossConnectPoint);
		crossConnectPoint.setExchange(this);

		return crossConnectPoint;
	}

	public CrossConnectPoint removeCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		getCrossConnectPoints().remove(crossConnectPoint);
		crossConnectPoint.setExchange(null);

		return crossConnectPoint;
	}

	public List<CustomerPremiseEquipment> getCustomerPremiseEquipments() {
		return this.customerPremiseEquipments;
	}

	public void setCustomerPremiseEquipments(List<CustomerPremiseEquipment> customerPremiseEquipments) {
		this.customerPremiseEquipments = customerPremiseEquipments;
	}

	public CustomerPremiseEquipment addCustomerPremiseEquipment(CustomerPremiseEquipment customerPremiseEquipment) {
		getCustomerPremiseEquipments().add(customerPremiseEquipment);
		customerPremiseEquipment.setExchange(this);

		return customerPremiseEquipment;
	}

	public CustomerPremiseEquipment removeCustomerPremiseEquipment(CustomerPremiseEquipment customerPremiseEquipment) {
		getCustomerPremiseEquipments().remove(customerPremiseEquipment);
		customerPremiseEquipment.setExchange(null);

		return customerPremiseEquipment;
	}

	public List<DistributionFrame> getDistributionFrames() {
		return this.distributionFrames;
	}

	public void setDistributionFrames(List<DistributionFrame> distributionFrames) {
		this.distributionFrames = distributionFrames;
	}

	public DistributionFrame addDistributionFrame(DistributionFrame distributionFrame) {
		getDistributionFrames().add(distributionFrame);
		distributionFrame.setExchange(this);

		return distributionFrame;
	}

	public DistributionFrame removeDistributionFrame(DistributionFrame distributionFrame) {
		getDistributionFrames().remove(distributionFrame);
		distributionFrame.setExchange(null);

		return distributionFrame;
	}

	public List<DistributionPoint> getDistributionPoints() {
		return this.distributionPoints;
	}

	public void setDistributionPoints(List<DistributionPoint> distributionPoints) {
		this.distributionPoints = distributionPoints;
	}

	public DistributionPoint addDistributionPoint(DistributionPoint distributionPoint) {
		getDistributionPoints().add(distributionPoint);
		distributionPoint.setExchange(this);

		return distributionPoint;
	}

	public DistributionPoint removeDistributionPoint(DistributionPoint distributionPoint) {
		getDistributionPoints().remove(distributionPoint);
		distributionPoint.setExchange(null);

		return distributionPoint;
	}

	public List<Dslam> getDslams() {
		return this.dslams;
	}

	public void setDslams(List<Dslam> dslams) {
		this.dslams = dslams;
	}

	public Dslam addDslam(Dslam dslam) {
		getDslams().add(dslam);
		dslam.setExchange(this);

		return dslam;
	}

	public Dslam removeDslam(Dslam dslam) {
		getDslams().remove(dslam);
		dslam.setExchange(null);

		return dslam;
	}

	public List<Enclosure> getEnclosures() {
		return this.enclosures;
	}

	public void setEnclosures(List<Enclosure> enclosures) {
		this.enclosures = enclosures;
	}

	public Enclosure addEnclosure(Enclosure enclosure) {
		getEnclosures().add(enclosure);
		enclosure.setExchange(this);

		return enclosure;
	}

	public Enclosure removeEnclosure(Enclosure enclosure) {
		getEnclosures().remove(enclosure);
		enclosure.setExchange(null);

		return enclosure;
	}

	public List<JointingChamber> getJointingChambers() {
		return this.jointingChambers;
	}

	public void setJointingChambers(List<JointingChamber> jointingChambers) {
		this.jointingChambers = jointingChambers;
	}

	public JointingChamber addJointingChamber(JointingChamber jointingChamber) {
		getJointingChambers().add(jointingChamber);
		jointingChamber.setExchange(this);

		return jointingChamber;
	}

	public JointingChamber removeJointingChamber(JointingChamber jointingChamber) {
		getJointingChambers().remove(jointingChamber);
		jointingChamber.setExchange(null);

		return jointingChamber;
	}

	public List<JointClosure> getJointClosures() {
		return this.jointClosures;
	}

	public void setJointClosures(List<JointClosure> jointClosures) {
		this.jointClosures = jointClosures;
	}

	public JointClosure addJointClosure(JointClosure jointClosure) {
		getJointClosures().add(jointClosure);
		jointClosure.setExchange(this);

		return jointClosure;
	}

	public JointClosure removeJointClosure(JointClosure jointClosure) {
		getJointClosures().remove(jointClosure);
		jointClosure.setExchange(null);

		return jointClosure;
	}

	public List<MultiFunctionalNode> getMultiFunctionalNodes() {
		return this.multiFunctionalNodes;
	}

	public void setMultiFunctionalNodes(List<MultiFunctionalNode> multiFunctionalNodes) {
		this.multiFunctionalNodes = multiFunctionalNodes;
	}

	public MultiFunctionalNode addMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		getMultiFunctionalNodes().add(multiFunctionalNode);
		multiFunctionalNode.setExchange(this);

		return multiFunctionalNode;
	}

	public MultiFunctionalNode removeMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		getMultiFunctionalNodes().remove(multiFunctionalNode);
		multiFunctionalNode.setExchange(null);

		return multiFunctionalNode;
	}

	public List<NetworkTerminatingEquipment> getNetworkTerminatingEquipments() {
		return this.networkTerminatingEquipments;
	}

	public void setNetworkTerminatingEquipments(List<NetworkTerminatingEquipment> networkTerminatingEquipments) {
		this.networkTerminatingEquipments = networkTerminatingEquipments;
	}

	public NetworkTerminatingEquipment addNetworkTerminatingEquipment(NetworkTerminatingEquipment networkTerminatingEquipment) {
		getNetworkTerminatingEquipments().add(networkTerminatingEquipment);
		networkTerminatingEquipment.setExchange(this);

		return networkTerminatingEquipment;
	}

	public NetworkTerminatingEquipment removeNetworkTerminatingEquipment(NetworkTerminatingEquipment networkTerminatingEquipment) {
		getNetworkTerminatingEquipments().remove(networkTerminatingEquipment);
		networkTerminatingEquipment.setExchange(null);

		return networkTerminatingEquipment;
	}

	public List<SpanSection> getSpanSections() {
		return this.spanSections;
	}

	public void setSpanSections(List<SpanSection> spanSections) {
		this.spanSections = spanSections;
	}

	public SpanSection addSpanSection(SpanSection spanSection) {
		getSpanSections().add(spanSection);
		spanSection.setExchange(this);

		return spanSection;
	}

	public SpanSection removeSpanSection(SpanSection spanSection) {
		getSpanSections().remove(spanSection);
		spanSection.setExchange(null);

		return spanSection;
	}

	public List<Structure> getStructures() {
		return this.structures;
	}

	public void setStructures(List<Structure> structures) {
		this.structures = structures;
	}

	public Structure addStructure(Structure structure) {
		getStructures().add(structure);
		structure.setExchange(this);

		return structure;
	}

	public Structure removeStructure(Structure structure) {
		getStructures().remove(structure);
		structure.setExchange(null);

		return structure;
	}

	public List<WirelessEquipment> getWirelessEquipments() {
		return this.wirelessEquipments;
	}

	public void setWirelessEquipments(List<WirelessEquipment> wirelessEquipments) {
		this.wirelessEquipments = wirelessEquipments;
	}

	public WirelessEquipment addWirelessEquipment(WirelessEquipment wirelessEquipment) {
		getWirelessEquipments().add(wirelessEquipment);
		wirelessEquipment.setExchange(this);

		return wirelessEquipment;
	}

	public WirelessEquipment removeWirelessEquipment(WirelessEquipment wirelessEquipment) {
		getWirelessEquipments().remove(wirelessEquipment);
		wirelessEquipment.setExchange(null);

		return wirelessEquipment;
	}

}