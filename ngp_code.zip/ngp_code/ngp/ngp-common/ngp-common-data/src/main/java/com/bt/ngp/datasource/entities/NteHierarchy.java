package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the NTE_HIERARCHY database table.
 * 
 */
@javax.persistence.Entity
@Table(name="NTE_HIERARCHY")
@NamedQuery(name="NteHierarchy.findAll", query="SELECT n FROM NteHierarchy n")
public class NteHierarchy implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="EQ_HIERARCHY_SPEC_ID", length=50)
	private String eqHierarchySpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LEG_ID", precision=38)
	private BigDecimal legId;

	@Column(name="NTE_POS_END_NUM", nullable=false, precision=38)
	private BigDecimal ntePosEndNum;

	@Column(name="NTE_POS_START_NUM", nullable=false, precision=38)
	private BigDecimal ntePosStartNum;

	//bi-directional many-to-one association to NteChassisPhAssoc
	@ManyToOne
	@JoinColumn(name="CHASSIS_PH_ASSOC_ID")
	private NteChassisPhAssoc nteChassisPhAssoc;

	//bi-directional many-to-one association to NetworkTerminatingEquipment
	@ManyToOne
	@JoinColumn(name="NTE_NAME")
	private NetworkTerminatingEquipment networkTerminatingEquipment;

	//bi-directional many-to-one association to NtePhPluginAssoc
	@ManyToOne
	@JoinColumn(name="PH_PLUGIN_ASSOC_ID")
	private NtePhPluginAssoc ntePhPluginAssoc;

	//bi-directional many-to-one association to NtePluginPortAssoc
	@ManyToOne
	@JoinColumn(name="PLUGIN_PORT_ASSOC_ID")
	private NtePluginPortAssoc ntePluginPortAssoc;

	public NteHierarchy() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEqHierarchySpecId() {
		return this.eqHierarchySpecId;
	}

	public void setEqHierarchySpecId(String eqHierarchySpecId) {
		this.eqHierarchySpecId = eqHierarchySpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getLegId() {
		return this.legId;
	}

	public void setLegId(BigDecimal legId) {
		this.legId = legId;
	}

	public BigDecimal getNtePosEndNum() {
		return this.ntePosEndNum;
	}

	public void setNtePosEndNum(BigDecimal ntePosEndNum) {
		this.ntePosEndNum = ntePosEndNum;
	}

	public BigDecimal getNtePosStartNum() {
		return this.ntePosStartNum;
	}

	public void setNtePosStartNum(BigDecimal ntePosStartNum) {
		this.ntePosStartNum = ntePosStartNum;
	}

	public NteChassisPhAssoc getNteChassisPhAssoc() {
		return this.nteChassisPhAssoc;
	}

	public void setNteChassisPhAssoc(NteChassisPhAssoc nteChassisPhAssoc) {
		this.nteChassisPhAssoc = nteChassisPhAssoc;
	}

	public NetworkTerminatingEquipment getNetworkTerminatingEquipment() {
		return this.networkTerminatingEquipment;
	}

	public void setNetworkTerminatingEquipment(NetworkTerminatingEquipment networkTerminatingEquipment) {
		this.networkTerminatingEquipment = networkTerminatingEquipment;
	}

	public NtePhPluginAssoc getNtePhPluginAssoc() {
		return this.ntePhPluginAssoc;
	}

	public void setNtePhPluginAssoc(NtePhPluginAssoc ntePhPluginAssoc) {
		this.ntePhPluginAssoc = ntePhPluginAssoc;
	}

	public NtePluginPortAssoc getNtePluginPortAssoc() {
		return this.ntePluginPortAssoc;
	}

	public void setNtePluginPortAssoc(NtePluginPortAssoc ntePluginPortAssoc) {
		this.ntePluginPortAssoc = ntePluginPortAssoc;
	}

}