package com.bt.ngp.common.data.jpa.repository;

import org.springframework.stereotype.Repository;
import com.bt.ngp.datasource.entities.DfPortChar;

@Repository
public interface DfPortCharRepository extends SqlRepository<DfPortChar> {
	
}