package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the NTE_CHASSIS_PH_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="NTE_CHASSIS_PH_ASSOC")
@NamedQuery(name="NteChassisPhAssoc.findAll", query="SELECT n FROM NteChassisPhAssoc n")
public class NteChassisPhAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="COMP_HOLDER_ASSOC_SPEC_ID", length=50)
	private String compHolderAssocSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="END_POSITION_NUM", nullable=false, precision=38)
	private BigDecimal endPositionNum;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="START_POSITION_NUM", nullable=false, precision=38)
	private BigDecimal startPositionNum;

	//bi-directional many-to-one association to Chassi
	@ManyToOne
	@JoinColumn(name="CHASSIS_NAME")
	private Chassi chassi;

	//bi-directional many-to-one association to NetworkTerminatingEquipment
	@ManyToOne
	@JoinColumn(name="NTE_NAME")
	private NetworkTerminatingEquipment networkTerminatingEquipment;

	//bi-directional many-to-one association to PluginHolder
	@ManyToOne
	@JoinColumn(name="PH_NAME")
	private PluginHolder pluginHolder;

	//bi-directional many-to-one association to NteHierarchy
	@OneToMany(mappedBy="nteChassisPhAssoc")
	private List<NteHierarchy> nteHierarchies;

	public NteChassisPhAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompHolderAssocSpecId() {
		return this.compHolderAssocSpecId;
	}

	public void setCompHolderAssocSpecId(String compHolderAssocSpecId) {
		this.compHolderAssocSpecId = compHolderAssocSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public BigDecimal getEndPositionNum() {
		return this.endPositionNum;
	}

	public void setEndPositionNum(BigDecimal endPositionNum) {
		this.endPositionNum = endPositionNum;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getStartPositionNum() {
		return this.startPositionNum;
	}

	public void setStartPositionNum(BigDecimal startPositionNum) {
		this.startPositionNum = startPositionNum;
	}

	public Chassi getChassi() {
		return this.chassi;
	}

	public void setChassi(Chassi chassi) {
		this.chassi = chassi;
	}

	public NetworkTerminatingEquipment getNetworkTerminatingEquipment() {
		return this.networkTerminatingEquipment;
	}

	public void setNetworkTerminatingEquipment(NetworkTerminatingEquipment networkTerminatingEquipment) {
		this.networkTerminatingEquipment = networkTerminatingEquipment;
	}

	public PluginHolder getPluginHolder() {
		return this.pluginHolder;
	}

	public void setPluginHolder(PluginHolder pluginHolder) {
		this.pluginHolder = pluginHolder;
	}

	public List<NteHierarchy> getNteHierarchies() {
		return this.nteHierarchies;
	}

	public void setNteHierarchies(List<NteHierarchy> nteHierarchies) {
		this.nteHierarchies = nteHierarchies;
	}

	public NteHierarchy addNteHierarchy(NteHierarchy nteHierarchy) {
		getNteHierarchies().add(nteHierarchy);
		nteHierarchy.setNteChassisPhAssoc(this);

		return nteHierarchy;
	}

	public NteHierarchy removeNteHierarchy(NteHierarchy nteHierarchy) {
		getNteHierarchies().remove(nteHierarchy);
		nteHierarchy.setNteChassisPhAssoc(null);

		return nteHierarchy;
	}

}