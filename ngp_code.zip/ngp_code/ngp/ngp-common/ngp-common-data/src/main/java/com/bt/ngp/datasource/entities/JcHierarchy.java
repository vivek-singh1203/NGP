package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the JC_HIERARCHY database table.
 * 
 */
@javax.persistence.Entity
@Table(name="JC_HIERARCHY")
@NamedQuery(name="JcHierarchy.findAll", query="SELECT j FROM JcHierarchy j")
public class JcHierarchy implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="EQ_HIERARCHY_SPEC_ID", length=50)
	private String eqHierarchySpecId;

	@Column(name="JC_POS_END_NUM", nullable=false, precision=38)
	private BigDecimal jcPosEndNum;

	@Column(name="JC_POS_START_NUM", nullable=false, precision=38)
	private BigDecimal jcPosStartNum;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LEG_ID", precision=38)
	private BigDecimal legId;

	//bi-directional many-to-one association to JcChassisPhAssoc
	@ManyToOne
	@JoinColumn(name="CHASSIS_PH_ASSOC_ID")
	private JcChassisPhAssoc jcChassisPhAssoc;

	//bi-directional many-to-one association to JointClosure
	@ManyToOne
	@JoinColumn(name="JC_NAME")
	private JointClosure jointClosure;

	//bi-directional many-to-one association to JcPhPluginAssoc
	@ManyToOne
	@JoinColumn(name="PH_PLUGIN_ASSOC_ID")
	private JcPhPluginAssoc jcPhPluginAssoc;

	//bi-directional many-to-one association to JcPluginPortAssoc
	@ManyToOne
	@JoinColumn(name="PLUGIN_PORT_ASSOC_ID")
	private JcPluginPortAssoc jcPluginPortAssoc;

	public JcHierarchy() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEqHierarchySpecId() {
		return this.eqHierarchySpecId;
	}

	public void setEqHierarchySpecId(String eqHierarchySpecId) {
		this.eqHierarchySpecId = eqHierarchySpecId;
	}

	public BigDecimal getJcPosEndNum() {
		return this.jcPosEndNum;
	}

	public void setJcPosEndNum(BigDecimal jcPosEndNum) {
		this.jcPosEndNum = jcPosEndNum;
	}

	public BigDecimal getJcPosStartNum() {
		return this.jcPosStartNum;
	}

	public void setJcPosStartNum(BigDecimal jcPosStartNum) {
		this.jcPosStartNum = jcPosStartNum;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getLegId() {
		return this.legId;
	}

	public void setLegId(BigDecimal legId) {
		this.legId = legId;
	}

	public JcChassisPhAssoc getJcChassisPhAssoc() {
		return this.jcChassisPhAssoc;
	}

	public void setJcChassisPhAssoc(JcChassisPhAssoc jcChassisPhAssoc) {
		this.jcChassisPhAssoc = jcChassisPhAssoc;
	}

	public JointClosure getJointClosure() {
		return this.jointClosure;
	}

	public void setJointClosure(JointClosure jointClosure) {
		this.jointClosure = jointClosure;
	}

	public JcPhPluginAssoc getJcPhPluginAssoc() {
		return this.jcPhPluginAssoc;
	}

	public void setJcPhPluginAssoc(JcPhPluginAssoc jcPhPluginAssoc) {
		this.jcPhPluginAssoc = jcPhPluginAssoc;
	}

	public JcPluginPortAssoc getJcPluginPortAssoc() {
		return this.jcPluginPortAssoc;
	}

	public void setJcPluginPortAssoc(JcPluginPortAssoc jcPluginPortAssoc) {
		this.jcPluginPortAssoc = jcPluginPortAssoc;
	}

}