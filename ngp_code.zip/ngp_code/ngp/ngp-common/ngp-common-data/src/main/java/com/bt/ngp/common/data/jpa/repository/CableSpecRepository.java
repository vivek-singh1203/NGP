/**
 * 
 */
package com.bt.ngp.common.data.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.spec.CableSpec;
import com.bt.ngp.datasource.spec.CableSpecPK;

/**
 * @author 611174701
 *
 */
@Repository
public interface CableSpecRepository extends JpaRepository<CableSpec, CableSpecPK> {

	public CableSpec findByCableSpecPKIdName(@Param("name")String name);
}
