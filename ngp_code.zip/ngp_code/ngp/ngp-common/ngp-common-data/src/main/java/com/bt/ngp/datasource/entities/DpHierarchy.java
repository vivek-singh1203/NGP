package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the DP_HIERARCHY database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DP_HIERARCHY")
@NamedQuery(name="DpHierarchy.findAll", query="SELECT d FROM DpHierarchy d")
public class DpHierarchy implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DP_POS_END_NUM", nullable=false, precision=38)
	private BigDecimal dpPosEndNum;

	@Column(name="DP_POS_START_NUM", nullable=false, precision=38)
	private BigDecimal dpPosStartNum;

	@Column(name="EQ_HIERARCHY_SPEC_ID", length=50)
	private String eqHierarchySpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LEG_ID", precision=38)
	private BigDecimal legId;

	//bi-directional many-to-one association to DpChassisPhAssoc
	@ManyToOne
	@JoinColumn(name="CHASSIS_PH_ASSOC_ID")
	private DpChassisPhAssoc dpChassisPhAssoc;

	//bi-directional many-to-one association to DistributionPoint
	@ManyToOne
	@JoinColumn(name="DP_NAME")
	private DistributionPoint distributionPoint;

	//bi-directional many-to-one association to DpPhPluginAssoc
	@ManyToOne
	@JoinColumn(name="PH_PLUGIN_ASSOC_ID")
	private DpPhPluginAssoc dpPhPluginAssoc;

	//bi-directional many-to-one association to DpPluginPortAssoc
	@ManyToOne
	@JoinColumn(name="PLUGIN_PORT_ASSOC_ID")
	private DpPluginPortAssoc dpPluginPortAssoc;

	public DpHierarchy() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public BigDecimal getDpPosEndNum() {
		return this.dpPosEndNum;
	}

	public void setDpPosEndNum(BigDecimal dpPosEndNum) {
		this.dpPosEndNum = dpPosEndNum;
	}

	public BigDecimal getDpPosStartNum() {
		return this.dpPosStartNum;
	}

	public void setDpPosStartNum(BigDecimal dpPosStartNum) {
		this.dpPosStartNum = dpPosStartNum;
	}

	public String getEqHierarchySpecId() {
		return this.eqHierarchySpecId;
	}

	public void setEqHierarchySpecId(String eqHierarchySpecId) {
		this.eqHierarchySpecId = eqHierarchySpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getLegId() {
		return this.legId;
	}

	public void setLegId(BigDecimal legId) {
		this.legId = legId;
	}

	public DpChassisPhAssoc getDpChassisPhAssoc() {
		return this.dpChassisPhAssoc;
	}

	public void setDpChassisPhAssoc(DpChassisPhAssoc dpChassisPhAssoc) {
		this.dpChassisPhAssoc = dpChassisPhAssoc;
	}

	public DistributionPoint getDistributionPoint() {
		return this.distributionPoint;
	}

	public void setDistributionPoint(DistributionPoint distributionPoint) {
		this.distributionPoint = distributionPoint;
	}

	public DpPhPluginAssoc getDpPhPluginAssoc() {
		return this.dpPhPluginAssoc;
	}

	public void setDpPhPluginAssoc(DpPhPluginAssoc dpPhPluginAssoc) {
		this.dpPhPluginAssoc = dpPhPluginAssoc;
	}

	public DpPluginPortAssoc getDpPluginPortAssoc() {
		return this.dpPluginPortAssoc;
	}

	public void setDpPluginPortAssoc(DpPluginPortAssoc dpPluginPortAssoc) {
		this.dpPluginPortAssoc = dpPluginPortAssoc;
	}

}