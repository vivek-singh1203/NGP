package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.JointClosure;
import com.bt.ngp.datasource.entities.WePort;
import com.bt.ngp.datasource.spec.PortSpec;
import com.bt.ngp.datasource.spec.PortSpecPK;

@Repository
public interface PortSpecRepository extends JpaRepository<PortSpec, PortSpecPK> {
	
	public PortSpec findByPortSpecPKIdName(String name);
	
}