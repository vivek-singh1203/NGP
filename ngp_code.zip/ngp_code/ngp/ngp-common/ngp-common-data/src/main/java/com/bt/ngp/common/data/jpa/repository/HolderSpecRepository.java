package com.bt.ngp.common.data.jpa.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.spec.EqSpec;
import com.bt.ngp.datasource.spec.EqSpecPK;
import com.bt.ngp.datasource.spec.HolderSpec;
import com.bt.ngp.datasource.spec.HolderSpecPK;

@Repository
public interface HolderSpecRepository extends JpaRepository<HolderSpec,HolderSpecPK>{

	
	public HolderSpec findByHolderSpecPKIdName(@Param("name")String name);

}
