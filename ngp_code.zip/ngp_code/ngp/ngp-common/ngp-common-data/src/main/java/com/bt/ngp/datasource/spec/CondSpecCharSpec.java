package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the COND_SPEC_CHAR_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="COND_SPEC_CHAR_SPEC")
@NamedQuery(name="CondSpecCharSpec.findAll", query="SELECT c FROM CondSpecCharSpec c")
public class CondSpecCharSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CAN_BE_OVERRIDEN", nullable=false)
	private BigDecimal canBeOverriden;

	@Column(name="CHAR_SPEC_CATEGORY_NAME", length=30)
	private String charSpecCategoryName;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(length=40)
	private String description;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(name="IS_UNIQUE_WHEN_PRESENT")
	private BigDecimal isUniqueWhenPresent;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="MAX_CARDINALITY")
	private BigDecimal maxCardinality;

	@Column(name="MIN_CARDINALITY")
	private BigDecimal minCardinality;

	@Column(nullable=false, length=30)
	private String name;

	@Column(length=50)
	private String remarks;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	@Column(name="VALUE_TYPE", nullable=false, length=30)
	private String valueType;

	//bi-directional many-to-one association to CondSpecCharValueSpec
	@ManyToOne
	@JoinColumn(name="CHAR_VALUE_SPEC_ID")
	private CondSpecCharValueSpec condSpecCharValueSpec;

	//bi-directional many-to-one association to ConductorSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="COND_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="COND_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private ConductorSpec conductorSpec;

	//bi-directional many-to-one association to EntityCharSpec
	@ManyToOne
	@JoinColumn(name="ENTITY_CHAR_SPEC_NAME")
	private EntityCharSpec entityCharSpec;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to CondSpecCharSpecRel
	@OneToMany(mappedBy="condSpecCharSpec1")
	private List<CondSpecCharSpecRel> condSpecCharSpecRels1;

	//bi-directional many-to-one association to CondSpecCharSpecRel
	@OneToMany(mappedBy="condSpecCharSpec2")
	private List<CondSpecCharSpecRel> condSpecCharSpecRels2;

	public CondSpecCharSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public BigDecimal getCanBeOverriden() {
		return this.canBeOverriden;
	}

	public void setCanBeOverriden(BigDecimal canBeOverriden) {
		this.canBeOverriden = canBeOverriden;
	}

	public String getCharSpecCategoryName() {
		return this.charSpecCategoryName;
	}

	public void setCharSpecCategoryName(String charSpecCategoryName) {
		this.charSpecCategoryName = charSpecCategoryName;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public BigDecimal getIsUniqueWhenPresent() {
		return this.isUniqueWhenPresent;
	}

	public void setIsUniqueWhenPresent(BigDecimal isUniqueWhenPresent) {
		this.isUniqueWhenPresent = isUniqueWhenPresent;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getMaxCardinality() {
		return this.maxCardinality;
	}

	public void setMaxCardinality(BigDecimal maxCardinality) {
		this.maxCardinality = maxCardinality;
	}

	public BigDecimal getMinCardinality() {
		return this.minCardinality;
	}

	public void setMinCardinality(BigDecimal minCardinality) {
		this.minCardinality = minCardinality;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public String getValueType() {
		return this.valueType;
	}

	public void setValueType(String valueType) {
		this.valueType = valueType;
	}

	public CondSpecCharValueSpec getCondSpecCharValueSpec() {
		return this.condSpecCharValueSpec;
	}

	public void setCondSpecCharValueSpec(CondSpecCharValueSpec condSpecCharValueSpec) {
		this.condSpecCharValueSpec = condSpecCharValueSpec;
	}

	public ConductorSpec getConductorSpec() {
		return this.conductorSpec;
	}

	public void setConductorSpec(ConductorSpec conductorSpec) {
		this.conductorSpec = conductorSpec;
	}

	public EntityCharSpec getEntityCharSpec() {
		return this.entityCharSpec;
	}

	public void setEntityCharSpec(EntityCharSpec entityCharSpec) {
		this.entityCharSpec = entityCharSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public List<CondSpecCharSpecRel> getCondSpecCharSpecRels1() {
		return this.condSpecCharSpecRels1;
	}

	public void setCondSpecCharSpecRels1(List<CondSpecCharSpecRel> condSpecCharSpecRels1) {
		this.condSpecCharSpecRels1 = condSpecCharSpecRels1;
	}

	public CondSpecCharSpecRel addCondSpecCharSpecRels1(CondSpecCharSpecRel condSpecCharSpecRels1) {
		getCondSpecCharSpecRels1().add(condSpecCharSpecRels1);
		condSpecCharSpecRels1.setCondSpecCharSpec1(this);

		return condSpecCharSpecRels1;
	}

	public CondSpecCharSpecRel removeCondSpecCharSpecRels1(CondSpecCharSpecRel condSpecCharSpecRels1) {
		getCondSpecCharSpecRels1().remove(condSpecCharSpecRels1);
		condSpecCharSpecRels1.setCondSpecCharSpec1(null);

		return condSpecCharSpecRels1;
	}

	public List<CondSpecCharSpecRel> getCondSpecCharSpecRels2() {
		return this.condSpecCharSpecRels2;
	}

	public void setCondSpecCharSpecRels2(List<CondSpecCharSpecRel> condSpecCharSpecRels2) {
		this.condSpecCharSpecRels2 = condSpecCharSpecRels2;
	}

	public CondSpecCharSpecRel addCondSpecCharSpecRels2(CondSpecCharSpecRel condSpecCharSpecRels2) {
		getCondSpecCharSpecRels2().add(condSpecCharSpecRels2);
		condSpecCharSpecRels2.setCondSpecCharSpec2(this);

		return condSpecCharSpecRels2;
	}

	public CondSpecCharSpecRel removeCondSpecCharSpecRels2(CondSpecCharSpecRel condSpecCharSpecRels2) {
		getCondSpecCharSpecRels2().remove(condSpecCharSpecRels2);
		condSpecCharSpecRels2.setCondSpecCharSpec2(null);

		return condSpecCharSpecRels2;
	}

}