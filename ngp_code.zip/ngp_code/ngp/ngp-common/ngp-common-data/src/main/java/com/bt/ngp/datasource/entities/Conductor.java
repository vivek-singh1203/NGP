package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the CONDUCTOR database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CONDUCTOR")
@NamedQuery(name="Conductor.findAll", query="SELECT c FROM Conductor c")
public class Conductor implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CALCULATED_LENGTH", precision=126)
	private double calculatedLength;

	@Column(name="CALCULATED_LENGTH_UNIT", length=10)
	private String calculatedLengthUnit;

	@Column(name="CONDUCTOR_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal conductorSeqNum;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	/*@Column(name="GEO_POSITION", nullable=false)
	 private Object geoPosition; */

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="MEASURED_LENGTH", precision=126)
	private double measuredLength;

	@Column(name="MEASURED_LENGTH_UNIT", length=10)
	private String measuredLengthUnit;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	@Column(name="UTILISATION_STATE", length=20)
	private String utilisationState;

	//bi-directional many-to-one association to CableSectionHierarchy
	@OneToMany(mappedBy="conductor",fetch=FetchType.LAZY)
	private List<CableSectionHierarchy> cableSectionHierarchies;

	//bi-directional many-to-one association to CcpCableConductorSplicing
	@OneToMany(mappedBy="origCondName",fetch=FetchType.LAZY)
	private List<CcpCsCondSplicing> ccpCableConductorSplicingsOrigCondName;

	//bi-directional many-to-one association to CcpCableConductorSplicing
	@OneToMany(mappedBy="termCondName",fetch=FetchType.LAZY)
	private List<CcpCsCondSplicing> ccpCableConductorSplicingsTermCondName;

	//bi-directional many-to-one association to CcpCsPortTerm
	@OneToMany(mappedBy="conductor",fetch=FetchType.LAZY)
	private List<CcpCsPortTerm> ccpCsPortTerms;

	//bi-directional many-to-one association to Exchange
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="EXCHANGE_1141_CODE")
	private Exchange exchange;

	//bi-directional many-to-one association to Store
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to ConductorChar
	@OneToMany(mappedBy="conductor",fetch=FetchType.LAZY)
	private List<ConductorChar> conductorChars;

	//bi-directional many-to-one association to CpeCsCondSplicing
	@OneToMany(mappedBy="conductorOrigCondName",fetch=FetchType.LAZY)
	private List<CpeCsCondSplicing> cpeCsCondSplicings1;

	//bi-directional many-to-one association to CpeCsCondSplicing
	@OneToMany(mappedBy="conductorTermCondName",fetch=FetchType.LAZY)
	private List<CpeCsCondSplicing> cpeCsCondSplicings2;

	//bi-directional many-to-one association to CpeCsPortTerm
	@OneToMany(mappedBy="conductor",fetch=FetchType.LAZY)
	private List<CpeCsPortTerm> cpeCsPortTerms;

	//bi-directional many-to-one association to DfCsCondSplicing
	@OneToMany(mappedBy="conductorOrigCondName",fetch=FetchType.LAZY)
	private List<DfCsCondSplicing> dfCsCondSplicings1;

	//bi-directional many-to-one association to DfCsCondSplicing
	@OneToMany(mappedBy="conductorTermCondName",fetch=FetchType.LAZY)
	private List<DfCsCondSplicing> dfCsCondSplicings2;

	//bi-directional many-to-one association to DfCsPortTerm
	@OneToMany(mappedBy="conductor",fetch=FetchType.LAZY)
	private List<DfCsPortTerm> dfCsPortTerms;

	//bi-directional many-to-one association to DpCsCondSplicing
	@OneToMany(mappedBy="conductorOrigCondName",fetch=FetchType.LAZY)
	private List<DpCsCondSplicing> dpCsCondSplicings1;

	//bi-directional many-to-one association to DpCsCondSplicing
	@OneToMany(mappedBy="conductorTermCondName",fetch=FetchType.LAZY)
	private List<DpCsCondSplicing> dpCsCondSplicings2;

	//bi-directional many-to-one association to DpCsPortTerm
	@OneToMany(mappedBy="conductor",fetch=FetchType.LAZY)
	private List<DpCsPortTerm> dpCsPortTerms;

	//bi-directional many-to-one association to DslamCsCondSplicing
	@OneToMany(mappedBy="conductorOrigCondName",fetch=FetchType.LAZY)
	private List<DslamCsCondSplicing> dslamCsCondSplicings1;

	//bi-directional many-to-one association to DslamCsCondSplicing
	@OneToMany(mappedBy="conductorTermCondName",fetch=FetchType.LAZY)
	private List<DslamCsCondSplicing> dslamCsCondSplicings2;

	//bi-directional many-to-one association to DslamCsPortTerm
	@OneToMany(mappedBy="conductor",fetch=FetchType.LAZY)
	private List<DslamCsPortTerm> dslamCsPortTerms;

	//bi-directional many-to-one association to JcCsCondSplicing
	@OneToMany(mappedBy="conductorOrigCondName",fetch=FetchType.LAZY)
	private List<JcCsCondSplicing> jcCsCondSplicings1;

	//bi-directional many-to-one association to JcCsCondSplicing
	@OneToMany(mappedBy="conductorTermCondName",fetch=FetchType.LAZY)
	private List<JcCsCondSplicing> jcCsCondSplicings2;

	//bi-directional many-to-one association to JcCsPortTerm
	@OneToMany(mappedBy="conductor",fetch=FetchType.LAZY)
	private List<JcCsPortTerm> jcCsPortTerms;

	//bi-directional many-to-one association to MfnCableConductorSplicing
	@OneToMany(mappedBy="origConductorName",fetch=FetchType.LAZY)
	private List<MfnCsCondSplicing> mfnCableConductorOrigConductorName;

	//bi-directional many-to-one association to MfnCableConductorSplicing
	@OneToMany(mappedBy="termConductorName",fetch=FetchType.LAZY)
	private List<MfnCsCondSplicing> mfnCableConductorTermConductorName;

	//bi-directional many-to-one association to MfnCsPortTerm
	@OneToMany(mappedBy="conductor",fetch=FetchType.LAZY)
	private List<MfnCsPortTerm> mfnCsPortTerms;

	//bi-directional many-to-one association to NteCsCondSplicing
	@OneToMany(mappedBy="conductorOrigCondName",fetch=FetchType.LAZY)
	private List<NteCsCondSplicing> nteCsCondSplicings1;

	//bi-directional many-to-one association to NteCsCondSplicing
	@OneToMany(mappedBy="conductorTermCondName",fetch=FetchType.LAZY)
	private List<NteCsCondSplicing> nteCsCondSplicings2;

	//bi-directional many-to-one association to NteCsPortTerm
	@OneToMany(mappedBy="conductor",fetch=FetchType.LAZY)
	private List<NteCsPortTerm> nteCsPortTerms;

	//bi-directional many-to-one association to WeCableConductorSplicing
	@OneToMany(mappedBy="origConductorName",fetch=FetchType.LAZY)
	private List<WeCsCondSplicing> weCableConductorSplicingsOrig;

	//bi-directional many-to-one association to WeCableConductorSplicing
	@OneToMany(mappedBy="termConductorName",fetch=FetchType.LAZY)
	private List<WeCsCondSplicing> weCableConductorSplicingsTerm;

	//bi-directional many-to-one association to WeCsPortTerm
	@OneToMany(mappedBy="conductor",fetch=FetchType.LAZY)
	private List<WeCsPortTerm> weCsPortTerms;

	public Conductor() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public double getCalculatedLength() {
		return this.calculatedLength;
	}

	public void setCalculatedLength(double calculatedLength) {
		this.calculatedLength = calculatedLength;
	}

	public String getCalculatedLengthUnit() {
		return this.calculatedLengthUnit;
	}

	public void setCalculatedLengthUnit(String calculatedLengthUnit) {
		this.calculatedLengthUnit = calculatedLengthUnit;
	}

	public BigDecimal getConductorSeqNum() {
		return this.conductorSeqNum;
	}

	public void setConductorSeqNum(BigDecimal conductorSeqNum) {
		this.conductorSeqNum = conductorSeqNum;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public double getMeasuredLength() {
		return this.measuredLength;
	}

	public void setMeasuredLength(double measuredLength) {
		this.measuredLength = measuredLength;
	}

	public String getMeasuredLengthUnit() {
		return this.measuredLengthUnit;
	}

	public void setMeasuredLengthUnit(String measuredLengthUnit) {
		this.measuredLengthUnit = measuredLengthUnit;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public String getUtilisationState() {
		return this.utilisationState;
	}

	public void setUtilisationState(String utilisationState) {
		this.utilisationState = utilisationState;
	}

	public List<CableSectionHierarchy> getCableSectionHierarchies() {
		return this.cableSectionHierarchies;
	}

	public void setCableSectionHierarchies(List<CableSectionHierarchy> cableSectionHierarchies) {
		this.cableSectionHierarchies = cableSectionHierarchies;
	}

	public CableSectionHierarchy addCableSectionHierarchy(CableSectionHierarchy cableSectionHierarchy) {
		getCableSectionHierarchies().add(cableSectionHierarchy);
		cableSectionHierarchy.setConductor(this);

		return cableSectionHierarchy;
	}

	public CableSectionHierarchy removeCableSectionHierarchy(CableSectionHierarchy cableSectionHierarchy) {
		getCableSectionHierarchies().remove(cableSectionHierarchy);
		cableSectionHierarchy.setConductor(null);

		return cableSectionHierarchy;
	}

	public List<CcpCsCondSplicing> getCcpCableConductorSplicingsOrigCondName() {
		return this.ccpCableConductorSplicingsOrigCondName;
	}

	public void setCcpCableConductorSplicingsOrigCondName(List<CcpCsCondSplicing> ccpCableConductorSplicingsOrigCondName) {
		this.ccpCableConductorSplicingsOrigCondName = ccpCableConductorSplicingsOrigCondName;
	}

	public CcpCsCondSplicing addCcpCableConductorSplicingsOrigCondName(CcpCsCondSplicing ccpCableConductorSplicingsOrigCondName) {
		getCcpCableConductorSplicingsOrigCondName().add(ccpCableConductorSplicingsOrigCondName);
		ccpCableConductorSplicingsOrigCondName.setOrigCondName(this);

		return ccpCableConductorSplicingsOrigCondName;
	}

	public CcpCsCondSplicing removeCcpCableConductorSplicingsOrigCondName(CcpCsCondSplicing ccpCableConductorSplicingsOrigCondName) {
		getCcpCableConductorSplicingsOrigCondName().remove(ccpCableConductorSplicingsOrigCondName);
		ccpCableConductorSplicingsOrigCondName.setOrigCondName(null);

		return ccpCableConductorSplicingsOrigCondName;
	}

	public List<CcpCsCondSplicing> getCcpCableConductorSplicingsTermCondName() {
		return this.ccpCableConductorSplicingsTermCondName;
	}

	public void setCcpCableConductorSplicingsTermCondName(List<CcpCsCondSplicing> ccpCableConductorSplicingsTermCondName) {
		this.ccpCableConductorSplicingsTermCondName = ccpCableConductorSplicingsTermCondName;
	}

	public CcpCsCondSplicing addCcpCableConductorSplicingsTermCondName(CcpCsCondSplicing ccpCableConductorSplicingsTermCondName) {
		getCcpCableConductorSplicingsTermCondName().add(ccpCableConductorSplicingsTermCondName);
		ccpCableConductorSplicingsTermCondName.setTermCondName(this);

		return ccpCableConductorSplicingsTermCondName;
	}

	public CcpCsCondSplicing removeCcpCableConductorSplicingsTermCondName(CcpCsCondSplicing ccpCableConductorSplicingsTermCondName) {
		getCcpCableConductorSplicingsTermCondName().remove(ccpCableConductorSplicingsTermCondName);
		ccpCableConductorSplicingsTermCondName.setTermCondName(null);

		return ccpCableConductorSplicingsTermCondName;
	}

	public List<CcpCsPortTerm> getCcpCsPortTerms() {
		return this.ccpCsPortTerms;
	}

	public void setCcpCsPortTerms(List<CcpCsPortTerm> ccpCsPortTerms) {
		this.ccpCsPortTerms = ccpCsPortTerms;
	}

	public CcpCsPortTerm addCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		getCcpCsPortTerms().add(ccpCsPortTerm);
		ccpCsPortTerm.setConductor(this);

		return ccpCsPortTerm;
	}

	public CcpCsPortTerm removeCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		getCcpCsPortTerms().remove(ccpCsPortTerm);
		ccpCsPortTerm.setConductor(null);

		return ccpCsPortTerm;
	}

	public Exchange getExchange() {
		return this.exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public List<ConductorChar> getConductorChars() {
		return this.conductorChars;
	}

	public void setConductorChars(List<ConductorChar> conductorChars) {
		this.conductorChars = conductorChars;
	}

	public ConductorChar addConductorChar(ConductorChar conductorChar) {
		getConductorChars().add(conductorChar);
		conductorChar.setConductor(this);

		return conductorChar;
	}

	public ConductorChar removeConductorChar(ConductorChar conductorChar) {
		getConductorChars().remove(conductorChar);
		conductorChar.setConductor(null);

		return conductorChar;
	}

	public List<CpeCsCondSplicing> getCpeCsCondSplicings1() {
		return this.cpeCsCondSplicings1;
	}

	public void setCpeCsCondSplicings1(List<CpeCsCondSplicing> cpeCsCondSplicings1) {
		this.cpeCsCondSplicings1 = cpeCsCondSplicings1;
	}

	public CpeCsCondSplicing addCpeCsCondSplicings1(CpeCsCondSplicing cpeCsCondSplicings1) {
		getCpeCsCondSplicings1().add(cpeCsCondSplicings1);
		cpeCsCondSplicings1.setConductorOrigCondName(this);

		return cpeCsCondSplicings1;
	}

	public CpeCsCondSplicing removeCpeCsCondSplicings1(CpeCsCondSplicing cpeCsCondSplicings1) {
		getCpeCsCondSplicings1().remove(cpeCsCondSplicings1);
		cpeCsCondSplicings1.setConductorOrigCondName(null);

		return cpeCsCondSplicings1;
	}

	public List<CpeCsCondSplicing> getCpeCsCondSplicings2() {
		return this.cpeCsCondSplicings2;
	}

	public void setCpeCsCondSplicings2(List<CpeCsCondSplicing> cpeCsCondSplicings2) {
		this.cpeCsCondSplicings2 = cpeCsCondSplicings2;
	}

	public CpeCsCondSplicing addCpeCsCondSplicings2(CpeCsCondSplicing cpeCsCondSplicings2) {
		getCpeCsCondSplicings2().add(cpeCsCondSplicings2);
		cpeCsCondSplicings2.setConductorTermCondName(this);

		return cpeCsCondSplicings2;
	}

	public CpeCsCondSplicing removeCpeCsCondSplicings2(CpeCsCondSplicing cpeCsCondSplicings2) {
		getCpeCsCondSplicings2().remove(cpeCsCondSplicings2);
		cpeCsCondSplicings2.setConductorTermCondName(null);

		return cpeCsCondSplicings2;
	}

	public List<CpeCsPortTerm> getCpeCsPortTerms() {
		return this.cpeCsPortTerms;
	}

	public void setCpeCsPortTerms(List<CpeCsPortTerm> cpeCsPortTerms) {
		this.cpeCsPortTerms = cpeCsPortTerms;
	}

	public CpeCsPortTerm addCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		getCpeCsPortTerms().add(cpeCsPortTerm);
		cpeCsPortTerm.setConductor(this);

		return cpeCsPortTerm;
	}

	public CpeCsPortTerm removeCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		getCpeCsPortTerms().remove(cpeCsPortTerm);
		cpeCsPortTerm.setConductor(null);

		return cpeCsPortTerm;
	}

	public List<DfCsCondSplicing> getDfCsCondSplicings1() {
		return this.dfCsCondSplicings1;
	}

	public void setDfCsCondSplicings1(List<DfCsCondSplicing> dfCsCondSplicings1) {
		this.dfCsCondSplicings1 = dfCsCondSplicings1;
	}

	public DfCsCondSplicing addDfCsCondSplicings1(DfCsCondSplicing dfCsCondSplicings1) {
		getDfCsCondSplicings1().add(dfCsCondSplicings1);
		dfCsCondSplicings1.setConductorOrigCondName(this);

		return dfCsCondSplicings1;
	}

	public DfCsCondSplicing removeDfCsCondSplicings1(DfCsCondSplicing dfCsCondSplicings1) {
		getDfCsCondSplicings1().remove(dfCsCondSplicings1);
		dfCsCondSplicings1.setConductorOrigCondName(null);

		return dfCsCondSplicings1;
	}

	public List<DfCsCondSplicing> getDfCsCondSplicings2() {
		return this.dfCsCondSplicings2;
	}

	public void setDfCsCondSplicings2(List<DfCsCondSplicing> dfCsCondSplicings2) {
		this.dfCsCondSplicings2 = dfCsCondSplicings2;
	}

	public DfCsCondSplicing addDfCsCondSplicings2(DfCsCondSplicing dfCsCondSplicings2) {
		getDfCsCondSplicings2().add(dfCsCondSplicings2);
		dfCsCondSplicings2.setConductorTermCondName(this);

		return dfCsCondSplicings2;
	}

	public DfCsCondSplicing removeDfCsCondSplicings2(DfCsCondSplicing dfCsCondSplicings2) {
		getDfCsCondSplicings2().remove(dfCsCondSplicings2);
		dfCsCondSplicings2.setConductorTermCondName(null);

		return dfCsCondSplicings2;
	}

	public List<DfCsPortTerm> getDfCsPortTerms() {
		return this.dfCsPortTerms;
	}

	public void setDfCsPortTerms(List<DfCsPortTerm> dfCsPortTerms) {
		this.dfCsPortTerms = dfCsPortTerms;
	}

	public DfCsPortTerm addDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().add(dfCsPortTerm);
		dfCsPortTerm.setConductor(this);

		return dfCsPortTerm;
	}

	public DfCsPortTerm removeDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().remove(dfCsPortTerm);
		dfCsPortTerm.setConductor(null);

		return dfCsPortTerm;
	}

	public List<DpCsCondSplicing> getDpCsCondSplicings1() {
		return this.dpCsCondSplicings1;
	}

	public void setDpCsCondSplicings1(List<DpCsCondSplicing> dpCsCondSplicings1) {
		this.dpCsCondSplicings1 = dpCsCondSplicings1;
	}

	public DpCsCondSplicing addDpCsCondSplicings1(DpCsCondSplicing dpCsCondSplicings1) {
		getDpCsCondSplicings1().add(dpCsCondSplicings1);
		dpCsCondSplicings1.setConductorOrigCondName(this);

		return dpCsCondSplicings1;
	}

	public DpCsCondSplicing removeDpCsCondSplicings1(DpCsCondSplicing dpCsCondSplicings1) {
		getDpCsCondSplicings1().remove(dpCsCondSplicings1);
		dpCsCondSplicings1.setConductorOrigCondName(null);

		return dpCsCondSplicings1;
	}

	public List<DpCsCondSplicing> getDpCsCondSplicings2() {
		return this.dpCsCondSplicings2;
	}

	public void setDpCsCondSplicings2(List<DpCsCondSplicing> dpCsCondSplicings2) {
		this.dpCsCondSplicings2 = dpCsCondSplicings2;
	}

	public DpCsCondSplicing addDpCsCondSplicings2(DpCsCondSplicing dpCsCondSplicings2) {
		getDpCsCondSplicings2().add(dpCsCondSplicings2);
		dpCsCondSplicings2.setConductorTermCondName(this);

		return dpCsCondSplicings2;
	}

	public DpCsCondSplicing removeDpCsCondSplicings2(DpCsCondSplicing dpCsCondSplicings2) {
		getDpCsCondSplicings2().remove(dpCsCondSplicings2);
		dpCsCondSplicings2.setConductorTermCondName(null);

		return dpCsCondSplicings2;
	}

	public List<DpCsPortTerm> getDpCsPortTerms() {
		return this.dpCsPortTerms;
	}

	public void setDpCsPortTerms(List<DpCsPortTerm> dpCsPortTerms) {
		this.dpCsPortTerms = dpCsPortTerms;
	}

	public DpCsPortTerm addDpCsPortTerm(DpCsPortTerm dpCsPortTerm) {
		getDpCsPortTerms().add(dpCsPortTerm);
		dpCsPortTerm.setConductor(this);

		return dpCsPortTerm;
	}

	public DpCsPortTerm removeDpCsPortTerm(DpCsPortTerm dpCsPortTerm) {
		getDpCsPortTerms().remove(dpCsPortTerm);
		dpCsPortTerm.setConductor(null);

		return dpCsPortTerm;
	}

	public List<DslamCsCondSplicing> getDslamCsCondSplicings1() {
		return this.dslamCsCondSplicings1;
	}

	public void setDslamCsCondSplicings1(List<DslamCsCondSplicing> dslamCsCondSplicings1) {
		this.dslamCsCondSplicings1 = dslamCsCondSplicings1;
	}

	public DslamCsCondSplicing addDslamCsCondSplicings1(DslamCsCondSplicing dslamCsCondSplicings1) {
		getDslamCsCondSplicings1().add(dslamCsCondSplicings1);
		dslamCsCondSplicings1.setConductorOrigCondName(this);

		return dslamCsCondSplicings1;
	}

	public DslamCsCondSplicing removeDslamCsCondSplicings1(DslamCsCondSplicing dslamCsCondSplicings1) {
		getDslamCsCondSplicings1().remove(dslamCsCondSplicings1);
		dslamCsCondSplicings1.setConductorOrigCondName(null);

		return dslamCsCondSplicings1;
	}

	public List<DslamCsCondSplicing> getDslamCsCondSplicings2() {
		return this.dslamCsCondSplicings2;
	}

	public void setDslamCsCondSplicings2(List<DslamCsCondSplicing> dslamCsCondSplicings2) {
		this.dslamCsCondSplicings2 = dslamCsCondSplicings2;
	}

	public DslamCsCondSplicing addDslamCsCondSplicings2(DslamCsCondSplicing dslamCsCondSplicings2) {
		getDslamCsCondSplicings2().add(dslamCsCondSplicings2);
		dslamCsCondSplicings2.setConductorTermCondName(this);

		return dslamCsCondSplicings2;
	}

	public DslamCsCondSplicing removeDslamCsCondSplicings2(DslamCsCondSplicing dslamCsCondSplicings2) {
		getDslamCsCondSplicings2().remove(dslamCsCondSplicings2);
		dslamCsCondSplicings2.setConductorTermCondName(null);

		return dslamCsCondSplicings2;
	}

	public List<DslamCsPortTerm> getDslamCsPortTerms() {
		return this.dslamCsPortTerms;
	}

	public void setDslamCsPortTerms(List<DslamCsPortTerm> dslamCsPortTerms) {
		this.dslamCsPortTerms = dslamCsPortTerms;
	}

	public DslamCsPortTerm addDslamCsPortTerm(DslamCsPortTerm dslamCsPortTerm) {
		getDslamCsPortTerms().add(dslamCsPortTerm);
		dslamCsPortTerm.setConductor(this);

		return dslamCsPortTerm;
	}

	public DslamCsPortTerm removeDslamCsPortTerm(DslamCsPortTerm dslamCsPortTerm) {
		getDslamCsPortTerms().remove(dslamCsPortTerm);
		dslamCsPortTerm.setConductor(null);

		return dslamCsPortTerm;
	}

	public List<JcCsCondSplicing> getJcCsCondSplicings1() {
		return this.jcCsCondSplicings1;
	}

	public void setJcCsCondSplicings1(List<JcCsCondSplicing> jcCsCondSplicings1) {
		this.jcCsCondSplicings1 = jcCsCondSplicings1;
	}

	public JcCsCondSplicing addJcCsCondSplicings1(JcCsCondSplicing jcCsCondSplicings1) {
		getJcCsCondSplicings1().add(jcCsCondSplicings1);
		jcCsCondSplicings1.setConductorOrigCondName(this);

		return jcCsCondSplicings1;
	}

	public JcCsCondSplicing removeJcCsCondSplicings1(JcCsCondSplicing jcCsCondSplicings1) {
		getJcCsCondSplicings1().remove(jcCsCondSplicings1);
		jcCsCondSplicings1.setConductorOrigCondName(null);

		return jcCsCondSplicings1;
	}

	public List<JcCsCondSplicing> getJcCsCondSplicings2() {
		return this.jcCsCondSplicings2;
	}

	public void setJcCsCondSplicings2(List<JcCsCondSplicing> jcCsCondSplicings2) {
		this.jcCsCondSplicings2 = jcCsCondSplicings2;
	}

	public JcCsCondSplicing addJcCsCondSplicings2(JcCsCondSplicing jcCsCondSplicings2) {
		getJcCsCondSplicings2().add(jcCsCondSplicings2);
		jcCsCondSplicings2.setConductorTermCondName(this);

		return jcCsCondSplicings2;
	}

	public JcCsCondSplicing removeJcCsCondSplicings2(JcCsCondSplicing jcCsCondSplicings2) {
		getJcCsCondSplicings2().remove(jcCsCondSplicings2);
		jcCsCondSplicings2.setConductorTermCondName(null);

		return jcCsCondSplicings2;
	}

	public List<JcCsPortTerm> getJcCsPortTerms() {
		return this.jcCsPortTerms;
	}

	public void setJcCsPortTerms(List<JcCsPortTerm> jcCsPortTerms) {
		this.jcCsPortTerms = jcCsPortTerms;
	}

	public JcCsPortTerm addJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		getJcCsPortTerms().add(jcCsPortTerm);
		jcCsPortTerm.setConductor(this);

		return jcCsPortTerm;
	}

	public JcCsPortTerm removeJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		getJcCsPortTerms().remove(jcCsPortTerm);
		jcCsPortTerm.setConductor(null);

		return jcCsPortTerm;
	}

	public List<MfnCsCondSplicing> getMfnCableConductorSplicings1() {
		return this.mfnCableConductorOrigConductorName;
	}

	public void setMfnCableConductorSplicings1(List<MfnCsCondSplicing> mfnCableConductorSplicings1) {
		this.mfnCableConductorOrigConductorName = mfnCableConductorSplicings1;
	}

	public MfnCsCondSplicing addMfnCableConductorSplicings1(MfnCsCondSplicing mfnCableConductorSplicings1) {
		getMfnCableConductorSplicings1().add(mfnCableConductorSplicings1);
		mfnCableConductorSplicings1.setOrigConductorName(this);

		return mfnCableConductorSplicings1;
	}

	public MfnCsCondSplicing removeMfnCableConductorSplicings1(MfnCsCondSplicing mfnCableConductorSplicings1) {
		getMfnCableConductorSplicings1().remove(mfnCableConductorSplicings1);
		mfnCableConductorSplicings1.setOrigConductorName(null);

		return mfnCableConductorSplicings1;
	}

	public List<MfnCsCondSplicing> getMfnCableConductorSplicings2() {
		return this.mfnCableConductorTermConductorName;
	}

	public void setMfnCableConductorSplicings2(List<MfnCsCondSplicing> mfnCableConductorSplicings2) {
		this.mfnCableConductorTermConductorName = mfnCableConductorSplicings2;
	}

	public MfnCsCondSplicing addMfnCableConductorSplicings2(MfnCsCondSplicing mfnCableConductorSplicings2) {
		getMfnCableConductorSplicings2().add(mfnCableConductorSplicings2);
		mfnCableConductorSplicings2.setTermConductorName(this);

		return mfnCableConductorSplicings2;
	}

	public MfnCsCondSplicing removeMfnCableConductorSplicings2(MfnCsCondSplicing mfnCableConductorSplicings2) {
		getMfnCableConductorSplicings2().remove(mfnCableConductorSplicings2);
		mfnCableConductorSplicings2.setTermConductorName(null);

		return mfnCableConductorSplicings2;
	}

	public List<MfnCsPortTerm> getMfnCsPortTerms() {
		return this.mfnCsPortTerms;
	}

	public void setMfnCsPortTerms(List<MfnCsPortTerm> mfnCsPortTerms) {
		this.mfnCsPortTerms = mfnCsPortTerms;
	}

	public MfnCsPortTerm addMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		getMfnCsPortTerms().add(mfnCsPortTerm);
		mfnCsPortTerm.setConductor(this);

		return mfnCsPortTerm;
	}

	public MfnCsPortTerm removeMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		getMfnCsPortTerms().remove(mfnCsPortTerm);
		mfnCsPortTerm.setConductor(null);

		return mfnCsPortTerm;
	}

	public List<NteCsCondSplicing> getNteCsCondSplicings1() {
		return this.nteCsCondSplicings1;
	}

	public void setNteCsCondSplicings1(List<NteCsCondSplicing> nteCsCondSplicings1) {
		this.nteCsCondSplicings1 = nteCsCondSplicings1;
	}

	public NteCsCondSplicing addNteCsCondSplicings1(NteCsCondSplicing nteCsCondSplicings1) {
		getNteCsCondSplicings1().add(nteCsCondSplicings1);
		nteCsCondSplicings1.setConductorOrigCondName(this);

		return nteCsCondSplicings1;
	}

	public NteCsCondSplicing removeNteCsCondSplicings1(NteCsCondSplicing nteCsCondSplicings1) {
		getNteCsCondSplicings1().remove(nteCsCondSplicings1);
		nteCsCondSplicings1.setConductorOrigCondName(null);

		return nteCsCondSplicings1;
	}

	public List<NteCsCondSplicing> getNteCsCondSplicings2() {
		return this.nteCsCondSplicings2;
	}

	public void setNteCsCondSplicings2(List<NteCsCondSplicing> nteCsCondSplicings2) {
		this.nteCsCondSplicings2 = nteCsCondSplicings2;
	}

	public NteCsCondSplicing addNteCsCondSplicings2(NteCsCondSplicing nteCsCondSplicings2) {
		getNteCsCondSplicings2().add(nteCsCondSplicings2);
		nteCsCondSplicings2.setConductorTermCondName(this);

		return nteCsCondSplicings2;
	}

	public NteCsCondSplicing removeNteCsCondSplicings2(NteCsCondSplicing nteCsCondSplicings2) {
		getNteCsCondSplicings2().remove(nteCsCondSplicings2);
		nteCsCondSplicings2.setConductorTermCondName(null);

		return nteCsCondSplicings2;
	}

	public List<NteCsPortTerm> getNteCsPortTerms() {
		return this.nteCsPortTerms;
	}

	public void setNteCsPortTerms(List<NteCsPortTerm> nteCsPortTerms) {
		this.nteCsPortTerms = nteCsPortTerms;
	}

	public NteCsPortTerm addNteCsPortTerm(NteCsPortTerm nteCsPortTerm) {
		getNteCsPortTerms().add(nteCsPortTerm);
		nteCsPortTerm.setConductor(this);

		return nteCsPortTerm;
	}

	public NteCsPortTerm removeNteCsPortTerm(NteCsPortTerm nteCsPortTerm) {
		getNteCsPortTerms().remove(nteCsPortTerm);
		nteCsPortTerm.setConductor(null);

		return nteCsPortTerm;
	}

	public List<WeCsCondSplicing> getWeCableConductorSplicingsOrig() {
		return this.weCableConductorSplicingsOrig;
	}

	public void setWeCableConductorSplicingsOrig(List<WeCsCondSplicing> weCableConductorSplicingsOrig) {
		this.weCableConductorSplicingsOrig = weCableConductorSplicingsOrig;
	}

	public WeCsCondSplicing addWeCableConductorSplicingsOrig(WeCsCondSplicing weCableConductorSplicingsOrig) {
		getWeCableConductorSplicingsOrig().add(weCableConductorSplicingsOrig);
		weCableConductorSplicingsOrig.setOrigConductorName(this);

		return weCableConductorSplicingsOrig;
	}

	public WeCsCondSplicing removeWeCableConductorSplicingsOrig(WeCsCondSplicing weCableConductorSplicingsOrig) {
		getWeCableConductorSplicingsOrig().remove(weCableConductorSplicingsOrig);
		weCableConductorSplicingsOrig.setOrigConductorName(null);

		return weCableConductorSplicingsOrig;
	}

	public List<WeCsCondSplicing> getWeCableConductorSplicingsTerm() {
		return this.weCableConductorSplicingsTerm;
	}

	public void setWeCableConductorSplicingsTerm(List<WeCsCondSplicing> weCableConductorSplicingsTerm) {
		this.weCableConductorSplicingsTerm = weCableConductorSplicingsTerm;
	}

	public WeCsCondSplicing addWeCableConductorSplicingsTerm(WeCsCondSplicing weCableConductorSplicingsTerm) {
		getWeCableConductorSplicingsTerm().add(weCableConductorSplicingsTerm);
		weCableConductorSplicingsTerm.setTermConductorName(this);

		return weCableConductorSplicingsTerm;
	}

	public WeCsCondSplicing removeWeCableConductorSplicingsTerm(WeCsCondSplicing weCableConductorSplicingsTerm) {
		getWeCableConductorSplicingsTerm().remove(weCableConductorSplicingsTerm);
		weCableConductorSplicingsTerm.setTermConductorName(null);

		return weCableConductorSplicingsTerm;
	}

	public List<WeCsPortTerm> getWeCsPortTerms() {
		return this.weCsPortTerms;
	}

	public void setWeCsPortTerms(List<WeCsPortTerm> weCsPortTerms) {
		this.weCsPortTerms = weCsPortTerms;
	}

	public WeCsPortTerm addWeCsPortTerm(WeCsPortTerm weCsPortTerm) {
		getWeCsPortTerms().add(weCsPortTerm);
		weCsPortTerm.setConductor(this);

		return weCsPortTerm;
	}

	public WeCsPortTerm removeWeCsPortTerm(WeCsPortTerm weCsPortTerm) {
		getWeCsPortTerms().remove(weCsPortTerm);
		weCsPortTerm.setConductor(null);

		return weCsPortTerm;
	}

}