package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the JCHAMBER_SELF_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="JCHAMBER_SELF_ASSOC")
@NamedQuery(name="JchamberSelfAssoc.findAll", query="SELECT j FROM JchamberSelfAssoc j")
public class JchamberSelfAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, precision=38)
	private long id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="JCHAMBER_SELF_ASSOC_SPEC_ID", length=50)
	private String jchamberSelfAssocSpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to JointingChamber
	@ManyToOne
	@JoinColumn(name="CHILD_JCHAMBER_NAME")
	private JointingChamber childJointingChamber;

	//bi-directional many-to-one association to JointingChamber
	@ManyToOne
	@JoinColumn(name="PARENT_JCHAMBER_NAME")
	private JointingChamber parentJointingChamber;

	public JchamberSelfAssoc() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getJchamberSelfAssocSpecId() {
		return this.jchamberSelfAssocSpecId;
	}

	public void setJchamberSelfAssocSpecId(String jchamberSelfAssocSpecId) {
		this.jchamberSelfAssocSpecId = jchamberSelfAssocSpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public JointingChamber getChildJointingChamber() {
		return this.childJointingChamber;
	}

	public void setChildJointingChamber(JointingChamber jointingChamber) {
		this.childJointingChamber = jointingChamber;
	}

	public JointingChamber getParentJointingChamber() {
		return this.parentJointingChamber;
	}

	public void setParentJointingChamber(JointingChamber jointingChamber) {
		this.parentJointingChamber = jointingChamber;
	}

}