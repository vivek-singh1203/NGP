package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.Exchange;
import com.bt.ngp.datasource.entities.MultiFunctionalNode;

@Repository
public interface MfnRepository extends CommonOperation<MultiFunctionalNode> {

	@Query(name="MfnRepository.findEquipmentWithoutCableSectionAssoc", nativeQuery=true)
	List<MultiFunctionalNode> findEquipmentWithoutCableSectionAssoc(@Param("exchangeCode") String exchange1141Code);
	
	List<MultiFunctionalNode> findByExchangeAndMfnStructureAssocsIsNull(@Param("exchange") Exchange exchange);
}
