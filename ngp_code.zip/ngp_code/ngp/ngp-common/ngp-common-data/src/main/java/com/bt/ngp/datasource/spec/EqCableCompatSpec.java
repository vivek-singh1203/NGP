package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the EQ_CABLE_COMPAT_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="EQ_CABLE_COMPAT_SPEC")
@NamedQuery(name="EqCableCompatSpec.findAll", query="SELECT e FROM EqCableCompatSpec e")
public class EqCableCompatSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CABLE_ENTITY_NAME", length=30)
	private String cableEntityName;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="EQ_ENTITY_NAME", length=30)
	private String eqEntityName;

	@Column(name="IS_COMPATIBLE", nullable=false)
	private BigDecimal isCompatible;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="TERMINATION_TYPE", length=20)
	private String terminationType;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="CABLE_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory1;

	//bi-directional many-to-one association to CableSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="CABLE_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="CABLE_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private CableSpec cableSpec;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="CABLE_SPEC_TYPE_NAME")
	private SpecType specType1;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="EQ_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory2;

	//bi-directional many-to-one association to EqSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="EQ_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="EQ_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private EqSpec eqSpec;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="EQ_SPEC_TYPE_NAME")
	private SpecType specType2;

	public EqCableCompatSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCableEntityName() {
		return this.cableEntityName;
	}

	public void setCableEntityName(String cableEntityName) {
		this.cableEntityName = cableEntityName;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEqEntityName() {
		return this.eqEntityName;
	}

	public void setEqEntityName(String eqEntityName) {
		this.eqEntityName = eqEntityName;
	}

	public BigDecimal getIsCompatible() {
		return this.isCompatible;
	}

	public void setIsCompatible(BigDecimal isCompatible) {
		this.isCompatible = isCompatible;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getTerminationType() {
		return this.terminationType;
	}

	public void setTerminationType(String terminationType) {
		this.terminationType = terminationType;
	}

	public SpecCategory getSpecCategory1() {
		return this.specCategory1;
	}

	public void setSpecCategory1(SpecCategory specCategory1) {
		this.specCategory1 = specCategory1;
	}

	public CableSpec getCableSpec() {
		return this.cableSpec;
	}

	public void setCableSpec(CableSpec cableSpec) {
		this.cableSpec = cableSpec;
	}

	public SpecType getSpecType1() {
		return this.specType1;
	}

	public void setSpecType1(SpecType specType1) {
		this.specType1 = specType1;
	}

	public SpecCategory getSpecCategory2() {
		return this.specCategory2;
	}

	public void setSpecCategory2(SpecCategory specCategory2) {
		this.specCategory2 = specCategory2;
	}

	public EqSpec getEqSpec() {
		return this.eqSpec;
	}

	public void setEqSpec(EqSpec eqSpec) {
		this.eqSpec = eqSpec;
	}

	public SpecType getSpecType2() {
		return this.specType2;
	}

	public void setSpecType2(SpecType specType2) {
		this.specType2 = specType2;
	}

}