package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.vividsolutions.jts.geom.Point;


/**
 * The persistent class for the MULTI_FUNCTIONAL_NODE database table.
 * 
 */
@javax.persistence.Entity
@Table(name="MULTI_FUNCTIONAL_NODE")
@NamedQuery(name="MultiFunctionalNode.findAll", query="SELECT m FROM MultiFunctionalNode m")
public class MultiFunctionalNode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="NAME",unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="DESG_NAME", length=30)
	private String desgName;

	@Column(name="DESG_NUM", precision=38)
	private BigDecimal desgNum;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(name="FIELD_LABEL", length=30)
	private String fieldLabel;

	@Column(name = "GEO_POSITION", columnDefinition = "geometry(Point,3857)")
	private Point geoPosition;

	public Point getGeoPosition() {
		return geoPosition;
	}

	public void setGeoPosition(Point geoPosition) {
		this.geoPosition = geoPosition;
	}

	@Column(name="ID",nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to AuxComponent
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<AuxComponent> auxComponents;

	//bi-directional many-to-one association to Chassi
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<Chassi> chassis;

	//bi-directional many-to-one association to Connector
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<Connector> connectors;

	//bi-directional many-to-one association to MfnCableConductorSplicing
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<MfnCsCondSplicing> mfnCableConductorSplicings;

	//bi-directional many-to-one association to MfnChar
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<MfnChar> mfnChars;

	//bi-directional many-to-one association to MfnChassisPhAssoc
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<MfnChassisPhAssoc> mfnChassisPhAssocs;

	//bi-directional many-to-one association to MfnCsPortTerm
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<MfnCsPortTerm> mfnCsPortTerms;

	//bi-directional many-to-one association to MfnHierarchy
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<MfnHierarchy> mfnHierarchies;

	//bi-directional many-to-one association to MfnPhPluginAssoc
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<MfnPhPluginAssoc> mfnPhPluginAssocs;

	//bi-directional many-to-one association to MfnPluginPortAssoc
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<MfnPluginPortAssoc> mfnPluginPortAssocs;

	//bi-directional many-to-one association to MfnPort
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<MfnPort> mfnPorts;

	//bi-directional many-to-one association to MfnPortChar
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<MfnPortChar> mfnPortChars;

	//bi-directional many-to-one association to MfnPortPortAssoc
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<MfnPortPortAssoc> mfnPortPortAssocs;

	//bi-directional many-to-one association to MfnStructureAssoc
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<MfnStructureAssoc> mfnStructureAssocs;

	//bi-directional many-to-one association to Exchange
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="EXCHANGE_1141_CODE")
	private Exchange exchange;

	//bi-directional many-to-one association to Store
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to Plugin
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<Plugin> plugins;

	//bi-directional many-to-one association to PluginHolder
	@OneToMany(mappedBy="multiFunctionalNode")
	private List<PluginHolder> pluginHolders;

	public MultiFunctionalNode() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getDesgName() {
		return this.desgName;
	}

	public void setDesgName(String desgName) {
		this.desgName = desgName;
	}

	public BigDecimal getDesgNum() {
		return this.desgNum;
	}

	public void setDesgNum(BigDecimal desgNum) {
		this.desgNum = desgNum;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getFieldLabel() {
		return this.fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<AuxComponent> getAuxComponents() {
		return this.auxComponents;
	}

	public void setAuxComponents(List<AuxComponent> auxComponents) {
		this.auxComponents = auxComponents;
	}

	public AuxComponent addAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().add(auxComponent);
		auxComponent.setMultiFunctionalNode(this);

		return auxComponent;
	}

	public AuxComponent removeAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().remove(auxComponent);
		auxComponent.setMultiFunctionalNode(null);

		return auxComponent;
	}

	public List<Chassi> getChassis() {
		return this.chassis;
	}

	public void setChassis(List<Chassi> chassis) {
		this.chassis = chassis;
	}

	public Chassi addChassi(Chassi chassi) {
		getChassis().add(chassi);
		chassi.setMultiFunctionalNode(this);

		return chassi;
	}

	public Chassi removeChassi(Chassi chassi) {
		getChassis().remove(chassi);
		chassi.setMultiFunctionalNode(null);

		return chassi;
	}

	public List<Connector> getConnectors() {
		return this.connectors;
	}

	public void setConnectors(List<Connector> connectors) {
		this.connectors = connectors;
	}

	public Connector addConnector(Connector connector) {
		getConnectors().add(connector);
		connector.setMultiFunctionalNode(this);

		return connector;
	}

	public Connector removeConnector(Connector connector) {
		getConnectors().remove(connector);
		connector.setMultiFunctionalNode(null);

		return connector;
	}

	public List<MfnCsCondSplicing> getMfnCableConductorSplicings() {
		return this.mfnCableConductorSplicings;
	}

	public void setMfnCableConductorSplicings(List<MfnCsCondSplicing> mfnCableConductorSplicings) {
		this.mfnCableConductorSplicings = mfnCableConductorSplicings;
	}

	public MfnCsCondSplicing addMfnCableConductorSplicing(MfnCsCondSplicing mfnCableConductorSplicing) {
		getMfnCableConductorSplicings().add(mfnCableConductorSplicing);
		mfnCableConductorSplicing.setMultiFunctionalNode(this);

		return mfnCableConductorSplicing;
	}

	public MfnCsCondSplicing removeMfnCableConductorSplicing(MfnCsCondSplicing mfnCableConductorSplicing) {
		getMfnCableConductorSplicings().remove(mfnCableConductorSplicing);
		mfnCableConductorSplicing.setMultiFunctionalNode(null);

		return mfnCableConductorSplicing;
	}

	public List<MfnChar> getMfnChars() {
		return this.mfnChars;
	}

	public void setMfnChars(List<MfnChar> mfnChars) {
		this.mfnChars = mfnChars;
	}

	public MfnChar addMfnChar(MfnChar mfnChar) {
		getMfnChars().add(mfnChar);
		mfnChar.setMultiFunctionalNode(this);

		return mfnChar;
	}

	public MfnChar removeMfnChar(MfnChar mfnChar) {
		getMfnChars().remove(mfnChar);
		mfnChar.setMultiFunctionalNode(null);

		return mfnChar;
	}

	public List<MfnChassisPhAssoc> getMfnChassisPhAssocs() {
		return this.mfnChassisPhAssocs;
	}

	public void setMfnChassisPhAssocs(List<MfnChassisPhAssoc> mfnChassisPhAssocs) {
		this.mfnChassisPhAssocs = mfnChassisPhAssocs;
	}

	public MfnChassisPhAssoc addMfnChassisPhAssoc(MfnChassisPhAssoc mfnChassisPhAssoc) {
		getMfnChassisPhAssocs().add(mfnChassisPhAssoc);
		mfnChassisPhAssoc.setMultiFunctionalNode(this);

		return mfnChassisPhAssoc;
	}

	public MfnChassisPhAssoc removeMfnChassisPhAssoc(MfnChassisPhAssoc mfnChassisPhAssoc) {
		getMfnChassisPhAssocs().remove(mfnChassisPhAssoc);
		mfnChassisPhAssoc.setMultiFunctionalNode(null);

		return mfnChassisPhAssoc;
	}

	public List<MfnCsPortTerm> getMfnCsPortTerms() {
		return this.mfnCsPortTerms;
	}

	public void setMfnCsPortTerms(List<MfnCsPortTerm> mfnCsPortTerms) {
		this.mfnCsPortTerms = mfnCsPortTerms;
	}

	public MfnCsPortTerm addMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		getMfnCsPortTerms().add(mfnCsPortTerm);
		mfnCsPortTerm.setMultiFunctionalNode(this);

		return mfnCsPortTerm;
	}

	public MfnCsPortTerm removeMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		getMfnCsPortTerms().remove(mfnCsPortTerm);
		mfnCsPortTerm.setMultiFunctionalNode(null);

		return mfnCsPortTerm;
	}

	public List<MfnHierarchy> getMfnHierarchies() {
		return this.mfnHierarchies;
	}

	public void setMfnHierarchies(List<MfnHierarchy> mfnHierarchies) {
		this.mfnHierarchies = mfnHierarchies;
	}

	public MfnHierarchy addMfnHierarchy(MfnHierarchy mfnHierarchy) {
		getMfnHierarchies().add(mfnHierarchy);
		mfnHierarchy.setMultiFunctionalNode(this);

		return mfnHierarchy;
	}

	public MfnHierarchy removeMfnHierarchy(MfnHierarchy mfnHierarchy) {
		getMfnHierarchies().remove(mfnHierarchy);
		mfnHierarchy.setMultiFunctionalNode(null);

		return mfnHierarchy;
	}

	public List<MfnPhPluginAssoc> getMfnPhPluginAssocs() {
		return this.mfnPhPluginAssocs;
	}

	public void setMfnPhPluginAssocs(List<MfnPhPluginAssoc> mfnPhPluginAssocs) {
		this.mfnPhPluginAssocs = mfnPhPluginAssocs;
	}

	public MfnPhPluginAssoc addMfnPhPluginAssoc(MfnPhPluginAssoc mfnPhPluginAssoc) {
		getMfnPhPluginAssocs().add(mfnPhPluginAssoc);
		mfnPhPluginAssoc.setMultiFunctionalNode(this);

		return mfnPhPluginAssoc;
	}

	public MfnPhPluginAssoc removeMfnPhPluginAssoc(MfnPhPluginAssoc mfnPhPluginAssoc) {
		getMfnPhPluginAssocs().remove(mfnPhPluginAssoc);
		mfnPhPluginAssoc.setMultiFunctionalNode(null);

		return mfnPhPluginAssoc;
	}

	public List<MfnPluginPortAssoc> getMfnPluginPortAssocs() {
		return this.mfnPluginPortAssocs;
	}

	public void setMfnPluginPortAssocs(List<MfnPluginPortAssoc> mfnPluginPortAssocs) {
		this.mfnPluginPortAssocs = mfnPluginPortAssocs;
	}

	public MfnPluginPortAssoc addMfnPluginPortAssoc(MfnPluginPortAssoc mfnPluginPortAssoc) {
		getMfnPluginPortAssocs().add(mfnPluginPortAssoc);
		mfnPluginPortAssoc.setMultiFunctionalNode(this);

		return mfnPluginPortAssoc;
	}

	public MfnPluginPortAssoc removeMfnPluginPortAssoc(MfnPluginPortAssoc mfnPluginPortAssoc) {
		getMfnPluginPortAssocs().remove(mfnPluginPortAssoc);
		mfnPluginPortAssoc.setMultiFunctionalNode(null);

		return mfnPluginPortAssoc;
	}

	public List<MfnPort> getMfnPorts() {
		return this.mfnPorts;
	}

	public void setMfnPorts(List<MfnPort> mfnPorts) {
		this.mfnPorts = mfnPorts;
	}

	public MfnPort addMfnPort(MfnPort mfnPort) {
		getMfnPorts().add(mfnPort);
		mfnPort.setMultiFunctionalNode(this);

		return mfnPort;
	}

	public MfnPort removeMfnPort(MfnPort mfnPort) {
		getMfnPorts().remove(mfnPort);
		mfnPort.setMultiFunctionalNode(null);

		return mfnPort;
	}

	public List<MfnPortChar> getMfnPortChars() {
		return this.mfnPortChars;
	}

	public void setMfnPortChars(List<MfnPortChar> mfnPortChars) {
		this.mfnPortChars = mfnPortChars;
	}

	public MfnPortChar addMfnPortChar(MfnPortChar mfnPortChar) {
		getMfnPortChars().add(mfnPortChar);
		mfnPortChar.setMultiFunctionalNode(this);

		return mfnPortChar;
	}

	public MfnPortChar removeMfnPortChar(MfnPortChar mfnPortChar) {
		getMfnPortChars().remove(mfnPortChar);
		mfnPortChar.setMultiFunctionalNode(null);

		return mfnPortChar;
	}

	public List<MfnPortPortAssoc> getMfnPortPortAssocs() {
		return this.mfnPortPortAssocs;
	}

	public void setMfnPortPortAssocs(List<MfnPortPortAssoc> mfnPortPortAssocs) {
		this.mfnPortPortAssocs = mfnPortPortAssocs;
	}

	public MfnPortPortAssoc addMfnPortPortAssoc(MfnPortPortAssoc mfnPortPortAssoc) {
		getMfnPortPortAssocs().add(mfnPortPortAssoc);
		mfnPortPortAssoc.setMultiFunctionalNode(this);

		return mfnPortPortAssoc;
	}

	public MfnPortPortAssoc removeMfnPortPortAssoc(MfnPortPortAssoc mfnPortPortAssoc) {
		getMfnPortPortAssocs().remove(mfnPortPortAssoc);
		mfnPortPortAssoc.setMultiFunctionalNode(null);

		return mfnPortPortAssoc;
	}

	public List<MfnStructureAssoc> getMfnStructureAssocs() {
		return this.mfnStructureAssocs;
	}

	public void setMfnStructureAssocs(List<MfnStructureAssoc> mfnStructureAssocs) {
		this.mfnStructureAssocs = mfnStructureAssocs;
	}

	public MfnStructureAssoc addMfnStructureAssoc(MfnStructureAssoc mfnStructureAssoc) {
		getMfnStructureAssocs().add(mfnStructureAssoc);
		mfnStructureAssoc.setMultiFunctionalNode(this);

		return mfnStructureAssoc;
	}

	public MfnStructureAssoc removeMfnStructureAssoc(MfnStructureAssoc mfnStructureAssoc) {
		getMfnStructureAssocs().remove(mfnStructureAssoc);
		mfnStructureAssoc.setMultiFunctionalNode(null);

		return mfnStructureAssoc;
	}

	public Exchange getExchange() {
		return this.exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public List<Plugin> getPlugins() {
		return this.plugins;
	}

	public void setPlugins(List<Plugin> plugins) {
		this.plugins = plugins;
	}

	public Plugin addPlugin(Plugin plugin) {
		getPlugins().add(plugin);
		plugin.setMultiFunctionalNode(this);

		return plugin;
	}

	public Plugin removePlugin(Plugin plugin) {
		getPlugins().remove(plugin);
		plugin.setMultiFunctionalNode(null);

		return plugin;
	}

	public List<PluginHolder> getPluginHolders() {
		return this.pluginHolders;
	}

	public void setPluginHolders(List<PluginHolder> pluginHolders) {
		this.pluginHolders = pluginHolders;
	}

	public PluginHolder addPluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().add(pluginHolder);
		pluginHolder.setMultiFunctionalNode(this);

		return pluginHolder;
	}

	public PluginHolder removePluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().remove(pluginHolder);
		pluginHolder.setMultiFunctionalNode(null);

		return pluginHolder;
	}

}