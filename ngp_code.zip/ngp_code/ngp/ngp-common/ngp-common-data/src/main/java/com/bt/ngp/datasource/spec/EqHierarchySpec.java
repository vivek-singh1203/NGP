package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the EQ_HIERARCHY_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="EQ_HIERARCHY_SPEC")
@NamedQuery(name="EqHierarchySpec.findAll", query="SELECT e FROM EqHierarchySpec e")
public class EqHierarchySpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="EQ_ENTITY_NAME", length=30)
	private String eqEntityName;

	@Column(name="HIERARCHY_LEG_ID", nullable=false, precision=38)
	private BigDecimal hierarchyLegId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_START_SEQ_NO", nullable=false, precision=38)
	private BigDecimal portStartSeqNo;

	//bi-directional many-to-one association to EqCompHolderAssocSpec
	@ManyToOne
	@JoinColumn(name="COMP_HOLDER_ASSOC_SPEC_ID")
	private EqCompHolderAssocSpec eqCompHolderAssocSpec;

	//bi-directional many-to-one association to EqCompPortAssocSpec
	@ManyToOne
	@JoinColumn(name="COMP_PORT_ASSOC_SPEC_ID")
	private EqCompPortAssocSpec eqCompPortAssocSpec;

	//bi-directional many-to-one association to EqHolderCompAssocSpec
	@ManyToOne
	@JoinColumn(name="HOLDER_COMP_ASSOC_SPEC_ID")
	private EqHolderCompAssocSpec eqHolderCompAssocSpec;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="EQ_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to EqSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="EQ_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="EQ_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private EqSpec eqSpec;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="EQ_SPEC_TYPE_NAME")
	private SpecType specType;

	public EqHierarchySpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEqEntityName() {
		return this.eqEntityName;
	}

	public void setEqEntityName(String eqEntityName) {
		this.eqEntityName = eqEntityName;
	}

	public BigDecimal getHierarchyLegId() {
		return this.hierarchyLegId;
	}

	public void setHierarchyLegId(BigDecimal hierarchyLegId) {
		this.hierarchyLegId = hierarchyLegId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortStartSeqNo() {
		return this.portStartSeqNo;
	}

	public void setPortStartSeqNo(BigDecimal portStartSeqNo) {
		this.portStartSeqNo = portStartSeqNo;
	}

	public EqCompHolderAssocSpec getEqCompHolderAssocSpec() {
		return this.eqCompHolderAssocSpec;
	}

	public void setEqCompHolderAssocSpec(EqCompHolderAssocSpec eqCompHolderAssocSpec) {
		this.eqCompHolderAssocSpec = eqCompHolderAssocSpec;
	}

	public EqCompPortAssocSpec getEqCompPortAssocSpec() {
		return this.eqCompPortAssocSpec;
	}

	public void setEqCompPortAssocSpec(EqCompPortAssocSpec eqCompPortAssocSpec) {
		this.eqCompPortAssocSpec = eqCompPortAssocSpec;
	}

	public EqHolderCompAssocSpec getEqHolderCompAssocSpec() {
		return this.eqHolderCompAssocSpec;
	}

	public void setEqHolderCompAssocSpec(EqHolderCompAssocSpec eqHolderCompAssocSpec) {
		this.eqHolderCompAssocSpec = eqHolderCompAssocSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public EqSpec getEqSpec() {
		return this.eqSpec;
	}

	public void setEqSpec(EqSpec eqSpec) {
		this.eqSpec = eqSpec;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

}