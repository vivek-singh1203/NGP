package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the CARDS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CARDS")
@NamedQuery(name="Card.findAll", query="SELECT c FROM Card c")
public class Card implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=40)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=40)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=10)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to CardHolder
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CARD_HOLDER_NAME")
	private CardHolder cardHolder;

	//bi-directional many-to-one association to Dslam
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="DSLAM_NAME")
	private Dslam dslam;

	//bi-directional many-to-one association to Store
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to CardChar
	@OneToMany(mappedBy="card")
	private List<CardChar> cardChars;

	//bi-directional many-to-one association to DslamCardPortAssoc
	@OneToMany(mappedBy="card")
	private List<DslamCardPortAssoc> dslamCardPortAssocs;

	//bi-directional many-to-one association to DslamChCardAssoc
	@OneToMany(mappedBy="card")
	private List<DslamChCardAssoc> dslamChCardAssocs;

	//bi-directional many-to-one association to DslamCsPortTerm
	@OneToMany(mappedBy="card")
	private List<DslamCsPortTerm> dslamCsPortTerms;

	//bi-directional many-to-one association to DslamPort
	@OneToMany(mappedBy="card")
	private List<DslamPort> dslamPorts;

	//bi-directional many-to-one association to DslamPortPortAssoc
	@OneToMany(mappedBy="card1")
	private List<DslamPortPortAssoc> dslamPortPortAssocs1;

	//bi-directional many-to-one association to DslamPortPortAssoc
	@OneToMany(mappedBy="card2")
	private List<DslamPortPortAssoc> dslamPortPortAssocs2;

	public Card() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public CardHolder getCardHolder() {
		return this.cardHolder;
	}

	public void setCardHolder(CardHolder cardHolder) {
		this.cardHolder = cardHolder;
	}

	public Dslam getDslam() {
		return this.dslam;
	}

	public void setDslam(Dslam dslam) {
		this.dslam = dslam;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public List<CardChar> getCardChars() {
		return this.cardChars;
	}

	public void setCardChars(List<CardChar> cardChars) {
		this.cardChars = cardChars;
	}

	public CardChar addCardChar(CardChar cardChar) {
		getCardChars().add(cardChar);
		cardChar.setCard(this);

		return cardChar;
	}

	public CardChar removeCardChar(CardChar cardChar) {
		getCardChars().remove(cardChar);
		cardChar.setCard(null);

		return cardChar;
	}

	public List<DslamCardPortAssoc> getDslamCardPortAssocs() {
		return this.dslamCardPortAssocs;
	}

	public void setDslamCardPortAssocs(List<DslamCardPortAssoc> dslamCardPortAssocs) {
		this.dslamCardPortAssocs = dslamCardPortAssocs;
	}

	public DslamCardPortAssoc addDslamCardPortAssoc(DslamCardPortAssoc dslamCardPortAssoc) {
		getDslamCardPortAssocs().add(dslamCardPortAssoc);
		dslamCardPortAssoc.setCard(this);

		return dslamCardPortAssoc;
	}

	public DslamCardPortAssoc removeDslamCardPortAssoc(DslamCardPortAssoc dslamCardPortAssoc) {
		getDslamCardPortAssocs().remove(dslamCardPortAssoc);
		dslamCardPortAssoc.setCard(null);

		return dslamCardPortAssoc;
	}

	public List<DslamChCardAssoc> getDslamChCardAssocs() {
		return this.dslamChCardAssocs;
	}

	public void setDslamChCardAssocs(List<DslamChCardAssoc> dslamChCardAssocs) {
		this.dslamChCardAssocs = dslamChCardAssocs;
	}

	public DslamChCardAssoc addDslamChCardAssoc(DslamChCardAssoc dslamChCardAssoc) {
		getDslamChCardAssocs().add(dslamChCardAssoc);
		dslamChCardAssoc.setCard(this);

		return dslamChCardAssoc;
	}

	public DslamChCardAssoc removeDslamChCardAssoc(DslamChCardAssoc dslamChCardAssoc) {
		getDslamChCardAssocs().remove(dslamChCardAssoc);
		dslamChCardAssoc.setCard(null);

		return dslamChCardAssoc;
	}

	public List<DslamCsPortTerm> getDslamCsPortTerms() {
		return this.dslamCsPortTerms;
	}

	public void setDslamCsPortTerms(List<DslamCsPortTerm> dslamCsPortTerms) {
		this.dslamCsPortTerms = dslamCsPortTerms;
	}

	public DslamCsPortTerm addDslamCsPortTerm(DslamCsPortTerm dslamCsPortTerm) {
		getDslamCsPortTerms().add(dslamCsPortTerm);
		dslamCsPortTerm.setCard(this);

		return dslamCsPortTerm;
	}

	public DslamCsPortTerm removeDslamCsPortTerm(DslamCsPortTerm dslamCsPortTerm) {
		getDslamCsPortTerms().remove(dslamCsPortTerm);
		dslamCsPortTerm.setCard(null);

		return dslamCsPortTerm;
	}

	public List<DslamPort> getDslamPorts() {
		return this.dslamPorts;
	}

	public void setDslamPorts(List<DslamPort> dslamPorts) {
		this.dslamPorts = dslamPorts;
	}

	public DslamPort addDslamPort(DslamPort dslamPort) {
		getDslamPorts().add(dslamPort);
		dslamPort.setCard(this);

		return dslamPort;
	}

	public DslamPort removeDslamPort(DslamPort dslamPort) {
		getDslamPorts().remove(dslamPort);
		dslamPort.setCard(null);

		return dslamPort;
	}

	public List<DslamPortPortAssoc> getDslamPortPortAssocs1() {
		return this.dslamPortPortAssocs1;
	}

	public void setDslamPortPortAssocs1(List<DslamPortPortAssoc> dslamPortPortAssocs1) {
		this.dslamPortPortAssocs1 = dslamPortPortAssocs1;
	}

	public DslamPortPortAssoc addDslamPortPortAssocs1(DslamPortPortAssoc dslamPortPortAssocs1) {
		getDslamPortPortAssocs1().add(dslamPortPortAssocs1);
		dslamPortPortAssocs1.setCard1(this);

		return dslamPortPortAssocs1;
	}

	public DslamPortPortAssoc removeDslamPortPortAssocs1(DslamPortPortAssoc dslamPortPortAssocs1) {
		getDslamPortPortAssocs1().remove(dslamPortPortAssocs1);
		dslamPortPortAssocs1.setCard1(null);

		return dslamPortPortAssocs1;
	}

	public List<DslamPortPortAssoc> getDslamPortPortAssocs2() {
		return this.dslamPortPortAssocs2;
	}

	public void setDslamPortPortAssocs2(List<DslamPortPortAssoc> dslamPortPortAssocs2) {
		this.dslamPortPortAssocs2 = dslamPortPortAssocs2;
	}

	public DslamPortPortAssoc addDslamPortPortAssocs2(DslamPortPortAssoc dslamPortPortAssocs2) {
		getDslamPortPortAssocs2().add(dslamPortPortAssocs2);
		dslamPortPortAssocs2.setCard2(this);

		return dslamPortPortAssocs2;
	}

	public DslamPortPortAssoc removeDslamPortPortAssocs2(DslamPortPortAssoc dslamPortPortAssocs2) {
		getDslamPortPortAssocs2().remove(dslamPortPortAssocs2);
		dslamPortPortAssocs2.setCard2(null);

		return dslamPortPortAssocs2;
	}

}