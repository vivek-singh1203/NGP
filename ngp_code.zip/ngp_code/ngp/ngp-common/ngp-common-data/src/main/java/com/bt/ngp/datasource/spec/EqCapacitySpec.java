package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the EQ_CAPACITY_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="EQ_CAPACITY_SPEC")
@NamedQuery(name="EqCapacitySpec.findAll", query="SELECT e FROM EqCapacitySpec e")
public class EqCapacitySpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=30)
	private String name;

	@Column(name="ALERT_THR_USAGE_PERCENTAGE", precision=126)
	private double alertThrUsagePercentage;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="MAX_SPARE_PERCENTAGE", precision=126)
	private double maxSparePercentage;

	@Column(name="MAX_USAGE_PERCENTAGE", precision=126)
	private double maxUsagePercentage;

	@Column(name="MIN_SPARE_PERCENTAGE", precision=126)
	private double minSparePercentage;

	@Column(name="MIN_USAGE_PERCENTAGE", precision=126)
	private double minUsagePercentage;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	//bi-directional many-to-one association to EqSpec
	@OneToMany(mappedBy="eqCapacitySpec")
	private List<EqSpec> eqSpecs;

	public EqCapacitySpec() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getAlertThrUsagePercentage() {
		return this.alertThrUsagePercentage;
	}

	public void setAlertThrUsagePercentage(double alertThrUsagePercentage) {
		this.alertThrUsagePercentage = alertThrUsagePercentage;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public double getMaxSparePercentage() {
		return this.maxSparePercentage;
	}

	public void setMaxSparePercentage(double maxSparePercentage) {
		this.maxSparePercentage = maxSparePercentage;
	}

	public double getMaxUsagePercentage() {
		return this.maxUsagePercentage;
	}

	public void setMaxUsagePercentage(double maxUsagePercentage) {
		this.maxUsagePercentage = maxUsagePercentage;
	}

	public double getMinSparePercentage() {
		return this.minSparePercentage;
	}

	public void setMinSparePercentage(double minSparePercentage) {
		this.minSparePercentage = minSparePercentage;
	}

	public double getMinUsagePercentage() {
		return this.minUsagePercentage;
	}

	public void setMinUsagePercentage(double minUsagePercentage) {
		this.minUsagePercentage = minUsagePercentage;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public List<EqSpec> getEqSpecs() {
		return this.eqSpecs;
	}

	public void setEqSpecs(List<EqSpec> eqSpecs) {
		this.eqSpecs = eqSpecs;
	}

	public EqSpec addEqSpec(EqSpec eqSpec) {
		getEqSpecs().add(eqSpec);
		eqSpec.setEqCapacitySpec(this);

		return eqSpec;
	}

	public EqSpec removeEqSpec(EqSpec eqSpec) {
		getEqSpecs().remove(eqSpec);
		eqSpec.setEqCapacitySpec(null);

		return eqSpec;
	}

}