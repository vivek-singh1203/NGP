package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the BLOCKS database table.
 * 
 */
@javax.persistence.Entity
@Table(name = "BLOCKS")
@NamedQuery(name = "Block.findAll", query = "SELECT b FROM Block b")
public class Block implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique = true, nullable = false, length = 25)
	private String name;

	@Column(name = "ALTERNATE_NAME", length = 50)
	private String alternateName;

	@Column(name = "ASSET_IDENTIFIER", length = 30)
	private String assetIdentifier;

	@Column(name = "CREATED_BY", nullable = false, length = 40)
	private String createdBy;

	@Column(name = "CREATED_DATE", nullable = false)
	private Timestamp createdDate;

	@Column(name = "DATA_QUALITY_INDICATOR", length = 20)
	private String dataQualityIndicator;

	@Column(name = "FAULT_STATE", length = 25)
	private String faultState;

	@Column(nullable = false, length = 50)
	private String id;

	@Column(name = "LAST_MODIFIED_BY", length = 40)
	private String lastModifiedBy;

	@Column(name = "LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name = "RESOURCE_1141_CODE", nullable = false, length = 30)
	private String resource1141Code;

	@Column(name = "RESOURCE_STATE", nullable = false, length = 25)
	private String resourceState;

	@Column(name = "SERIAL_NUMBER", length = 30)
	private String serialNumber;

	@Column(name = "SERVICE_STATE", length = 25)
	private String serviceState;

	@Column(name = "SPEC_CATEGORY_NAME", length = 30)
	private String specCategoryName;

	@Column(name = "SPEC_NAME", length = 30)
	private String specName;

	@Column(name = "SPEC_TYPE_NAME", length = 40)
	private String specTypeName;

	@Column(name = "SPEC_VERSION", length = 10)
	private String specVersion;

	@Column(name = "USER_LABEL", length = 50)
	private String userLabel;

	// bi-directional many-to-one association to BlockHolder
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "BLOCK_HOLDER_NAME")
	private BlockHolder blockHolder;

	// bi-directional many-to-one association to DistributionFrame
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FRAME_NAME")
	private DistributionFrame distributionFrame;

	// bi-directional many-to-one association to Store
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STORE_NAME")
	private Store store;

	// bi-directional many-to-one association to Supplier
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SUPPLIER_NAME")
	private Supplier supplier;

	// bi-directional many-to-one association to BlockChar
	@OneToMany(mappedBy = "block")
	private List<BlockChar> blockChars;

	// bi-directional many-to-one association to BlockSelfAssoc
	@OneToMany(mappedBy = "block1")
	private List<BlockSelfAssoc> blockSelfAssocs1;

	// bi-directional many-to-one association to BlockSelfAssoc
	@OneToMany(mappedBy = "block2")
	private List<BlockSelfAssoc> blockSelfAssocs2;

	// bi-directional many-to-one association to DfBhBlockAssoc
	@OneToMany(mappedBy = "block")
	private List<DfBhBlockAssoc> dfBhBlockAssocs;

	// bi-directional many-to-one association to DfBlockPortAssoc
	@OneToMany(mappedBy = "block")
	private List<DfBlockPortAssoc> dfBlockPortAssocs;

	// bi-directional many-to-one association to DfCsPortTerm
	@OneToMany(mappedBy = "block")
	private List<DfCsPortTerm> dfCsPortTerms;

	// bi-directional many-to-one association to DfPort
	@OneToMany(mappedBy = "block")
	private List<DfPort> dfPorts;

	// bi-directional many-to-one association to DfPortPortAssoc
	@OneToMany(mappedBy = "block1")
	private List<DfPortPortAssoc> dfPortPortAssocs1;

	// bi-directional many-to-one association to DfPortPortAssoc
	@OneToMany(mappedBy = "block2")
	private List<DfPortPortAssoc> dfPortPortAssocs2;

	public Block() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public BlockHolder getBlockHolder() {
		return this.blockHolder;
	}

	public void setBlockHolder(BlockHolder blockHolder) {
		this.blockHolder = blockHolder;
	}

	public DistributionFrame getDistributionFrame() {
		return this.distributionFrame;
	}

	public void setDistributionFrame(DistributionFrame distributionFrame) {
		this.distributionFrame = distributionFrame;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public List<BlockChar> getBlockChars() {
		return this.blockChars;
	}

	public void setBlockChars(List<BlockChar> blockChars) {
		this.blockChars = blockChars;
	}

	public BlockChar addBlockChar(BlockChar blockChar) {
		getBlockChars().add(blockChar);
		blockChar.setBlock(this);

		return blockChar;
	}

	public BlockChar removeBlockChar(BlockChar blockChar) {
		getBlockChars().remove(blockChar);
		blockChar.setBlock(null);

		return blockChar;
	}

	public List<BlockSelfAssoc> getBlockSelfAssocs1() {
		return this.blockSelfAssocs1;
	}

	public void setBlockSelfAssocs1(List<BlockSelfAssoc> blockSelfAssocs1) {
		this.blockSelfAssocs1 = blockSelfAssocs1;
	}

	public BlockSelfAssoc addBlockSelfAssocs1(BlockSelfAssoc blockSelfAssocs1) {
		getBlockSelfAssocs1().add(blockSelfAssocs1);
		blockSelfAssocs1.setBlock1(this);

		return blockSelfAssocs1;
	}

	public BlockSelfAssoc removeBlockSelfAssocs1(BlockSelfAssoc blockSelfAssocs1) {
		getBlockSelfAssocs1().remove(blockSelfAssocs1);
		blockSelfAssocs1.setBlock1(null);

		return blockSelfAssocs1;
	}

	public List<BlockSelfAssoc> getBlockSelfAssocs2() {
		return this.blockSelfAssocs2;
	}

	public void setBlockSelfAssocs2(List<BlockSelfAssoc> blockSelfAssocs2) {
		this.blockSelfAssocs2 = blockSelfAssocs2;
	}

	public BlockSelfAssoc addBlockSelfAssocs2(BlockSelfAssoc blockSelfAssocs2) {
		getBlockSelfAssocs2().add(blockSelfAssocs2);
		blockSelfAssocs2.setBlock2(this);

		return blockSelfAssocs2;
	}

	public BlockSelfAssoc removeBlockSelfAssocs2(BlockSelfAssoc blockSelfAssocs2) {
		getBlockSelfAssocs2().remove(blockSelfAssocs2);
		blockSelfAssocs2.setBlock2(null);

		return blockSelfAssocs2;
	}

	public List<DfBhBlockAssoc> getDfBhBlockAssocs() {
		return this.dfBhBlockAssocs;
	}

	public void setDfBhBlockAssocs(List<DfBhBlockAssoc> dfBhBlockAssocs) {
		this.dfBhBlockAssocs = dfBhBlockAssocs;
	}

	public DfBhBlockAssoc addDfBhBlockAssoc(DfBhBlockAssoc dfBhBlockAssoc) {
		getDfBhBlockAssocs().add(dfBhBlockAssoc);
		dfBhBlockAssoc.setBlock(this);

		return dfBhBlockAssoc;
	}

	public DfBhBlockAssoc removeDfBhBlockAssoc(DfBhBlockAssoc dfBhBlockAssoc) {
		getDfBhBlockAssocs().remove(dfBhBlockAssoc);
		dfBhBlockAssoc.setBlock(null);

		return dfBhBlockAssoc;
	}

	public List<DfBlockPortAssoc> getDfBlockPortAssocs() {
		return this.dfBlockPortAssocs;
	}

	public void setDfBlockPortAssocs(List<DfBlockPortAssoc> dfBlockPortAssocs) {
		this.dfBlockPortAssocs = dfBlockPortAssocs;
	}

	public DfBlockPortAssoc addDfBlockPortAssoc(DfBlockPortAssoc dfBlockPortAssoc) {
		getDfBlockPortAssocs().add(dfBlockPortAssoc);
		dfBlockPortAssoc.setBlock(this);

		return dfBlockPortAssoc;
	}

	public DfBlockPortAssoc removeDfBlockPortAssoc(DfBlockPortAssoc dfBlockPortAssoc) {
		getDfBlockPortAssocs().remove(dfBlockPortAssoc);
		dfBlockPortAssoc.setBlock(null);

		return dfBlockPortAssoc;
	}

	public List<DfCsPortTerm> getDfCsPortTerms() {
		return this.dfCsPortTerms;
	}

	public void setDfCsPortTerms(List<DfCsPortTerm> dfCsPortTerms) {
		this.dfCsPortTerms = dfCsPortTerms;
	}

	public DfCsPortTerm addDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().add(dfCsPortTerm);
		dfCsPortTerm.setBlock(this);

		return dfCsPortTerm;
	}

	public DfCsPortTerm removeDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().remove(dfCsPortTerm);
		dfCsPortTerm.setBlock(null);

		return dfCsPortTerm;
	}

	public List<DfPort> getDfPorts() {
		return this.dfPorts;
	}

	public void setDfPorts(List<DfPort> dfPorts) {
		this.dfPorts = dfPorts;
	}

	public DfPort addDfPort(DfPort dfPort) {
		getDfPorts().add(dfPort);
		dfPort.setBlock(this);

		return dfPort;
	}

	public DfPort removeDfPort(DfPort dfPort) {
		getDfPorts().remove(dfPort);
		dfPort.setBlock(null);

		return dfPort;
	}

	public List<DfPortPortAssoc> getDfPortPortAssocs1() {
		return this.dfPortPortAssocs1;
	}

	public void setDfPortPortAssocs1(List<DfPortPortAssoc> dfPortPortAssocs1) {
		this.dfPortPortAssocs1 = dfPortPortAssocs1;
	}

	public DfPortPortAssoc addDfPortPortAssocs1(DfPortPortAssoc dfPortPortAssocs1) {
		getDfPortPortAssocs1().add(dfPortPortAssocs1);
		dfPortPortAssocs1.setBlock1(this);

		return dfPortPortAssocs1;
	}

	public DfPortPortAssoc removeDfPortPortAssocs1(DfPortPortAssoc dfPortPortAssocs1) {
		getDfPortPortAssocs1().remove(dfPortPortAssocs1);
		dfPortPortAssocs1.setBlock1(null);

		return dfPortPortAssocs1;
	}

	public List<DfPortPortAssoc> getDfPortPortAssocs2() {
		return this.dfPortPortAssocs2;
	}

	public void setDfPortPortAssocs2(List<DfPortPortAssoc> dfPortPortAssocs2) {
		this.dfPortPortAssocs2 = dfPortPortAssocs2;
	}

	public DfPortPortAssoc addDfPortPortAssocs2(DfPortPortAssoc dfPortPortAssocs2) {
		getDfPortPortAssocs2().add(dfPortPortAssocs2);
		dfPortPortAssocs2.setBlock2(this);

		return dfPortPortAssocs2;
	}

	public DfPortPortAssoc removeDfPortPortAssocs2(DfPortPortAssoc dfPortPortAssocs2) {
		getDfPortPortAssocs2().remove(dfPortPortAssocs2);
		dfPortPortAssocs2.setBlock2(null);

		return dfPortPortAssocs2;
	}

}