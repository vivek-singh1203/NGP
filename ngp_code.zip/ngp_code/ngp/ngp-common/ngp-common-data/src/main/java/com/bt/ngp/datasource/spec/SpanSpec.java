package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the SPAN_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="SPAN_SPEC")
@NamedQuery(name="SpanSpec.findAll", query="SELECT s FROM SpanSpec s")
public class SpanSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SpanSpecPK spanSpecPKId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DEPTH", precision=126)
	private double depth;

	@Column(name="DEPTH_UNIT", length=10)
	private String depthUnit;

	@Column(precision=126)
	private double diameter;

	@Column(name="DIAMETER_UNIT", length=10)
	private String diameterUnit;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(precision=126)
	private double height;

	@Column(name="HEIGHT_UNIT", length=10)
	private String heightUnit;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="IS_ORDERABLE")
	private String isOrderable;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LENGTH", precision=126)
	private double length;

	@Column(name="LENGTH_UNIT", length=10)
	private String lengthUnit;

	@Column(name="MANUFACTURER_NAME", length=30)
	private String manufacturerName;

	@Column(name="MATERIAL_COST_PER_UNIT", precision=126)
	private double materialCostPerUnit;

	@Column(name="MATERIAL_COST_UNIT", length=10)
	private String materialCostUnit;

	@Column(name="MATERIAL_TYPE", length=10)
	private String materialType;

	@Column(name="SPEC_REMARKS", length=50)
	private String specRemarks;

	@Column(name="SPEC_STATUS", nullable=false, length=10)
	private String specStatus;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	@Column(precision=126)
	private double volume;

	@Column(name="VOLUME_UNIT", length=10)
	private String volumeUnit;

	@Column(precision=126)
	private double weight;

	@Column(name="WEIGHT_UNIT", length=10)
	private String weightUnit;

	@Column(precision=126)
	private double width;

	@Column(name="WIDTH_UNIT", length=10)
	private String widthUnit;

	//bi-directional many-to-one association to CableSpanCompatSpec
	@OneToMany(mappedBy="spanSpec")
	private List<CableSpanCompatSpec> cableSpanCompatSpecs;

	//bi-directional many-to-one association to SpanSelfAssocSpec
	@OneToMany(mappedBy="spanSpec1")
	private List<SpanSelfAssocSpec> spanSelfAssocSpecs1;

	//bi-directional many-to-one association to SpanSelfAssocSpec
	@OneToMany(mappedBy="spanSpec2")
	private List<SpanSelfAssocSpec> spanSelfAssocSpecs2;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to SpanSpecCharSpec
	@OneToMany(mappedBy="spanSpec")
	private List<SpanSpecCharSpec> spanSpecCharSpecs;

	//bi-directional many-to-one association to SpanSpecCharSpecRel
	@OneToMany(mappedBy="spanSpec")
	private List<SpanSpecCharSpecRel> spanSpecCharSpecRels;

	//bi-directional many-to-one association to SpanSpecCharValueSpec
	@OneToMany(mappedBy="spanSpec")
	private List<SpanSpecCharValueSpec> spanSpecCharValueSpecs;

	//bi-directional many-to-one association to StructureSpanCompatSpec
	@OneToMany(mappedBy="spanSpec")
	private List<StructureSpanCompatSpec> structureSpanCompatSpecs;

	public SpanSpec() {
	}

	public SpanSpecPK getSpanSpecPKId() {
		return this.spanSpecPKId;
	}

	public void setId(SpanSpecPK spanSpecPKId) {
		this.spanSpecPKId = spanSpecPKId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public double getDepth() {
		return this.depth;
	}

	public void setDepth(double depth) {
		this.depth = depth;
	}

	public String getDepthUnit() {
		return this.depthUnit;
	}

	public void setDepthUnit(String depthUnit) {
		this.depthUnit = depthUnit;
	}

	public double getDiameter() {
		return this.diameter;
	}

	public void setDiameter(double diameter) {
		this.diameter = diameter;
	}

	public String getDiameterUnit() {
		return this.diameterUnit;
	}

	public void setDiameterUnit(String diameterUnit) {
		this.diameterUnit = diameterUnit;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public double getHeight() {
		return this.height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public String getHeightUnit() {
		return this.heightUnit;
	}

	public void setHeightUnit(String heightUnit) {
		this.heightUnit = heightUnit;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIsOrderable() {
		return this.isOrderable;
	}

	public void setIsOrderable(String isOrderable) {
		this.isOrderable = isOrderable;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public double getLength() {
		return this.length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public String getLengthUnit() {
		return this.lengthUnit;
	}

	public void setLengthUnit(String lengthUnit) {
		this.lengthUnit = lengthUnit;
	}

	public String getManufacturerName() {
		return this.manufacturerName;
	}

	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}

	public double getMaterialCostPerUnit() {
		return this.materialCostPerUnit;
	}

	public void setMaterialCostPerUnit(double materialCostPerUnit) {
		this.materialCostPerUnit = materialCostPerUnit;
	}

	public String getMaterialCostUnit() {
		return this.materialCostUnit;
	}

	public void setMaterialCostUnit(String materialCostUnit) {
		this.materialCostUnit = materialCostUnit;
	}

	public String getMaterialType() {
		return this.materialType;
	}

	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}

	public String getSpecRemarks() {
		return this.specRemarks;
	}

	public void setSpecRemarks(String specRemarks) {
		this.specRemarks = specRemarks;
	}

	public String getSpecStatus() {
		return this.specStatus;
	}

	public void setSpecStatus(String specStatus) {
		this.specStatus = specStatus;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public double getVolume() {
		return this.volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public String getVolumeUnit() {
		return this.volumeUnit;
	}

	public void setVolumeUnit(String volumeUnit) {
		this.volumeUnit = volumeUnit;
	}

	public double getWeight() {
		return this.weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getWeightUnit() {
		return this.weightUnit;
	}

	public void setWeightUnit(String weightUnit) {
		this.weightUnit = weightUnit;
	}

	public double getWidth() {
		return this.width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public String getWidthUnit() {
		return this.widthUnit;
	}

	public void setWidthUnit(String widthUnit) {
		this.widthUnit = widthUnit;
	}

	public List<CableSpanCompatSpec> getCableSpanCompatSpecs() {
		return this.cableSpanCompatSpecs;
	}

	public void setCableSpanCompatSpecs(List<CableSpanCompatSpec> cableSpanCompatSpecs) {
		this.cableSpanCompatSpecs = cableSpanCompatSpecs;
	}

	public CableSpanCompatSpec addCableSpanCompatSpec(CableSpanCompatSpec cableSpanCompatSpec) {
		getCableSpanCompatSpecs().add(cableSpanCompatSpec);
		cableSpanCompatSpec.setSpanSpec(this);

		return cableSpanCompatSpec;
	}

	public CableSpanCompatSpec removeCableSpanCompatSpec(CableSpanCompatSpec cableSpanCompatSpec) {
		getCableSpanCompatSpecs().remove(cableSpanCompatSpec);
		cableSpanCompatSpec.setSpanSpec(null);

		return cableSpanCompatSpec;
	}

	public List<SpanSelfAssocSpec> getSpanSelfAssocSpecs1() {
		return this.spanSelfAssocSpecs1;
	}

	public void setSpanSelfAssocSpecs1(List<SpanSelfAssocSpec> spanSelfAssocSpecs1) {
		this.spanSelfAssocSpecs1 = spanSelfAssocSpecs1;
	}

	public SpanSelfAssocSpec addSpanSelfAssocSpecs1(SpanSelfAssocSpec spanSelfAssocSpecs1) {
		getSpanSelfAssocSpecs1().add(spanSelfAssocSpecs1);
		spanSelfAssocSpecs1.setSpanSpec1(this);

		return spanSelfAssocSpecs1;
	}

	public SpanSelfAssocSpec removeSpanSelfAssocSpecs1(SpanSelfAssocSpec spanSelfAssocSpecs1) {
		getSpanSelfAssocSpecs1().remove(spanSelfAssocSpecs1);
		spanSelfAssocSpecs1.setSpanSpec1(null);

		return spanSelfAssocSpecs1;
	}

	public List<SpanSelfAssocSpec> getSpanSelfAssocSpecs2() {
		return this.spanSelfAssocSpecs2;
	}

	public void setSpanSelfAssocSpecs2(List<SpanSelfAssocSpec> spanSelfAssocSpecs2) {
		this.spanSelfAssocSpecs2 = spanSelfAssocSpecs2;
	}

	public SpanSelfAssocSpec addSpanSelfAssocSpecs2(SpanSelfAssocSpec spanSelfAssocSpecs2) {
		getSpanSelfAssocSpecs2().add(spanSelfAssocSpecs2);
		spanSelfAssocSpecs2.setSpanSpec2(this);

		return spanSelfAssocSpecs2;
	}

	public SpanSelfAssocSpec removeSpanSelfAssocSpecs2(SpanSelfAssocSpec spanSelfAssocSpecs2) {
		getSpanSelfAssocSpecs2().remove(spanSelfAssocSpecs2);
		spanSelfAssocSpecs2.setSpanSpec2(null);

		return spanSelfAssocSpecs2;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public List<SpanSpecCharSpec> getSpanSpecCharSpecs() {
		return this.spanSpecCharSpecs;
	}

	public void setSpanSpecCharSpecs(List<SpanSpecCharSpec> spanSpecCharSpecs) {
		this.spanSpecCharSpecs = spanSpecCharSpecs;
	}

	public SpanSpecCharSpec addSpanSpecCharSpec(SpanSpecCharSpec spanSpecCharSpec) {
		getSpanSpecCharSpecs().add(spanSpecCharSpec);
		spanSpecCharSpec.setSpanSpec(this);

		return spanSpecCharSpec;
	}

	public SpanSpecCharSpec removeSpanSpecCharSpec(SpanSpecCharSpec spanSpecCharSpec) {
		getSpanSpecCharSpecs().remove(spanSpecCharSpec);
		spanSpecCharSpec.setSpanSpec(null);

		return spanSpecCharSpec;
	}

	public List<SpanSpecCharSpecRel> getSpanSpecCharSpecRels() {
		return this.spanSpecCharSpecRels;
	}

	public void setSpanSpecCharSpecRels(List<SpanSpecCharSpecRel> spanSpecCharSpecRels) {
		this.spanSpecCharSpecRels = spanSpecCharSpecRels;
	}

	public SpanSpecCharSpecRel addSpanSpecCharSpecRel(SpanSpecCharSpecRel spanSpecCharSpecRel) {
		getSpanSpecCharSpecRels().add(spanSpecCharSpecRel);
		spanSpecCharSpecRel.setSpanSpec(this);

		return spanSpecCharSpecRel;
	}

	public SpanSpecCharSpecRel removeSpanSpecCharSpecRel(SpanSpecCharSpecRel spanSpecCharSpecRel) {
		getSpanSpecCharSpecRels().remove(spanSpecCharSpecRel);
		spanSpecCharSpecRel.setSpanSpec(null);

		return spanSpecCharSpecRel;
	}

	public List<SpanSpecCharValueSpec> getSpanSpecCharValueSpecs() {
		return this.spanSpecCharValueSpecs;
	}

	public void setSpanSpecCharValueSpecs(List<SpanSpecCharValueSpec> spanSpecCharValueSpecs) {
		this.spanSpecCharValueSpecs = spanSpecCharValueSpecs;
	}

	public SpanSpecCharValueSpec addSpanSpecCharValueSpec(SpanSpecCharValueSpec spanSpecCharValueSpec) {
		getSpanSpecCharValueSpecs().add(spanSpecCharValueSpec);
		spanSpecCharValueSpec.setSpanSpec(this);

		return spanSpecCharValueSpec;
	}

	public SpanSpecCharValueSpec removeSpanSpecCharValueSpec(SpanSpecCharValueSpec spanSpecCharValueSpec) {
		getSpanSpecCharValueSpecs().remove(spanSpecCharValueSpec);
		spanSpecCharValueSpec.setSpanSpec(null);

		return spanSpecCharValueSpec;
	}

	public List<StructureSpanCompatSpec> getStructureSpanCompatSpecs() {
		return this.structureSpanCompatSpecs;
	}

	public void setStructureSpanCompatSpecs(List<StructureSpanCompatSpec> structureSpanCompatSpecs) {
		this.structureSpanCompatSpecs = structureSpanCompatSpecs;
	}

	public StructureSpanCompatSpec addStructureSpanCompatSpec(StructureSpanCompatSpec structureSpanCompatSpec) {
		getStructureSpanCompatSpecs().add(structureSpanCompatSpec);
		structureSpanCompatSpec.setSpanSpec(this);

		return structureSpanCompatSpec;
	}

	public StructureSpanCompatSpec removeStructureSpanCompatSpec(StructureSpanCompatSpec structureSpanCompatSpec) {
		getStructureSpanCompatSpecs().remove(structureSpanCompatSpec);
		structureSpanCompatSpec.setSpanSpec(null);

		return structureSpanCompatSpec;
	}

}