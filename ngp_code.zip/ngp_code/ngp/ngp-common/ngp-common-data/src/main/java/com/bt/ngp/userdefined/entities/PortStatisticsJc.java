/**
 * this class is to map resultset for JointClosure port statistic data
 *
 * @since 5 Feb 2018
 * @author Aditya Ajmera 609734641
 */

package com.bt.ngp.userdefined.entities;

import com.bt.ngp.datasource.entities.JointClosure;
import com.bt.ngp.datasource.entities.Plugin;

/**
 * @author 609734641
 *
 */
public class PortStatisticsJc {
	private JointClosure jointClosure;

	private Plugin plugin;

	private long portCount;

	/**
	 * default constructor
	 */
	public PortStatisticsJc() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param jointClosure
	 * @param plugin
	 * @param portCount
	 */
	public PortStatisticsJc(JointClosure jointClosure, Plugin plugin,
			long portCount) {
		super();
		this.jointClosure = jointClosure;
		this.plugin = plugin;
		this.portCount = portCount;
	}

	/**
	 * @return the jointClosure
	 */
	public JointClosure getJointClosure() {
		return jointClosure;
	}

	/**
	 * @param jointClosure the jointClosure to set
	 */
	public void setJointClosure(JointClosure jointClosure) {
		this.jointClosure = jointClosure;
	}

	/**
	 * @return the plugin
	 */
	public Plugin getPlugin() {
		return plugin;
	}

	/**
	 * @param plugin the plugin to set
	 */
	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

	/**
	 * @return the portCount
	 */
	public long getPortCount() {
		return portCount;
	}

	/**
	 * @param portCount the portCount to set
	 */
	public void setPortCount(long portCount) {
		this.portCount = portCount;
	}
}
