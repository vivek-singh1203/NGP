/**
 * port statistics class for distribution point
 *
 * @since 5 Feb 2018
 * @author Aditya Ajmera 609734641
 */

package com.bt.ngp.userdefined.entities;

import com.bt.ngp.datasource.entities.DistributionPoint;
import com.bt.ngp.datasource.entities.Plugin;

/**
 * @author 609734641
 *
 */
public class PortStatisticsDp {
	private DistributionPoint distributionPoint;

	private Plugin plugin;

	private long portCount;

	/**
	 * default constructor
	 */
	public PortStatisticsDp() {
		super();
	}

	/**
	 * @param distributionPoint
	 * @param plugin
	 * @param portCount
	 */
	public PortStatisticsDp(DistributionPoint distributionPoint, Plugin plugin,
			long portCount) {
		super();
		this.distributionPoint = distributionPoint;
		this.plugin = plugin;
		this.portCount = portCount;
	}

	/**
	 * @return the distributionPoint
	 */
	public DistributionPoint getDistributionPoint() {
		return distributionPoint;
	}

	/**
	 * @param distributionPoint the distributionPoint to set
	 */
	public void setDistributionPoint(DistributionPoint distributionPoint) {
		this.distributionPoint = distributionPoint;
	}

	/**
	 * @return the plugin
	 */
	public Plugin getPlugin() {
		return plugin;
	}

	/**
	 * @param plugin the plugin to set
	 */
	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

	/**
	 * @return the portCount
	 */
	public long getPortCount() {
		return portCount;
	}

	/**
	 * @param portCount the portCount to set
	 */
	public void setPortCount(long portCount) {
		this.portCount = portCount;
	}
}
