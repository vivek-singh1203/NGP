package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the CCP_CS_COND_SPLICING database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CCP_CS_COND_SPLICING")
@NamedQuery(name="CcpCsCondSplicing.findAll", query="SELECT c FROM CcpCsCondSplicing c")
public class CcpCsCondSplicing implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique = true, nullable = false, length = 50)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SeqGen")
    @SequenceGenerator(name = "SeqGen", sequenceName = "CCP_CS_COND_SPLICING_SEQ", allocationSize = 1)
	private long id;

	@Column(name = "CREATED_BY", nullable = false, length = 40)
	private String createdBy;

	@Column(name = "CREATED_DATE", nullable = false)
	private Timestamp createdDate;

	@Column(name = "DATA_QUALITY_INDICATOR", length = 20)
	private String dataQualityIndicator;

	@Column(name = "LAST_MODIFIED_BY", length = 40)
	private String lastModifiedBy;

	@Column(name = "LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name = "ORIG_COND_SEQ_NUM", nullable = false, precision = 38)
	private BigDecimal origCondSeqNum;

	@Column(name="SPLICING_RESOURCE", nullable=false, length=20)
	private String splicingResource;

	@Column(name = "SPLICING_STATE", length = 20)
	private String splicingState;

	@Column(name = "TERM_COND_SEQ_NUM", nullable = false, precision = 38)
	private BigDecimal termCondSeqNum;

	//bi-directional many-to-one association to CrossConnectPoint
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CCP_NAME")
	private CrossConnectPoint crossConnectPoint;

	//bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_CB_NAME")
	private ConductorBundle origCbName;

	//bi-directional many-to-one association to Conductor
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ORIG_COND_NAME")
	private Conductor origCondName;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ORIG_CS_NAME")
	private CableSection origCsName;

	// bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "ORIG_PARENT_CS_NAME")
	private CableSection origParentCsName;

	// bi-directional many-to-one association to ConductorBundle
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "TERM_CB_NAME")
	private ConductorBundle termCbName;

	// bi-directional many-to-one association to Conductor
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "TERM_COND_NAME")
	private Conductor termCondName;

	// bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "TERM_CS_NAME")
	private CableSection termCsName;

	// bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "TERM_PARENT_CS_NAME")
	private CableSection termParentCsName;

	public CcpCsCondSplicing() {
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy
	 *            the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	public Timestamp getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate
	 *            the createdDate to set
	 */
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the dataQualityIndicator
	 */
	public String getDataQualityIndicator() {
		return dataQualityIndicator;
	}

	/**
	 * @param dataQualityIndicator
	 *            the dataQualityIndicator to set
	 */
	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	/**
	 * @param lastModifiedBy
	 *            the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	/**
	 * @return the lastModifiedDate
	 */
	public Timestamp getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * @param lastModifiedDate
	 *            the lastModifiedDate to set
	 */
	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/**
	 * @return the origCondSeqNum
	 */
	public BigDecimal getOrigCondSeqNum() {
		return origCondSeqNum;
	}

	/**
	 * @param origCondSeqNum
	 *            the origCondSeqNum to set
	 */
	public void setOrigCondSeqNum(BigDecimal origCondSeqNum) {
		this.origCondSeqNum = origCondSeqNum;
	}

	/**
	 * @return the splicingResource
	 */
	public String getSplicingResource() {
		return splicingResource;
	}

	/**
	 * @param splicingResource
	 *            the splicingResource to set
	 */
	public void setSplicingResource(String splicingResource) {
		this.splicingResource = splicingResource;
	}

	/**
	 * @return the splicingState
	 */
	public String getSplicingState() {
		return splicingState;
	}

	/**
	 * @param splicingState
	 *            the splicingState to set
	 */
	public void setSplicingState(String splicingState) {
		this.splicingState = splicingState;
	}

	/**
	 * @return the termCondSeqNum
	 */
	public BigDecimal getTermCondSeqNum() {
		return termCondSeqNum;
	}

	/**
	 * @param termCondSeqNum
	 *            the termCondSeqNum to set
	 */
	public void setTermCondSeqNum(BigDecimal termCondSeqNum) {
		this.termCondSeqNum = termCondSeqNum;
	}

	/**
	 * @return the crossConnectPoint
	 */
	public CrossConnectPoint getCrossConnectPoint() {
		return crossConnectPoint;
	}

	/**
	 * @param crossConnectPoint
	 *            the crossConnectPoint to set
	 */
	public void setCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		this.crossConnectPoint = crossConnectPoint;
	}

	/**
	 * @return the origCbName
	 */
	public ConductorBundle getOrigCbName() {
		return origCbName;
	}

	/**
	 * @param origCbName
	 *            the origCbName to set
	 */
	public void setOrigCbName(ConductorBundle origCbName) {
		this.origCbName = origCbName;
	}

	/**
	 * @return the origCondName
	 */
	public Conductor getOrigCondName() {
		return origCondName;
	}

	/**
	 * @param origCondName
	 *            the origCondName to set
	 */
	public void setOrigCondName(Conductor origCondName) {
		this.origCondName = origCondName;
	}

	/**
	 * @return the origCsName
	 */
	public CableSection getOrigCsName() {
		return origCsName;
	}

	/**
	 * @param origCsName
	 *            the origCsName to set
	 */
	public void setOrigCsName(CableSection origCsName) {
		this.origCsName = origCsName;
	}

	/**
	 * @return the origParentCsName
	 */
	public CableSection getOrigParentCsName() {
		return origParentCsName;
	}

	/**
	 * @param origParentCsName
	 *            the origParentCsName to set
	 */
	public void setOrigParentCsName(CableSection origParentCsName) {
		this.origParentCsName = origParentCsName;
	}

	/**
	 * @return the termCbName
	 */
	public ConductorBundle getTermCbName() {
		return termCbName;
	}

	/**
	 * @param termCbName
	 *            the termCbName to set
	 */
	public void setTermCbName(ConductorBundle termCbName) {
		this.termCbName = termCbName;
	}

	/**
	 * @return the termCondName
	 */
	public Conductor getTermCondName() {
		return termCondName;
	}

	/**
	 * @param termCondName
	 *            the termCondName to set
	 */
	public void setTermCondName(Conductor termCondName) {
		this.termCondName = termCondName;
	}

	/**
	 * @return the termCsName
	 */
	public CableSection getTermCsName() {
		return termCsName;
	}

	/**
	 * @param termCsName
	 *            the termCsName to set
	 */
	public void setTermCsName(CableSection termCsName) {
		this.termCsName = termCsName;
	}

	/**
	 * @return the termParentCsName
	 */
	public CableSection getTermParentCsName() {
		return termParentCsName;
	}

	/**
	 * @param termParentCsName
	 *            the termParentCsName to set
	 */
	public void setTermParentCsName(CableSection termParentCsName) {
		this.termParentCsName = termParentCsName;
	}

}