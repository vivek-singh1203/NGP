package com.bt.ngp.common.data.jpa.repository;

import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.JchamberChar;

@Repository
public interface JChamberCharRepository extends SqlRepository<JchamberChar> {

}
