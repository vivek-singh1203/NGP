package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the CABLE_SPAN_COMPAT_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CABLE_SPAN_COMPAT_SPEC")
@NamedQuery(name="CableSpanCompatSpec.findAll", query="SELECT c FROM CableSpanCompatSpec c")
public class CableSpanCompatSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CABLE_ENTITY_NAME", length=30)
	private String cableEntityName;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="IS_COMPATIBLE", nullable=false)
	private BigDecimal isCompatible;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="SPAN_ENTITY_NAME", length=30)
	private String spanEntityName;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="CABLE_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory1;

	//bi-directional many-to-one association to CableSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="CABLE_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="CABLE_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private CableSpec cableSpec;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="CABLE_SPEC_TYPE_NAME")
	private SpecType specType1;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPAN_SPEC_CATEGORY_NAME")
	private SpecCategory specCategory2;

	//bi-directional many-to-one association to SpanSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="SPAN_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="SPAN_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private SpanSpec spanSpec;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPAN_SPEC_TYPE_NAME")
	private SpecType specType2;

	public CableSpanCompatSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCableEntityName() {
		return this.cableEntityName;
	}

	public void setCableEntityName(String cableEntityName) {
		this.cableEntityName = cableEntityName;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public BigDecimal getIsCompatible() {
		return this.isCompatible;
	}

	public void setIsCompatible(BigDecimal isCompatible) {
		this.isCompatible = isCompatible;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getSpanEntityName() {
		return this.spanEntityName;
	}

	public void setSpanEntityName(String spanEntityName) {
		this.spanEntityName = spanEntityName;
	}

	public SpecCategory getSpecCategory1() {
		return this.specCategory1;
	}

	public void setSpecCategory1(SpecCategory specCategory1) {
		this.specCategory1 = specCategory1;
	}

	public CableSpec getCableSpec() {
		return this.cableSpec;
	}

	public void setCableSpec(CableSpec cableSpec) {
		this.cableSpec = cableSpec;
	}

	public SpecType getSpecType1() {
		return this.specType1;
	}

	public void setSpecType1(SpecType specType1) {
		this.specType1 = specType1;
	}

	public SpecCategory getSpecCategory2() {
		return this.specCategory2;
	}

	public void setSpecCategory2(SpecCategory specCategory2) {
		this.specCategory2 = specCategory2;
	}

	public SpanSpec getSpanSpec() {
		return this.spanSpec;
	}

	public void setSpanSpec(SpanSpec spanSpec) {
		this.spanSpec = spanSpec;
	}

	public SpecType getSpecType2() {
		return this.specType2;
	}

	public void setSpecType2(SpecType specType2) {
		this.specType2 = specType2;
	}

}