package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the POLE_CHAR database table.
 * 
 */
@javax.persistence.Entity
@Table(name="POLE_CHAR")
@NamedQuery(name="PoleChar.findAll", query="SELECT p FROM PoleChar p")
public class PoleChar implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CHAR_NAME", nullable=false, length=30)
	private String charName;

	@Column(name="CHAR_SPEC_ID", length=50)
	private String charSpecId;

	@Column(name="CHAR_VALUE", length=50)
	private String charValue;

	@Column(name="CHAR_VALUE_SPEC_ID", length=50)
	private String charValueSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to Pole
	@ManyToOne
	@JoinColumn(name="POLE_NAME")
	private Pole pole;

	public PoleChar() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCharName() {
		return this.charName;
	}

	public void setCharName(String charName) {
		this.charName = charName;
	}

	public String getCharSpecId() {
		return this.charSpecId;
	}

	public void setCharSpecId(String charSpecId) {
		this.charSpecId = charSpecId;
	}

	public String getCharValue() {
		return this.charValue;
	}

	public void setCharValue(String charValue) {
		this.charValue = charValue;
	}

	public String getCharValueSpecId() {
		return this.charValueSpecId;
	}

	public void setCharValueSpecId(String charValueSpecId) {
		this.charValueSpecId = charValueSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Pole getPole() {
		return this.pole;
	}

	public void setPole(Pole pole) {
		this.pole = pole;
	}

}