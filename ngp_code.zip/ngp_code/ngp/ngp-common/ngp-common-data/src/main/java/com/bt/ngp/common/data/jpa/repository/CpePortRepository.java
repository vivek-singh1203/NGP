package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CpePort;
import com.bt.ngp.userdefined.entities.PortStatisticsCpe;

@Repository
public interface CpePortRepository extends CommonOperation<CpePort> {
	@Query(name = "CpePortRepository.fetchPortCountInPlugin", nativeQuery = false)
	public List<PortStatisticsCpe> fetchPortCount(
			@Param("cpePort") CpePort cpePort);
}