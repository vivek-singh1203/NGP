package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the CABLE_SELF_ASSOC_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CABLE_SELF_ASSOC_SPEC")
@NamedQuery(name="CableSelfAssocSpec.findAll", query="SELECT c FROM CableSelfAssocSpec c")
public class CableSelfAssocSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, precision=38)
	private long id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="NO_OF_CHILD_INSTANCES", nullable=false, precision=38)
	private BigDecimal noOfChildInstances;

	//bi-directional many-to-one association to CableSpec
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="CHILD_CABLE_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="CHILD_CABLE_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private CableSpec cableSpec1;

	//bi-directional many-to-one association to CableSpec
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="PARENT_CABLE_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="PARENT_CABLE_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private CableSpec cableSpec2;

	public CableSelfAssocSpec() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getNoOfChildInstances() {
		return this.noOfChildInstances;
	}

	public void setNoOfChildInstances(BigDecimal noOfChildInstances) {
		this.noOfChildInstances = noOfChildInstances;
	}

	public CableSpec getCableSpec1() {
		return this.cableSpec1;
	}

	public void setCableSpec1(CableSpec cableSpec1) {
		this.cableSpec1 = cableSpec1;
	}

	public CableSpec getCableSpec2() {
		return this.cableSpec2;
	}

	public void setCableSpec2(CableSpec cableSpec2) {
		this.cableSpec2 = cableSpec2;
	}

}