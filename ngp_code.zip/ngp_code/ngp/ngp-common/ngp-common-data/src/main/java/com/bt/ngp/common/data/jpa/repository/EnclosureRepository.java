package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.Enclosure;

@Repository
public interface EnclosureRepository extends SqlRepository<Enclosure> {

	public Enclosure findByName(@Param("name") String name);
	
	public List<Enclosure> findByNameIn(List<String> structures);
	
	@Query(name="EnclosureRepository.findEnclosureWithoutSpanSectionAssoc", nativeQuery=true)
	public List<Enclosure> findEnclosureWithoutSpanSectionAssoc(@Param("exchangeCode") String exchangeCode);
	
	@Query(name="EnclosureRepository.EnclosureWithoutEquipment", nativeQuery=true)
	public List<Enclosure> findEnclosureWithoutEquipment(@Param("exchangeCode") String exchangeCode, @Param("physicalStructureType") String physicalStructureType);
	
}