package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the MFN_HIERARCHY database table.
 * 
 */
@javax.persistence.Entity
@Table(name="MFN_HIERARCHY")
@NamedQuery(name="MfnHierarchy.findAll", query="SELECT m FROM MfnHierarchy m")
public class MfnHierarchy implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="EQ_HIERARCHY_SPEC_ID", length=50)
	private String eqHierarchySpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LEG_ID", precision=38)
	private BigDecimal legId;

	@Column(name="MFN_POS_END_NUM", nullable=false, precision=38)
	private BigDecimal mfnPosEndNum;

	@Column(name="MFN_POS_START_NUM", nullable=false, precision=38)
	private BigDecimal mfnPosStartNum;

	//bi-directional many-to-one association to MfnChassisPhAssoc
	@ManyToOne
	@JoinColumn(name="CHASSIS_PH_ASSOC_ID")
	private MfnChassisPhAssoc mfnChassisPhAssoc;

	//bi-directional many-to-one association to MultiFunctionalNode
	@ManyToOne
	@JoinColumn(name="MFN_NAME")
	private MultiFunctionalNode multiFunctionalNode;

	//bi-directional many-to-one association to MfnPhPluginAssoc
	@ManyToOne
	@JoinColumn(name="PH_PLUGIN_ASSOC_ID")
	private MfnPhPluginAssoc mfnPhPluginAssoc;

	//bi-directional many-to-one association to MfnPluginPortAssoc
	@ManyToOne
	@JoinColumn(name="PLUGIN_PORT_ASSOC_ID")
	private MfnPluginPortAssoc mfnPluginPortAssoc;

	public MfnHierarchy() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEqHierarchySpecId() {
		return this.eqHierarchySpecId;
	}

	public void setEqHierarchySpecId(String eqHierarchySpecId) {
		this.eqHierarchySpecId = eqHierarchySpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getLegId() {
		return this.legId;
	}

	public void setLegId(BigDecimal legId) {
		this.legId = legId;
	}

	public BigDecimal getMfnPosEndNum() {
		return this.mfnPosEndNum;
	}

	public void setMfnPosEndNum(BigDecimal mfnPosEndNum) {
		this.mfnPosEndNum = mfnPosEndNum;
	}

	public BigDecimal getMfnPosStartNum() {
		return this.mfnPosStartNum;
	}

	public void setMfnPosStartNum(BigDecimal mfnPosStartNum) {
		this.mfnPosStartNum = mfnPosStartNum;
	}

	public MfnChassisPhAssoc getMfnChassisPhAssoc() {
		return this.mfnChassisPhAssoc;
	}

	public void setMfnChassisPhAssoc(MfnChassisPhAssoc mfnChassisPhAssoc) {
		this.mfnChassisPhAssoc = mfnChassisPhAssoc;
	}

	public MultiFunctionalNode getMultiFunctionalNode() {
		return this.multiFunctionalNode;
	}

	public void setMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		this.multiFunctionalNode = multiFunctionalNode;
	}

	public MfnPhPluginAssoc getMfnPhPluginAssoc() {
		return this.mfnPhPluginAssoc;
	}

	public void setMfnPhPluginAssoc(MfnPhPluginAssoc mfnPhPluginAssoc) {
		this.mfnPhPluginAssoc = mfnPhPluginAssoc;
	}

	public MfnPluginPortAssoc getMfnPluginPortAssoc() {
		return this.mfnPluginPortAssoc;
	}

	public void setMfnPluginPortAssoc(MfnPluginPortAssoc mfnPluginPortAssoc) {
		this.mfnPluginPortAssoc = mfnPluginPortAssoc;
	}

}