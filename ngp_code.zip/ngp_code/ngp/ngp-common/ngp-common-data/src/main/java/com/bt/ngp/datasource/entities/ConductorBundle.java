package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the CONDUCTOR_BUNDLE database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CONDUCTOR_BUNDLE")
@NamedQuery(name="ConductorBundle.findAll", query="SELECT c FROM ConductorBundle c")
public class ConductorBundle implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CALCULATED_LENGTH", precision=126)
	private double calculatedLength;

	@Column(name="CALCULATED_LENGTH_UNIT", length=10)
	private String calculatedLengthUnit;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	/*@Column(name="GEO_POSITION", nullable=false)
	 private Object geoPosition; */

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="MEASURED_LENGTH", precision=126)
	private double measuredLength;

	@Column(name="MEASURED_LENGTH_UNIT", length=10)
	private String measuredLengthUnit;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name = "SPEC_NAME", length = 30)
	private String specName;

	/**
	 * @return the specName
	 */
	public String getSpecName() {
		return specName;
	}

	/**
	 * @param specName the specName to set
	 */
	public void setSpecName(String specName) {
		this.specName = specName;
	}

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to CableSectionHierarchy
	@OneToMany(mappedBy="conductorBundle")
	private List<CableSectionHierarchy> cableSectionHierarchies;

	//bi-directional many-to-one association to CbChar
	@OneToMany(mappedBy="conductorBundle")
	private List<CbChar> cbChars;

	//bi-directional many-to-one association to CbSelfAssoc
	@OneToMany(mappedBy="conductorBundle1")
	private List<CbSelfAssoc> cbSelfAssocs1;

	//bi-directional many-to-one association to CbSelfAssoc
	@OneToMany(mappedBy="conductorBundle2")
	private List<CbSelfAssoc> cbSelfAssocs2;

	//bi-directional many-to-one association to CcpCableConductorSplicing
	@OneToMany(mappedBy="origCbName")
	private List<CcpCsCondSplicing> ccpCableConductorSplicingsOrigCbName;

	//bi-directional many-to-one association to CcpCableConductorSplicing
	@OneToMany(mappedBy="termCbName")
	private List<CcpCsCondSplicing> ccpCableConductorSplicingsTermCbName;

	//bi-directional many-to-one association to CcpCsPortTerm
	@OneToMany(mappedBy="conductorBundle")
	private List<CcpCsPortTerm> ccpCsPortTerms;

	//bi-directional many-to-one association to CbSpec
/*	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private CbSpec cbSpec;*/

	//bi-directional many-to-one association to Exchange
	@ManyToOne
	@JoinColumn(name="EXCHANGE_1141_CODE")
	private Exchange exchange;

	//bi-directional many-to-one association to Store
	@ManyToOne
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to CpeCsCondSplicing
	@OneToMany(mappedBy="conductorBundleOrigCbName")
	private List<CpeCsCondSplicing> cpeCsCondSplicings1;

	//bi-directional many-to-one association to CpeCsCondSplicing
	@OneToMany(mappedBy="conductorBundleTermCbName")
	private List<CpeCsCondSplicing> cpeCsCondSplicings2;

	//bi-directional many-to-one association to CpeCsPortTerm
	@OneToMany(mappedBy="conductorBundle")
	private List<CpeCsPortTerm> cpeCsPortTerms;

	//bi-directional many-to-one association to DfCsCondSplicing
	@OneToMany(mappedBy="conductorBundleOrigCbName")
	private List<DfCsCondSplicing> dfCsCondSplicings1;

	//bi-directional many-to-one association to DfCsCondSplicing
	@OneToMany(mappedBy="conductorBundleTermCbName")
	private List<DfCsCondSplicing> dfCsCondSplicings2;

	//bi-directional many-to-one association to DfCsPortTerm
	@OneToMany(mappedBy="conductorBundle")
	private List<DfCsPortTerm> dfCsPortTerms;

	//bi-directional many-to-one association to DpCsCondSplicing
	@OneToMany(mappedBy="conductorBundleOrigCbName")
	private List<DpCsCondSplicing> dpCsCondSplicings1;

	//bi-directional many-to-one association to DpCsCondSplicing
	@OneToMany(mappedBy="conductorBundleTermCbName")
	private List<DpCsCondSplicing> dpCsCondSplicings2;

	//bi-directional many-to-one association to DpCsPortTerm
	@OneToMany(mappedBy="conductorBundle")
	private List<DpCsPortTerm> dpCsPortTerms;

	//bi-directional many-to-one association to DslamCsCondSplicing
	@OneToMany(mappedBy="conductorBundleOrigCbName")
	private List<DslamCsCondSplicing> dslamCsCondSplicings1;

	//bi-directional many-to-one association to DslamCsCondSplicing
	@OneToMany(mappedBy="conductorBundleTermCbName")
	private List<DslamCsCondSplicing> dslamCsCondSplicings2;

	//bi-directional many-to-one association to DslamCsPortTerm
	@OneToMany(mappedBy="conductorBundle")
	private List<DslamCsPortTerm> dslamCsPortTerms;

	//bi-directional many-to-one association to JcCsCondSplicing
	@OneToMany(mappedBy="conductorBundleOrigCbName")
	private List<JcCsCondSplicing> jcCsCondSplicings1;

	//bi-directional many-to-one association to JcCsCondSplicing
	@OneToMany(mappedBy="conductorBundleTermCbName")
	private List<JcCsCondSplicing> jcCsCondSplicings2;

	//bi-directional many-to-one association to JcCsPortTerm
	@OneToMany(mappedBy="conductorBundle")
	private List<JcCsPortTerm> jcCsPortTerms;

	//bi-directional many-to-one association to MfnCableConductorSplicing
	@OneToMany(mappedBy="origCbName")
	private List<MfnCsCondSplicing> mfnCableConductorOrigCbName;

	//bi-directional many-to-one association to MfnCableConductorSplicing
	@OneToMany(mappedBy="termCbName")
	private List<MfnCsCondSplicing> mfnCableConductorTermCbName;

	//bi-directional many-to-one association to MfnCsPortTerm
	@OneToMany(mappedBy="conductorBundle")
	private List<MfnCsPortTerm> mfnCsPortTerms;

	//bi-directional many-to-one association to NteCsCondSplicing
	@OneToMany(mappedBy="conductorBundleOrigCbName")
	private List<NteCsCondSplicing> nteCsCondSplicings1;

	//bi-directional many-to-one association to NteCsCondSplicing
	@OneToMany(mappedBy="conductorBundleTermCbName")
	private List<NteCsCondSplicing> nteCsCondSplicings2;

	//bi-directional many-to-one association to NteCsPortTerm
	@OneToMany(mappedBy="conductorBundle")
	private List<NteCsPortTerm> nteCsPortTerms;

	//bi-directional many-to-one association to WeCableConductorSplicing
	@OneToMany(mappedBy="origCbName")
	private List<WeCsCondSplicing> weCableConductorSplicingsOriginatingCb;

	//bi-directional many-to-one association to WeCableConductorSplicing
	@OneToMany(mappedBy="termCbName")
	private List<WeCsCondSplicing> weCableConductorSplicingsTerminatingCb;

	//bi-directional many-to-one association to WeCsPortTerm
	@OneToMany(mappedBy="conductorBundle")
	private List<WeCsPortTerm> weCsPortTerms;

	public ConductorBundle() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public double getCalculatedLength() {
		return this.calculatedLength;
	}

	public void setCalculatedLength(double calculatedLength) {
		this.calculatedLength = calculatedLength;
	}

	public String getCalculatedLengthUnit() {
		return this.calculatedLengthUnit;
	}

	public void setCalculatedLengthUnit(String calculatedLengthUnit) {
		this.calculatedLengthUnit = calculatedLengthUnit;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public double getMeasuredLength() {
		return this.measuredLength;
	}

	public void setMeasuredLength(double measuredLength) {
		this.measuredLength = measuredLength;
	}

	public String getMeasuredLengthUnit() {
		return this.measuredLengthUnit;
	}

	public void setMeasuredLengthUnit(String measuredLengthUnit) {
		this.measuredLengthUnit = measuredLengthUnit;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<CableSectionHierarchy> getCableSectionHierarchies() {
		return this.cableSectionHierarchies;
	}

	public void setCableSectionHierarchies(List<CableSectionHierarchy> cableSectionHierarchies) {
		this.cableSectionHierarchies = cableSectionHierarchies;
	}

	public CableSectionHierarchy addCableSectionHierarchy(CableSectionHierarchy cableSectionHierarchy) {
		if (null == getCableSectionHierarchies()) {
			setCableSectionHierarchies(new ArrayList<>());
		}
		getCableSectionHierarchies().add(cableSectionHierarchy);
		cableSectionHierarchy.setConductorBundle(this);

		return cableSectionHierarchy;
	}

	public CableSectionHierarchy removeCableSectionHierarchy(CableSectionHierarchy cableSectionHierarchy) {
		getCableSectionHierarchies().remove(cableSectionHierarchy);
		cableSectionHierarchy.setConductorBundle(null);

		return cableSectionHierarchy;
	}

	public List<CbChar> getCbChars() {
		return this.cbChars;
	}

	public void setCbChars(List<CbChar> cbChars) {
		this.cbChars = cbChars;
	}

	public CbChar addCbChar(CbChar cbChar) {
		if (null == getCbChars()) {
			setCbChars(new ArrayList<>());
		}
		getCbChars().add(cbChar);
		cbChar.setConductorBundle(this);

		return cbChar;
	}

	public CbChar removeCbChar(CbChar cbChar) {
		getCbChars().remove(cbChar);
		cbChar.setConductorBundle(null);

		return cbChar;
	}

	public List<CbSelfAssoc> getCbSelfAssocs1() {
		return this.cbSelfAssocs1;
	}

	public void setCbSelfAssocs1(List<CbSelfAssoc> cbSelfAssocs1) {
		this.cbSelfAssocs1 = cbSelfAssocs1;
	}

	public CbSelfAssoc addCbSelfAssocs1(CbSelfAssoc cbSelfAssocs1) {
		getCbSelfAssocs1().add(cbSelfAssocs1);
		cbSelfAssocs1.setConductorBundle1(this);

		return cbSelfAssocs1;
	}

	public CbSelfAssoc removeCbSelfAssocs1(CbSelfAssoc cbSelfAssocs1) {
		getCbSelfAssocs1().remove(cbSelfAssocs1);
		cbSelfAssocs1.setConductorBundle1(null);

		return cbSelfAssocs1;
	}

	public List<CbSelfAssoc> getCbSelfAssocs2() {
		return this.cbSelfAssocs2;
	}

	public void setCbSelfAssocs2(List<CbSelfAssoc> cbSelfAssocs2) {
		this.cbSelfAssocs2 = cbSelfAssocs2;
	}

	public CbSelfAssoc addCbSelfAssocs2(CbSelfAssoc cbSelfAssocs2) {
		getCbSelfAssocs2().add(cbSelfAssocs2);
		cbSelfAssocs2.setConductorBundle2(this);

		return cbSelfAssocs2;
	}

	public CbSelfAssoc removeCbSelfAssocs2(CbSelfAssoc cbSelfAssocs2) {
		getCbSelfAssocs2().remove(cbSelfAssocs2);
		cbSelfAssocs2.setConductorBundle2(null);

		return cbSelfAssocs2;
	}

	public List<CcpCsCondSplicing> getCcpCableConductorSplicingsOrigCbName() {
		return this.ccpCableConductorSplicingsOrigCbName;
	}

	public void setCcpCableConductorSplicingsOrigCbName(List<CcpCsCondSplicing> ccpCableConductorSplicingsOrigCbName) {
		this.ccpCableConductorSplicingsOrigCbName = ccpCableConductorSplicingsOrigCbName;
	}

	public CcpCsCondSplicing addCcpCableConductorSplicingsOrigCbName(CcpCsCondSplicing ccpCableConductorSplicingsOrigCbName) {
		getCcpCableConductorSplicingsOrigCbName().add(ccpCableConductorSplicingsOrigCbName);
		ccpCableConductorSplicingsOrigCbName.setOrigCbName(this);

		return ccpCableConductorSplicingsOrigCbName;
	}

	public CcpCsCondSplicing removeCcpCableConductorSplicingsOrigCbName(CcpCsCondSplicing ccpCableConductorSplicingsOrigCbName) {
		getCcpCableConductorSplicingsOrigCbName().remove(ccpCableConductorSplicingsOrigCbName);
		ccpCableConductorSplicingsOrigCbName.setOrigCbName(null);

		return ccpCableConductorSplicingsOrigCbName;
	}

	public List<CcpCsCondSplicing> getCcpCableConductorSplicingsTermCbName() {
		return this.ccpCableConductorSplicingsTermCbName;
	}

	public void setCcpCableConductorSplicingsTermCbName(List<CcpCsCondSplicing> ccpCableConductorSplicingsTermCbName) {
		this.ccpCableConductorSplicingsTermCbName = ccpCableConductorSplicingsTermCbName;
	}

	public CcpCsCondSplicing addCcpCableConductorSplicingsTermCbName(CcpCsCondSplicing ccpCableConductorSplicingsTermCbName) {
		getCcpCableConductorSplicingsTermCbName().add(ccpCableConductorSplicingsTermCbName);
		ccpCableConductorSplicingsTermCbName.setTermCbName(this);

		return ccpCableConductorSplicingsTermCbName;
	}

	public CcpCsCondSplicing removeCcpCableConductorSplicingsTermCbName(CcpCsCondSplicing ccpCableConductorSplicingsTermCbName) {
		getCcpCableConductorSplicingsTermCbName().remove(ccpCableConductorSplicingsTermCbName);
		ccpCableConductorSplicingsTermCbName.setTermCbName(null);

		return ccpCableConductorSplicingsTermCbName;
	}

	public List<CcpCsPortTerm> getCcpCsPortTerms() {
		return this.ccpCsPortTerms;
	}

	public void setCcpCsPortTerms(List<CcpCsPortTerm> ccpCsPortTerms) {
		this.ccpCsPortTerms = ccpCsPortTerms;
	}

	public CcpCsPortTerm addCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		getCcpCsPortTerms().add(ccpCsPortTerm);
		ccpCsPortTerm.setConductorBundle(this);

		return ccpCsPortTerm;
	}

	public CcpCsPortTerm removeCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		getCcpCsPortTerms().remove(ccpCsPortTerm);
		ccpCsPortTerm.setConductorBundle(null);

		return ccpCsPortTerm;
	}

/*	public CbSpec getCbSpec() {
		return this.cbSpec;
	}

	public void setCbSpec(CbSpec cbSpec) {
		this.cbSpec = cbSpec;
	}*/

	public Exchange getExchange() {
		return this.exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public List<CpeCsCondSplicing> getCpeCsCondSplicings1() {
		return this.cpeCsCondSplicings1;
	}

	public void setCpeCsCondSplicings1(List<CpeCsCondSplicing> cpeCsCondSplicings1) {
		this.cpeCsCondSplicings1 = cpeCsCondSplicings1;
	}

	public CpeCsCondSplicing addCpeCsCondSplicings1(CpeCsCondSplicing cpeCsCondSplicings1) {
		getCpeCsCondSplicings1().add(cpeCsCondSplicings1);
		cpeCsCondSplicings1.setConductorBundleOrigCbName(this);

		return cpeCsCondSplicings1;
	}

	public CpeCsCondSplicing removeCpeCsCondSplicings1(CpeCsCondSplicing cpeCsCondSplicings1) {
		getCpeCsCondSplicings1().remove(cpeCsCondSplicings1);
		cpeCsCondSplicings1.setConductorBundleOrigCbName(null);

		return cpeCsCondSplicings1;
	}

	public List<CpeCsCondSplicing> getCpeCsCondSplicings2() {
		return this.cpeCsCondSplicings2;
	}

	public void setCpeCsCondSplicings2(List<CpeCsCondSplicing> cpeCsCondSplicings2) {
		this.cpeCsCondSplicings2 = cpeCsCondSplicings2;
	}

	public CpeCsCondSplicing addCpeCsCondSplicings2(CpeCsCondSplicing cpeCsCondSplicings2) {
		getCpeCsCondSplicings2().add(cpeCsCondSplicings2);
		cpeCsCondSplicings2.setConductorBundleTermCbName(this);

		return cpeCsCondSplicings2;
	}

	public CpeCsCondSplicing removeCpeCsCondSplicings2(CpeCsCondSplicing cpeCsCondSplicings2) {
		getCpeCsCondSplicings2().remove(cpeCsCondSplicings2);
		cpeCsCondSplicings2.setConductorBundleTermCbName(null);

		return cpeCsCondSplicings2;
	}

	public List<CpeCsPortTerm> getCpeCsPortTerms() {
		return this.cpeCsPortTerms;
	}

	public void setCpeCsPortTerms(List<CpeCsPortTerm> cpeCsPortTerms) {
		this.cpeCsPortTerms = cpeCsPortTerms;
	}

	public CpeCsPortTerm addCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		getCpeCsPortTerms().add(cpeCsPortTerm);
		cpeCsPortTerm.setConductorBundle(this);

		return cpeCsPortTerm;
	}

	public CpeCsPortTerm removeCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		getCpeCsPortTerms().remove(cpeCsPortTerm);
		cpeCsPortTerm.setConductorBundle(null);

		return cpeCsPortTerm;
	}

	public List<DfCsCondSplicing> getDfCsCondSplicings1() {
		return this.dfCsCondSplicings1;
	}

	public void setDfCsCondSplicings1(List<DfCsCondSplicing> dfCsCondSplicings1) {
		this.dfCsCondSplicings1 = dfCsCondSplicings1;
	}

	public DfCsCondSplicing addDfCsCondSplicings1(DfCsCondSplicing dfCsCondSplicings1) {
		getDfCsCondSplicings1().add(dfCsCondSplicings1);
		dfCsCondSplicings1.setConductorBundleOrigCbName(this);

		return dfCsCondSplicings1;
	}

	public DfCsCondSplicing removeDfCsCondSplicings1(DfCsCondSplicing dfCsCondSplicings1) {
		getDfCsCondSplicings1().remove(dfCsCondSplicings1);
		dfCsCondSplicings1.setConductorBundleOrigCbName(null);

		return dfCsCondSplicings1;
	}

	public List<DfCsCondSplicing> getDfCsCondSplicings2() {
		return this.dfCsCondSplicings2;
	}

	public void setDfCsCondSplicings2(List<DfCsCondSplicing> dfCsCondSplicings2) {
		this.dfCsCondSplicings2 = dfCsCondSplicings2;
	}

	public DfCsCondSplicing addDfCsCondSplicings2(DfCsCondSplicing dfCsCondSplicings2) {
		getDfCsCondSplicings2().add(dfCsCondSplicings2);
		dfCsCondSplicings2.setConductorBundleTermCbName(this);

		return dfCsCondSplicings2;
	}

	public DfCsCondSplicing removeDfCsCondSplicings2(DfCsCondSplicing dfCsCondSplicings2) {
		getDfCsCondSplicings2().remove(dfCsCondSplicings2);
		dfCsCondSplicings2.setConductorBundleTermCbName(null);

		return dfCsCondSplicings2;
	}

	public List<DfCsPortTerm> getDfCsPortTerms() {
		return this.dfCsPortTerms;
	}

	public void setDfCsPortTerms(List<DfCsPortTerm> dfCsPortTerms) {
		this.dfCsPortTerms = dfCsPortTerms;
	}

	public DfCsPortTerm addDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().add(dfCsPortTerm);
		dfCsPortTerm.setConductorBundle(this);

		return dfCsPortTerm;
	}

	public DfCsPortTerm removeDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().remove(dfCsPortTerm);
		dfCsPortTerm.setConductorBundle(null);

		return dfCsPortTerm;
	}

	public List<DpCsCondSplicing> getDpCsCondSplicings1() {
		return this.dpCsCondSplicings1;
	}

	public void setDpCsCondSplicings1(List<DpCsCondSplicing> dpCsCondSplicings1) {
		this.dpCsCondSplicings1 = dpCsCondSplicings1;
	}

	public DpCsCondSplicing addDpCsCondSplicings1(DpCsCondSplicing dpCsCondSplicings1) {
		getDpCsCondSplicings1().add(dpCsCondSplicings1);
		dpCsCondSplicings1.setConductorBundleOrigCbName(this);

		return dpCsCondSplicings1;
	}

	public DpCsCondSplicing removeDpCsCondSplicings1(DpCsCondSplicing dpCsCondSplicings1) {
		getDpCsCondSplicings1().remove(dpCsCondSplicings1);
		dpCsCondSplicings1.setConductorBundleOrigCbName(null);

		return dpCsCondSplicings1;
	}

	public List<DpCsCondSplicing> getDpCsCondSplicings2() {
		return this.dpCsCondSplicings2;
	}

	public void setDpCsCondSplicings2(List<DpCsCondSplicing> dpCsCondSplicings2) {
		this.dpCsCondSplicings2 = dpCsCondSplicings2;
	}

	public DpCsCondSplicing addDpCsCondSplicings2(DpCsCondSplicing dpCsCondSplicings2) {
		getDpCsCondSplicings2().add(dpCsCondSplicings2);
		dpCsCondSplicings2.setConductorBundleTermCbName(this);

		return dpCsCondSplicings2;
	}

	public DpCsCondSplicing removeDpCsCondSplicings2(DpCsCondSplicing dpCsCondSplicings2) {
		getDpCsCondSplicings2().remove(dpCsCondSplicings2);
		dpCsCondSplicings2.setConductorBundleTermCbName(null);

		return dpCsCondSplicings2;
	}

	public List<DpCsPortTerm> getDpCsPortTerms() {
		return this.dpCsPortTerms;
	}

	public void setDpCsPortTerms(List<DpCsPortTerm> dpCsPortTerms) {
		this.dpCsPortTerms = dpCsPortTerms;
	}

	public DpCsPortTerm addDpCsPortTerm(DpCsPortTerm dpCsPortTerm) {
		getDpCsPortTerms().add(dpCsPortTerm);
		dpCsPortTerm.setConductorBundle(this);

		return dpCsPortTerm;
	}

	public DpCsPortTerm removeDpCsPortTerm(DpCsPortTerm dpCsPortTerm) {
		getDpCsPortTerms().remove(dpCsPortTerm);
		dpCsPortTerm.setConductorBundle(null);

		return dpCsPortTerm;
	}

	public List<DslamCsCondSplicing> getDslamCsCondSplicings1() {
		return this.dslamCsCondSplicings1;
	}

	public void setDslamCsCondSplicings1(List<DslamCsCondSplicing> dslamCsCondSplicings1) {
		this.dslamCsCondSplicings1 = dslamCsCondSplicings1;
	}

	public DslamCsCondSplicing addDslamCsCondSplicings1(DslamCsCondSplicing dslamCsCondSplicings1) {
		getDslamCsCondSplicings1().add(dslamCsCondSplicings1);
		dslamCsCondSplicings1.setConductorBundleOrigCbName(this);

		return dslamCsCondSplicings1;
	}

	public DslamCsCondSplicing removeDslamCsCondSplicings1(DslamCsCondSplicing dslamCsCondSplicings1) {
		getDslamCsCondSplicings1().remove(dslamCsCondSplicings1);
		dslamCsCondSplicings1.setConductorBundleOrigCbName(null);

		return dslamCsCondSplicings1;
	}

	public List<DslamCsCondSplicing> getDslamCsCondSplicings2() {
		return this.dslamCsCondSplicings2;
	}

	public void setDslamCsCondSplicings2(List<DslamCsCondSplicing> dslamCsCondSplicings2) {
		this.dslamCsCondSplicings2 = dslamCsCondSplicings2;
	}

	public DslamCsCondSplicing addDslamCsCondSplicings2(DslamCsCondSplicing dslamCsCondSplicings2) {
		getDslamCsCondSplicings2().add(dslamCsCondSplicings2);
		dslamCsCondSplicings2.setConductorBundleTermCbName(this);

		return dslamCsCondSplicings2;
	}

	public DslamCsCondSplicing removeDslamCsCondSplicings2(DslamCsCondSplicing dslamCsCondSplicings2) {
		getDslamCsCondSplicings2().remove(dslamCsCondSplicings2);
		dslamCsCondSplicings2.setConductorBundleTermCbName(null);

		return dslamCsCondSplicings2;
	}

	public List<DslamCsPortTerm> getDslamCsPortTerms() {
		return this.dslamCsPortTerms;
	}

	public void setDslamCsPortTerms(List<DslamCsPortTerm> dslamCsPortTerms) {
		this.dslamCsPortTerms = dslamCsPortTerms;
	}

	public DslamCsPortTerm addDslamCsPortTerm(DslamCsPortTerm dslamCsPortTerm) {
		getDslamCsPortTerms().add(dslamCsPortTerm);
		dslamCsPortTerm.setConductorBundle(this);

		return dslamCsPortTerm;
	}

	public DslamCsPortTerm removeDslamCsPortTerm(DslamCsPortTerm dslamCsPortTerm) {
		getDslamCsPortTerms().remove(dslamCsPortTerm);
		dslamCsPortTerm.setConductorBundle(null);

		return dslamCsPortTerm;
	}

	public List<JcCsCondSplicing> getJcCsCondSplicings1() {
		return this.jcCsCondSplicings1;
	}

	public void setJcCsCondSplicings1(List<JcCsCondSplicing> jcCsCondSplicings1) {
		this.jcCsCondSplicings1 = jcCsCondSplicings1;
	}

	public JcCsCondSplicing addJcCsCondSplicings1(JcCsCondSplicing jcCsCondSplicings1) {
		getJcCsCondSplicings1().add(jcCsCondSplicings1);
		jcCsCondSplicings1.setConductorBundleOrigCbName(this);

		return jcCsCondSplicings1;
	}

	public JcCsCondSplicing removeJcCsCondSplicings1(JcCsCondSplicing jcCsCondSplicings1) {
		getJcCsCondSplicings1().remove(jcCsCondSplicings1);
		jcCsCondSplicings1.setConductorBundleOrigCbName(null);

		return jcCsCondSplicings1;
	}

	public List<JcCsCondSplicing> getJcCsCondSplicings2() {
		return this.jcCsCondSplicings2;
	}

	public void setJcCsCondSplicings2(List<JcCsCondSplicing> jcCsCondSplicings2) {
		this.jcCsCondSplicings2 = jcCsCondSplicings2;
	}

	public JcCsCondSplicing addJcCsCondSplicings2(JcCsCondSplicing jcCsCondSplicings2) {
		getJcCsCondSplicings2().add(jcCsCondSplicings2);
		jcCsCondSplicings2.setConductorBundleTermCbName(this);

		return jcCsCondSplicings2;
	}

	public JcCsCondSplicing removeJcCsCondSplicings2(JcCsCondSplicing jcCsCondSplicings2) {
		getJcCsCondSplicings2().remove(jcCsCondSplicings2);
		jcCsCondSplicings2.setConductorBundleTermCbName(null);

		return jcCsCondSplicings2;
	}

	public List<JcCsPortTerm> getJcCsPortTerms() {
		return this.jcCsPortTerms;
	}

	public void setJcCsPortTerms(List<JcCsPortTerm> jcCsPortTerms) {
		this.jcCsPortTerms = jcCsPortTerms;
	}

	public JcCsPortTerm addJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		getJcCsPortTerms().add(jcCsPortTerm);
		jcCsPortTerm.setConductorBundle(this);

		return jcCsPortTerm;
	}

	public JcCsPortTerm removeJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		getJcCsPortTerms().remove(jcCsPortTerm);
		jcCsPortTerm.setConductorBundle(null);

		return jcCsPortTerm;
	}

	public List<MfnCsCondSplicing> getMfnCableConductorSplicings1() {
		return this.mfnCableConductorOrigCbName;
	}

	public void setMfnCableConductorSplicings1(List<MfnCsCondSplicing> mfnCableConductorSplicings1) {
		this.mfnCableConductorOrigCbName = mfnCableConductorSplicings1;
	}

	public MfnCsCondSplicing addMfnCableConductorSplicings1(MfnCsCondSplicing mfnCableConductorSplicings1) {
		getMfnCableConductorSplicings1().add(mfnCableConductorSplicings1);
		mfnCableConductorSplicings1.setOrigCbName(this);

		return mfnCableConductorSplicings1;
	}

	public MfnCsCondSplicing removeMfnCableConductorSplicings1(MfnCsCondSplicing mfnCableConductorSplicings1) {
		getMfnCableConductorSplicings1().remove(mfnCableConductorSplicings1);
		mfnCableConductorSplicings1.setOrigCbName(null);

		return mfnCableConductorSplicings1;
	}

	public List<MfnCsCondSplicing> getMfnCableConductorSplicings2() {
		return this.mfnCableConductorTermCbName;
	}

	public void setMfnCableConductorSplicings2(List<MfnCsCondSplicing> mfnCableConductorSplicings2) {
		this.mfnCableConductorTermCbName = mfnCableConductorSplicings2;
	}

	public MfnCsCondSplicing addMfnCableConductorSplicings2(MfnCsCondSplicing mfnCableConductorSplicings2) {
		getMfnCableConductorSplicings2().add(mfnCableConductorSplicings2);
		mfnCableConductorSplicings2.setTermCbName(this);

		return mfnCableConductorSplicings2;
	}

	public MfnCsCondSplicing removeMfnCableConductorSplicings2(MfnCsCondSplicing mfnCableConductorSplicings2) {
		getMfnCableConductorSplicings2().remove(mfnCableConductorSplicings2);
		mfnCableConductorSplicings2.setTermCbName(null);

		return mfnCableConductorSplicings2;
	}

	public List<MfnCsPortTerm> getMfnCsPortTerms() {
		return this.mfnCsPortTerms;
	}

	public void setMfnCsPortTerms(List<MfnCsPortTerm> mfnCsPortTerms) {
		this.mfnCsPortTerms = mfnCsPortTerms;
	}

	public MfnCsPortTerm addMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		getMfnCsPortTerms().add(mfnCsPortTerm);
		mfnCsPortTerm.setConductorBundle(this);

		return mfnCsPortTerm;
	}

	public MfnCsPortTerm removeMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		getMfnCsPortTerms().remove(mfnCsPortTerm);
		mfnCsPortTerm.setConductorBundle(null);

		return mfnCsPortTerm;
	}

	public List<NteCsCondSplicing> getNteCsCondSplicings1() {
		return this.nteCsCondSplicings1;
	}

	public void setNteCsCondSplicings1(List<NteCsCondSplicing> nteCsCondSplicings1) {
		this.nteCsCondSplicings1 = nteCsCondSplicings1;
	}

	public NteCsCondSplicing addNteCsCondSplicings1(NteCsCondSplicing nteCsCondSplicings1) {
		getNteCsCondSplicings1().add(nteCsCondSplicings1);
		nteCsCondSplicings1.setConductorBundleOrigCbName(this);

		return nteCsCondSplicings1;
	}

	public NteCsCondSplicing removeNteCsCondSplicings1(NteCsCondSplicing nteCsCondSplicings1) {
		getNteCsCondSplicings1().remove(nteCsCondSplicings1);
		nteCsCondSplicings1.setConductorBundleOrigCbName(null);

		return nteCsCondSplicings1;
	}

	public List<NteCsCondSplicing> getNteCsCondSplicings2() {
		return this.nteCsCondSplicings2;
	}

	public void setNteCsCondSplicings2(List<NteCsCondSplicing> nteCsCondSplicings2) {
		this.nteCsCondSplicings2 = nteCsCondSplicings2;
	}

	public NteCsCondSplicing addNteCsCondSplicings2(NteCsCondSplicing nteCsCondSplicings2) {
		getNteCsCondSplicings2().add(nteCsCondSplicings2);
		nteCsCondSplicings2.setConductorBundleTermCbName(this);

		return nteCsCondSplicings2;
	}

	public NteCsCondSplicing removeNteCsCondSplicings2(NteCsCondSplicing nteCsCondSplicings2) {
		getNteCsCondSplicings2().remove(nteCsCondSplicings2);
		nteCsCondSplicings2.setConductorBundleTermCbName(null);

		return nteCsCondSplicings2;
	}

	public List<NteCsPortTerm> getNteCsPortTerms() {
		return this.nteCsPortTerms;
	}

	public void setNteCsPortTerms(List<NteCsPortTerm> nteCsPortTerms) {
		this.nteCsPortTerms = nteCsPortTerms;
	}

	public NteCsPortTerm addNteCsPortTerm(NteCsPortTerm nteCsPortTerm) {
		getNteCsPortTerms().add(nteCsPortTerm);
		nteCsPortTerm.setConductorBundle(this);

		return nteCsPortTerm;
	}

	public NteCsPortTerm removeNteCsPortTerm(NteCsPortTerm nteCsPortTerm) {
		getNteCsPortTerms().remove(nteCsPortTerm);
		nteCsPortTerm.setConductorBundle(null);

		return nteCsPortTerm;
	}

	public List<WeCsCondSplicing> getWeCableConductorSplicingsOriginatingCb() {
		return this.weCableConductorSplicingsOriginatingCb;
	}

	public void setWeCableConductorSplicingsOriginatingCb(List<WeCsCondSplicing> weCableConductorSplicingsOriginatingCb) {
		this.weCableConductorSplicingsOriginatingCb = weCableConductorSplicingsOriginatingCb;
	}

	public WeCsCondSplicing addWeCableConductorSplicingsOriginatingCb(WeCsCondSplicing weCableConductorSplicingsOriginatingCb) {
		getWeCableConductorSplicingsOriginatingCb().add(weCableConductorSplicingsOriginatingCb);
		weCableConductorSplicingsOriginatingCb.setOrigCbName(this);

		return weCableConductorSplicingsOriginatingCb;
	}

	public WeCsCondSplicing removeWeCableConductorSplicingsOriginatingCb(WeCsCondSplicing weCableConductorSplicingsOriginatingCb) {
		getWeCableConductorSplicingsOriginatingCb().remove(weCableConductorSplicingsOriginatingCb);
		weCableConductorSplicingsOriginatingCb.setOrigCbName(null);

		return weCableConductorSplicingsOriginatingCb;
	}

	public List<WeCsCondSplicing> getWeCableConductorSplicingsTerminatingCb() {
		return this.weCableConductorSplicingsTerminatingCb;
	}

	public void setWeCableConductorSplicingsTerminatingCb(List<WeCsCondSplicing> weCableConductorSplicingsTerminatingCb) {
		this.weCableConductorSplicingsTerminatingCb = weCableConductorSplicingsTerminatingCb;
	}

	public WeCsCondSplicing addWeCableConductorSplicingsTerminatingCb(WeCsCondSplicing weCableConductorSplicingsTerminatingCb) {
		getWeCableConductorSplicingsTerminatingCb().add(weCableConductorSplicingsTerminatingCb);
		weCableConductorSplicingsTerminatingCb.setTermCbName(this);

		return weCableConductorSplicingsTerminatingCb;
	}

	public WeCsCondSplicing removeWeCableConductorSplicingsTerminatingCb(WeCsCondSplicing weCableConductorSplicingsTerminatingCb) {
		getWeCableConductorSplicingsTerminatingCb().remove(weCableConductorSplicingsTerminatingCb);
		weCableConductorSplicingsTerminatingCb.setTermCbName(null);

		return weCableConductorSplicingsTerminatingCb;
	}

	public List<WeCsPortTerm> getWeCsPortTerms() {
		return this.weCsPortTerms;
	}

	public void setWeCsPortTerms(List<WeCsPortTerm> weCsPortTerms) {
		this.weCsPortTerms = weCsPortTerms;
	}

	public WeCsPortTerm addWeCsPortTerm(WeCsPortTerm weCsPortTerm) {
		getWeCsPortTerms().add(weCsPortTerm);
		weCsPortTerm.setConductorBundle(this);

		return weCsPortTerm;
	}

	public WeCsPortTerm removeWeCsPortTerm(WeCsPortTerm weCsPortTerm) {
		getWeCsPortTerms().remove(weCsPortTerm);
		weCsPortTerm.setConductorBundle(null);

		return weCsPortTerm;
	}

}