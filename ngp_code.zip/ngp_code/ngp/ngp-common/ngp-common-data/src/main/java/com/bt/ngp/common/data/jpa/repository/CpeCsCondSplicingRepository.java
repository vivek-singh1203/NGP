package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.CpeCsCondSplicing;

@Repository
public interface CpeCsCondSplicingRepository extends SqlRepository<CpeCsCondSplicing> {

	List<CpeCsCondSplicing> findByOrigCsNameAndTermCsName(CableSection origCsName, CableSection termCsName);

	@Transactional
	@Modifying
	@Query(name = "CpeCsCondSplicingRepository.deleteCpeCsCondSplicingByNameOfWiredEntities", nativeQuery = true)
	public int deleteCpeCsCondSplicing(@Param("cpeCsCondSplicing") CpeCsCondSplicing cpeCsCondSplicing);

	@Query(name = "CpeCsCondSplicingRepository.findConductorSplicingOriginating")
	public List<CpeCsCondSplicing> findOriginatingConductorSplicing(
			@Param("cpeCsCondSplicing") CpeCsCondSplicing cpeCsCondSplicing);

	@Query(name = "CpeCsCondSplicingRepository.findConductorSplicingTerminating")
	public List<CpeCsCondSplicing> findTerminatingConductorSplicing(
			@Param("cpeCsCondSplicing") CpeCsCondSplicing cpeCsCondSplicing);

	public List<CpeCsCondSplicing> findByTermParentCsName(CableSection termParentCsName);

	public List<CpeCsCondSplicing> findByOrigParentCsName(CableSection origParentCsName);

	public CpeCsCondSplicing findByOrigParentCsNameAndOrigCsNameAndSplicingResource(CableSection origParentCsName,
			CableSection origCsName, String splicingResource);

	public CpeCsCondSplicing findByTermParentCsNameAndTermCsNameAndSplicingResource(CableSection termParentCsName,
			CableSection termCsName, String splicingResource);

}
