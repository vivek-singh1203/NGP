package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.bt.ngp.datasource.entities.Exchange;

public interface ExchangeRepository extends SqlRepository<Exchange> {

	public Exchange findByExchange1141Code(@Param("exchange1141Code") String exchange1141Code);
	
	public List<Exchange> findByDistrictId(String districtId);
}
