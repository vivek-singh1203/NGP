package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the CB_SELF_ASSOC_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CB_SELF_ASSOC_SPEC")
@NamedQuery(name="CbSelfAssocSpec.findAll", query="SELECT c FROM CbSelfAssocSpec c")
public class CbSelfAssocSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, precision=38)
	private long id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="NO_OF_CHILD_INSTANCES", nullable=false, precision=38)
	private BigDecimal noOfChildInstances;

	//bi-directional many-to-one association to CbSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="CHILD_CB_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="CHILD_CB_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private CbSpec cbSpec1;

	//bi-directional many-to-one association to CbSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="PARENT_CB_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="PARENT_CB_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private CbSpec cbSpec2;

	public CbSelfAssocSpec() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getNoOfChildInstances() {
		return this.noOfChildInstances;
	}

	public void setNoOfChildInstances(BigDecimal noOfChildInstances) {
		this.noOfChildInstances = noOfChildInstances;
	}

	public CbSpec getCbSpec1() {
		return this.cbSpec1;
	}

	public void setCbSpec1(CbSpec cbSpec1) {
		this.cbSpec1 = cbSpec1;
	}

	public CbSpec getCbSpec2() {
		return this.cbSpec2;
	}

	public void setCbSpec2(CbSpec cbSpec2) {
		this.cbSpec2 = cbSpec2;
	}

}