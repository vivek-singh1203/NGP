package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the CHASSIS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CHASSIS")
@NamedQuery(name="Chassi.findAll", query="SELECT c FROM Chassi c")
public class Chassi implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="NAME",unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(name="ID", nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to CcpChassisPhAssoc
	@OneToMany(mappedBy="chassi")
	private List<CcpChassisPhAssoc> ccpChassisPhAssocs;

	//bi-directional many-to-one association to CcpCsPortTerm
	@OneToMany(mappedBy="chassi")
	private List<CcpCsPortTerm> ccpCsPortTerms;

	//bi-directional many-to-one association to CcpPortPortAssoc
	@OneToMany(mappedBy="chassi1")
	private List<CcpPortPortAssoc> ccpPortPortAssocs1;

	//bi-directional many-to-one association to CcpPortPortAssoc
	@OneToMany(mappedBy="chassi2")
	private List<CcpPortPortAssoc> ccpPortPortAssocs2;

	//bi-directional many-to-one association to CrossConnectPoint
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="CCP_NAME")
	private CrossConnectPoint crossConnectPoint;

	//bi-directional many-to-one association to CustomerPremiseEquipment
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="CPE_NAME")
	private CustomerPremiseEquipment customerPremiseEquipment;

	//bi-directional many-to-one association to DistributionPoint
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="DP_NAME")
	private DistributionPoint distributionPoint;

	//bi-directional many-to-one association to JointClosure
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="JC_NAME")
	private JointClosure jointClosure;

	//bi-directional many-to-one association to MultiFunctionalNode
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="MFN_NAME")
	private MultiFunctionalNode multiFunctionalNode;

	//bi-directional many-to-one association to NetworkTerminatingEquipment
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="NTE_NAME")
	private NetworkTerminatingEquipment networkTerminatingEquipment;

	//bi-directional many-to-one association to Store
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to WirelessEquipment
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="WEQ_NAME")
	private WirelessEquipment wirelessEquipment;

	//bi-directional many-to-one association to ChassisChar
	@OneToMany(mappedBy="chassi")
	private List<ChassisChar> chassisChars;

	//bi-directional many-to-one association to CpeChassisPhAssoc
	@OneToMany(mappedBy="chassi")
	private List<CpeChassisPhAssoc> cpeChassisPhAssocs;

	//bi-directional many-to-one association to CpeCsPortTerm
	@OneToMany(mappedBy="chassi")
	private List<CpeCsPortTerm> cpeCsPortTerms;

	//bi-directional many-to-one association to CpePortPortAssoc
	@OneToMany(mappedBy="chassi1")
	private List<CpePortPortAssoc> cpePortPortAssocs1;

	//bi-directional many-to-one association to CpePortPortAssoc
	@OneToMany(mappedBy="chassi2")
	private List<CpePortPortAssoc> cpePortPortAssocs2;

/*	//bi-directional many-to-one association to DfCsPortTerm
	@OneToMany(mappedBy="chassi")
	private List<DfCsPortTerm> dfCsPortTerms;

	//bi-directional many-to-one association to DfPortPortAssoc
	@OneToMany(mappedBy="chassi1")
	private List<DfPortPortAssoc> dfPortPortAssocs1;

	//bi-directional many-to-one association to DfPortPortAssoc
	@OneToMany(mappedBy="chassi2")
	private List<DfPortPortAssoc> dfPortPortAssocs2;*/

	//bi-directional many-to-one association to DpChassisPhAssoc
	@OneToMany(mappedBy="chassi")
	private List<DpChassisPhAssoc> dpChassisPhAssocs;

	//bi-directional many-to-one association to DpCsPortTerm
	@OneToMany(mappedBy="chassi")
	private List<DpCsPortTerm> dpCsPortTerms;

	//bi-directional many-to-one association to DpPortPortAssoc
	@OneToMany(mappedBy="chassi1")
	private List<DpPortPortAssoc> dpPortPortAssocs1;

	//bi-directional many-to-one association to DpPortPortAssoc
	@OneToMany(mappedBy="chassi2")
	private List<DpPortPortAssoc> dpPortPortAssocs2;

	//bi-directional many-to-one association to JcChassisPhAssoc
	@OneToMany(mappedBy="chassi")
	private List<JcChassisPhAssoc> jcChassisPhAssocs;

	//bi-directional many-to-one association to JcCsPortTerm
	@OneToMany(mappedBy="chassi")
	private List<JcCsPortTerm> jcCsPortTerms;

	//bi-directional many-to-one association to JcPortPortAssoc
	@OneToMany(mappedBy="chassi1")
	private List<JcPortPortAssoc> jcPortPortAssocs1;

	//bi-directional many-to-one association to JcPortPortAssoc
	@OneToMany(mappedBy="chassi2")
	private List<JcPortPortAssoc> jcPortPortAssocs2;

	//bi-directional many-to-one association to MfnChassisPhAssoc
	@OneToMany(mappedBy="chassi")
	private List<MfnChassisPhAssoc> mfnChassisPhAssocs;

	//bi-directional many-to-one association to MfnCsPortTerm
	@OneToMany(mappedBy="chassi")
	private List<MfnCsPortTerm> mfnCsPortTerms;

	//bi-directional many-to-one association to MfnPortPortAssoc
	@OneToMany(mappedBy="chassi1")
	private List<MfnPortPortAssoc> mfnPortPortAssocs1;

	//bi-directional many-to-one association to MfnPortPortAssoc
	@OneToMany(mappedBy="chassi2")
	private List<MfnPortPortAssoc> mfnPortPortAssocs2;

	//bi-directional many-to-one association to NteChassisPhAssoc
	@OneToMany(mappedBy="chassi")
	private List<NteChassisPhAssoc> nteChassisPhAssocs;

	//bi-directional many-to-one association to NteCsPortTerm
	@OneToMany(mappedBy="chassi")
	private List<NteCsPortTerm> nteCsPortTerms;

	//bi-directional many-to-one association to NtePortPortAssoc
	@OneToMany(mappedBy="chassi1")
	private List<NtePortPortAssoc> ntePortPortAssocs1;

	//bi-directional many-to-one association to NtePortPortAssoc
	@OneToMany(mappedBy="chassi2")
	private List<NtePortPortAssoc> ntePortPortAssocs2;

	//bi-directional many-to-one association to PluginHolder
	@OneToMany(mappedBy="chassi")
	private List<PluginHolder> pluginHolders;

	//bi-directional many-to-one association to WeChassisPhAssoc
	@OneToMany(mappedBy="chassi")
	private List<WeChassisPhAssoc> weChassisPhAssocs;

	//bi-directional many-to-one association to WeCsPortTerm
	@OneToMany(mappedBy="chassi")
	private List<WeCsPortTerm> weCsPortTerms;

	//bi-directional many-to-one association to WePortPortAssoc
	@OneToMany(mappedBy="chassi1")
	private List<WePortPortAssoc> wePortPortAssocs1;

	//bi-directional many-to-one association to WePortPortAssoc
	@OneToMany(mappedBy="chassi2")
	private List<WePortPortAssoc> wePortPortAssocs2;

	public Chassi() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<CcpChassisPhAssoc> getCcpChassisPhAssocs() {
		return this.ccpChassisPhAssocs;
	}

	public void setCcpChassisPhAssocs(List<CcpChassisPhAssoc> ccpChassisPhAssocs) {
		this.ccpChassisPhAssocs = ccpChassisPhAssocs;
	}

	public CcpChassisPhAssoc addCcpChassisPhAssoc(CcpChassisPhAssoc ccpChassisPhAssoc) {
		getCcpChassisPhAssocs().add(ccpChassisPhAssoc);
		ccpChassisPhAssoc.setChassi(this);

		return ccpChassisPhAssoc;
	}

	public CcpChassisPhAssoc removeCcpChassisPhAssoc(CcpChassisPhAssoc ccpChassisPhAssoc) {
		getCcpChassisPhAssocs().remove(ccpChassisPhAssoc);
		ccpChassisPhAssoc.setChassi(null);

		return ccpChassisPhAssoc;
	}

	public List<CcpCsPortTerm> getCcpCsPortTerms() {
		return this.ccpCsPortTerms;
	}

	public void setCcpCsPortTerms(List<CcpCsPortTerm> ccpCsPortTerms) {
		this.ccpCsPortTerms = ccpCsPortTerms;
	}

	public CcpCsPortTerm addCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		getCcpCsPortTerms().add(ccpCsPortTerm);
		ccpCsPortTerm.setChassi(this);

		return ccpCsPortTerm;
	}

	public CcpCsPortTerm removeCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		getCcpCsPortTerms().remove(ccpCsPortTerm);
		ccpCsPortTerm.setChassi(null);

		return ccpCsPortTerm;
	}

	public List<CcpPortPortAssoc> getCcpPortPortAssocs1() {
		return this.ccpPortPortAssocs1;
	}

	public void setCcpPortPortAssocs1(List<CcpPortPortAssoc> ccpPortPortAssocs1) {
		this.ccpPortPortAssocs1 = ccpPortPortAssocs1;
	}

	public CcpPortPortAssoc addCcpPortPortAssocs1(CcpPortPortAssoc ccpPortPortAssocs1) {
		getCcpPortPortAssocs1().add(ccpPortPortAssocs1);
		ccpPortPortAssocs1.setChassi1(this);

		return ccpPortPortAssocs1;
	}

	public CcpPortPortAssoc removeCcpPortPortAssocs1(CcpPortPortAssoc ccpPortPortAssocs1) {
		getCcpPortPortAssocs1().remove(ccpPortPortAssocs1);
		ccpPortPortAssocs1.setChassi1(null);

		return ccpPortPortAssocs1;
	}

	public List<CcpPortPortAssoc> getCcpPortPortAssocs2() {
		return this.ccpPortPortAssocs2;
	}

	public void setCcpPortPortAssocs2(List<CcpPortPortAssoc> ccpPortPortAssocs2) {
		this.ccpPortPortAssocs2 = ccpPortPortAssocs2;
	}

	public CcpPortPortAssoc addCcpPortPortAssocs2(CcpPortPortAssoc ccpPortPortAssocs2) {
		getCcpPortPortAssocs2().add(ccpPortPortAssocs2);
		ccpPortPortAssocs2.setChassi2(this);

		return ccpPortPortAssocs2;
	}

	public CcpPortPortAssoc removeCcpPortPortAssocs2(CcpPortPortAssoc ccpPortPortAssocs2) {
		getCcpPortPortAssocs2().remove(ccpPortPortAssocs2);
		ccpPortPortAssocs2.setChassi2(null);

		return ccpPortPortAssocs2;
	}

	public CrossConnectPoint getCrossConnectPoint() {
		return this.crossConnectPoint;
	}

	public void setCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		this.crossConnectPoint = crossConnectPoint;
	}

	public CustomerPremiseEquipment getCustomerPremiseEquipment() {
		return this.customerPremiseEquipment;
	}

	public void setCustomerPremiseEquipment(CustomerPremiseEquipment customerPremiseEquipment) {
		this.customerPremiseEquipment = customerPremiseEquipment;
	}

	public DistributionPoint getDistributionPoint() {
		return this.distributionPoint;
	}

	public void setDistributionPoint(DistributionPoint distributionPoint) {
		this.distributionPoint = distributionPoint;
	}

	public JointClosure getJointClosure() {
		return this.jointClosure;
	}

	public void setJointClosure(JointClosure jointClosure) {
		this.jointClosure = jointClosure;
	}

	public MultiFunctionalNode getMultiFunctionalNode() {
		return this.multiFunctionalNode;
	}

	public void setMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		this.multiFunctionalNode = multiFunctionalNode;
	}

	public NetworkTerminatingEquipment getNetworkTerminatingEquipment() {
		return this.networkTerminatingEquipment;
	}

	public void setNetworkTerminatingEquipment(NetworkTerminatingEquipment networkTerminatingEquipment) {
		this.networkTerminatingEquipment = networkTerminatingEquipment;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public WirelessEquipment getWirelessEquipment() {
		return this.wirelessEquipment;
	}

	public void setWirelessEquipment(WirelessEquipment wirelessEquipment) {
		this.wirelessEquipment = wirelessEquipment;
	}

	public List<ChassisChar> getChassisChars() {
		return this.chassisChars;
	}

	public void setChassisChars(List<ChassisChar> chassisChars) {
		this.chassisChars = chassisChars;
	}

	public ChassisChar addChassisChar(ChassisChar chassisChar) {
		getChassisChars().add(chassisChar);
		chassisChar.setChassi(this);

		return chassisChar;
	}

	public ChassisChar removeChassisChar(ChassisChar chassisChar) {
		getChassisChars().remove(chassisChar);
		chassisChar.setChassi(null);

		return chassisChar;
	}

	public List<CpeChassisPhAssoc> getCpeChassisPhAssocs() {
		return this.cpeChassisPhAssocs;
	}

	public void setCpeChassisPhAssocs(List<CpeChassisPhAssoc> cpeChassisPhAssocs) {
		this.cpeChassisPhAssocs = cpeChassisPhAssocs;
	}

	public CpeChassisPhAssoc addCpeChassisPhAssoc(CpeChassisPhAssoc cpeChassisPhAssoc) {
		getCpeChassisPhAssocs().add(cpeChassisPhAssoc);
		cpeChassisPhAssoc.setChassi(this);

		return cpeChassisPhAssoc;
	}

	public CpeChassisPhAssoc removeCpeChassisPhAssoc(CpeChassisPhAssoc cpeChassisPhAssoc) {
		getCpeChassisPhAssocs().remove(cpeChassisPhAssoc);
		cpeChassisPhAssoc.setChassi(null);

		return cpeChassisPhAssoc;
	}

	public List<CpeCsPortTerm> getCpeCsPortTerms() {
		return this.cpeCsPortTerms;
	}

	public void setCpeCsPortTerms(List<CpeCsPortTerm> cpeCsPortTerms) {
		this.cpeCsPortTerms = cpeCsPortTerms;
	}

	public CpeCsPortTerm addCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		getCpeCsPortTerms().add(cpeCsPortTerm);
		cpeCsPortTerm.setChassi(this);

		return cpeCsPortTerm;
	}

	public CpeCsPortTerm removeCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		getCpeCsPortTerms().remove(cpeCsPortTerm);
		cpeCsPortTerm.setChassi(null);

		return cpeCsPortTerm;
	}

	public List<CpePortPortAssoc> getCpePortPortAssocs1() {
		return this.cpePortPortAssocs1;
	}

	public void setCpePortPortAssocs1(List<CpePortPortAssoc> cpePortPortAssocs1) {
		this.cpePortPortAssocs1 = cpePortPortAssocs1;
	}

	public CpePortPortAssoc addCpePortPortAssocs1(CpePortPortAssoc cpePortPortAssocs1) {
		getCpePortPortAssocs1().add(cpePortPortAssocs1);
		cpePortPortAssocs1.setChassi1(this);

		return cpePortPortAssocs1;
	}

	public CpePortPortAssoc removeCpePortPortAssocs1(CpePortPortAssoc cpePortPortAssocs1) {
		getCpePortPortAssocs1().remove(cpePortPortAssocs1);
		cpePortPortAssocs1.setChassi1(null);

		return cpePortPortAssocs1;
	}

	public List<CpePortPortAssoc> getCpePortPortAssocs2() {
		return this.cpePortPortAssocs2;
	}

	public void setCpePortPortAssocs2(List<CpePortPortAssoc> cpePortPortAssocs2) {
		this.cpePortPortAssocs2 = cpePortPortAssocs2;
	}

	public CpePortPortAssoc addCpePortPortAssocs2(CpePortPortAssoc cpePortPortAssocs2) {
		getCpePortPortAssocs2().add(cpePortPortAssocs2);
		cpePortPortAssocs2.setChassi2(this);

		return cpePortPortAssocs2;
	}

	public CpePortPortAssoc removeCpePortPortAssocs2(CpePortPortAssoc cpePortPortAssocs2) {
		getCpePortPortAssocs2().remove(cpePortPortAssocs2);
		cpePortPortAssocs2.setChassi2(null);

		return cpePortPortAssocs2;
	}

/*	public List<DfCsPortTerm> getDfCsPortTerms() {
		return this.dfCsPortTerms;
	}

	public void setDfCsPortTerms(List<DfCsPortTerm> dfCsPortTerms) {
		this.dfCsPortTerms = dfCsPortTerms;
	}

	public DfCsPortTerm addDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().add(dfCsPortTerm);
		dfCsPortTerm.setChassi(this);

		return dfCsPortTerm;
	}

	public DfCsPortTerm removeDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().remove(dfCsPortTerm);
		dfCsPortTerm.setChassi(null);

		return dfCsPortTerm;
	}

	public List<DfPortPortAssoc> getDfPortPortAssocs1() {
		return this.dfPortPortAssocs1;
	}

	public void setDfPortPortAssocs1(List<DfPortPortAssoc> dfPortPortAssocs1) {
		this.dfPortPortAssocs1 = dfPortPortAssocs1;
	}

	public DfPortPortAssoc addDfPortPortAssocs1(DfPortPortAssoc dfPortPortAssocs1) {
		getDfPortPortAssocs1().add(dfPortPortAssocs1);
		dfPortPortAssocs1.setChassi1(this);

		return dfPortPortAssocs1;
	}

	public DfPortPortAssoc removeDfPortPortAssocs1(DfPortPortAssoc dfPortPortAssocs1) {
		getDfPortPortAssocs1().remove(dfPortPortAssocs1);
		dfPortPortAssocs1.setChassi1(null);

		return dfPortPortAssocs1;
	}

	public List<DfPortPortAssoc> getDfPortPortAssocs2() {
		return this.dfPortPortAssocs2;
	}

	public void setDfPortPortAssocs2(List<DfPortPortAssoc> dfPortPortAssocs2) {
		this.dfPortPortAssocs2 = dfPortPortAssocs2;
	}

	public DfPortPortAssoc addDfPortPortAssocs2(DfPortPortAssoc dfPortPortAssocs2) {
		getDfPortPortAssocs2().add(dfPortPortAssocs2);
		dfPortPortAssocs2.setChassi2(this);

		return dfPortPortAssocs2;
	}

	public DfPortPortAssoc removeDfPortPortAssocs2(DfPortPortAssoc dfPortPortAssocs2) {
		getDfPortPortAssocs2().remove(dfPortPortAssocs2);
		dfPortPortAssocs2.setChassi2(null);

		return dfPortPortAssocs2;
	}*/

	public List<DpChassisPhAssoc> getDpChassisPhAssocs() {
		return this.dpChassisPhAssocs;
	}

	public void setDpChassisPhAssocs(List<DpChassisPhAssoc> dpChassisPhAssocs) {
		this.dpChassisPhAssocs = dpChassisPhAssocs;
	}

	public DpChassisPhAssoc addDpChassisPhAssoc(DpChassisPhAssoc dpChassisPhAssoc) {
		getDpChassisPhAssocs().add(dpChassisPhAssoc);
		dpChassisPhAssoc.setChassi(this);

		return dpChassisPhAssoc;
	}

	public DpChassisPhAssoc removeDpChassisPhAssoc(DpChassisPhAssoc dpChassisPhAssoc) {
		getDpChassisPhAssocs().remove(dpChassisPhAssoc);
		dpChassisPhAssoc.setChassi(null);

		return dpChassisPhAssoc;
	}

	public List<DpCsPortTerm> getDpCsPortTerms() {
		return this.dpCsPortTerms;
	}

	public void setDpCsPortTerms(List<DpCsPortTerm> dpCsPortTerms) {
		this.dpCsPortTerms = dpCsPortTerms;
	}

	public DpCsPortTerm addDpCsPortTerm(DpCsPortTerm dpCsPortTerm) {
		getDpCsPortTerms().add(dpCsPortTerm);
		dpCsPortTerm.setChassi(this);

		return dpCsPortTerm;
	}

	public DpCsPortTerm removeDpCsPortTerm(DpCsPortTerm dpCsPortTerm) {
		getDpCsPortTerms().remove(dpCsPortTerm);
		dpCsPortTerm.setChassi(null);

		return dpCsPortTerm;
	}

	public List<DpPortPortAssoc> getDpPortPortAssocs1() {
		return this.dpPortPortAssocs1;
	}

	public void setDpPortPortAssocs1(List<DpPortPortAssoc> dpPortPortAssocs1) {
		this.dpPortPortAssocs1 = dpPortPortAssocs1;
	}

	public DpPortPortAssoc addDpPortPortAssocs1(DpPortPortAssoc dpPortPortAssocs1) {
		getDpPortPortAssocs1().add(dpPortPortAssocs1);
		dpPortPortAssocs1.setChassi1(this);

		return dpPortPortAssocs1;
	}

	public DpPortPortAssoc removeDpPortPortAssocs1(DpPortPortAssoc dpPortPortAssocs1) {
		getDpPortPortAssocs1().remove(dpPortPortAssocs1);
		dpPortPortAssocs1.setChassi1(null);

		return dpPortPortAssocs1;
	}

	public List<DpPortPortAssoc> getDpPortPortAssocs2() {
		return this.dpPortPortAssocs2;
	}

	public void setDpPortPortAssocs2(List<DpPortPortAssoc> dpPortPortAssocs2) {
		this.dpPortPortAssocs2 = dpPortPortAssocs2;
	}

	public DpPortPortAssoc addDpPortPortAssocs2(DpPortPortAssoc dpPortPortAssocs2) {
		getDpPortPortAssocs2().add(dpPortPortAssocs2);
		dpPortPortAssocs2.setChassi2(this);

		return dpPortPortAssocs2;
	}

	public DpPortPortAssoc removeDpPortPortAssocs2(DpPortPortAssoc dpPortPortAssocs2) {
		getDpPortPortAssocs2().remove(dpPortPortAssocs2);
		dpPortPortAssocs2.setChassi2(null);

		return dpPortPortAssocs2;
	}

	public List<JcChassisPhAssoc> getJcChassisPhAssocs() {
		return this.jcChassisPhAssocs;
	}

	public void setJcChassisPhAssocs(List<JcChassisPhAssoc> jcChassisPhAssocs) {
		this.jcChassisPhAssocs = jcChassisPhAssocs;
	}

	public JcChassisPhAssoc addJcChassisPhAssoc(JcChassisPhAssoc jcChassisPhAssoc) {
		getJcChassisPhAssocs().add(jcChassisPhAssoc);
		jcChassisPhAssoc.setChassi(this);

		return jcChassisPhAssoc;
	}

	public JcChassisPhAssoc removeJcChassisPhAssoc(JcChassisPhAssoc jcChassisPhAssoc) {
		getJcChassisPhAssocs().remove(jcChassisPhAssoc);
		jcChassisPhAssoc.setChassi(null);

		return jcChassisPhAssoc;
	}

	public List<JcCsPortTerm> getJcCsPortTerms() {
		return this.jcCsPortTerms;
	}

	public void setJcCsPortTerms(List<JcCsPortTerm> jcCsPortTerms) {
		this.jcCsPortTerms = jcCsPortTerms;
	}

	public JcCsPortTerm addJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		getJcCsPortTerms().add(jcCsPortTerm);
		jcCsPortTerm.setChassi(this);

		return jcCsPortTerm;
	}

	public JcCsPortTerm removeJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		getJcCsPortTerms().remove(jcCsPortTerm);
		jcCsPortTerm.setChassi(null);

		return jcCsPortTerm;
	}

	public List<JcPortPortAssoc> getJcPortPortAssocs1() {
		return this.jcPortPortAssocs1;
	}

	public void setJcPortPortAssocs1(List<JcPortPortAssoc> jcPortPortAssocs1) {
		this.jcPortPortAssocs1 = jcPortPortAssocs1;
	}

	public JcPortPortAssoc addJcPortPortAssocs1(JcPortPortAssoc jcPortPortAssocs1) {
		getJcPortPortAssocs1().add(jcPortPortAssocs1);
		jcPortPortAssocs1.setChassi1(this);

		return jcPortPortAssocs1;
	}

	public JcPortPortAssoc removeJcPortPortAssocs1(JcPortPortAssoc jcPortPortAssocs1) {
		getJcPortPortAssocs1().remove(jcPortPortAssocs1);
		jcPortPortAssocs1.setChassi1(null);

		return jcPortPortAssocs1;
	}

	public List<JcPortPortAssoc> getJcPortPortAssocs2() {
		return this.jcPortPortAssocs2;
	}

	public void setJcPortPortAssocs2(List<JcPortPortAssoc> jcPortPortAssocs2) {
		this.jcPortPortAssocs2 = jcPortPortAssocs2;
	}

	public JcPortPortAssoc addJcPortPortAssocs2(JcPortPortAssoc jcPortPortAssocs2) {
		getJcPortPortAssocs2().add(jcPortPortAssocs2);
		jcPortPortAssocs2.setChassi2(this);

		return jcPortPortAssocs2;
	}

	public JcPortPortAssoc removeJcPortPortAssocs2(JcPortPortAssoc jcPortPortAssocs2) {
		getJcPortPortAssocs2().remove(jcPortPortAssocs2);
		jcPortPortAssocs2.setChassi2(null);

		return jcPortPortAssocs2;
	}

	public List<MfnChassisPhAssoc> getMfnChassisPhAssocs() {
		return this.mfnChassisPhAssocs;
	}

	public void setMfnChassisPhAssocs(List<MfnChassisPhAssoc> mfnChassisPhAssocs) {
		this.mfnChassisPhAssocs = mfnChassisPhAssocs;
	}

	public MfnChassisPhAssoc addMfnChassisPhAssoc(MfnChassisPhAssoc mfnChassisPhAssoc) {
		getMfnChassisPhAssocs().add(mfnChassisPhAssoc);
		mfnChassisPhAssoc.setChassi(this);

		return mfnChassisPhAssoc;
	}

	public MfnChassisPhAssoc removeMfnChassisPhAssoc(MfnChassisPhAssoc mfnChassisPhAssoc) {
		getMfnChassisPhAssocs().remove(mfnChassisPhAssoc);
		mfnChassisPhAssoc.setChassi(null);

		return mfnChassisPhAssoc;
	}

	public List<MfnCsPortTerm> getMfnCsPortTerms() {
		return this.mfnCsPortTerms;
	}

	public void setMfnCsPortTerms(List<MfnCsPortTerm> mfnCsPortTerms) {
		this.mfnCsPortTerms = mfnCsPortTerms;
	}

	public MfnCsPortTerm addMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		getMfnCsPortTerms().add(mfnCsPortTerm);
		mfnCsPortTerm.setChassi(this);

		return mfnCsPortTerm;
	}

	public MfnCsPortTerm removeMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		getMfnCsPortTerms().remove(mfnCsPortTerm);
		mfnCsPortTerm.setChassi(null);

		return mfnCsPortTerm;
	}

	public List<MfnPortPortAssoc> getMfnPortPortAssocs1() {
		return this.mfnPortPortAssocs1;
	}

	public void setMfnPortPortAssocs1(List<MfnPortPortAssoc> mfnPortPortAssocs1) {
		this.mfnPortPortAssocs1 = mfnPortPortAssocs1;
	}

	public MfnPortPortAssoc addMfnPortPortAssocs1(MfnPortPortAssoc mfnPortPortAssocs1) {
		getMfnPortPortAssocs1().add(mfnPortPortAssocs1);
		mfnPortPortAssocs1.setChassi1(this);

		return mfnPortPortAssocs1;
	}

	public MfnPortPortAssoc removeMfnPortPortAssocs1(MfnPortPortAssoc mfnPortPortAssocs1) {
		getMfnPortPortAssocs1().remove(mfnPortPortAssocs1);
		mfnPortPortAssocs1.setChassi1(null);

		return mfnPortPortAssocs1;
	}

	public List<MfnPortPortAssoc> getMfnPortPortAssocs2() {
		return this.mfnPortPortAssocs2;
	}

	public void setMfnPortPortAssocs2(List<MfnPortPortAssoc> mfnPortPortAssocs2) {
		this.mfnPortPortAssocs2 = mfnPortPortAssocs2;
	}

	public MfnPortPortAssoc addMfnPortPortAssocs2(MfnPortPortAssoc mfnPortPortAssocs2) {
		getMfnPortPortAssocs2().add(mfnPortPortAssocs2);
		mfnPortPortAssocs2.setChassi2(this);

		return mfnPortPortAssocs2;
	}

	public MfnPortPortAssoc removeMfnPortPortAssocs2(MfnPortPortAssoc mfnPortPortAssocs2) {
		getMfnPortPortAssocs2().remove(mfnPortPortAssocs2);
		mfnPortPortAssocs2.setChassi2(null);

		return mfnPortPortAssocs2;
	}

	public List<NteChassisPhAssoc> getNteChassisPhAssocs() {
		return this.nteChassisPhAssocs;
	}

	public void setNteChassisPhAssocs(List<NteChassisPhAssoc> nteChassisPhAssocs) {
		this.nteChassisPhAssocs = nteChassisPhAssocs;
	}

	public NteChassisPhAssoc addNteChassisPhAssoc(NteChassisPhAssoc nteChassisPhAssoc) {
		getNteChassisPhAssocs().add(nteChassisPhAssoc);
		nteChassisPhAssoc.setChassi(this);

		return nteChassisPhAssoc;
	}

	public NteChassisPhAssoc removeNteChassisPhAssoc(NteChassisPhAssoc nteChassisPhAssoc) {
		getNteChassisPhAssocs().remove(nteChassisPhAssoc);
		nteChassisPhAssoc.setChassi(null);

		return nteChassisPhAssoc;
	}

	public List<NteCsPortTerm> getNteCsPortTerms() {
		return this.nteCsPortTerms;
	}

	public void setNteCsPortTerms(List<NteCsPortTerm> nteCsPortTerms) {
		this.nteCsPortTerms = nteCsPortTerms;
	}

	public NteCsPortTerm addNteCsPortTerm(NteCsPortTerm nteCsPortTerm) {
		getNteCsPortTerms().add(nteCsPortTerm);
		nteCsPortTerm.setChassi(this);

		return nteCsPortTerm;
	}

	public NteCsPortTerm removeNteCsPortTerm(NteCsPortTerm nteCsPortTerm) {
		getNteCsPortTerms().remove(nteCsPortTerm);
		nteCsPortTerm.setChassi(null);

		return nteCsPortTerm;
	}

	public List<NtePortPortAssoc> getNtePortPortAssocs1() {
		return this.ntePortPortAssocs1;
	}

	public void setNtePortPortAssocs1(List<NtePortPortAssoc> ntePortPortAssocs1) {
		this.ntePortPortAssocs1 = ntePortPortAssocs1;
	}

	public NtePortPortAssoc addNtePortPortAssocs1(NtePortPortAssoc ntePortPortAssocs1) {
		getNtePortPortAssocs1().add(ntePortPortAssocs1);
		ntePortPortAssocs1.setChassi1(this);

		return ntePortPortAssocs1;
	}

	public NtePortPortAssoc removeNtePortPortAssocs1(NtePortPortAssoc ntePortPortAssocs1) {
		getNtePortPortAssocs1().remove(ntePortPortAssocs1);
		ntePortPortAssocs1.setChassi1(null);

		return ntePortPortAssocs1;
	}

	public List<NtePortPortAssoc> getNtePortPortAssocs2() {
		return this.ntePortPortAssocs2;
	}

	public void setNtePortPortAssocs2(List<NtePortPortAssoc> ntePortPortAssocs2) {
		this.ntePortPortAssocs2 = ntePortPortAssocs2;
	}

	public NtePortPortAssoc addNtePortPortAssocs2(NtePortPortAssoc ntePortPortAssocs2) {
		getNtePortPortAssocs2().add(ntePortPortAssocs2);
		ntePortPortAssocs2.setChassi2(this);

		return ntePortPortAssocs2;
	}

	public NtePortPortAssoc removeNtePortPortAssocs2(NtePortPortAssoc ntePortPortAssocs2) {
		getNtePortPortAssocs2().remove(ntePortPortAssocs2);
		ntePortPortAssocs2.setChassi2(null);

		return ntePortPortAssocs2;
	}

	public List<PluginHolder> getPluginHolders() {
		return this.pluginHolders;
	}

	public void setPluginHolders(List<PluginHolder> pluginHolders) {
		this.pluginHolders = pluginHolders;
	}

	public PluginHolder addPluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().add(pluginHolder);
		pluginHolder.setChassi(this);

		return pluginHolder;
	}

	public PluginHolder removePluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().remove(pluginHolder);
		pluginHolder.setChassi(null);

		return pluginHolder;
	}

	public List<WeChassisPhAssoc> getWeChassisPhAssocs() {
		return this.weChassisPhAssocs;
	}

	public void setWeChassisPhAssocs(List<WeChassisPhAssoc> weChassisPhAssocs) {
		this.weChassisPhAssocs = weChassisPhAssocs;
	}

	public WeChassisPhAssoc addWeChassisPhAssoc(WeChassisPhAssoc weChassisPhAssoc) {
		getWeChassisPhAssocs().add(weChassisPhAssoc);
		weChassisPhAssoc.setChassi(this);

		return weChassisPhAssoc;
	}

	public WeChassisPhAssoc removeWeChassisPhAssoc(WeChassisPhAssoc weChassisPhAssoc) {
		getWeChassisPhAssocs().remove(weChassisPhAssoc);
		weChassisPhAssoc.setChassi(null);

		return weChassisPhAssoc;
	}

	public List<WeCsPortTerm> getWeCsPortTerms() {
		return this.weCsPortTerms;
	}

	public void setWeCsPortTerms(List<WeCsPortTerm> weCsPortTerms) {
		this.weCsPortTerms = weCsPortTerms;
	}

	public WeCsPortTerm addWeCsPortTerm(WeCsPortTerm weCsPortTerm) {
		getWeCsPortTerms().add(weCsPortTerm);
		weCsPortTerm.setChassi(this);

		return weCsPortTerm;
	}

	public WeCsPortTerm removeWeCsPortTerm(WeCsPortTerm weCsPortTerm) {
		getWeCsPortTerms().remove(weCsPortTerm);
		weCsPortTerm.setChassi(null);

		return weCsPortTerm;
	}

	public List<WePortPortAssoc> getWePortPortAssocs1() {
		return this.wePortPortAssocs1;
	}

	public void setWePortPortAssocs1(List<WePortPortAssoc> wePortPortAssocs1) {
		this.wePortPortAssocs1 = wePortPortAssocs1;
	}

	public WePortPortAssoc addWePortPortAssocs1(WePortPortAssoc wePortPortAssocs1) {
		getWePortPortAssocs1().add(wePortPortAssocs1);
		wePortPortAssocs1.setChassi1(this);

		return wePortPortAssocs1;
	}

	public WePortPortAssoc removeWePortPortAssocs1(WePortPortAssoc wePortPortAssocs1) {
		getWePortPortAssocs1().remove(wePortPortAssocs1);
		wePortPortAssocs1.setChassi1(null);

		return wePortPortAssocs1;
	}

	public List<WePortPortAssoc> getWePortPortAssocs2() {
		return this.wePortPortAssocs2;
	}

	public void setWePortPortAssocs2(List<WePortPortAssoc> wePortPortAssocs2) {
		this.wePortPortAssocs2 = wePortPortAssocs2;
	}

	public WePortPortAssoc addWePortPortAssocs2(WePortPortAssoc wePortPortAssocs2) {
		getWePortPortAssocs2().add(wePortPortAssocs2);
		wePortPortAssocs2.setChassi2(this);

		return wePortPortAssocs2;
	}

	public WePortPortAssoc removeWePortPortAssocs2(WePortPortAssoc wePortPortAssocs2) {
		getWePortPortAssocs2().remove(wePortPortAssocs2);
		wePortPortAssocs2.setChassi2(null);

		return wePortPortAssocs2;
	}

}