package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the SPAN_SECTION_ENDS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="SPAN_SECTION_ENDS")
@NamedQuery(name="SpanSectionEnd.findAll", query="SELECT s FROM SpanSectionEnd s")
public class SpanSectionEnd implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CONNECTION_STATE", nullable=false, length=20)
	private String connectionState;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="ORIG_END_ENTITY_NAME", length=30)
	private String origEndEntityName;

	@Column(name="ORIG_END_NAME", nullable=false, length=30)
	private String origEndName;

	@Column(name="STRUCTURE_SPAN_COMP_SPEC_ID", length=50)
	private String structureSpanCompSpecId;

	@Column(name="TERM_END_ENTITY_NAME", length=30)
	private String termEndEntityName;

	@Column(name="TERM_END_NAME", nullable=false, length=30)
	private String termEndName;

	//bi-directional many-to-one association to SpanSection
	@ManyToOne
	@JoinColumn(name="SPAN_SECTION_NAME")
	private SpanSection spanSection;

	public SpanSectionEnd() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getConnectionState() {
		return this.connectionState;
	}

	public void setConnectionState(String connectionState) {
		this.connectionState = connectionState;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getOrigEndEntityName() {
		return this.origEndEntityName;
	}

	public void setOrigEndEntityName(String origEndEntityName) {
		this.origEndEntityName = origEndEntityName;
	}

	public String getOrigEndName() {
		return this.origEndName;
	}

	public void setOrigEndName(String origEndName) {
		this.origEndName = origEndName;
	}

	public String getStructureSpanCompSpecId() {
		return this.structureSpanCompSpecId;
	}

	public void setStructureSpanCompSpecId(String structureSpanCompSpecId) {
		this.structureSpanCompSpecId = structureSpanCompSpecId;
	}

	public String getTermEndEntityName() {
		return this.termEndEntityName;
	}

	public void setTermEndEntityName(String termEndEntityName) {
		this.termEndEntityName = termEndEntityName;
	}

	public String getTermEndName() {
		return this.termEndName;
	}

	public void setTermEndName(String termEndName) {
		this.termEndName = termEndName;
	}

	public SpanSection getSpanSection() {
		return this.spanSection;
	}

	public void setSpanSection(SpanSection spanSection) {
		this.spanSection = spanSection;
	}

}