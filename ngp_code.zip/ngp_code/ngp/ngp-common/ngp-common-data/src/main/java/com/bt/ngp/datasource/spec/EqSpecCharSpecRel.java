package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the EQ_SPEC_CHAR_SPEC_REL database table.
 * 
 */
@javax.persistence.Entity
@Table(name="EQ_SPEC_CHAR_SPEC_REL")
@NamedQuery(name="EqSpecCharSpecRel.findAll", query="SELECT e FROM EqSpecCharSpecRel e")
public class EqSpecCharSpecRel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CHAR_SPEC_RELATION_TYPE", length=10)
	private String charSpecRelationType;

	@Column(name="CHAR_VALUE_SPEC_RELATION_TYPE", length=10)
	private String charValueSpecRelationType;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to EqSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="EQ_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="EQ_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private EqSpec eqSpec;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to EqSpecCharSpec
	@ManyToOne
	@JoinColumn(name="SOURCE_CHAR_SPEC_ID")
	private EqSpecCharSpec eqSpecCharSpec1;

	//bi-directional many-to-one association to EqSpecCharSpec
	@ManyToOne
	@JoinColumn(name="TARGET_CHAR_SPEC_ID")
	private EqSpecCharSpec eqSpecCharSpec2;

	public EqSpecCharSpecRel() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCharSpecRelationType() {
		return this.charSpecRelationType;
	}

	public void setCharSpecRelationType(String charSpecRelationType) {
		this.charSpecRelationType = charSpecRelationType;
	}

	public String getCharValueSpecRelationType() {
		return this.charValueSpecRelationType;
	}

	public void setCharValueSpecRelationType(String charValueSpecRelationType) {
		this.charValueSpecRelationType = charValueSpecRelationType;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public EqSpec getEqSpec() {
		return this.eqSpec;
	}

	public void setEqSpec(EqSpec eqSpec) {
		this.eqSpec = eqSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public EqSpecCharSpec getEqSpecCharSpec1() {
		return this.eqSpecCharSpec1;
	}

	public void setEqSpecCharSpec1(EqSpecCharSpec eqSpecCharSpec1) {
		this.eqSpecCharSpec1 = eqSpecCharSpec1;
	}

	public EqSpecCharSpec getEqSpecCharSpec2() {
		return this.eqSpecCharSpec2;
	}

	public void setEqSpecCharSpec2(EqSpecCharSpec eqSpecCharSpec2) {
		this.eqSpecCharSpec2 = eqSpecCharSpec2;
	}

}