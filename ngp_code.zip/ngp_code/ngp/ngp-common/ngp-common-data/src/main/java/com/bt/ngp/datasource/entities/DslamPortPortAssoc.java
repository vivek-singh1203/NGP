package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the DSLAM_PORT_PORT_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name = "DSLAM_PORT_PORT_ASSOC")
@NamedQuery(name = "DslamPortPortAssoc.findAll", query = "SELECT d FROM DslamPortPortAssoc d")
public class DslamPortPortAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique = true, nullable = false, length = 50)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SeqGen")
	@SequenceGenerator(name = "SeqGen", sequenceName = "DSLAM_PORT_PORT_ASSOC_SEQ", allocationSize = 1)
	private long id;

	@Column(name = "CREATED_BY", nullable = false, length = 40)
	private String createdBy;

	@Column(name = "CREATED_DATE", nullable = false)
	private Timestamp createdDate;

	@Column(name = "EQ_P2P_ASPEC_ID", length = 50)
	private String eqP2pAspecId;

	@Column(name = "LAST_MODIFIED_BY", length = 40)
	private String lastModifiedBy;

	@Column(name = "LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name = "SOURCE_PORT_SEQ_NO", nullable = false, precision = 38)
	private BigDecimal sourcePortSeqNo;

	@Column(name = "TARGET_PORT_SEQ_NO", nullable = false, precision = 38)
	private BigDecimal targetPortSeqNo;

	// bi-directional many-to-one association to Dslam
	@ManyToOne
	@JoinColumn(name = "DSLAM_NAME")
	private Dslam dslam;

	// bi-directional many-to-one association to Card
	@ManyToOne
	@JoinColumn(name = "SOURCE_CARD_NAME")
	private Card card1;

	// bi-directional many-to-one association to DslamPort
	@ManyToOne
	@JoinColumn(name = "SOURCE_PORT_NAME")
	private DslamPort dslamPort1;

	// bi-directional many-to-one association to Rack
	@ManyToOne
	@JoinColumn(name = "SOURCE_RACK_NAME")
	private Rack rack1;

	// bi-directional many-to-one association to Card
	@ManyToOne
	@JoinColumn(name = "TARGET_CARD_NAME")
	private Card card2;

	// bi-directional many-to-one association to DslamPort
	@ManyToOne
	@JoinColumn(name = "TARGET_PORT_NAME")
	private DslamPort dslamPort2;

	// bi-directional many-to-one association to Rack
	@ManyToOne
	@JoinColumn(name = "TARGET_RACK_NAME")
	private Rack rack2;

	public DslamPortPortAssoc() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEqP2pAspecId() {
		return this.eqP2pAspecId;
	}

	public void setEqP2pAspecId(String eqP2pAspecId) {
		this.eqP2pAspecId = eqP2pAspecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getSourcePortSeqNo() {
		return this.sourcePortSeqNo;
	}

	public void setSourcePortSeqNo(BigDecimal sourcePortSeqNo) {
		this.sourcePortSeqNo = sourcePortSeqNo;
	}

	public BigDecimal getTargetPortSeqNo() {
		return this.targetPortSeqNo;
	}

	public void setTargetPortSeqNo(BigDecimal targetPortSeqNo) {
		this.targetPortSeqNo = targetPortSeqNo;
	}

	public Dslam getDslam() {
		return this.dslam;
	}

	public void setDslam(Dslam dslam) {
		this.dslam = dslam;
	}

	public Card getCard1() {
		return this.card1;
	}

	public void setCard1(Card card1) {
		this.card1 = card1;
	}

	public DslamPort getDslamPort1() {
		return this.dslamPort1;
	}

	public void setDslamPort1(DslamPort dslamPort1) {
		this.dslamPort1 = dslamPort1;
	}

	public Rack getRack1() {
		return this.rack1;
	}

	public void setRack1(Rack rack1) {
		this.rack1 = rack1;
	}

	public Card getCard2() {
		return this.card2;
	}

	public void setCard2(Card card2) {
		this.card2 = card2;
	}

	public DslamPort getDslamPort2() {
		return this.dslamPort2;
	}

	public void setDslamPort2(DslamPort dslamPort2) {
		this.dslamPort2 = dslamPort2;
	}

	public Rack getRack2() {
		return this.rack2;
	}

	public void setRack2(Rack rack2) {
		this.rack2 = rack2;
	}

}