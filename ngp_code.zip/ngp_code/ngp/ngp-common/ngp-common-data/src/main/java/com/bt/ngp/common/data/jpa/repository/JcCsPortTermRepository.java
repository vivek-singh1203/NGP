package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.Chassi;
import com.bt.ngp.datasource.entities.Conductor;
import com.bt.ngp.datasource.entities.ConductorBundle;
import com.bt.ngp.datasource.entities.JcCsPortTerm;
import com.bt.ngp.datasource.entities.JcPort;
import com.bt.ngp.datasource.entities.JointClosure;
import com.bt.ngp.datasource.entities.Plugin;

@Repository
public interface JcCsPortTermRepository extends SqlRepository<JcCsPortTerm> {

	public JcCsPortTerm findByJointClosureAndChassiAndPluginAndJcPortAndCableSectionAndConductorBundleAndConductor(
			JointClosure jointClosure, Chassi chassi, Plugin plugin, JcPort jcPort, CableSection cableSection,
			ConductorBundle conductorBundle, Conductor conductor);

	@Query(name = "JcCsPortTermRepository.findJcCsPortTerm", nativeQuery = true)
	List<JcCsPortTerm> findJcCsPortTerm(@Param("termObj") JcCsPortTerm termObj);

	@Query(name = "JcCsPortTermRepository.fetchViaJcCsCbCond", nativeQuery = true)
	public JcCsPortTerm fetchJcCsPortTerm(@Param("jcCsPortTerm") JcCsPortTerm jcCsPortTerm);

	List<JcCsPortTerm> findByJointClosure(@Param("jointClosure") JointClosure jointClosure);

	@Query(name = "JcCsPortTermRepository.findByConductorAndTerminationType")
	List<JcCsPortTerm> findByConductorAndTerminationType(@Param("jcCsPortTermObj") JcCsPortTerm jcCsPortTermTermObj);

	@Query(name = "JcCsPortTermRepository.findByCableSectionAndPort")
	List<JcCsPortTerm> findByCableSectionAndPort(@Param("jcCsPortTermObj") JcCsPortTerm jcCsPortTermTermObj);

	JcCsPortTerm findByCableSectionAndJointClosure(CableSection cableSection, JointClosure jointClosure);

	@Query(name = "JcCsPortTermRepository.findByJcCableAndConductor")
	List<JcCsPortTerm> findByJcCableAndConductor(@Param("jcCsPortTerm") JcCsPortTerm jcCsPortTerm);

}
