package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the DSLAM_HIERARCHY database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DSLAM_HIERARCHY")
@NamedQuery(name="DslamHierarchy.findAll", query="SELECT d FROM DslamHierarchy d")
public class DslamHierarchy implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DSLAM_POS_END_NUM", nullable=false, precision=38)
	private BigDecimal dslamPosEndNum;

	@Column(name="DSLAM_POS_START_NUM", nullable=false, precision=38)
	private BigDecimal dslamPosStartNum;

	@Column(name="EQ_HIERARCHY_SPEC_ID", length=50)
	private String eqHierarchySpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LEG_ID", precision=38)
	private BigDecimal legId;

	//bi-directional many-to-one association to DslamChCardAssoc
	@ManyToOne
	@JoinColumn(name="DSLAM_CH_CARD_ASSOC_ID")
	private DslamChCardAssoc dslamChCardAssoc;

	//bi-directional many-to-one association to DslamCardPortAssoc
	@ManyToOne
	@JoinColumn(name="DSLAM_CARD_PORT_ASSOC_ID")
	private DslamCardPortAssoc dslamCardPortAssoc;

	//bi-directional many-to-one association to Dslam
	@ManyToOne
	@JoinColumn(name="DSLAM_NAME")
	private Dslam dslam;

	//bi-directional many-to-one association to DslamRackChAssoc
	@ManyToOne
	@JoinColumn(name="DSLAM_RACK_CH_ASSOC_ID")
	private DslamRackChAssoc dslamRackChAssoc;

	public DslamHierarchy() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public BigDecimal getDslamPosEndNum() {
		return this.dslamPosEndNum;
	}

	public void setDslamPosEndNum(BigDecimal dslamPosEndNum) {
		this.dslamPosEndNum = dslamPosEndNum;
	}

	public BigDecimal getDslamPosStartNum() {
		return this.dslamPosStartNum;
	}

	public void setDslamPosStartNum(BigDecimal dslamPosStartNum) {
		this.dslamPosStartNum = dslamPosStartNum;
	}

	public String getEqHierarchySpecId() {
		return this.eqHierarchySpecId;
	}

	public void setEqHierarchySpecId(String eqHierarchySpecId) {
		this.eqHierarchySpecId = eqHierarchySpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getLegId() {
		return this.legId;
	}

	public void setLegId(BigDecimal legId) {
		this.legId = legId;
	}

	public DslamChCardAssoc getDslamChCardAssoc() {
		return this.dslamChCardAssoc;
	}

	public void setDslamChCardAssoc(DslamChCardAssoc dslamChCardAssoc) {
		this.dslamChCardAssoc = dslamChCardAssoc;
	}

	public DslamCardPortAssoc getDslamCardPortAssoc() {
		return this.dslamCardPortAssoc;
	}

	public void setDslamCardPortAssoc(DslamCardPortAssoc dslamCardPortAssoc) {
		this.dslamCardPortAssoc = dslamCardPortAssoc;
	}

	public Dslam getDslam() {
		return this.dslam;
	}

	public void setDslam(Dslam dslam) {
		this.dslam = dslam;
	}

	public DslamRackChAssoc getDslamRackChAssoc() {
		return this.dslamRackChAssoc;
	}

	public void setDslamRackChAssoc(DslamRackChAssoc dslamRackChAssoc) {
		this.dslamRackChAssoc = dslamRackChAssoc;
	}

}