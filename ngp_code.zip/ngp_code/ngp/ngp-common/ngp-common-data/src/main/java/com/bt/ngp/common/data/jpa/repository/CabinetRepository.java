package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.Cabinet;

@Repository
public interface CabinetRepository extends SqlRepository<Cabinet> {

	public Cabinet findByName(@Param("name") String name);
	
	public List<Cabinet> findByNameIn(List<String> structures);
	
	@Query(name="CabinetRepository.findCabinetWithoutSpanSectionAssoc", nativeQuery=true)
	public List<Cabinet> findCabinetWithoutSpanSectionAssoc(@Param("exchangeCode") String exchangeCode);

	@Query(name="CabinetRepository.CabinetWithoutEquipment", nativeQuery=true)
	public List<Cabinet> findCabinetWithoutEquipment(@Param("exchangeCode") String exchangeCode, @Param("physicalStructureType") String physicalStructureType);
	
}