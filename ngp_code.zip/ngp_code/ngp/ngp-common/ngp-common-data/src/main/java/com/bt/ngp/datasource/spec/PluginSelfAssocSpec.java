package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the PLUGIN_SELF_ASSOC_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="PLUGIN_SELF_ASSOC_SPEC")
@NamedQuery(name="PluginSelfAssocSpec.findAll", query="SELECT p FROM PluginSelfAssocSpec p")
public class PluginSelfAssocSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, precision=38)
	private long id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="NO_OF_CHILD_INSTANCES", nullable=false, precision=38)
	private BigDecimal noOfChildInstances;

	//bi-directional many-to-one association to EqSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="CHILD_PLUGIN_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="CHILD_PLUGIN_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private EqSpec eqSpec1;

	//bi-directional many-to-one association to EqSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="PARENT_PLUGIN_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="PARENT_PLUGIN_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private EqSpec eqSpec2;

	public PluginSelfAssocSpec() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getNoOfChildInstances() {
		return this.noOfChildInstances;
	}

	public void setNoOfChildInstances(BigDecimal noOfChildInstances) {
		this.noOfChildInstances = noOfChildInstances;
	}

	public EqSpec getEqSpec1() {
		return this.eqSpec1;
	}

	public void setEqSpec1(EqSpec eqSpec1) {
		this.eqSpec1 = eqSpec1;
	}

	public EqSpec getEqSpec2() {
		return this.eqSpec2;
	}

	public void setEqSpec2(EqSpec eqSpec2) {
		this.eqSpec2 = eqSpec2;
	}

}