package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the SPAN_SPEC_CHAR_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="SPAN_SPEC_CHAR_SPEC")
@NamedQuery(name="SpanSpecCharSpec.findAll", query="SELECT s FROM SpanSpecCharSpec s")
public class SpanSpecCharSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CAN_BE_OVERRIDEN", nullable=false)
	private BigDecimal canBeOverriden;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(length=40)
	private String description;

	@Column(name="ENTITY_CHAR_CATEGORY_NAME", length=30)
	private String entityCharCategoryName;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(name="IS_UNIQUE_WHEN_PRESENT")
	private BigDecimal isUniqueWhenPresent;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="MAX_CARDINALITY")
	private BigDecimal maxCardinality;

	@Column(name="MIN_CARDINALITY")
	private BigDecimal minCardinality;

	@Column(nullable=false, length=30)
	private String name;

	@Column(length=50)
	private String remarks;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	@Column(name="VALUE_TYPE", nullable=false, length=30)
	private String valueType;

	//bi-directional many-to-one association to EntityCharSpec
	@ManyToOne
	@JoinColumn(name="ENTITY_CHAR_SPEC_NAME")
	private EntityCharSpec entityCharSpec;

	//bi-directional many-to-one association to SpanSpecCharValueSpec
	@ManyToOne
	@JoinColumn(name="CHAR_VALUE_SPEC_ID", nullable=false)
	private SpanSpecCharValueSpec spanSpecCharValueSpec;

	//bi-directional many-to-one association to SpanSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="SPAN_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="SPAN_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private SpanSpec spanSpec;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to SpanSpecCharSpecRel
	@OneToMany(mappedBy="spanSpecCharSpec1")
	private List<SpanSpecCharSpecRel> spanSpecCharSpecRels1;

	//bi-directional many-to-one association to SpanSpecCharSpecRel
	@OneToMany(mappedBy="spanSpecCharSpec2")
	private List<SpanSpecCharSpecRel> spanSpecCharSpecRels2;

	public SpanSpecCharSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public BigDecimal getCanBeOverriden() {
		return this.canBeOverriden;
	}

	public void setCanBeOverriden(BigDecimal canBeOverriden) {
		this.canBeOverriden = canBeOverriden;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEntityCharCategoryName() {
		return this.entityCharCategoryName;
	}

	public void setEntityCharCategoryName(String entityCharCategoryName) {
		this.entityCharCategoryName = entityCharCategoryName;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public BigDecimal getIsUniqueWhenPresent() {
		return this.isUniqueWhenPresent;
	}

	public void setIsUniqueWhenPresent(BigDecimal isUniqueWhenPresent) {
		this.isUniqueWhenPresent = isUniqueWhenPresent;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getMaxCardinality() {
		return this.maxCardinality;
	}

	public void setMaxCardinality(BigDecimal maxCardinality) {
		this.maxCardinality = maxCardinality;
	}

	public BigDecimal getMinCardinality() {
		return this.minCardinality;
	}

	public void setMinCardinality(BigDecimal minCardinality) {
		this.minCardinality = minCardinality;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRemarks() {
		return this.remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public String getValueType() {
		return this.valueType;
	}

	public void setValueType(String valueType) {
		this.valueType = valueType;
	}

	public EntityCharSpec getEntityCharSpec() {
		return this.entityCharSpec;
	}

	public void setEntityCharSpec(EntityCharSpec entityCharSpec) {
		this.entityCharSpec = entityCharSpec;
	}

	public SpanSpecCharValueSpec getSpanSpecCharValueSpec() {
		return this.spanSpecCharValueSpec;
	}

	public void setSpanSpecCharValueSpec(SpanSpecCharValueSpec spanSpecCharValueSpec) {
		this.spanSpecCharValueSpec = spanSpecCharValueSpec;
	}

	public SpanSpec getSpanSpec() {
		return this.spanSpec;
	}

	public void setSpanSpec(SpanSpec spanSpec) {
		this.spanSpec = spanSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public List<SpanSpecCharSpecRel> getSpanSpecCharSpecRels1() {
		return this.spanSpecCharSpecRels1;
	}

	public void setSpanSpecCharSpecRels1(List<SpanSpecCharSpecRel> spanSpecCharSpecRels1) {
		this.spanSpecCharSpecRels1 = spanSpecCharSpecRels1;
	}

	public SpanSpecCharSpecRel addSpanSpecCharSpecRels1(SpanSpecCharSpecRel spanSpecCharSpecRels1) {
		getSpanSpecCharSpecRels1().add(spanSpecCharSpecRels1);
		spanSpecCharSpecRels1.setSpanSpecCharSpec1(this);

		return spanSpecCharSpecRels1;
	}

	public SpanSpecCharSpecRel removeSpanSpecCharSpecRels1(SpanSpecCharSpecRel spanSpecCharSpecRels1) {
		getSpanSpecCharSpecRels1().remove(spanSpecCharSpecRels1);
		spanSpecCharSpecRels1.setSpanSpecCharSpec1(null);

		return spanSpecCharSpecRels1;
	}

	public List<SpanSpecCharSpecRel> getSpanSpecCharSpecRels2() {
		return this.spanSpecCharSpecRels2;
	}

	public void setSpanSpecCharSpecRels2(List<SpanSpecCharSpecRel> spanSpecCharSpecRels2) {
		this.spanSpecCharSpecRels2 = spanSpecCharSpecRels2;
	}

	public SpanSpecCharSpecRel addSpanSpecCharSpecRels2(SpanSpecCharSpecRel spanSpecCharSpecRels2) {
		getSpanSpecCharSpecRels2().add(spanSpecCharSpecRels2);
		spanSpecCharSpecRels2.setSpanSpecCharSpec2(this);

		return spanSpecCharSpecRels2;
	}

	public SpanSpecCharSpecRel removeSpanSpecCharSpecRels2(SpanSpecCharSpecRel spanSpecCharSpecRels2) {
		getSpanSpecCharSpecRels2().remove(spanSpecCharSpecRels2);
		spanSpecCharSpecRels2.setSpanSpecCharSpec2(null);

		return spanSpecCharSpecRels2;
	}

}