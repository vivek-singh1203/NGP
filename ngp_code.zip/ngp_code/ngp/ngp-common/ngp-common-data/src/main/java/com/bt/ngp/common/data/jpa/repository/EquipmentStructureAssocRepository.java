package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.query.Param;

@NoRepositoryBean
public interface EquipmentStructureAssocRepository<T> extends SqlRepository<T> {

	public List<T> findByStructureName(@Param("structureName")String structureName);

}