package com.bt.ngp.common.data.jpa.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.bt.ngp.datasource.entities.Chassi;
import com.bt.ngp.datasource.entities.Rack;


public interface RackRepository extends CommonOperation<Rack>{
		
}
