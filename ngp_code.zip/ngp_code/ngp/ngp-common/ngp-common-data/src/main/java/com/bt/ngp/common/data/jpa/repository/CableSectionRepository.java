package com.bt.ngp.common.data.jpa.repository;

import java.math.BigInteger;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.Exchange;

@Repository
public interface CableSectionRepository extends SqlRepository<CableSection> {
	
	@Query(name="CableSectionRepository.findCableSectionwithJointClosure",nativeQuery=true)
	public List<CableSection> findCableSectionwithJointClosure(@Param("id") long id);
	
	public CableSection findByName(String name);
	
	@Query("SELECT cs FROM CableSection cs WHERE cs.desgName=:desgName and cs.desgNum IN :desgNums")
	List<CableSection> findByDesgNumAndDesgName(
			@Param("desgNums") Set<BigInteger> desgNums,
			@Param("desgName") String desgName);
	
	public List<CableSection> findByExchangeAndCableSectionEndsTermEndNameIsNull(
			@Param("exchange") Exchange exchange);

	public List<CableSection> findByExchangeAndCableSpanAssocsIsNull(
			@Param("exchange") Exchange exchange);

}
