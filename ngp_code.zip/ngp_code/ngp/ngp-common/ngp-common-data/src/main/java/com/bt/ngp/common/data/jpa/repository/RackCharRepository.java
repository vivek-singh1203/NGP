package com.bt.ngp.common.data.jpa.repository;

import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.RackChar;

/**
 * Rack Char Repository 
 * @author 609511044
 *
 */
@Repository
public interface RackCharRepository extends SqlRepository<RackChar>{

}
