package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.vividsolutions.jts.geom.Point;


/**
 * The persistent class for the CUSTOMER_PREMISE_EQUIPMENT database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CUSTOMER_PREMISE_EQUIPMENT")
@NamedQuery(name="CustomerPremiseEquipment.findAll", query="SELECT c FROM CustomerPremiseEquipment c")
public class CustomerPremiseEquipment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="DESG_NAME", length=30)
	private String desgName;

	@Column(name="DESG_NUM", precision=38)
	private BigDecimal desgNum;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(name="FIELD_LABEL", length=30)
	private String fieldLabel;

	@Column(name = "GEO_POSITION", columnDefinition = "geometry(Point,3857)")
	private Point geoPosition;

	/**
	 * @return the geoPosition
	 */
	public Point getGeoPosition() {
		return geoPosition;
	}

	/**
	 * @param geoPosition the geoPosition to set
	 */
	public void setGeoPosition(Point geoPosition) {
		this.geoPosition = geoPosition;
	}

	@Column(name="ID", nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to AuxComponent
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<AuxComponent> auxComponents;

	//bi-directional many-to-one association to Chassi
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<Chassi> chassis;

	//bi-directional many-to-one association to Connector
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<Connector> connectors;

	//bi-directional many-to-one association to CpeChar
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<CpeChar> cpeChars;

	//bi-directional many-to-one association to CpeChassisPhAssoc
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<CpeChassisPhAssoc> cpeChassisPhAssocs;

	//bi-directional many-to-one association to CpeCsCondSplicing
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<CpeCsCondSplicing> cpeCsCondSplicings;

	//bi-directional many-to-one association to CpeCsPortTerm
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<CpeCsPortTerm> cpeCsPortTerms;

	//bi-directional many-to-one association to CpeHierarchy
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<CpeHierarchy> cpeHierarchies;

	//bi-directional many-to-one association to CpePhPluginAssoc
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<CpePhPluginAssoc> cpePhPluginAssocs;

	//bi-directional many-to-one association to CpePluginPortAssoc
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<CpePluginPortAssoc> cpePluginPortAssocs;

	//bi-directional many-to-one association to CpePort
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<CpePort> cpePorts;

	//bi-directional many-to-one association to CpePortChar
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<CpePortChar> cpePortChars;

	//bi-directional many-to-one association to CpePortPortAssoc
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<CpePortPortAssoc> cpePortPortAssocs;

	//bi-directional many-to-one association to CpeStructureAssoc
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<CpeStructureAssoc> cpeStructureAssocs;

	//bi-directional many-to-one association to Store
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to Exchange
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="EXCHANGE_1141_CODE")
	private Exchange exchange;

	//bi-directional many-to-one association to Plugin
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<Plugin> plugins;

	//bi-directional many-to-one association to PluginHolder
	@OneToMany(mappedBy="customerPremiseEquipment")
	private List<PluginHolder> pluginHolders;

	public CustomerPremiseEquipment() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getDesgName() {
		return this.desgName;
	}

	public void setDesgName(String desgName) {
		this.desgName = desgName;
	}

	public BigDecimal getDesgNum() {
		return this.desgNum;
	}

	public void setDesgNum(BigDecimal desgNum) {
		this.desgNum = desgNum;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getFieldLabel() {
		return this.fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<AuxComponent> getAuxComponents() {
		return this.auxComponents;
	}

	public void setAuxComponents(List<AuxComponent> auxComponents) {
		this.auxComponents = auxComponents;
	}

	public AuxComponent addAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().add(auxComponent);
		auxComponent.setCustomerPremiseEquipment(this);

		return auxComponent;
	}

	public AuxComponent removeAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().remove(auxComponent);
		auxComponent.setCustomerPremiseEquipment(null);

		return auxComponent;
	}

	public List<Chassi> getChassis() {
		return this.chassis;
	}

	public void setChassis(List<Chassi> chassis) {
		this.chassis = chassis;
	}

	public Chassi addChassi(Chassi chassi) {
		getChassis().add(chassi);
		chassi.setCustomerPremiseEquipment(this);

		return chassi;
	}

	public Chassi removeChassi(Chassi chassi) {
		getChassis().remove(chassi);
		chassi.setCustomerPremiseEquipment(null);

		return chassi;
	}

	public List<Connector> getConnectors() {
		return this.connectors;
	}

	public void setConnectors(List<Connector> connectors) {
		this.connectors = connectors;
	}

	public Connector addConnector(Connector connector) {
		getConnectors().add(connector);
		connector.setCustomerPremiseEquipment(this);

		return connector;
	}

	public Connector removeConnector(Connector connector) {
		getConnectors().remove(connector);
		connector.setCustomerPremiseEquipment(null);

		return connector;
	}

	public List<CpeChar> getCpeChars() {
		return this.cpeChars;
	}

	public void setCpeChars(List<CpeChar> cpeChars) {
		this.cpeChars = cpeChars;
	}

	public CpeChar addCpeChar(CpeChar cpeChar) {
		getCpeChars().add(cpeChar);
		cpeChar.setCustomerPremiseEquipment(this);

		return cpeChar;
	}

	public CpeChar removeCpeChar(CpeChar cpeChar) {
		getCpeChars().remove(cpeChar);
		cpeChar.setCustomerPremiseEquipment(null);

		return cpeChar;
	}

	public List<CpeChassisPhAssoc> getCpeChassisPhAssocs() {
		return this.cpeChassisPhAssocs;
	}

	public void setCpeChassisPhAssocs(List<CpeChassisPhAssoc> cpeChassisPhAssocs) {
		this.cpeChassisPhAssocs = cpeChassisPhAssocs;
	}

	public CpeChassisPhAssoc addCpeChassisPhAssoc(CpeChassisPhAssoc cpeChassisPhAssoc) {
		getCpeChassisPhAssocs().add(cpeChassisPhAssoc);
		cpeChassisPhAssoc.setCustomerPremiseEquipment(this);

		return cpeChassisPhAssoc;
	}

	public CpeChassisPhAssoc removeCpeChassisPhAssoc(CpeChassisPhAssoc cpeChassisPhAssoc) {
		getCpeChassisPhAssocs().remove(cpeChassisPhAssoc);
		cpeChassisPhAssoc.setCustomerPremiseEquipment(null);

		return cpeChassisPhAssoc;
	}

	public List<CpeCsCondSplicing> getCpeCsCondSplicings() {
		return this.cpeCsCondSplicings;
	}

	public void setCpeCsCondSplicings(List<CpeCsCondSplicing> cpeCsCondSplicings) {
		this.cpeCsCondSplicings = cpeCsCondSplicings;
	}

	public CpeCsCondSplicing addCpeCsCondSplicing(CpeCsCondSplicing cpeCsCondSplicing) {
		getCpeCsCondSplicings().add(cpeCsCondSplicing);
		cpeCsCondSplicing.setCustomerPremiseEquipment(this);

		return cpeCsCondSplicing;
	}

	public CpeCsCondSplicing removeCpeCsCondSplicing(CpeCsCondSplicing cpeCsCondSplicing) {
		getCpeCsCondSplicings().remove(cpeCsCondSplicing);
		cpeCsCondSplicing.setCustomerPremiseEquipment(null);

		return cpeCsCondSplicing;
	}

	public List<CpeCsPortTerm> getCpeCsPortTerms() {
		return this.cpeCsPortTerms;
	}

	public void setCpeCsPortTerms(List<CpeCsPortTerm> cpeCsPortTerms) {
		this.cpeCsPortTerms = cpeCsPortTerms;
	}

	public CpeCsPortTerm addCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		getCpeCsPortTerms().add(cpeCsPortTerm);
		cpeCsPortTerm.setCustomerPremiseEquipment(this);

		return cpeCsPortTerm;
	}

	public CpeCsPortTerm removeCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		getCpeCsPortTerms().remove(cpeCsPortTerm);
		cpeCsPortTerm.setCustomerPremiseEquipment(null);

		return cpeCsPortTerm;
	}

	public List<CpeHierarchy> getCpeHierarchies() {
		return this.cpeHierarchies;
	}

	public void setCpeHierarchies(List<CpeHierarchy> cpeHierarchies) {
		this.cpeHierarchies = cpeHierarchies;
	}

	public CpeHierarchy addCpeHierarchy(CpeHierarchy cpeHierarchy) {
		getCpeHierarchies().add(cpeHierarchy);
		cpeHierarchy.setCustomerPremiseEquipment(this);

		return cpeHierarchy;
	}

	public CpeHierarchy removeCpeHierarchy(CpeHierarchy cpeHierarchy) {
		getCpeHierarchies().remove(cpeHierarchy);
		cpeHierarchy.setCustomerPremiseEquipment(null);

		return cpeHierarchy;
	}

	public List<CpePhPluginAssoc> getCpePhPluginAssocs() {
		return this.cpePhPluginAssocs;
	}

	public void setCpePhPluginAssocs(List<CpePhPluginAssoc> cpePhPluginAssocs) {
		this.cpePhPluginAssocs = cpePhPluginAssocs;
	}

	public CpePhPluginAssoc addCpePhPluginAssoc(CpePhPluginAssoc cpePhPluginAssoc) {
		getCpePhPluginAssocs().add(cpePhPluginAssoc);
		cpePhPluginAssoc.setCustomerPremiseEquipment(this);

		return cpePhPluginAssoc;
	}

	public CpePhPluginAssoc removeCpePhPluginAssoc(CpePhPluginAssoc cpePhPluginAssoc) {
		getCpePhPluginAssocs().remove(cpePhPluginAssoc);
		cpePhPluginAssoc.setCustomerPremiseEquipment(null);

		return cpePhPluginAssoc;
	}

	public List<CpePluginPortAssoc> getCpePluginPortAssocs() {
		return this.cpePluginPortAssocs;
	}

	public void setCpePluginPortAssocs(List<CpePluginPortAssoc> cpePluginPortAssocs) {
		this.cpePluginPortAssocs = cpePluginPortAssocs;
	}

	public CpePluginPortAssoc addCpePluginPortAssoc(CpePluginPortAssoc cpePluginPortAssoc) {
		getCpePluginPortAssocs().add(cpePluginPortAssoc);
		cpePluginPortAssoc.setCustomerPremiseEquipment(this);

		return cpePluginPortAssoc;
	}

	public CpePluginPortAssoc removeCpePluginPortAssoc(CpePluginPortAssoc cpePluginPortAssoc) {
		getCpePluginPortAssocs().remove(cpePluginPortAssoc);
		cpePluginPortAssoc.setCustomerPremiseEquipment(null);

		return cpePluginPortAssoc;
	}

	public List<CpePort> getCpePorts() {
		return this.cpePorts;
	}

	public void setCpePorts(List<CpePort> cpePorts) {
		this.cpePorts = cpePorts;
	}

	public CpePort addCpePort(CpePort cpePort) {
		getCpePorts().add(cpePort);
		cpePort.setCustomerPremiseEquipment(this);

		return cpePort;
	}

	public CpePort removeCpePort(CpePort cpePort) {
		getCpePorts().remove(cpePort);
		cpePort.setCustomerPremiseEquipment(null);

		return cpePort;
	}

	public List<CpePortChar> getCpePortChars() {
		return this.cpePortChars;
	}

	public void setCpePortChars(List<CpePortChar> cpePortChars) {
		this.cpePortChars = cpePortChars;
	}

	public CpePortChar addCpePortChar(CpePortChar cpePortChar) {
		getCpePortChars().add(cpePortChar);
		cpePortChar.setCustomerPremiseEquipment(this);

		return cpePortChar;
	}

	public CpePortChar removeCpePortChar(CpePortChar cpePortChar) {
		getCpePortChars().remove(cpePortChar);
		cpePortChar.setCustomerPremiseEquipment(null);

		return cpePortChar;
	}

	public List<CpePortPortAssoc> getCpePortPortAssocs() {
		return this.cpePortPortAssocs;
	}

	public void setCpePortPortAssocs(List<CpePortPortAssoc> cpePortPortAssocs) {
		this.cpePortPortAssocs = cpePortPortAssocs;
	}

	public CpePortPortAssoc addCpePortPortAssoc(CpePortPortAssoc cpePortPortAssoc) {
		getCpePortPortAssocs().add(cpePortPortAssoc);
		cpePortPortAssoc.setCustomerPremiseEquipment(this);

		return cpePortPortAssoc;
	}

	public CpePortPortAssoc removeCpePortPortAssoc(CpePortPortAssoc cpePortPortAssoc) {
		getCpePortPortAssocs().remove(cpePortPortAssoc);
		cpePortPortAssoc.setCustomerPremiseEquipment(null);

		return cpePortPortAssoc;
	}

	public List<CpeStructureAssoc> getCpeStructureAssocs() {
		return this.cpeStructureAssocs;
	}

	public void setCpeStructureAssocs(List<CpeStructureAssoc> cpeStructureAssocs) {
		this.cpeStructureAssocs = cpeStructureAssocs;
	}

	public CpeStructureAssoc addCpeStructureAssoc(CpeStructureAssoc cpeStructureAssoc) {
		getCpeStructureAssocs().add(cpeStructureAssoc);
		cpeStructureAssoc.setCustomerPremiseEquipment(this);

		return cpeStructureAssoc;
	}

	public CpeStructureAssoc removeCpeStructureAssoc(CpeStructureAssoc cpeStructureAssoc) {
		getCpeStructureAssocs().remove(cpeStructureAssoc);
		cpeStructureAssoc.setCustomerPremiseEquipment(null);

		return cpeStructureAssoc;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public Exchange getExchange() {
		return this.exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public List<Plugin> getPlugins() {
		return this.plugins;
	}

	public void setPlugins(List<Plugin> plugins) {
		this.plugins = plugins;
	}

	public Plugin addPlugin(Plugin plugin) {
		getPlugins().add(plugin);
		plugin.setCustomerPremiseEquipment(this);

		return plugin;
	}

	public Plugin removePlugin(Plugin plugin) {
		getPlugins().remove(plugin);
		plugin.setCustomerPremiseEquipment(null);

		return plugin;
	}

	public List<PluginHolder> getPluginHolders() {
		return this.pluginHolders;
	}

	public void setPluginHolders(List<PluginHolder> pluginHolders) {
		this.pluginHolders = pluginHolders;
	}

	public PluginHolder addPluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().add(pluginHolder);
		pluginHolder.setCustomerPremiseEquipment(this);

		return pluginHolder;
	}

	public PluginHolder removePluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().remove(pluginHolder);
		pluginHolder.setCustomerPremiseEquipment(null);

		return pluginHolder;
	}

}