/**
 * 
 */
package com.bt.ngp.common.data.jpa.repository;

import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CbChar;

/**
 * Repository class for {@link CbChar}
 *
 * @since 25 Feb 2018
 * @author Mahesh 611174701
 */
@Repository
public interface CbCharRepository extends SqlRepository<CbChar> {

}
