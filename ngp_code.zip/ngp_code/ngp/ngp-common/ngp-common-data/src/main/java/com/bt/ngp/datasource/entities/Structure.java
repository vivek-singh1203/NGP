package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.vividsolutions.jts.geom.Point;

/**
 * The persistent class for the "STRUCTURE" database table.
 * 
 */
@javax.persistence.Entity
@Table(name="STRUCTURE")
@NamedQuery(name="Structure.findAll", query="SELECT s FROM Structure s")
public class Structure implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

/*	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;
*/
	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="DESG_NAME", length=30)
	private String desgName;

	@Column(name="DESG_NUM", precision=38)
	private BigDecimal desgNum;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(name="FIELD_LABEL", length=30)
	private String fieldLabel;

	@Column(name = "GEO_POSITION", columnDefinition = "geometry(Point,3857)")
	private Point geoPosition;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

/*	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;*/

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to Exchange
	@ManyToOne
	@JoinColumn(name="EXCHANGE_1141_CODE")
	private Exchange exchange;

	//bi-directional many-to-one association to Store
	@ManyToOne
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to StructureChar
	@OneToMany(mappedBy="structure")
	private List<StructureChar> structureChars;

	//bi-directional many-to-one association to StructureSelfAssoc
	@OneToMany(mappedBy="childStructure")
	private List<StructureSelfAssoc> childStructureSelfAssocs;

	//bi-directional many-to-one association to StructureSelfAssoc
	@OneToMany(mappedBy="parentStructure")
	private List<StructureSelfAssoc> parentStructureSelfAssocs;

	public Structure() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

/*	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}*/

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getDesgName() {
		return this.desgName;
	}

	public void setDesgName(String desgName) {
		this.desgName = desgName;
	}

	public BigDecimal getDesgNum() {
		return this.desgNum;
	}

	public void setDesgNum(BigDecimal desgNum) {
		this.desgNum = desgNum;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getFieldLabel() {
		return this.fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}

	public Point getGeoPosition() {
		return this.geoPosition;
	}

	public void setGeoPosition(Point geoPosition) {
		this.geoPosition = geoPosition;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

/*	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}*/

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public Exchange getExchange() {
		return this.exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public List<StructureChar> getStructureChars() {
		return this.structureChars;
	}

	public void setStructureChars(List<StructureChar> structureChars) {
		this.structureChars = structureChars;
	}

	public StructureChar addStructureChar(StructureChar structureChar) {
		getStructureChars().add(structureChar);
		structureChar.setStructure(this);

		return structureChar;
	}

	public StructureChar removeStructureChar(StructureChar structureChar) {
		getStructureChars().remove(structureChar);
		structureChar.setStructure(null);

		return structureChar;
	}

	public List<StructureSelfAssoc> getChildStructureSelfAssocs() {
		return this.childStructureSelfAssocs;
	}

	public void setChildStructureSelfAssocs(List<StructureSelfAssoc> structureSelfAssocs) {
		this.childStructureSelfAssocs = structureSelfAssocs;
	}

	public StructureSelfAssoc addChildStructureSelfAssocs(StructureSelfAssoc structureSelfAssocs) {
		getChildStructureSelfAssocs().add(structureSelfAssocs);
		structureSelfAssocs.setChildStructure(this);

		return structureSelfAssocs;
	}

	public StructureSelfAssoc removeChildStructureSelfAssocs(StructureSelfAssoc structureSelfAssocs) {
		getChildStructureSelfAssocs().remove(structureSelfAssocs);
		structureSelfAssocs.setChildStructure(null);

		return structureSelfAssocs;
	}

	public List<StructureSelfAssoc> getParentStructureSelfAssocs() {
		return this.parentStructureSelfAssocs;
	}

	public void setParentStructureSelfAssocs(List<StructureSelfAssoc> structureSelfAssocs) {
		this.parentStructureSelfAssocs = structureSelfAssocs;
	}

	public StructureSelfAssoc addParentStructureSelfAssocs(StructureSelfAssoc structureSelfAssocs) {
		getParentStructureSelfAssocs().add(structureSelfAssocs);
		structureSelfAssocs.setParentStructure(this);

		return structureSelfAssocs;
	}

	public StructureSelfAssoc removeStructureSelfAssocs2(StructureSelfAssoc structureSelfAssocs) {
		getParentStructureSelfAssocs().remove(structureSelfAssocs);
		structureSelfAssocs.setParentStructure(null);

		return structureSelfAssocs;
	}

}