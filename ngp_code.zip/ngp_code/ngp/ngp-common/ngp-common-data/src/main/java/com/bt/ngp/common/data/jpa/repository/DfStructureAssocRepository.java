package com.bt.ngp.common.data.jpa.repository;

import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.DfStructureAssoc;

@Repository
public interface DfStructureAssocRepository extends EquipmentStructureAssocRepository<DfStructureAssoc> {

}