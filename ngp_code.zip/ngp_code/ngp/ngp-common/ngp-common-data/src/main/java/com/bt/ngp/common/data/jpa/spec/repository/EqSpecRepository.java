package com.bt.ngp.common.data.jpa.spec.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.spec.EqSpec;
import com.bt.ngp.datasource.spec.EqSpecPK;
/**
 * This Repository handle fetch related to Equipment Specification
 * @author 609511044
 *
 */
@Repository
public interface EqSpecRepository extends JpaRepository<EqSpec,EqSpecPK>{

	@Query(name="EqSpecRepository.findEntityNameByCategoryAndType",nativeQuery=true)
	public String findEntityNameByCategoryAndType(@Param("eqSpecObj")EqSpec eqSpecObj);
	
	public EqSpec findByEqSpecPKIdName(@Param("name")String name);

}
