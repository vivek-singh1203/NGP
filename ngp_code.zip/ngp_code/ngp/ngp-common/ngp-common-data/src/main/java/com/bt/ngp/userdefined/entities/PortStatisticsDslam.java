/**
 * This file is for mapping PortStatistics for Dslam
 *
 * @since 5 Feb 2018
 * @author Aditya Ajmera 609734641
 */

package com.bt.ngp.userdefined.entities;

import com.bt.ngp.datasource.entities.Card;
import com.bt.ngp.datasource.entities.Dslam;

/**
 * @author 609734641
 *
 */
public class PortStatisticsDslam {
	private Dslam dslam;

	private Card card;

	private long portCount;

	/**
	 * default constructor
	 */
	public PortStatisticsDslam() {
		super();
	}

	/**
	 * @param dslam
	 * @param card
	 * @param portCount
	 */
	public PortStatisticsDslam(Dslam dslam, Card card, long portCount) {
		super();
		this.dslam = dslam;
		this.card = card;
		this.portCount = portCount;
	}

	/**
	 * @return the dslam
	 */
	public Dslam getDslam() {
		return dslam;
	}

	/**
	 * @param dslam the dslam to set
	 */
	public void setDslam(Dslam dslam) {
		this.dslam = dslam;
	}

	/**
	 * @return the card
	 */
	public Card getCard() {
		return card;
	}

	/**
	 * @param card the card to set
	 */
	public void setCard(Card card) {
		this.card = card;
	}

	/**
	 * @return the portCount
	 */
	public long getPortCount() {
		return portCount;
	}

	/**
	 * @param portCount the portCount to set
	 */
	public void setPortCount(long portCount) {
		this.portCount = portCount;
	}
}
