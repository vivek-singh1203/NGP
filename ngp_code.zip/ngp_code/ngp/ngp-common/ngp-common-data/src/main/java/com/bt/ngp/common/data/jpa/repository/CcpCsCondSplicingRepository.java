package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.CcpCsCondSplicing;

@Repository
public interface CcpCsCondSplicingRepository extends SqlRepository<CcpCsCondSplicing> {
	public List<CcpCsCondSplicing> findByOrigCsNameAndTermCsName(CableSection origCsName, CableSection termCsName);

	@Transactional
	@Modifying
	@Query(name = "CcpCsCondSplicingRepository.deleteCcpCableConductorSplicingByNameOfWiredEntities", nativeQuery = true)
	public int deleteCcpCableConductorSplicing(
			@Param("ccpCableConductorSplicing") CcpCsCondSplicing ccpCableConductorSplicing);

	@Query(name = "CcpCsCondSplicingRepository.findConductorSplicingOriginating")
	public List<CcpCsCondSplicing> findOriginatingConductorSplicing(
			@Param("ccpCableConductorSplicing") CcpCsCondSplicing ccpCableConductorSplicing);

	@Query(name = "CcpCsCondSplicingRepository.findConductorSplicingTerminating")
	public List<CcpCsCondSplicing> findTerminatingConductorSplicing(
			@Param("ccpCableConductorSplicing") CcpCsCondSplicing ccpCableConductorSplicing);

	public List<CcpCsCondSplicing> findByOrigParentCsName(CableSection origParentCsName);

	public List<CcpCsCondSplicing> findByTermParentCsName(CableSection termParentCsName);

	public CcpCsCondSplicing findByOrigParentCsNameAndOrigCsNameAndSplicingResource(CableSection origParentCsName,
			CableSection origCsName, String splicingResource);

	public CcpCsCondSplicing findByTermParentCsNameAndTermCsNameAndSplicingResource(CableSection termParentCsName,
			CableSection termCsName, String splicingResource);
}
