package com.bt.ngp.common.data.jpa.repository;

import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.JcPortPortAssoc;

@Repository
public interface JcPortPortAssocRepository extends SqlRepository<JcPortPortAssoc> {

}
