package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the DF_RACK_BH_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DF_RACK_BH_ASSOC")
@NamedQuery(name="DfRackBhAssoc.findAll", query="SELECT d FROM DfRackBhAssoc d")
public class DfRackBhAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="COMP_HOLDER_ASSOC_SPEC_ID", length=50)
	private String compHolderAssocSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="END_POSITION_NUM", nullable=false, precision=38)
	private BigDecimal endPositionNum;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="START_POSITION_NUM", nullable=false, precision=38)
	private BigDecimal startPositionNum;

	//bi-directional many-to-one association to DfHierarchy
	@OneToMany(mappedBy="dfRackBhAssoc")
	private List<DfHierarchy> dfHierarchies;

	//bi-directional many-to-one association to BlockHolder
	@ManyToOne
	@JoinColumn(name="BH_NAME")
	private BlockHolder blockHolder;

	//bi-directional many-to-one association to DistributionFrame
	@ManyToOne
	@JoinColumn(name="FRAME_NAME")
	private DistributionFrame distributionFrame;

	//bi-directional many-to-one association to Rack
	@ManyToOne
	@JoinColumn(name="RACK_NAME")
	private Rack rack;

	public DfRackBhAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompHolderAssocSpecId() {
		return this.compHolderAssocSpecId;
	}

	public void setCompHolderAssocSpecId(String compHolderAssocSpecId) {
		this.compHolderAssocSpecId = compHolderAssocSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public BigDecimal getEndPositionNum() {
		return this.endPositionNum;
	}

	public void setEndPositionNum(BigDecimal endPositionNum) {
		this.endPositionNum = endPositionNum;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getStartPositionNum() {
		return this.startPositionNum;
	}

	public void setStartPositionNum(BigDecimal startPositionNum) {
		this.startPositionNum = startPositionNum;
	}

	public List<DfHierarchy> getDfHierarchies() {
		return this.dfHierarchies;
	}

	public void setDfHierarchies(List<DfHierarchy> dfHierarchies) {
		this.dfHierarchies = dfHierarchies;
	}

	public DfHierarchy addDfHierarchy(DfHierarchy dfHierarchy) {
		getDfHierarchies().add(dfHierarchy);
		dfHierarchy.setDfRackBhAssoc(this);

		return dfHierarchy;
	}

	public DfHierarchy removeDfHierarchy(DfHierarchy dfHierarchy) {
		getDfHierarchies().remove(dfHierarchy);
		dfHierarchy.setDfRackBhAssoc(null);

		return dfHierarchy;
	}

	public BlockHolder getBlockHolder() {
		return this.blockHolder;
	}

	public void setBlockHolder(BlockHolder blockHolder) {
		this.blockHolder = blockHolder;
	}

	public DistributionFrame getDistributionFrame() {
		return this.distributionFrame;
	}

	public void setDistributionFrame(DistributionFrame distributionFrame) {
		this.distributionFrame = distributionFrame;
	}

	public Rack getRack() {
		return this.rack;
	}

	public void setRack(Rack rack) {
		this.rack = rack;
	}

}