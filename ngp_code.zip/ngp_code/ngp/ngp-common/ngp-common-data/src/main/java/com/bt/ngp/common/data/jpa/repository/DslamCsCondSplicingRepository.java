package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.DslamCsCondSplicing;

@Repository
public interface DslamCsCondSplicingRepository extends SqlRepository<DslamCsCondSplicing> {

	public List<DslamCsCondSplicing> findByCableSectionOrigCsNameAndCableSectionTermCsName(
			CableSection cableSectionOrigCsName, CableSection cableSectionTermCsName);

	@Transactional
	@Modifying
	@Query(name = "DslamCsCondSplicingRepository.deleteDslamCsCondSplicingByNameOfWiredEntities", nativeQuery = true)
	public int deleteDslamCsCondSplicing(@Param("dslamCsCondSplicing") DslamCsCondSplicing dslamCsCondSplicing);

	@Query(name = "DslamCsCondSplicingRepository.findConductorSplicingOriginating")
	public List<DslamCsCondSplicing> findOriginatingConductorSplicing(
			@Param("dslamCsCondSplicing") DslamCsCondSplicing dslamCsCondSplicing);

	@Query(name = "DslamCsCondSplicingRepository.findConductorSplicingTerminating")
	public List<DslamCsCondSplicing> findTerminatingConductorSplicing(
			@Param("dslamCsCondSplicing") DslamCsCondSplicing dslamCsCondSplicing);

	public List<DslamCsCondSplicing> findByCableSectionOrigParentCsName(CableSection cableSectionOrigParentCsName);

	public List<DslamCsCondSplicing> findByCableSectionTermParentCsName(CableSection cableSectionTermParentCsName);

	public DslamCsCondSplicing findByCableSectionOrigParentCsNameAndCableSectionOrigCsNameAndSplicingResource(
			CableSection cableSectionOrigParentCsName, CableSection cableSectionOrigCsName, String splicingResource);

	public DslamCsCondSplicing findByCableSectionTermParentCsNameAndCableSectionTermCsNameAndSplicingResource(
			CableSection cableSectionTermParentCsName, CableSection cableSectionTermCsName, String splicingResource);

}
