package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.vividsolutions.jts.geom.Point;


/**
 * The persistent class for the DISTRIBUTION_FRAMES database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DISTRIBUTION_FRAMES")
@NamedQuery(name="DistributionFrame.findAll", query="SELECT d FROM DistributionFrame d")
public class DistributionFrame implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="DESG_NAME", length=30)
	private String desgName;

	@Column(name="DESG_NUM", precision=38)
	private BigDecimal desgNum;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(name="FIELD_LABEL", length=30)
	private String fieldLabel;

	@Column(name = "GEO_POSITION", columnDefinition = "geometry(Point,3857)")
	private Point geoPosition;

	/**
	 * @return the geoPosition
	 */
	public Point getGeoPosition() {
		return geoPosition;
	}

	/**
	 * @param geoPosition the geoPosition to set
	 */
	public void setGeoPosition(Point geoPosition) {
		this.geoPosition = geoPosition;
	}

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to AuxComponent
	@OneToMany(mappedBy="distributionFrame")
	private List<AuxComponent> auxComponents;

	//bi-directional many-to-one association to Block
	@OneToMany(mappedBy="distributionFrame")
	private List<Block> blocks;

	//bi-directional many-to-one association to BlockHolder
	@OneToMany(mappedBy="distributionFrame")
	private List<BlockHolder> blockHolders;

	//bi-directional many-to-one association to Connector
	@OneToMany(mappedBy="distributionFrame")
	private List<Connector> connectors;

	//bi-directional many-to-one association to DfBhBlockAssoc
	@OneToMany(mappedBy="distributionFrame")
	private List<DfBhBlockAssoc> dfBhBlockAssocs;

	//bi-directional many-to-one association to DfBlockPortAssoc
	@OneToMany(mappedBy="distributionFrame")
	private List<DfBlockPortAssoc> dfBlockPortAssocs;

	//bi-directional many-to-one association to DfChar
	@OneToMany(mappedBy="distributionFrame")
	private List<DfChar> dfChars;

	//bi-directional many-to-one association to DfCsCondSplicing
	@OneToMany(mappedBy="distributionFrame")
	private List<DfCsCondSplicing> dfCsCondSplicings;

	//bi-directional many-to-one association to DfCsPortTerm
	@OneToMany(mappedBy="distributionFrame")
	private List<DfCsPortTerm> dfCsPortTerms;

	//bi-directional many-to-one association to DfHierarchy
	@OneToMany(mappedBy="distributionFrame")
	private List<DfHierarchy> dfHierarchies;

	//bi-directional many-to-one association to DfPort
	@OneToMany(mappedBy="distributionFrame")
	private List<DfPort> dfPorts;

	//bi-directional many-to-one association to DfPortChar
	@OneToMany(mappedBy="distributionFrame")
	private List<DfPortChar> dfPortChars;

	//bi-directional many-to-one association to DfPortPortAssoc
	@OneToMany(mappedBy="distributionFrame")
	private List<DfPortPortAssoc> dfPortPortAssocs;

	//bi-directional many-to-one association to DfRackBhAssoc
	@OneToMany(mappedBy="distributionFrame")
	private List<DfRackBhAssoc> dfRackBhAssocs;

	//bi-directional many-to-one association to DfStructureAssoc
	@OneToMany(mappedBy="distributionFrame")
	private List<DfStructureAssoc> dfStructureAssocs;

	//bi-directional many-to-one association to Store
	@ManyToOne
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to Exchange
	@ManyToOne
	@JoinColumn(name="EXCHANGE_1141_CODE")
	private Exchange exchange;

	//bi-directional many-to-one association to Rack
	@OneToMany(mappedBy="distributionFrame")
	private List<Rack> racks;

	public DistributionFrame() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getDesgName() {
		return this.desgName;
	}

	public void setDesgName(String desgName) {
		this.desgName = desgName;
	}

	public BigDecimal getDesgNum() {
		return this.desgNum;
	}

	public void setDesgNum(BigDecimal desgNum) {
		this.desgNum = desgNum;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getFieldLabel() {
		return this.fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<AuxComponent> getAuxComponents() {
		return this.auxComponents;
	}

	public void setAuxComponents(List<AuxComponent> auxComponents) {
		this.auxComponents = auxComponents;
	}

	public AuxComponent addAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().add(auxComponent);
		auxComponent.setDistributionFrame(this);

		return auxComponent;
	}

	public AuxComponent removeAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().remove(auxComponent);
		auxComponent.setDistributionFrame(null);

		return auxComponent;
	}

	public List<Block> getBlocks() {
		return this.blocks;
	}

	public void setBlocks(List<Block> blocks) {
		this.blocks = blocks;
	}

	public Block addBlock(Block block) {
		getBlocks().add(block);
		block.setDistributionFrame(this);

		return block;
	}

	public Block removeBlock(Block block) {
		getBlocks().remove(block);
		block.setDistributionFrame(null);

		return block;
	}

	public List<BlockHolder> getBlockHolders() {
		return this.blockHolders;
	}

	public void setBlockHolders(List<BlockHolder> blockHolders) {
		this.blockHolders = blockHolders;
	}

	public BlockHolder addBlockHolder(BlockHolder blockHolder) {
		getBlockHolders().add(blockHolder);
		blockHolder.setDistributionFrame(this);

		return blockHolder;
	}

	public BlockHolder removeBlockHolder(BlockHolder blockHolder) {
		getBlockHolders().remove(blockHolder);
		blockHolder.setDistributionFrame(null);

		return blockHolder;
	}

	public List<Connector> getConnectors() {
		return this.connectors;
	}

	public void setConnectors(List<Connector> connectors) {
		this.connectors = connectors;
	}

	public Connector addConnector(Connector connector) {
		getConnectors().add(connector);
		connector.setDistributionFrame(this);

		return connector;
	}

	public Connector removeConnector(Connector connector) {
		getConnectors().remove(connector);
		connector.setDistributionFrame(null);

		return connector;
	}

	public List<DfBhBlockAssoc> getDfBhBlockAssocs() {
		return this.dfBhBlockAssocs;
	}

	public void setDfBhBlockAssocs(List<DfBhBlockAssoc> dfBhBlockAssocs) {
		this.dfBhBlockAssocs = dfBhBlockAssocs;
	}

	public DfBhBlockAssoc addDfBhBlockAssoc(DfBhBlockAssoc dfBhBlockAssoc) {
		getDfBhBlockAssocs().add(dfBhBlockAssoc);
		dfBhBlockAssoc.setDistributionFrame(this);

		return dfBhBlockAssoc;
	}

	public DfBhBlockAssoc removeDfBhBlockAssoc(DfBhBlockAssoc dfBhBlockAssoc) {
		getDfBhBlockAssocs().remove(dfBhBlockAssoc);
		dfBhBlockAssoc.setDistributionFrame(null);

		return dfBhBlockAssoc;
	}

	public List<DfBlockPortAssoc> getDfBlockPortAssocs() {
		return this.dfBlockPortAssocs;
	}

	public void setDfBlockPortAssocs(List<DfBlockPortAssoc> dfBlockPortAssocs) {
		this.dfBlockPortAssocs = dfBlockPortAssocs;
	}

	public DfBlockPortAssoc addDfBlockPortAssoc(DfBlockPortAssoc dfBlockPortAssoc) {
		getDfBlockPortAssocs().add(dfBlockPortAssoc);
		dfBlockPortAssoc.setDistributionFrame(this);

		return dfBlockPortAssoc;
	}

	public DfBlockPortAssoc removeDfBlockPortAssoc(DfBlockPortAssoc dfBlockPortAssoc) {
		getDfBlockPortAssocs().remove(dfBlockPortAssoc);
		dfBlockPortAssoc.setDistributionFrame(null);

		return dfBlockPortAssoc;
	}

	public List<DfChar> getDfChars() {
		return this.dfChars;
	}

	public void setDfChars(List<DfChar> dfChars) {
		this.dfChars = dfChars;
	}

	public DfChar addDfChar(DfChar dfChar) {
		getDfChars().add(dfChar);
		dfChar.setDistributionFrame(this);

		return dfChar;
	}

	public DfChar removeDfChar(DfChar dfChar) {
		getDfChars().remove(dfChar);
		dfChar.setDistributionFrame(null);

		return dfChar;
	}

	public List<DfCsCondSplicing> getDfCsCondSplicings() {
		return this.dfCsCondSplicings;
	}

	public void setDfCsCondSplicings(List<DfCsCondSplicing> dfCsCondSplicings) {
		this.dfCsCondSplicings = dfCsCondSplicings;
	}

	public DfCsCondSplicing addDfCsCondSplicing(DfCsCondSplicing dfCsCondSplicing) {
		getDfCsCondSplicings().add(dfCsCondSplicing);
		dfCsCondSplicing.setDistributionFrame(this);

		return dfCsCondSplicing;
	}

	public DfCsCondSplicing removeDfCsCondSplicing(DfCsCondSplicing dfCsCondSplicing) {
		getDfCsCondSplicings().remove(dfCsCondSplicing);
		dfCsCondSplicing.setDistributionFrame(null);

		return dfCsCondSplicing;
	}

	public List<DfCsPortTerm> getDfCsPortTerms() {
		return this.dfCsPortTerms;
	}

	public void setDfCsPortTerms(List<DfCsPortTerm> dfCsPortTerms) {
		this.dfCsPortTerms = dfCsPortTerms;
	}

	public DfCsPortTerm addDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().add(dfCsPortTerm);
		dfCsPortTerm.setDistributionFrame(this);

		return dfCsPortTerm;
	}

	public DfCsPortTerm removeDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().remove(dfCsPortTerm);
		dfCsPortTerm.setDistributionFrame(null);

		return dfCsPortTerm;
	}

	public List<DfHierarchy> getDfHierarchies() {
		return this.dfHierarchies;
	}

	public void setDfHierarchies(List<DfHierarchy> dfHierarchies) {
		this.dfHierarchies = dfHierarchies;
	}

	public DfHierarchy addDfHierarchy(DfHierarchy dfHierarchy) {
		getDfHierarchies().add(dfHierarchy);
		dfHierarchy.setDistributionFrame(this);

		return dfHierarchy;
	}

	public DfHierarchy removeDfHierarchy(DfHierarchy dfHierarchy) {
		getDfHierarchies().remove(dfHierarchy);
		dfHierarchy.setDistributionFrame(null);

		return dfHierarchy;
	}

	public List<DfPort> getDfPorts() {
		return this.dfPorts;
	}

	public void setDfPorts(List<DfPort> dfPorts) {
		this.dfPorts = dfPorts;
	}

	public DfPort addDfPort(DfPort dfPort) {
		getDfPorts().add(dfPort);
		dfPort.setDistributionFrame(this);

		return dfPort;
	}

	public DfPort removeDfPort(DfPort dfPort) {
		getDfPorts().remove(dfPort);
		dfPort.setDistributionFrame(null);

		return dfPort;
	}

	public List<DfPortChar> getDfPortChars() {
		return this.dfPortChars;
	}

	public void setDfPortChars(List<DfPortChar> dfPortChars) {
		this.dfPortChars = dfPortChars;
	}

	public DfPortChar addDfPortChar(DfPortChar dfPortChar) {
		getDfPortChars().add(dfPortChar);
		dfPortChar.setDistributionFrame(this);

		return dfPortChar;
	}

	public DfPortChar removeDfPortChar(DfPortChar dfPortChar) {
		getDfPortChars().remove(dfPortChar);
		dfPortChar.setDistributionFrame(null);

		return dfPortChar;
	}

	public List<DfPortPortAssoc> getDfPortPortAssocs() {
		return this.dfPortPortAssocs;
	}

	public void setDfPortPortAssocs(List<DfPortPortAssoc> dfPortPortAssocs) {
		this.dfPortPortAssocs = dfPortPortAssocs;
	}

	public DfPortPortAssoc addDfPortPortAssoc(DfPortPortAssoc dfPortPortAssoc) {
		getDfPortPortAssocs().add(dfPortPortAssoc);
		dfPortPortAssoc.setDistributionFrame(this);

		return dfPortPortAssoc;
	}

	public DfPortPortAssoc removeDfPortPortAssoc(DfPortPortAssoc dfPortPortAssoc) {
		getDfPortPortAssocs().remove(dfPortPortAssoc);
		dfPortPortAssoc.setDistributionFrame(null);

		return dfPortPortAssoc;
	}

	public List<DfRackBhAssoc> getDfRackBhAssocs() {
		return this.dfRackBhAssocs;
	}

	public void setDfRackBhAssocs(List<DfRackBhAssoc> dfRackBhAssocs) {
		this.dfRackBhAssocs = dfRackBhAssocs;
	}

	public DfRackBhAssoc addDfRackBhAssoc(DfRackBhAssoc dfRackBhAssoc) {
		getDfRackBhAssocs().add(dfRackBhAssoc);
		dfRackBhAssoc.setDistributionFrame(this);

		return dfRackBhAssoc;
	}

	public DfRackBhAssoc removeDfRackBhAssoc(DfRackBhAssoc dfRackBhAssoc) {
		getDfRackBhAssocs().remove(dfRackBhAssoc);
		dfRackBhAssoc.setDistributionFrame(null);

		return dfRackBhAssoc;
	}

	public List<DfStructureAssoc> getDfStructureAssocs() {
		return this.dfStructureAssocs;
	}

	public void setDfStructureAssocs(List<DfStructureAssoc> dfStructureAssocs) {
		this.dfStructureAssocs = dfStructureAssocs;
	}

	public DfStructureAssoc addDfStructureAssoc(DfStructureAssoc dfStructureAssoc) {
		getDfStructureAssocs().add(dfStructureAssoc);
		dfStructureAssoc.setDistributionFrame(this);

		return dfStructureAssoc;
	}

	public DfStructureAssoc removeDfStructureAssoc(DfStructureAssoc dfStructureAssoc) {
		getDfStructureAssocs().remove(dfStructureAssoc);
		dfStructureAssoc.setDistributionFrame(null);

		return dfStructureAssoc;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public Exchange getExchange() {
		return this.exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public List<Rack> getRacks() {
		return this.racks;
	}

	public void setRacks(List<Rack> racks) {
		this.racks = racks;
	}

	public Rack addRack(Rack rack) {
		getRacks().add(rack);
		rack.setDistributionFrame(this);

		return rack;
	}

	public Rack removeRack(Rack rack) {
		getRacks().remove(rack);
		rack.setDistributionFrame(null);

		return rack;
	}

}