package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.DpCsCondSplicing;

@Repository
public interface DpCsCondSplicingRepository extends SqlRepository<DpCsCondSplicing> {

	List<DpCsCondSplicing> findByCableSectionOrigCsNameAndCableSectionTermCsName(CableSection cableSectionOrigCsName,
			CableSection cableSectionTermCsName);

	@Transactional
	@Modifying
	@Query(name = "DpCsCondSplicingRepository.deleteDpCsCondSplicingByNameOfWiredEntities", nativeQuery = true)
	public int deleteDpCsCondSplicing(@Param("dpCsCondSplicing") DpCsCondSplicing dpCsCondSplicing);

	@Query(name = "DpCsCondSplicingRepository.findConductorSplicingOriginating")
	public List<DpCsCondSplicing> findOriginatingConductorSplicing(
			@Param("dpCsCondSplicing") DpCsCondSplicing dpCsCondSplicing);

	@Query(name = "DpCsCondSplicingRepository.findConductorSplicingTerminating")
	public List<DpCsCondSplicing> findTerminatingConductorSplicing(
			@Param("dpCsCondSplicing") DpCsCondSplicing dpCsCondSplicing);

	public List<DpCsCondSplicing> findByCableSectionOrigParentCsName(CableSection cableSectionOrigParentCsName);

	public List<DpCsCondSplicing> findByCableSectionTermParentCsName(CableSection cableSectionTermParentCsName);

	public DpCsCondSplicing findByCableSectionOrigParentCsNameAndCableSectionOrigCsNameAndSplicingResource(
			CableSection cableSectionOrigParentCsName, CableSection cableSectionOrigCsName, String splicingResource);

	public DpCsCondSplicing findByCableSectionTermParentCsNameAndCableSectionTermCsNameAndSplicingResource(
			CableSection cableSectionTermParentCsName, CableSection cableSectionTermCsName, String splicingResource);

}
