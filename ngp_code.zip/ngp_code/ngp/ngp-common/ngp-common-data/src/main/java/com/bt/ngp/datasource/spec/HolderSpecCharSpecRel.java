package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the HOLDER_SPEC_CHAR_SPEC_REL database table.
 * 
 */
@javax.persistence.Entity
@Table(name="HOLDER_SPEC_CHAR_SPEC_REL")
@NamedQuery(name="HolderSpecCharSpecRel.findAll", query="SELECT h FROM HolderSpecCharSpecRel h")
public class HolderSpecCharSpecRel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CHAR_SPEC_RELATION_TYPE", length=10)
	private String charSpecRelationType;

	@Column(name="CHAR_VALUE_SPEC_RELATION_TYPE", length=10)
	private String charValueSpecRelationType;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to HolderSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="HOLDER_SPEC_NAME", referencedColumnName="NAME"),
		@JoinColumn(name="HOLDER_SPEC_VERSION", referencedColumnName="SPEC_VERSION")
		})
	private HolderSpec holderSpec;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to HolderSpecCharSpec
	@ManyToOne
	@JoinColumn(name="SOURCE_CHAR_SPEC_ID")
	private HolderSpecCharSpec holderSpecCharSpec1;

	//bi-directional many-to-one association to HolderSpecCharSpec
	@ManyToOne
	@JoinColumn(name="TARGET_CHAR_SPEC_ID")
	private HolderSpecCharSpec holderSpecCharSpec2;

	public HolderSpecCharSpecRel() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCharSpecRelationType() {
		return this.charSpecRelationType;
	}

	public void setCharSpecRelationType(String charSpecRelationType) {
		this.charSpecRelationType = charSpecRelationType;
	}

	public String getCharValueSpecRelationType() {
		return this.charValueSpecRelationType;
	}

	public void setCharValueSpecRelationType(String charValueSpecRelationType) {
		this.charValueSpecRelationType = charValueSpecRelationType;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public HolderSpec getHolderSpec() {
		return this.holderSpec;
	}

	public void setHolderSpec(HolderSpec holderSpec) {
		this.holderSpec = holderSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public HolderSpecCharSpec getHolderSpecCharSpec1() {
		return this.holderSpecCharSpec1;
	}

	public void setHolderSpecCharSpec1(HolderSpecCharSpec holderSpecCharSpec1) {
		this.holderSpecCharSpec1 = holderSpecCharSpec1;
	}

	public HolderSpecCharSpec getHolderSpecCharSpec2() {
		return this.holderSpecCharSpec2;
	}

	public void setHolderSpecCharSpec2(HolderSpecCharSpec holderSpecCharSpec2) {
		this.holderSpecCharSpec2 = holderSpecCharSpec2;
	}

}