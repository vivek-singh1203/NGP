package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the ENTITY database table.
 * 
 */
@javax.persistence.Entity
@Table(name = "ENTITY")
@NamedQuery(name = "Entity.findAll", query = "SELECT e FROM Entity e")
public class Entity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique = true, nullable = false, length = 30)
	private String name;

	@Column(name = "CREATED_BY", nullable = false, length = 40)
	private String createdBy;

	@Column(name = "CREATED_DATE", nullable = false)
	private Timestamp createdDate;

	@Column(length = 40)
	private String description;

	@Column(nullable = false, precision = 38)
	private BigDecimal id;

	@Column(name = "LAST_MODIFIED_BY", length = 40)
	private String lastModifiedBy;

	@Column(name = "LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	// bi-directional many-to-one association to CableSectionEnd
	@OneToMany(mappedBy = "origEndEntityName")
	private List<CableSectionEnd> origEndEntityName;

	// bi-directional many-to-one association to CableSectionEnd
	@OneToMany(mappedBy = "termEndEntityName")
	private List<CableSectionEnd> termEndEntityName;

	// bi-directional many-to-one association to CbSpec
	/*
	 * @OneToMany(mappedBy="entity") private List<CbSpec> cbSpecs;
	 */

	// bi-directional many-to-one association to CcpStructureAssoc
	@OneToMany(mappedBy = "entity")
	private List<CcpStructureAssoc> ccpStructureAssocs;

	// bi-directional many-to-one association to CpeStructureAssoc
	@OneToMany(mappedBy = "entity")
	private List<CpeStructureAssoc> cpeStructureAssocs;

	// bi-directional many-to-one association to DfStructureAssoc
	@OneToMany(mappedBy = "entity")
	private List<DfStructureAssoc> dfStructureAssocs;

	// bi-directional many-to-one association to DpStructureAssoc
	@OneToMany(mappedBy = "entity")
	private List<DpStructureAssoc> dpStructureAssocs;

	// bi-directional many-to-one association to DslamStructureAssoc
	@OneToMany(mappedBy = "entity")
	private List<DslamStructureAssoc> dslamStructureAssocs;

	// bi-directional many-to-one association to EntityTypeCharSet
	@OneToMany(mappedBy = "entity")
	private List<EntityTypeCharSet> entityTypeCharSets;

	// bi-directional many-to-one association to JcStructureAssoc
	@OneToMany(mappedBy = "entity")
	private List<JcStructureAssoc> jcStructureAssocs;

	// bi-directional many-to-one association to MfnStructureAssoc
	@OneToMany(mappedBy = "entity")
	private List<MfnStructureAssoc> mfnStructureAssocs;

	// bi-directional many-to-one association to NteStructureAssoc
	@OneToMany(mappedBy = "entity")
	private List<NteStructureAssoc> nteStructureAssocs;

	// bi-directional many-to-one association to WeStructureAssoc
	@OneToMany(mappedBy = "entity")
	private List<WeStructureAssoc> weStructureAssocs;

	public Entity() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getId() {
		return this.id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public List<CableSectionEnd> getOrigEndEntityName() {
		return this.origEndEntityName;
	}

	public void setOrigEndEntityName(List<CableSectionEnd> origEndEntityName) {
		this.origEndEntityName = origEndEntityName;
	}

	public CableSectionEnd addOrigEndEntityName(
			CableSectionEnd origEndEntityName) {
		getOrigEndEntityName().add(origEndEntityName);
		origEndEntityName.setOrigEndEntityName(this);

		return origEndEntityName;
	}

	public CableSectionEnd removeOrigEndEntityName(
			CableSectionEnd origEndEntityName) {
		getOrigEndEntityName().remove(origEndEntityName);
		origEndEntityName.setOrigEndEntityName(null);

		return origEndEntityName;
	}

	public List<CableSectionEnd> getTermEndEntityName() {
		return this.termEndEntityName;
	}

	public void setTermEndEntityName(List<CableSectionEnd> termEndEntityName) {
		this.termEndEntityName = termEndEntityName;
	}

	public CableSectionEnd addTermEndEntityName(
			CableSectionEnd termEndEntityName) {
		getTermEndEntityName().add(termEndEntityName);
		termEndEntityName.setTermEndEntityName(this);

		return termEndEntityName;
	}

	public CableSectionEnd removeTermEndEntityName(
			CableSectionEnd termEndEntityName) {
		getTermEndEntityName().remove(termEndEntityName);
		termEndEntityName.setTermEndEntityName(null);

		return termEndEntityName;
	}

	/*
	 * public List<CbSpec> getCbSpecs() { return this.cbSpecs; }
	 * 
	 * public void setCbSpecs(List<CbSpec> cbSpecs) { this.cbSpecs = cbSpecs; }
	 * 
	 * public CbSpec addCbSpec(CbSpec cbSpec) { getCbSpecs().add(cbSpec);
	 * cbSpec.setEntity(this);
	 * 
	 * return cbSpec; }
	 * 
	 * public CbSpec removeCbSpec(CbSpec cbSpec) { getCbSpecs().remove(cbSpec);
	 * cbSpec.setEntity(null);
	 * 
	 * return cbSpec; }
	 */

	public List<CcpStructureAssoc> getCcpStructureAssocs() {
		return this.ccpStructureAssocs;
	}

	public void setCcpStructureAssocs(
			List<CcpStructureAssoc> ccpStructureAssocs) {
		this.ccpStructureAssocs = ccpStructureAssocs;
	}

	public CcpStructureAssoc addCcpStructureAssoc(
			CcpStructureAssoc ccpStructureAssoc) {
		getCcpStructureAssocs().add(ccpStructureAssoc);
		ccpStructureAssoc.setEntity(this);

		return ccpStructureAssoc;
	}

	public CcpStructureAssoc removeCcpStructureAssoc(
			CcpStructureAssoc ccpStructureAssoc) {
		getCcpStructureAssocs().remove(ccpStructureAssoc);
		ccpStructureAssoc.setEntity(null);

		return ccpStructureAssoc;
	}

	public List<CpeStructureAssoc> getCpeStructureAssocs() {
		return this.cpeStructureAssocs;
	}

	public void setCpeStructureAssocs(
			List<CpeStructureAssoc> cpeStructureAssocs) {
		this.cpeStructureAssocs = cpeStructureAssocs;
	}

	public CpeStructureAssoc addCpeStructureAssoc(
			CpeStructureAssoc cpeStructureAssoc) {
		getCpeStructureAssocs().add(cpeStructureAssoc);
		cpeStructureAssoc.setEntity(this);

		return cpeStructureAssoc;
	}

	public CpeStructureAssoc removeCpeStructureAssoc(
			CpeStructureAssoc cpeStructureAssoc) {
		getCpeStructureAssocs().remove(cpeStructureAssoc);
		cpeStructureAssoc.setEntity(null);

		return cpeStructureAssoc;
	}

	public List<DfStructureAssoc> getDfStructureAssocs() {
		return this.dfStructureAssocs;
	}

	public void setDfStructureAssocs(List<DfStructureAssoc> dfStructureAssocs) {
		this.dfStructureAssocs = dfStructureAssocs;
	}

	public DfStructureAssoc addDfStructureAssoc(
			DfStructureAssoc dfStructureAssoc) {
		getDfStructureAssocs().add(dfStructureAssoc);
		dfStructureAssoc.setEntity(this);

		return dfStructureAssoc;
	}

	public DfStructureAssoc removeDfStructureAssoc(
			DfStructureAssoc dfStructureAssoc) {
		getDfStructureAssocs().remove(dfStructureAssoc);
		dfStructureAssoc.setEntity(null);

		return dfStructureAssoc;
	}

	public List<DpStructureAssoc> getDpStructureAssocs() {
		return this.dpStructureAssocs;
	}

	public void setDpStructureAssocs(List<DpStructureAssoc> dpStructureAssocs) {
		this.dpStructureAssocs = dpStructureAssocs;
	}

	public DpStructureAssoc addDpStructureAssoc(
			DpStructureAssoc dpStructureAssoc) {
		getDpStructureAssocs().add(dpStructureAssoc);
		dpStructureAssoc.setEntity(this);

		return dpStructureAssoc;
	}

	public DpStructureAssoc removeDpStructureAssoc(
			DpStructureAssoc dpStructureAssoc) {
		getDpStructureAssocs().remove(dpStructureAssoc);
		dpStructureAssoc.setEntity(null);

		return dpStructureAssoc;
	}

	public List<DslamStructureAssoc> getDslamStructureAssocs() {
		return this.dslamStructureAssocs;
	}

	public void setDslamStructureAssocs(
			List<DslamStructureAssoc> dslamStructureAssocs) {
		this.dslamStructureAssocs = dslamStructureAssocs;
	}

	public DslamStructureAssoc addDslamStructureAssoc(
			DslamStructureAssoc dslamStructureAssoc) {
		getDslamStructureAssocs().add(dslamStructureAssoc);
		dslamStructureAssoc.setEntity(this);

		return dslamStructureAssoc;
	}

	public DslamStructureAssoc removeDslamStructureAssoc(
			DslamStructureAssoc dslamStructureAssoc) {
		getDslamStructureAssocs().remove(dslamStructureAssoc);
		dslamStructureAssoc.setEntity(null);

		return dslamStructureAssoc;
	}

	public List<EntityTypeCharSet> getEntityTypeCharSets() {
		return this.entityTypeCharSets;
	}

	public void setEntityTypeCharSets(
			List<EntityTypeCharSet> entityTypeCharSets) {
		this.entityTypeCharSets = entityTypeCharSets;
	}

	public EntityTypeCharSet addEntityTypeCharSet(
			EntityTypeCharSet entityTypeCharSet) {
		getEntityTypeCharSets().add(entityTypeCharSet);
		entityTypeCharSet.setEntity(this);

		return entityTypeCharSet;
	}

	public EntityTypeCharSet removeEntityTypeCharSet(
			EntityTypeCharSet entityTypeCharSet) {
		getEntityTypeCharSets().remove(entityTypeCharSet);
		entityTypeCharSet.setEntity(null);

		return entityTypeCharSet;
	}

	public List<JcStructureAssoc> getJcStructureAssocs() {
		return this.jcStructureAssocs;
	}

	public void setJcStructureAssocs(List<JcStructureAssoc> jcStructureAssocs) {
		this.jcStructureAssocs = jcStructureAssocs;
	}

	public JcStructureAssoc addJcStructureAssoc(
			JcStructureAssoc jcStructureAssoc) {
		getJcStructureAssocs().add(jcStructureAssoc);
		jcStructureAssoc.setEntity(this);

		return jcStructureAssoc;
	}

	public JcStructureAssoc removeJcStructureAssoc(
			JcStructureAssoc jcStructureAssoc) {
		getJcStructureAssocs().remove(jcStructureAssoc);
		jcStructureAssoc.setEntity(null);

		return jcStructureAssoc;
	}

	public List<MfnStructureAssoc> getMfnStructureAssocs() {
		return this.mfnStructureAssocs;
	}

	public void setMfnStructureAssocs(
			List<MfnStructureAssoc> mfnStructureAssocs) {
		this.mfnStructureAssocs = mfnStructureAssocs;
	}

	public MfnStructureAssoc addMfnStructureAssoc(
			MfnStructureAssoc mfnStructureAssoc) {
		getMfnStructureAssocs().add(mfnStructureAssoc);
		mfnStructureAssoc.setEntity(this);

		return mfnStructureAssoc;
	}

	public MfnStructureAssoc removeMfnStructureAssoc(
			MfnStructureAssoc mfnStructureAssoc) {
		getMfnStructureAssocs().remove(mfnStructureAssoc);
		mfnStructureAssoc.setEntity(null);

		return mfnStructureAssoc;
	}

	public List<NteStructureAssoc> getNteStructureAssocs() {
		return this.nteStructureAssocs;
	}

	public void setNteStructureAssocs(
			List<NteStructureAssoc> nteStructureAssocs) {
		this.nteStructureAssocs = nteStructureAssocs;
	}

	public NteStructureAssoc addNteStructureAssoc(
			NteStructureAssoc nteStructureAssoc) {
		getNteStructureAssocs().add(nteStructureAssoc);
		nteStructureAssoc.setEntity(this);

		return nteStructureAssoc;
	}

	public NteStructureAssoc removeNteStructureAssoc(
			NteStructureAssoc nteStructureAssoc) {
		getNteStructureAssocs().remove(nteStructureAssoc);
		nteStructureAssoc.setEntity(null);

		return nteStructureAssoc;
	}

	public List<WeStructureAssoc> getWeStructureAssocs() {
		return this.weStructureAssocs;
	}

	public void setWeStructureAssocs(List<WeStructureAssoc> weStructureAssocs) {
		this.weStructureAssocs = weStructureAssocs;
	}

	public WeStructureAssoc addWeStructureAssoc(
			WeStructureAssoc weStructureAssoc) {
		getWeStructureAssocs().add(weStructureAssoc);
		weStructureAssoc.setEntity(this);

		return weStructureAssoc;
	}

	public WeStructureAssoc removeWeStructureAssoc(
			WeStructureAssoc weStructureAssoc) {
		getWeStructureAssocs().remove(weStructureAssoc);
		weStructureAssoc.setEntity(null);

		return weStructureAssoc;
	}

}
