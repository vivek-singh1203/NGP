package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the MFN_PORTS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="MFN_PORTS")
@NamedQuery(name="MfnPort.findAll", query="SELECT m FROM MfnPort m")
public class MfnPort implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal portSeqNum;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to MfnCsPortTerm
	@OneToMany(mappedBy="mfnPort")
	private List<MfnCsPortTerm> mfnCsPortTerms;

	//bi-directional many-to-one association to MfnPluginPortAssoc
	@OneToMany(mappedBy="mfnPort")
	private List<MfnPluginPortAssoc> mfnPluginPortAssocs;

	//bi-directional many-to-one association to MultiFunctionalNode
	@ManyToOne
	@JoinColumn(name="MFN_NAME")
	private MultiFunctionalNode multiFunctionalNode;

	//bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	//bi-directional many-to-one association to MfnPortChar
	@OneToMany(mappedBy="mfnPort")
	private List<MfnPortChar> mfnPortChars;

	//bi-directional many-to-one association to MfnPortPortAssoc
	@OneToMany(mappedBy="mfnPort1")
	private List<MfnPortPortAssoc> mfnPortPortAssocs1;

	//bi-directional many-to-one association to MfnPortPortAssoc
	@OneToMany(mappedBy="mfnPort2")
	private List<MfnPortPortAssoc> mfnPortPortAssocs2;

	public MfnPort() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortSeqNum() {
		return this.portSeqNum;
	}

	public void setPortSeqNum(BigDecimal portSeqNum) {
		this.portSeqNum = portSeqNum;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<MfnCsPortTerm> getMfnCsPortTerms() {
		return this.mfnCsPortTerms;
	}

	public void setMfnCsPortTerms(List<MfnCsPortTerm> mfnCsPortTerms) {
		this.mfnCsPortTerms = mfnCsPortTerms;
	}

	public MfnCsPortTerm addMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		getMfnCsPortTerms().add(mfnCsPortTerm);
		mfnCsPortTerm.setMfnPort(this);

		return mfnCsPortTerm;
	}

	public MfnCsPortTerm removeMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		getMfnCsPortTerms().remove(mfnCsPortTerm);
		mfnCsPortTerm.setMfnPort(null);

		return mfnCsPortTerm;
	}

	public List<MfnPluginPortAssoc> getMfnPluginPortAssocs() {
		return this.mfnPluginPortAssocs;
	}

	public void setMfnPluginPortAssocs(List<MfnPluginPortAssoc> mfnPluginPortAssocs) {
		this.mfnPluginPortAssocs = mfnPluginPortAssocs;
	}

	public MfnPluginPortAssoc addMfnPluginPortAssoc(MfnPluginPortAssoc mfnPluginPortAssoc) {
		getMfnPluginPortAssocs().add(mfnPluginPortAssoc);
		mfnPluginPortAssoc.setMfnPort(this);

		return mfnPluginPortAssoc;
	}

	public MfnPluginPortAssoc removeMfnPluginPortAssoc(MfnPluginPortAssoc mfnPluginPortAssoc) {
		getMfnPluginPortAssocs().remove(mfnPluginPortAssoc);
		mfnPluginPortAssoc.setMfnPort(null);

		return mfnPluginPortAssoc;
	}

	public MultiFunctionalNode getMultiFunctionalNode() {
		return this.multiFunctionalNode;
	}

	public void setMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		this.multiFunctionalNode = multiFunctionalNode;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

	public List<MfnPortChar> getMfnPortChars() {
		return this.mfnPortChars;
	}

	public void setMfnPortChars(List<MfnPortChar> mfnPortChars) {
		this.mfnPortChars = mfnPortChars;
	}

	public MfnPortChar addMfnPortChar(MfnPortChar mfnPortChar) {
		getMfnPortChars().add(mfnPortChar);
		mfnPortChar.setMfnPort(this);

		return mfnPortChar;
	}

	public MfnPortChar removeMfnPortChar(MfnPortChar mfnPortChar) {
		getMfnPortChars().remove(mfnPortChar);
		mfnPortChar.setMfnPort(null);

		return mfnPortChar;
	}

	public List<MfnPortPortAssoc> getMfnPortPortAssocs1() {
		return this.mfnPortPortAssocs1;
	}

	public void setMfnPortPortAssocs1(List<MfnPortPortAssoc> mfnPortPortAssocs1) {
		this.mfnPortPortAssocs1 = mfnPortPortAssocs1;
	}

	public MfnPortPortAssoc addMfnPortPortAssocs1(MfnPortPortAssoc mfnPortPortAssocs1) {
		getMfnPortPortAssocs1().add(mfnPortPortAssocs1);
		mfnPortPortAssocs1.setMfnPort1(this);

		return mfnPortPortAssocs1;
	}

	public MfnPortPortAssoc removeMfnPortPortAssocs1(MfnPortPortAssoc mfnPortPortAssocs1) {
		getMfnPortPortAssocs1().remove(mfnPortPortAssocs1);
		mfnPortPortAssocs1.setMfnPort1(null);

		return mfnPortPortAssocs1;
	}

	public List<MfnPortPortAssoc> getMfnPortPortAssocs2() {
		return this.mfnPortPortAssocs2;
	}

	public void setMfnPortPortAssocs2(List<MfnPortPortAssoc> mfnPortPortAssocs2) {
		this.mfnPortPortAssocs2 = mfnPortPortAssocs2;
	}

	public MfnPortPortAssoc addMfnPortPortAssocs2(MfnPortPortAssoc mfnPortPortAssocs2) {
		getMfnPortPortAssocs2().add(mfnPortPortAssocs2);
		mfnPortPortAssocs2.setMfnPort2(this);

		return mfnPortPortAssocs2;
	}

	public MfnPortPortAssoc removeMfnPortPortAssocs2(MfnPortPortAssoc mfnPortPortAssocs2) {
		getMfnPortPortAssocs2().remove(mfnPortPortAssocs2);
		mfnPortPortAssocs2.setMfnPort2(null);

		return mfnPortPortAssocs2;
	}

}