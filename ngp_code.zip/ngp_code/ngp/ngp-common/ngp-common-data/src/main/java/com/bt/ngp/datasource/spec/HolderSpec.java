package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the HOLDER_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="HOLDER_SPEC")
@NamedQuery(name="HolderSpec.findAll", query="SELECT h FROM HolderSpec h")
public class HolderSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private HolderSpecPK holderSpecPKId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DEPTH", precision=126)
	private double depth;

	@Column(name="DEPTH_UNIT", length=10)
	private String depthUnit;

	@Column(precision=126)
	private double diameter;

	@Column(name="DIAMETER_UNIT", length=10)
	private String diameterUnit;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(precision=126)
	private double height;

	@Column(name="HEIGHT_UNIT", length=10)
	private String heightUnit;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="IS_ORDERABLE")
	private String isOrderable;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LENGTH", precision=126)
	private double length;

	@Column(name="LENGTH_UNIT", length=10)
	private String lengthUnit;

	@Column(name="MANUFACTURER_NAME", length=30)
	private String manufacturerName;

	@Column(name="POSITION_TO_OCCUPY", precision=38)
	private String positionToOccupy;

	@Column(name="SPEC_REMARKS", length=50)
	private String specRemarks;

	@Column(name="SPEC_STATUS", nullable=false, length=10)
	private String specStatus;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	@Column(precision=126)
	private double volume;

	@Column(name="VOLUME_UNIT", length=10)
	private String volumeUnit;

	@Column(precision=126)
	private double weight;

	@Column(name="WEIGHT_UNIT", length=10)
	private String weightUnit;

	@Column(precision=126)
	private double width;

	@Column(name="WIDTH_UNIT", length=10)
	private String widthUnit;

	//bi-directional many-to-one association to DeviceCompHolderAssocSpec
	@OneToMany(mappedBy="holderSpec")
	private List<DeviceCompHolderAssocSpec> deviceCompHolderAssocSpecs;

	//bi-directional many-to-one association to DeviceHolderCompAssocSpec
	@OneToMany(mappedBy="holderSpec")
	private List<DeviceHolderCompAssocSpec> deviceHolderCompAssocSpecs;

	//bi-directional many-to-one association to EqCompHolderAssocSpec
	@OneToMany(mappedBy="holderSpec")
	private List<EqCompHolderAssocSpec> eqCompHolderAssocSpecs;

	//bi-directional many-to-one association to EqHolderCompAssocSpec
	@OneToMany(mappedBy="holderSpec")
	private List<EqHolderCompAssocSpec> eqHolderCompAssocSpecs;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to HolderSpecCharSpec
	@OneToMany(mappedBy="holderSpec")
	private List<HolderSpecCharSpec> holderSpecCharSpecs;

	//bi-directional many-to-one association to HolderSpecCharSpecRel
	@OneToMany(mappedBy="holderSpec")
	private List<HolderSpecCharSpecRel> holderSpecCharSpecRels;

	//bi-directional many-to-one association to HolderSpecCharValueSpec
	@OneToMany(mappedBy="holderSpec")
	private List<HolderSpecCharValueSpec> holderSpecCharValueSpecs;

	public HolderSpec() {
	}

	public HolderSpecPK getHolderSpecPKId() {
		return this.holderSpecPKId;
	}

	public void setId(HolderSpecPK holderSpecPKId) {
		this.holderSpecPKId = holderSpecPKId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public double getDepth() {
		return this.depth;
	}

	public void setDepth(double depth) {
		this.depth = depth;
	}

	public String getDepthUnit() {
		return this.depthUnit;
	}

	public void setDepthUnit(String depthUnit) {
		this.depthUnit = depthUnit;
	}

	public double getDiameter() {
		return this.diameter;
	}

	public void setDiameter(double diameter) {
		this.diameter = diameter;
	}

	public String getDiameterUnit() {
		return this.diameterUnit;
	}

	public void setDiameterUnit(String diameterUnit) {
		this.diameterUnit = diameterUnit;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public double getHeight() {
		return this.height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public String getHeightUnit() {
		return this.heightUnit;
	}

	public void setHeightUnit(String heightUnit) {
		this.heightUnit = heightUnit;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIsOrderable() {
		return this.isOrderable;
	}

	public void setIsOrderable(String isOrderable) {
		this.isOrderable = isOrderable;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public double getLength() {
		return this.length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public String getLengthUnit() {
		return this.lengthUnit;
	}

	public void setLengthUnit(String lengthUnit) {
		this.lengthUnit = lengthUnit;
	}

	public String getManufacturerName() {
		return this.manufacturerName;
	}

	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}

	public String getPositionToOccupy() {
		return this.positionToOccupy;
	}

	public void setPositionToOccupy(String positionToOccupy) {
		this.positionToOccupy = positionToOccupy;
	}

	public String getSpecRemarks() {
		return this.specRemarks;
	}

	public void setSpecRemarks(String specRemarks) {
		this.specRemarks = specRemarks;
	}

	public String getSpecStatus() {
		return this.specStatus;
	}

	public void setSpecStatus(String specStatus) {
		this.specStatus = specStatus;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public double getVolume() {
		return this.volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public String getVolumeUnit() {
		return this.volumeUnit;
	}

	public void setVolumeUnit(String volumeUnit) {
		this.volumeUnit = volumeUnit;
	}

	public double getWeight() {
		return this.weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getWeightUnit() {
		return this.weightUnit;
	}

	public void setWeightUnit(String weightUnit) {
		this.weightUnit = weightUnit;
	}

	public double getWidth() {
		return this.width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public String getWidthUnit() {
		return this.widthUnit;
	}

	public void setWidthUnit(String widthUnit) {
		this.widthUnit = widthUnit;
	}

	public List<DeviceCompHolderAssocSpec> getDeviceCompHolderAssocSpecs() {
		return this.deviceCompHolderAssocSpecs;
	}

	public void setDeviceCompHolderAssocSpecs(List<DeviceCompHolderAssocSpec> deviceCompHolderAssocSpecs) {
		this.deviceCompHolderAssocSpecs = deviceCompHolderAssocSpecs;
	}

	public DeviceCompHolderAssocSpec addDeviceCompHolderAssocSpec(DeviceCompHolderAssocSpec deviceCompHolderAssocSpec) {
		getDeviceCompHolderAssocSpecs().add(deviceCompHolderAssocSpec);
		deviceCompHolderAssocSpec.setHolderSpec(this);

		return deviceCompHolderAssocSpec;
	}

	public DeviceCompHolderAssocSpec removeDeviceCompHolderAssocSpec(DeviceCompHolderAssocSpec deviceCompHolderAssocSpec) {
		getDeviceCompHolderAssocSpecs().remove(deviceCompHolderAssocSpec);
		deviceCompHolderAssocSpec.setHolderSpec(null);

		return deviceCompHolderAssocSpec;
	}

	public List<DeviceHolderCompAssocSpec> getDeviceHolderCompAssocSpecs() {
		return this.deviceHolderCompAssocSpecs;
	}

	public void setDeviceHolderCompAssocSpecs(List<DeviceHolderCompAssocSpec> deviceHolderCompAssocSpecs) {
		this.deviceHolderCompAssocSpecs = deviceHolderCompAssocSpecs;
	}

	public DeviceHolderCompAssocSpec addDeviceHolderCompAssocSpec(DeviceHolderCompAssocSpec deviceHolderCompAssocSpec) {
		getDeviceHolderCompAssocSpecs().add(deviceHolderCompAssocSpec);
		deviceHolderCompAssocSpec.setHolderSpec(this);

		return deviceHolderCompAssocSpec;
	}

	public DeviceHolderCompAssocSpec removeDeviceHolderCompAssocSpec(DeviceHolderCompAssocSpec deviceHolderCompAssocSpec) {
		getDeviceHolderCompAssocSpecs().remove(deviceHolderCompAssocSpec);
		deviceHolderCompAssocSpec.setHolderSpec(null);

		return deviceHolderCompAssocSpec;
	}

	public List<EqCompHolderAssocSpec> getEqCompHolderAssocSpecs() {
		return this.eqCompHolderAssocSpecs;
	}

	public void setEqCompHolderAssocSpecs(List<EqCompHolderAssocSpec> eqCompHolderAssocSpecs) {
		this.eqCompHolderAssocSpecs = eqCompHolderAssocSpecs;
	}

	public EqCompHolderAssocSpec addEqCompHolderAssocSpec(EqCompHolderAssocSpec eqCompHolderAssocSpec) {
		getEqCompHolderAssocSpecs().add(eqCompHolderAssocSpec);
		eqCompHolderAssocSpec.setHolderSpec(this);

		return eqCompHolderAssocSpec;
	}

	public EqCompHolderAssocSpec removeEqCompHolderAssocSpec(EqCompHolderAssocSpec eqCompHolderAssocSpec) {
		getEqCompHolderAssocSpecs().remove(eqCompHolderAssocSpec);
		eqCompHolderAssocSpec.setHolderSpec(null);

		return eqCompHolderAssocSpec;
	}

	public List<EqHolderCompAssocSpec> getEqHolderCompAssocSpecs() {
		return this.eqHolderCompAssocSpecs;
	}

	public void setEqHolderCompAssocSpecs(List<EqHolderCompAssocSpec> eqHolderCompAssocSpecs) {
		this.eqHolderCompAssocSpecs = eqHolderCompAssocSpecs;
	}

	public EqHolderCompAssocSpec addEqHolderCompAssocSpec(EqHolderCompAssocSpec eqHolderCompAssocSpec) {
		getEqHolderCompAssocSpecs().add(eqHolderCompAssocSpec);
		eqHolderCompAssocSpec.setHolderSpec(this);

		return eqHolderCompAssocSpec;
	}

	public EqHolderCompAssocSpec removeEqHolderCompAssocSpec(EqHolderCompAssocSpec eqHolderCompAssocSpec) {
		getEqHolderCompAssocSpecs().remove(eqHolderCompAssocSpec);
		eqHolderCompAssocSpec.setHolderSpec(null);

		return eqHolderCompAssocSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public List<HolderSpecCharSpec> getHolderSpecCharSpecs() {
		return this.holderSpecCharSpecs;
	}

	public void setHolderSpecCharSpecs(List<HolderSpecCharSpec> holderSpecCharSpecs) {
		this.holderSpecCharSpecs = holderSpecCharSpecs;
	}

	public HolderSpecCharSpec addHolderSpecCharSpec(HolderSpecCharSpec holderSpecCharSpec) {
		getHolderSpecCharSpecs().add(holderSpecCharSpec);
		holderSpecCharSpec.setHolderSpec(this);

		return holderSpecCharSpec;
	}

	public HolderSpecCharSpec removeHolderSpecCharSpec(HolderSpecCharSpec holderSpecCharSpec) {
		getHolderSpecCharSpecs().remove(holderSpecCharSpec);
		holderSpecCharSpec.setHolderSpec(null);

		return holderSpecCharSpec;
	}

	public List<HolderSpecCharSpecRel> getHolderSpecCharSpecRels() {
		return this.holderSpecCharSpecRels;
	}

	public void setHolderSpecCharSpecRels(List<HolderSpecCharSpecRel> holderSpecCharSpecRels) {
		this.holderSpecCharSpecRels = holderSpecCharSpecRels;
	}

	public HolderSpecCharSpecRel addHolderSpecCharSpecRel(HolderSpecCharSpecRel holderSpecCharSpecRel) {
		getHolderSpecCharSpecRels().add(holderSpecCharSpecRel);
		holderSpecCharSpecRel.setHolderSpec(this);

		return holderSpecCharSpecRel;
	}

	public HolderSpecCharSpecRel removeHolderSpecCharSpecRel(HolderSpecCharSpecRel holderSpecCharSpecRel) {
		getHolderSpecCharSpecRels().remove(holderSpecCharSpecRel);
		holderSpecCharSpecRel.setHolderSpec(null);

		return holderSpecCharSpecRel;
	}

	public List<HolderSpecCharValueSpec> getHolderSpecCharValueSpecs() {
		return this.holderSpecCharValueSpecs;
	}

	public void setHolderSpecCharValueSpecs(List<HolderSpecCharValueSpec> holderSpecCharValueSpecs) {
		this.holderSpecCharValueSpecs = holderSpecCharValueSpecs;
	}

	public HolderSpecCharValueSpec addHolderSpecCharValueSpec(HolderSpecCharValueSpec holderSpecCharValueSpec) {
		getHolderSpecCharValueSpecs().add(holderSpecCharValueSpec);
		holderSpecCharValueSpec.setHolderSpec(this);

		return holderSpecCharValueSpec;
	}

	public HolderSpecCharValueSpec removeHolderSpecCharValueSpec(HolderSpecCharValueSpec holderSpecCharValueSpec) {
		getHolderSpecCharValueSpecs().remove(holderSpecCharValueSpec);
		holderSpecCharValueSpec.setHolderSpec(null);

		return holderSpecCharValueSpec;
	}

}