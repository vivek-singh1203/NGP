/**
 * This file is for mapping PortStatistics for Distribution Frame.
 *
 * @since 5 Feb 2018
 * @author Aditya Ajmera 609734641
 */

package com.bt.ngp.userdefined.entities;

import com.bt.ngp.datasource.entities.Block;
import com.bt.ngp.datasource.entities.DistributionFrame;

/**
 * @author 609734641
 *
 */
public class PortStatisticsDf {
	private DistributionFrame distributionFrame;

	private Block block;

	private long portCount;

	/**
	 * distribution frame default constructor
	 */
	public PortStatisticsDf() {
		super();
	}

	/**
	 * @param distributionFrame
	 * @param block
	 * @param portCount
	 */
	public PortStatisticsDf(DistributionFrame distributionFrame, Block block,
			long portCount) {
		super();
		this.distributionFrame = distributionFrame;
		this.block = block;
		this.portCount = portCount;
	}

	/**
	 * @return the distributionFrame
	 */
	public DistributionFrame getDistributionFrame() {
		return distributionFrame;
	}

	/**
	 * @param distributionFrame the distributionFrame to set
	 */
	public void setDistributionFrame(DistributionFrame distributionFrame) {
		this.distributionFrame = distributionFrame;
	}

	/**
	 * @return the block
	 */
	public Block getBlock() {
		return block;
	}

	/**
	 * @param block the block to set
	 */
	public void setBlock(Block block) {
		this.block = block;
	}

	/**
	 * @return the portCount
	 */
	public long getPortCount() {
		return portCount;
	}

	/**
	 * @param portCount the portCount to set
	 */
	public void setPortCount(long portCount) {
		this.portCount = portCount;
	}
}
