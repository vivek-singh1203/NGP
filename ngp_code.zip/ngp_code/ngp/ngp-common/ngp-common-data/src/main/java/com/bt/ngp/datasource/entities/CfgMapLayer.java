package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the CFG_MAP_LAYER database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CFG_MAP_LAYER")
@NamedQuery(name="CfgMapLayer.findAll", query="SELECT c FROM CfgMapLayer c order by LPAD(POSITION, 10)")
public class CfgMapLayer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="CQL_FILTER")
	private String cqlFilter;

	@Temporal(TemporalType.DATE)
	@Column(name="CREATED_DATE")
	private Date createdDate;

	@Column(name="DEFAULT_LOAD")
	private String defaultLoad;

	private String description;

	@Column(name="DISPLAY_IND")
	private String displayInd;

	@Column(name="DISPLAY_NAME")
	private String displayName;

	@Column(name="GROUP_NAME")
	private String groupName;

	
	@Column(unique=true, nullable=false, length=25)
	private String id;

	@Column(name="IS_GROUP")
	private String isGroup;

	@Column(name="IS_RANGE")
	private String isRange;

	@Temporal(TemporalType.DATE)
	@Column(name="LAST_UPDATED_DATE")
	private Date lastUpdatedDate;

	@Id
	@Column(name="LAYER_NAME", unique=true, nullable=false, length=25)
	private String layerName;

	@Column(name="LAYER_TYPE")
	private String layerType;

	@Column(name="LAYERLABELSTYLING")
	private String layerlabelstyling;

	@Column(name="LAYERVISIBILITY")
	private String layervisibility;

	@Lob
	@Column(name="LEGEND_ICON")
	private byte[] legendIcon;

	@Column(name="MAX_VALUE")
	private String maxValue;

	@Column(name="MAXRESOLUTION")
	private String maxresolution;

	@Column(name="MIN_VALUE")
	private String minValue;

	@Column(name="MINRESOLUTION")
	private String minresolution;

	@Column(name="OLS_GROUP")
	private String olsGroup;

	@Column(name="POSITION")
	private String position;

	@Column(name="PRIMARY_DISPLAY_FIELD")
	private String primaryDisplayField;

	@Column(name="PROP_NAME")
	private String propName;

	@Column(name="ROLE")
	private String role;

	@Column(name="SEQUENCE_NUMBER")
	private BigDecimal sequenceNumber;

	@Column(name="SERVER_TYPE")
	private String serverType;

	@Column(name="SLD_FILE_NAME")
	private String sldFileName;

	private String style;

	@Column(name="TABLE_NAME")
	private String tableName;

	private String transparency;

	private String url;

	public CfgMapLayer() {
	}

	public String getCqlFilter() {
		return this.cqlFilter;
	}

	public void setCqlFilter(String cqlFilter) {
		this.cqlFilter = cqlFilter;
	}

	public Date getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getDefaultLoad() {
		return this.defaultLoad;
	}

	public void setDefaultLoad(String defaultLoad) {
		this.defaultLoad = defaultLoad;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDisplayInd() {
		return this.displayInd;
	}

	public void setDisplayInd(String displayInd) {
		this.displayInd = displayInd;
	}

	public String getDisplayName() {
		return this.displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getGroupName() {
		return this.groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIsGroup() {
		return this.isGroup;
	}

	public void setIsGroup(String isGroup) {
		this.isGroup = isGroup;
	}

	public String getIsRange() {
		return this.isRange;
	}

	public void setIsRange(String isRange) {
		this.isRange = isRange;
	}

	public Date getLastUpdatedDate() {
		return this.lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getLayerName() {
		return this.layerName;
	}

	public void setLayerName(String layerName) {
		this.layerName = layerName;
	}

	public String getLayerType() {
		return this.layerType;
	}

	public void setLayerType(String layerType) {
		this.layerType = layerType;
	}

	public String getLayerlabelstyling() {
		return this.layerlabelstyling;
	}

	public void setLayerlabelstyling(String layerlabelstyling) {
		this.layerlabelstyling = layerlabelstyling;
	}

	public String getLayervisibility() {
		return this.layervisibility;
	}

	public void setLayervisibility(String layervisibility) {
		this.layervisibility = layervisibility;
	}

	public byte[] getLegendIcon() {
		return this.legendIcon;
	}

	public void setLegendIcon(byte[] legendIcon) {
		this.legendIcon = legendIcon;
	}

	public String getMaxValue() {
		return this.maxValue;
	}

	public void setMaxValue(String maxValue) {
		this.maxValue = maxValue;
	}

	public String getMaxresolution() {
		return this.maxresolution;
	}

	public void setMaxresolution(String maxresolution) {
		this.maxresolution = maxresolution;
	}

	public String getMinValue() {
		return this.minValue;
	}

	public void setMinValue(String minValue) {
		this.minValue = minValue;
	}

	public String getMinresolution() {
		return this.minresolution;
	}

	public void setMinresolution(String minresolution) {
		this.minresolution = minresolution;
	}

	public String getOlsGroup() {
		return this.olsGroup;
	}

	public void setOlsGroup(String olsGroup) {
		this.olsGroup = olsGroup;
	}

	public String getPosition() {
		return this.position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getPrimaryDisplayField() {
		return this.primaryDisplayField;
	}

	public void setPrimaryDisplayField(String primaryDisplayField) {
		this.primaryDisplayField = primaryDisplayField;
	}

	public String getPropName() {
		return this.propName;
	}

	public void setPropName(String propName) {
		this.propName = propName;
	}

	public String getRole() {
		return this.role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public BigDecimal getSequenceNumber() {
		return this.sequenceNumber;
	}

	public void setSequenceNumber(BigDecimal sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getServerType() {
		return this.serverType;
	}

	public void setServerType(String serverType) {
		this.serverType = serverType;
	}

	public String getSldFileName() {
		return this.sldFileName;
	}

	public void setSldFileName(String sldFileName) {
		this.sldFileName = sldFileName;
	}

	public String getStyle() {
		return this.style;
	}

	public void setStyle(String style) {
		this.style = style;
	}

	public String getTableName() {
		return this.tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getTransparency() {
		return this.transparency;
	}

	public void setTransparency(String transparency) {
		this.transparency = transparency;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}