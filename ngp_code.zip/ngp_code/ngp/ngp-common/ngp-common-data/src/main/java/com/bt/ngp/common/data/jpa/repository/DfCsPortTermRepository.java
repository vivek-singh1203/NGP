package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.Block;
import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.Conductor;
import com.bt.ngp.datasource.entities.ConductorBundle;
import com.bt.ngp.datasource.entities.DfCsPortTerm;
import com.bt.ngp.datasource.entities.DfPort;
import com.bt.ngp.datasource.entities.DistributionFrame;
import com.bt.ngp.datasource.entities.Rack;

@Repository
public interface DfCsPortTermRepository extends SqlRepository<DfCsPortTerm> {

	public DfCsPortTerm findByDistributionFrameAndRackAndBlockAndDfPortAndCableSectionAndConductorBundleAndConductor(
			DistributionFrame distributionFrame, Rack rack, Block block, DfPort dfPort, CableSection cableSection,
			ConductorBundle conductorBundle, Conductor conductor);

	@Query(name = "DfCsPortTermRepository.findDfCsPortTerm", nativeQuery = true)
	List<DfCsPortTerm> findDfCsPortTerm(@Param("termObj") DfCsPortTerm termObj);

	@Query(name = "DfCsPortTermRepository.fetchViaDfCsCbCond", nativeQuery = true)
	public DfCsPortTerm fetchDfCsPortTerm(@Param("dfCsPortTerm") DfCsPortTerm dfCsPortTerm);

	List<DfCsPortTerm> findByDistributionFrame(@Param("distributionFrame") DistributionFrame distributionFrame);

	@Query(name = "DfCsPortTermRepository.findByConductorAndTerminationType")
	List<DfCsPortTerm> findByConductorAndTerminationType(@Param("dfCsPortTermObj") DfCsPortTerm dfCsPortTermObj);

	@Query(name = "DfCsPortTermRepository.findByCableSectionAndPort")
	List<DfCsPortTerm> findByCableSectionAndPort(@Param("dfCsPortTermObj") DfCsPortTerm dfCsPortTermObj);

	@Query(name = "DfCsPortTermRepository.findByDfCableAndConductor")
	List<DfCsPortTerm> findByDfCableAndConductor(@Param("dfCsPortTerm") DfCsPortTerm dfCsPortTerm);
}
