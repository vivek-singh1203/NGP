package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the NTE_PORT_PORT_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name = "NTE_PORT_PORT_ASSOC")
@NamedQuery(name = "NtePortPortAssoc.findAll", query = "SELECT n FROM NtePortPortAssoc n")
public class NtePortPortAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique = true, nullable = false, length = 50)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SeqGen")
	@SequenceGenerator(name = "SeqGen", sequenceName = "NTE_PORT_PORT_ASSOC_SEQ", allocationSize = 1)
	private long id;

	@Column(name = "CREATED_BY", nullable = false, length = 40)
	private String createdBy;

	@Column(name = "CREATED_DATE", nullable = false)
	private Timestamp createdDate;

	@Column(name = "EQ_P2P_ASPEC_ID", length = 50)
	private String eqP2pAspecId;

	@Column(name = "LAST_MODIFIED_BY", length = 40)
	private String lastModifiedBy;

	@Column(name = "LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name = "SOURCE_PORT_SEQ_NO", nullable = false, precision = 38)
	private BigDecimal sourcePortSeqNo;

	@Column(name = "TARGET_PORT_SEQ_NO", nullable = false, precision = 38)
	private BigDecimal targetPortSeqNo;

	// bi-directional many-to-one association to NetworkTerminatingEquipment
	@ManyToOne
	@JoinColumn(name = "NTE_NAME")
	private NetworkTerminatingEquipment networkTerminatingEquipment;

	// bi-directional many-to-one association to Chassi
	@ManyToOne
	@JoinColumn(name = "SOURCE_CHASSIS_NAME")
	private Chassi chassi1;

	// bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name = "SOURCE_PLUGIN_NAME")
	private Plugin plugin1;

	// bi-directional many-to-one association to NtePort
	@ManyToOne
	@JoinColumn(name = "SOURCE_PORT_NAME")
	private NtePort ntePort1;

	// bi-directional many-to-one association to Chassi
	@ManyToOne
	@JoinColumn(name = "TARGET_CHASSIS_NAME")
	private Chassi chassi2;

	// bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name = "TARGET_PLUGIN_NAME")
	private Plugin plugin2;

	// bi-directional many-to-one association to NtePort
	@ManyToOne
	@JoinColumn(name = "TARGET_PORT_NAME")
	private NtePort ntePort2;

	public NtePortPortAssoc() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEqP2pAspecId() {
		return this.eqP2pAspecId;
	}

	public void setEqP2pAspecId(String eqP2pAspecId) {
		this.eqP2pAspecId = eqP2pAspecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getSourcePortSeqNo() {
		return this.sourcePortSeqNo;
	}

	public void setSourcePortSeqNo(BigDecimal sourcePortSeqNo) {
		this.sourcePortSeqNo = sourcePortSeqNo;
	}

	public BigDecimal getTargetPortSeqNo() {
		return this.targetPortSeqNo;
	}

	public void setTargetPortSeqNo(BigDecimal targetPortSeqNo) {
		this.targetPortSeqNo = targetPortSeqNo;
	}

	public NetworkTerminatingEquipment getNetworkTerminatingEquipment() {
		return this.networkTerminatingEquipment;
	}

	public void setNetworkTerminatingEquipment(NetworkTerminatingEquipment networkTerminatingEquipment) {
		this.networkTerminatingEquipment = networkTerminatingEquipment;
	}

	public Chassi getChassi1() {
		return this.chassi1;
	}

	public void setChassi1(Chassi chassi1) {
		this.chassi1 = chassi1;
	}

	public Plugin getPlugin1() {
		return this.plugin1;
	}

	public void setPlugin1(Plugin plugin1) {
		this.plugin1 = plugin1;
	}

	public NtePort getNtePort1() {
		return this.ntePort1;
	}

	public void setNtePort1(NtePort ntePort1) {
		this.ntePort1 = ntePort1;
	}

	public Chassi getChassi2() {
		return this.chassi2;
	}

	public void setChassi2(Chassi chassi2) {
		this.chassi2 = chassi2;
	}

	public Plugin getPlugin2() {
		return this.plugin2;
	}

	public void setPlugin2(Plugin plugin2) {
		this.plugin2 = plugin2;
	}

	public NtePort getNtePort2() {
		return this.ntePort2;
	}

	public void setNtePort2(NtePort ntePort2) {
		this.ntePort2 = ntePort2;
	}

}