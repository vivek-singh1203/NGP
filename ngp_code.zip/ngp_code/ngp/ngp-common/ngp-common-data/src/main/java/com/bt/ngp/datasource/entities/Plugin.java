package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the PLUGINS database table.
 * 
 */
@javax.persistence.Entity
@Table(name = "PLUGINS")
@NamedQuery(name = "Plugin.findAll", query = "SELECT p FROM Plugin p")
public class Plugin implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique = true, nullable = false, length = 25)
	private String name;

	@Column(name = "ALTERNATE_NAME", length = 25)
	private String alternateName;

	@Column(name = "ASSET_IDENTIFIER", length = 30)
	private String assetIdentifier;

	@Column(name = "CREATED_BY", nullable = false, length = 40)
	private String createdBy;

	@Column(name = "CREATED_DATE", nullable = false)
	private Timestamp createdDate;

	@Column(name = "DATA_QUALITY_INDICATOR", length = 20)
	private String dataQualityIndicator;

	@Column(name = "FAULT_STATE", length = 25)
	private String faultState;

	@Column(nullable = false, length = 50)
	private String id;

	@Column(name = "LAST_MODIFIED_BY", length = 40)
	private String lastModifiedBy;

	@Column(name = "LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name = "RESOURCE_1141_CODE", nullable = false, length = 30)
	private String resource1141Code;

	@Column(name = "RESOURCE_STATE", nullable = false, length = 25)
	private String resourceState;

	@Column(name = "SERIAL_NUMBER", length = 30)
	private String serialNumber;

	@Column(name = "SERVICE_STATE", length = 25)
	private String serviceState;

	@Column(name = "SPEC_CATEGORY_NAME", length = 30)
	private String specCategoryName;

	@Column(name = "SPEC_NAME", length = 30)
	private String specName;

	@Column(name = "SPEC_TYPE_NAME", length = 30)
	private String specTypeName;

	@Column(name = "SPEC_VERSION", length = 5)
	private String specVersion;

	@Column(name = "USER_LABEL", length = 30)
	private String userLabel;

	// bi-directional many-to-one association to CcpCsPortTerm
	@OneToMany(mappedBy = "plugin")
	private List<CcpCsPortTerm> ccpCsPortTerms;

	// bi-directional many-to-one association to CcpPhPluginAssoc
	@OneToMany(mappedBy = "plugin")
	private List<CcpPhPluginAssoc> ccpPhPluginAssocs;

	// bi-directional many-to-one association to CcpPluginPortAssoc
	@OneToMany(mappedBy = "plugin")
	private List<CcpPluginPortAssoc> ccpPluginPortAssocs;

	// bi-directional many-to-one association to CcpPort
	@OneToMany(mappedBy = "plugin")
	private List<CcpPort> ccpPorts;

	// bi-directional many-to-one association to CcpPortPortAssoc
	@OneToMany(mappedBy = "plugin1")
	private List<CcpPortPortAssoc> ccpPortPortAssocs1;

	// bi-directional many-to-one association to CcpPortPortAssoc
	@OneToMany(mappedBy = "plugin2")
	private List<CcpPortPortAssoc> ccpPortPortAssocs2;

	// bi-directional many-to-one association to CpeCsPortTerm
	@OneToMany(mappedBy = "plugin")
	private List<CpeCsPortTerm> cpeCsPortTerms;

	// bi-directional many-to-one association to CpePhPluginAssoc
	@OneToMany(mappedBy = "plugin")
	private List<CpePhPluginAssoc> cpePhPluginAssocs;

	// bi-directional many-to-one association to CpePluginPortAssoc
	@OneToMany(mappedBy = "plugin")
	private List<CpePluginPortAssoc> cpePluginPortAssocs;

	// bi-directional many-to-one association to CpePort
	@OneToMany(mappedBy = "plugin")
	private List<CpePort> cpePorts;

	// bi-directional many-to-one association to CpePortPortAssoc
	@OneToMany(mappedBy = "plugin1")
	private List<CpePortPortAssoc> cpePortPortAssocs1;

	// bi-directional many-to-one association to CpePortPortAssoc
	@OneToMany(mappedBy = "plugin2")
	private List<CpePortPortAssoc> cpePortPortAssocs2;

	// bi-directional many-to-one association to DpCsPortTerm
	@OneToMany(mappedBy = "plugin")
	private List<DpCsPortTerm> dpCsPortTerms;

	// bi-directional many-to-one association to DpPhPluginAssoc
	@OneToMany(mappedBy = "plugin")
	private List<DpPhPluginAssoc> dpPhPluginAssocs;

	// bi-directional many-to-one association to DpPluginPortAssoc
	@OneToMany(mappedBy = "plugin")
	private List<DpPluginPortAssoc> dpPluginPortAssocs;

	// bi-directional many-to-one association to DpPort
	@OneToMany(mappedBy = "plugin")
	private List<DpPort> dpPorts;

	// bi-directional many-to-one association to DpPortPortAssoc
	@OneToMany(mappedBy = "plugin1")
	private List<DpPortPortAssoc> dpPortPortAssocs1;

	// bi-directional many-to-one association to DpPortPortAssoc
	@OneToMany(mappedBy = "plugin2")
	private List<DpPortPortAssoc> dpPortPortAssocs2;

	// bi-directional many-to-one association to JcCsPortTerm
	@OneToMany(mappedBy = "plugin")
	private List<JcCsPortTerm> jcCsPortTerms;

	// bi-directional many-to-one association to JcPhPluginAssoc
	@OneToMany(mappedBy = "plugin")
	private List<JcPhPluginAssoc> jcPhPluginAssocs;

	// bi-directional many-to-one association to JcPluginPortAssoc
	@OneToMany(mappedBy = "plugin")
	private List<JcPluginPortAssoc> jcPluginPortAssocs;

	// bi-directional many-to-one association to JcPort
	@OneToMany(mappedBy = "plugin")
	private List<JcPort> jcPorts;

	// bi-directional many-to-one association to JcPortPortAssoc
	@OneToMany(mappedBy = "plugin1")
	private List<JcPortPortAssoc> jcPortPortAssocs1;

	// bi-directional many-to-one association to JcPortPortAssoc
	@OneToMany(mappedBy = "plugin2")
	private List<JcPortPortAssoc> jcPortPortAssocs2;

	// bi-directional many-to-one association to MfnCsPortTerm
	@OneToMany(mappedBy = "plugin")
	private List<MfnCsPortTerm> mfnCsPortTerms;

	// bi-directional many-to-one association to MfnPhPluginAssoc
	@OneToMany(mappedBy = "plugin")
	private List<MfnPhPluginAssoc> mfnPhPluginAssocs;

	// bi-directional many-to-one association to MfnPluginPortAssoc
	@OneToMany(mappedBy = "plugin")
	private List<MfnPluginPortAssoc> mfnPluginPortAssocs;

	// bi-directional many-to-one association to MfnPort
	@OneToMany(mappedBy = "plugin")
	private List<MfnPort> mfnPorts;

	// bi-directional many-to-one association to MfnPortPortAssoc
	@OneToMany(mappedBy = "plugin1")
	private List<MfnPortPortAssoc> mfnPortPortAssocs1;

	// bi-directional many-to-one association to MfnPortPortAssoc
	@OneToMany(mappedBy = "plugin2")
	private List<MfnPortPortAssoc> mfnPortPortAssocs2;

	// bi-directional many-to-one association to NteCsPortTerm
	@OneToMany(mappedBy = "plugin")
	private List<NteCsPortTerm> nteCsPortTerms;

	// bi-directional many-to-one association to NtePhPluginAssoc
	@OneToMany(mappedBy = "plugin")
	private List<NtePhPluginAssoc> ntePhPluginAssocs;

	// bi-directional many-to-one association to NtePluginPortAssoc
	@OneToMany(mappedBy = "plugin")
	private List<NtePluginPortAssoc> ntePluginPortAssocs;

	// bi-directional many-to-one association to NtePort
	@OneToMany(mappedBy = "plugin")
	private List<NtePort> ntePorts;

	// bi-directional many-to-one association to NtePortPortAssoc
	@OneToMany(mappedBy = "plugin1")
	private List<NtePortPortAssoc> ntePortPortAssocs1;

	// bi-directional many-to-one association to NtePortPortAssoc
	@OneToMany(mappedBy = "plugin2")
	private List<NtePortPortAssoc> ntePortPortAssocs2;

	// bi-directional many-to-one association to PluginHolder
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "PH_NAME")
	private PluginHolder pluginHolder;

	// bi-directional many-to-one association to CrossConnectPoint
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CCP_NAME")
	private CrossConnectPoint crossConnectPoint;

	// bi-directional many-to-one association to CustomerPremiseEquipment
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "CPE_NAME")
	private CustomerPremiseEquipment customerPremiseEquipment;

	// bi-directional many-to-one association to DistributionPoint
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "DP_NAME")
	private DistributionPoint distributionPoint;

	// bi-directional many-to-one association to JointClosure
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "JC_NAME")
	private JointClosure jointClosure;

	// bi-directional many-to-one association to MultiFunctionalNode
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "MFN_NAME")
	private MultiFunctionalNode multiFunctionalNode;

	// bi-directional many-to-one association to NetworkTerminatingEquipment
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "NTE_NAME")
	private NetworkTerminatingEquipment networkTerminatingEquipment;

	// bi-directional many-to-one association to Store
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "STORE_NAME")
	private Store store;

	// bi-directional many-to-one association to Supplier
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "SUPPLIER_NAME")
	private Supplier supplier;

	// bi-directional many-to-one association to WirelessEquipment
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "WEQ_NAME")
	private WirelessEquipment wirelessEquipment;

	// bi-directional many-to-one association to PluginChar
	@OneToMany(mappedBy = "plugin")
	private List<PluginChar> pluginChars;

	// bi-directional many-to-one association to WeCsPortTerm
	@OneToMany(mappedBy = "plugin")
	private List<WeCsPortTerm> weCsPortTerms;

	// bi-directional many-to-one association to WePhPluginAssoc
	@OneToMany(mappedBy = "plugin")
	private List<WePhPluginAssoc> wePhPluginAssocs;

	// bi-directional many-to-one association to WePluginPortAssoc
	@OneToMany(mappedBy = "plugin")
	private List<WePluginPortAssoc> wePluginPortAssocs;

	// bi-directional many-to-one association to WePort
	@OneToMany(mappedBy = "plugin")
	private List<WePort> wePorts;

	// bi-directional many-to-one association to WePortPortAssoc
	@OneToMany(mappedBy = "plugin1")
	private List<WePortPortAssoc> wePortPortAssocs1;

	// bi-directional many-to-one association to WePortPortAssoc
	@OneToMany(mappedBy = "plugin2")
	private List<WePortPortAssoc> wePortPortAssocs2;

	public Plugin() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<CcpCsPortTerm> getCcpCsPortTerms() {
		return this.ccpCsPortTerms;
	}

	public void setCcpCsPortTerms(List<CcpCsPortTerm> ccpCsPortTerms) {
		this.ccpCsPortTerms = ccpCsPortTerms;
	}

	public CcpCsPortTerm addCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		getCcpCsPortTerms().add(ccpCsPortTerm);
		ccpCsPortTerm.setPlugin(this);

		return ccpCsPortTerm;
	}

	public CcpCsPortTerm removeCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		getCcpCsPortTerms().remove(ccpCsPortTerm);
		ccpCsPortTerm.setPlugin(null);

		return ccpCsPortTerm;
	}

	public List<CcpPhPluginAssoc> getCcpPhPluginAssocs() {
		return this.ccpPhPluginAssocs;
	}

	public void setCcpPhPluginAssocs(List<CcpPhPluginAssoc> ccpPhPluginAssocs) {
		this.ccpPhPluginAssocs = ccpPhPluginAssocs;
	}

	public CcpPhPluginAssoc addCcpPhPluginAssoc(CcpPhPluginAssoc ccpPhPluginAssoc) {
		getCcpPhPluginAssocs().add(ccpPhPluginAssoc);
		ccpPhPluginAssoc.setPlugin(this);

		return ccpPhPluginAssoc;
	}

	public CcpPhPluginAssoc removeCcpPhPluginAssoc(CcpPhPluginAssoc ccpPhPluginAssoc) {
		getCcpPhPluginAssocs().remove(ccpPhPluginAssoc);
		ccpPhPluginAssoc.setPlugin(null);

		return ccpPhPluginAssoc;
	}

	public List<CcpPluginPortAssoc> getCcpPluginPortAssocs() {
		return this.ccpPluginPortAssocs;
	}

	public void setCcpPluginPortAssocs(List<CcpPluginPortAssoc> ccpPluginPortAssocs) {
		this.ccpPluginPortAssocs = ccpPluginPortAssocs;
	}

	public CcpPluginPortAssoc addCcpPluginPortAssoc(CcpPluginPortAssoc ccpPluginPortAssoc) {
		getCcpPluginPortAssocs().add(ccpPluginPortAssoc);
		ccpPluginPortAssoc.setPlugin(this);

		return ccpPluginPortAssoc;
	}

	public CcpPluginPortAssoc removeCcpPluginPortAssoc(CcpPluginPortAssoc ccpPluginPortAssoc) {
		getCcpPluginPortAssocs().remove(ccpPluginPortAssoc);
		ccpPluginPortAssoc.setPlugin(null);

		return ccpPluginPortAssoc;
	}

	public List<CcpPort> getCcpPorts() {
		return this.ccpPorts;
	}

	public void setCcpPorts(List<CcpPort> ccpPorts) {
		this.ccpPorts = ccpPorts;
	}

	public CcpPort addCcpPort(CcpPort ccpPort) {
		getCcpPorts().add(ccpPort);
		ccpPort.setPlugin(this);

		return ccpPort;
	}

	public CcpPort removeCcpPort(CcpPort ccpPort) {
		getCcpPorts().remove(ccpPort);
		ccpPort.setPlugin(null);

		return ccpPort;
	}

	public List<CcpPortPortAssoc> getCcpPortPortAssocs1() {
		return this.ccpPortPortAssocs1;
	}

	public void setCcpPortPortAssocs1(List<CcpPortPortAssoc> ccpPortPortAssocs1) {
		this.ccpPortPortAssocs1 = ccpPortPortAssocs1;
	}

	public CcpPortPortAssoc addCcpPortPortAssocs1(CcpPortPortAssoc ccpPortPortAssocs1) {
		getCcpPortPortAssocs1().add(ccpPortPortAssocs1);
		ccpPortPortAssocs1.setPlugin1(this);

		return ccpPortPortAssocs1;
	}

	public CcpPortPortAssoc removeCcpPortPortAssocs1(CcpPortPortAssoc ccpPortPortAssocs1) {
		getCcpPortPortAssocs1().remove(ccpPortPortAssocs1);
		ccpPortPortAssocs1.setPlugin1(null);

		return ccpPortPortAssocs1;
	}

	public List<CcpPortPortAssoc> getCcpPortPortAssocs2() {
		return this.ccpPortPortAssocs2;
	}

	public void setCcpPortPortAssocs2(List<CcpPortPortAssoc> ccpPortPortAssocs2) {
		this.ccpPortPortAssocs2 = ccpPortPortAssocs2;
	}

	public CcpPortPortAssoc addCcpPortPortAssocs2(CcpPortPortAssoc ccpPortPortAssocs2) {
		getCcpPortPortAssocs2().add(ccpPortPortAssocs2);
		ccpPortPortAssocs2.setPlugin2(this);

		return ccpPortPortAssocs2;
	}

	public CcpPortPortAssoc removeCcpPortPortAssocs2(CcpPortPortAssoc ccpPortPortAssocs2) {
		getCcpPortPortAssocs2().remove(ccpPortPortAssocs2);
		ccpPortPortAssocs2.setPlugin2(null);

		return ccpPortPortAssocs2;
	}

	public List<CpeCsPortTerm> getCpeCsPortTerms() {
		return this.cpeCsPortTerms;
	}

	public void setCpeCsPortTerms(List<CpeCsPortTerm> cpeCsPortTerms) {
		this.cpeCsPortTerms = cpeCsPortTerms;
	}

	public CpeCsPortTerm addCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		getCpeCsPortTerms().add(cpeCsPortTerm);
		cpeCsPortTerm.setPlugin(this);

		return cpeCsPortTerm;
	}

	public CpeCsPortTerm removeCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		getCpeCsPortTerms().remove(cpeCsPortTerm);
		cpeCsPortTerm.setPlugin(null);

		return cpeCsPortTerm;
	}

	public List<CpePhPluginAssoc> getCpePhPluginAssocs() {
		return this.cpePhPluginAssocs;
	}

	public void setCpePhPluginAssocs(List<CpePhPluginAssoc> cpePhPluginAssocs) {
		this.cpePhPluginAssocs = cpePhPluginAssocs;
	}

	public CpePhPluginAssoc addCpePhPluginAssoc(CpePhPluginAssoc cpePhPluginAssoc) {
		getCpePhPluginAssocs().add(cpePhPluginAssoc);
		cpePhPluginAssoc.setPlugin(this);

		return cpePhPluginAssoc;
	}

	public CpePhPluginAssoc removeCpePhPluginAssoc(CpePhPluginAssoc cpePhPluginAssoc) {
		getCpePhPluginAssocs().remove(cpePhPluginAssoc);
		cpePhPluginAssoc.setPlugin(null);

		return cpePhPluginAssoc;
	}

	public List<CpePluginPortAssoc> getCpePluginPortAssocs() {
		return this.cpePluginPortAssocs;
	}

	public void setCpePluginPortAssocs(List<CpePluginPortAssoc> cpePluginPortAssocs) {
		this.cpePluginPortAssocs = cpePluginPortAssocs;
	}

	public CpePluginPortAssoc addCpePluginPortAssoc(CpePluginPortAssoc cpePluginPortAssoc) {
		getCpePluginPortAssocs().add(cpePluginPortAssoc);
		cpePluginPortAssoc.setPlugin(this);

		return cpePluginPortAssoc;
	}

	public CpePluginPortAssoc removeCpePluginPortAssoc(CpePluginPortAssoc cpePluginPortAssoc) {
		getCpePluginPortAssocs().remove(cpePluginPortAssoc);
		cpePluginPortAssoc.setPlugin(null);

		return cpePluginPortAssoc;
	}

	public List<CpePort> getCpePorts() {
		return this.cpePorts;
	}

	public void setCpePorts(List<CpePort> cpePorts) {
		this.cpePorts = cpePorts;
	}

	public CpePort addCpePort(CpePort cpePort) {
		getCpePorts().add(cpePort);
		cpePort.setPlugin(this);

		return cpePort;
	}

	public CpePort removeCpePort(CpePort cpePort) {
		getCpePorts().remove(cpePort);
		cpePort.setPlugin(null);

		return cpePort;
	}

	public List<CpePortPortAssoc> getCpePortPortAssocs1() {
		return this.cpePortPortAssocs1;
	}

	public void setCpePortPortAssocs1(List<CpePortPortAssoc> cpePortPortAssocs1) {
		this.cpePortPortAssocs1 = cpePortPortAssocs1;
	}

	public CpePortPortAssoc addCpePortPortAssocs1(CpePortPortAssoc cpePortPortAssocs1) {
		getCpePortPortAssocs1().add(cpePortPortAssocs1);
		cpePortPortAssocs1.setPlugin1(this);

		return cpePortPortAssocs1;
	}

	public CpePortPortAssoc removeCpePortPortAssocs1(CpePortPortAssoc cpePortPortAssocs1) {
		getCpePortPortAssocs1().remove(cpePortPortAssocs1);
		cpePortPortAssocs1.setPlugin1(null);

		return cpePortPortAssocs1;
	}

	public List<CpePortPortAssoc> getCpePortPortAssocs2() {
		return this.cpePortPortAssocs2;
	}

	public void setCpePortPortAssocs2(List<CpePortPortAssoc> cpePortPortAssocs2) {
		this.cpePortPortAssocs2 = cpePortPortAssocs2;
	}

	public CpePortPortAssoc addCpePortPortAssocs2(CpePortPortAssoc cpePortPortAssocs2) {
		getCpePortPortAssocs2().add(cpePortPortAssocs2);
		cpePortPortAssocs2.setPlugin2(this);

		return cpePortPortAssocs2;
	}

	public CpePortPortAssoc removeCpePortPortAssocs2(CpePortPortAssoc cpePortPortAssocs2) {
		getCpePortPortAssocs2().remove(cpePortPortAssocs2);
		cpePortPortAssocs2.setPlugin2(null);

		return cpePortPortAssocs2;
	}

	public List<DpCsPortTerm> getDpCsPortTerms() {
		return this.dpCsPortTerms;
	}

	public void setDpCsPortTerms(List<DpCsPortTerm> dpCsPortTerms) {
		this.dpCsPortTerms = dpCsPortTerms;
	}

	public DpCsPortTerm addDpCsPortTerm(DpCsPortTerm dpCsPortTerm) {
		getDpCsPortTerms().add(dpCsPortTerm);
		dpCsPortTerm.setPlugin(this);

		return dpCsPortTerm;
	}

	public DpCsPortTerm removeDpCsPortTerm(DpCsPortTerm dpCsPortTerm) {
		getDpCsPortTerms().remove(dpCsPortTerm);
		dpCsPortTerm.setPlugin(null);

		return dpCsPortTerm;
	}

	public List<DpPhPluginAssoc> getDpPhPluginAssocs() {
		return this.dpPhPluginAssocs;
	}

	public void setDpPhPluginAssocs(List<DpPhPluginAssoc> dpPhPluginAssocs) {
		this.dpPhPluginAssocs = dpPhPluginAssocs;
	}

	public DpPhPluginAssoc addDpPhPluginAssoc(DpPhPluginAssoc dpPhPluginAssoc) {
		getDpPhPluginAssocs().add(dpPhPluginAssoc);
		dpPhPluginAssoc.setPlugin(this);

		return dpPhPluginAssoc;
	}

	public DpPhPluginAssoc removeDpPhPluginAssoc(DpPhPluginAssoc dpPhPluginAssoc) {
		getDpPhPluginAssocs().remove(dpPhPluginAssoc);
		dpPhPluginAssoc.setPlugin(null);

		return dpPhPluginAssoc;
	}

	public List<DpPluginPortAssoc> getDpPluginPortAssocs() {
		return this.dpPluginPortAssocs;
	}

	public void setDpPluginPortAssocs(List<DpPluginPortAssoc> dpPluginPortAssocs) {
		this.dpPluginPortAssocs = dpPluginPortAssocs;
	}

	public DpPluginPortAssoc addDpPluginPortAssoc(DpPluginPortAssoc dpPluginPortAssoc) {
		getDpPluginPortAssocs().add(dpPluginPortAssoc);
		dpPluginPortAssoc.setPlugin(this);

		return dpPluginPortAssoc;
	}

	public DpPluginPortAssoc removeDpPluginPortAssoc(DpPluginPortAssoc dpPluginPortAssoc) {
		getDpPluginPortAssocs().remove(dpPluginPortAssoc);
		dpPluginPortAssoc.setPlugin(null);

		return dpPluginPortAssoc;
	}

	public List<DpPort> getDpPorts() {
		return this.dpPorts;
	}

	public void setDpPorts(List<DpPort> dpPorts) {
		this.dpPorts = dpPorts;
	}

	public DpPort addDpPort(DpPort dpPort) {
		getDpPorts().add(dpPort);
		dpPort.setPlugin(this);

		return dpPort;
	}

	public DpPort removeDpPort(DpPort dpPort) {
		getDpPorts().remove(dpPort);
		dpPort.setPlugin(null);

		return dpPort;
	}

	public List<DpPortPortAssoc> getDpPortPortAssocs1() {
		return this.dpPortPortAssocs1;
	}

	public void setDpPortPortAssocs1(List<DpPortPortAssoc> dpPortPortAssocs1) {
		this.dpPortPortAssocs1 = dpPortPortAssocs1;
	}

	public DpPortPortAssoc addDpPortPortAssocs1(DpPortPortAssoc dpPortPortAssocs1) {
		getDpPortPortAssocs1().add(dpPortPortAssocs1);
		dpPortPortAssocs1.setPlugin1(this);

		return dpPortPortAssocs1;
	}

	public DpPortPortAssoc removeDpPortPortAssocs1(DpPortPortAssoc dpPortPortAssocs1) {
		getDpPortPortAssocs1().remove(dpPortPortAssocs1);
		dpPortPortAssocs1.setPlugin1(null);

		return dpPortPortAssocs1;
	}

	public List<DpPortPortAssoc> getDpPortPortAssocs2() {
		return this.dpPortPortAssocs2;
	}

	public void setDpPortPortAssocs2(List<DpPortPortAssoc> dpPortPortAssocs2) {
		this.dpPortPortAssocs2 = dpPortPortAssocs2;
	}

	public DpPortPortAssoc addDpPortPortAssocs2(DpPortPortAssoc dpPortPortAssocs2) {
		getDpPortPortAssocs2().add(dpPortPortAssocs2);
		dpPortPortAssocs2.setPlugin2(this);

		return dpPortPortAssocs2;
	}

	public DpPortPortAssoc removeDpPortPortAssocs2(DpPortPortAssoc dpPortPortAssocs2) {
		getDpPortPortAssocs2().remove(dpPortPortAssocs2);
		dpPortPortAssocs2.setPlugin2(null);

		return dpPortPortAssocs2;
	}

	public List<JcCsPortTerm> getJcCsPortTerms() {
		return this.jcCsPortTerms;
	}

	public void setJcCsPortTerms(List<JcCsPortTerm> jcCsPortTerms) {
		this.jcCsPortTerms = jcCsPortTerms;
	}

	public JcCsPortTerm addJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		getJcCsPortTerms().add(jcCsPortTerm);
		jcCsPortTerm.setPlugin(this);

		return jcCsPortTerm;
	}

	public JcCsPortTerm removeJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		getJcCsPortTerms().remove(jcCsPortTerm);
		jcCsPortTerm.setPlugin(null);

		return jcCsPortTerm;
	}

	public List<JcPhPluginAssoc> getJcPhPluginAssocs() {
		return this.jcPhPluginAssocs;
	}

	public void setJcPhPluginAssocs(List<JcPhPluginAssoc> jcPhPluginAssocs) {
		this.jcPhPluginAssocs = jcPhPluginAssocs;
	}

	public JcPhPluginAssoc addJcPhPluginAssoc(JcPhPluginAssoc jcPhPluginAssoc) {
		getJcPhPluginAssocs().add(jcPhPluginAssoc);
		jcPhPluginAssoc.setPlugin(this);

		return jcPhPluginAssoc;
	}

	public JcPhPluginAssoc removeJcPhPluginAssoc(JcPhPluginAssoc jcPhPluginAssoc) {
		getJcPhPluginAssocs().remove(jcPhPluginAssoc);
		jcPhPluginAssoc.setPlugin(null);

		return jcPhPluginAssoc;
	}

	public List<JcPluginPortAssoc> getJcPluginPortAssocs() {
		return this.jcPluginPortAssocs;
	}

	public void setJcPluginPortAssocs(List<JcPluginPortAssoc> jcPluginPortAssocs) {
		this.jcPluginPortAssocs = jcPluginPortAssocs;
	}

	public JcPluginPortAssoc addJcPluginPortAssoc(JcPluginPortAssoc jcPluginPortAssoc) {
		getJcPluginPortAssocs().add(jcPluginPortAssoc);
		jcPluginPortAssoc.setPlugin(this);

		return jcPluginPortAssoc;
	}

	public JcPluginPortAssoc removeJcPluginPortAssoc(JcPluginPortAssoc jcPluginPortAssoc) {
		getJcPluginPortAssocs().remove(jcPluginPortAssoc);
		jcPluginPortAssoc.setPlugin(null);

		return jcPluginPortAssoc;
	}

	public List<JcPort> getJcPorts() {
		return this.jcPorts;
	}

	public void setJcPorts(List<JcPort> jcPorts) {
		this.jcPorts = jcPorts;
	}

	public JcPort addJcPort(JcPort jcPort) {
		getJcPorts().add(jcPort);
		jcPort.setPlugin(this);

		return jcPort;
	}

	public JcPort removeJcPort(JcPort jcPort) {
		getJcPorts().remove(jcPort);
		jcPort.setPlugin(null);

		return jcPort;
	}

	public List<JcPortPortAssoc> getJcPortPortAssocs1() {
		return this.jcPortPortAssocs1;
	}

	public void setJcPortPortAssocs1(List<JcPortPortAssoc> jcPortPortAssocs1) {
		this.jcPortPortAssocs1 = jcPortPortAssocs1;
	}

	public JcPortPortAssoc addJcPortPortAssocs1(JcPortPortAssoc jcPortPortAssocs1) {
		getJcPortPortAssocs1().add(jcPortPortAssocs1);
		jcPortPortAssocs1.setPlugin1(this);

		return jcPortPortAssocs1;
	}

	public JcPortPortAssoc removeJcPortPortAssocs1(JcPortPortAssoc jcPortPortAssocs1) {
		getJcPortPortAssocs1().remove(jcPortPortAssocs1);
		jcPortPortAssocs1.setPlugin1(null);

		return jcPortPortAssocs1;
	}

	public List<JcPortPortAssoc> getJcPortPortAssocs2() {
		return this.jcPortPortAssocs2;
	}

	public void setJcPortPortAssocs2(List<JcPortPortAssoc> jcPortPortAssocs2) {
		this.jcPortPortAssocs2 = jcPortPortAssocs2;
	}

	public JcPortPortAssoc addJcPortPortAssocs2(JcPortPortAssoc jcPortPortAssocs2) {
		getJcPortPortAssocs2().add(jcPortPortAssocs2);
		jcPortPortAssocs2.setPlugin2(this);

		return jcPortPortAssocs2;
	}

	public JcPortPortAssoc removeJcPortPortAssocs2(JcPortPortAssoc jcPortPortAssocs2) {
		getJcPortPortAssocs2().remove(jcPortPortAssocs2);
		jcPortPortAssocs2.setPlugin2(null);

		return jcPortPortAssocs2;
	}

	public List<MfnCsPortTerm> getMfnCsPortTerms() {
		return this.mfnCsPortTerms;
	}

	public void setMfnCsPortTerms(List<MfnCsPortTerm> mfnCsPortTerms) {
		this.mfnCsPortTerms = mfnCsPortTerms;
	}

	public MfnCsPortTerm addMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		getMfnCsPortTerms().add(mfnCsPortTerm);
		mfnCsPortTerm.setPlugin(this);

		return mfnCsPortTerm;
	}

	public MfnCsPortTerm removeMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		getMfnCsPortTerms().remove(mfnCsPortTerm);
		mfnCsPortTerm.setPlugin(null);

		return mfnCsPortTerm;
	}

	public List<MfnPhPluginAssoc> getMfnPhPluginAssocs() {
		return this.mfnPhPluginAssocs;
	}

	public void setMfnPhPluginAssocs(List<MfnPhPluginAssoc> mfnPhPluginAssocs) {
		this.mfnPhPluginAssocs = mfnPhPluginAssocs;
	}

	public MfnPhPluginAssoc addMfnPhPluginAssoc(MfnPhPluginAssoc mfnPhPluginAssoc) {
		getMfnPhPluginAssocs().add(mfnPhPluginAssoc);
		mfnPhPluginAssoc.setPlugin(this);

		return mfnPhPluginAssoc;
	}

	public MfnPhPluginAssoc removeMfnPhPluginAssoc(MfnPhPluginAssoc mfnPhPluginAssoc) {
		getMfnPhPluginAssocs().remove(mfnPhPluginAssoc);
		mfnPhPluginAssoc.setPlugin(null);

		return mfnPhPluginAssoc;
	}

	public List<MfnPluginPortAssoc> getMfnPluginPortAssocs() {
		return this.mfnPluginPortAssocs;
	}

	public void setMfnPluginPortAssocs(List<MfnPluginPortAssoc> mfnPluginPortAssocs) {
		this.mfnPluginPortAssocs = mfnPluginPortAssocs;
	}

	public MfnPluginPortAssoc addMfnPluginPortAssoc(MfnPluginPortAssoc mfnPluginPortAssoc) {
		getMfnPluginPortAssocs().add(mfnPluginPortAssoc);
		mfnPluginPortAssoc.setPlugin(this);

		return mfnPluginPortAssoc;
	}

	public MfnPluginPortAssoc removeMfnPluginPortAssoc(MfnPluginPortAssoc mfnPluginPortAssoc) {
		getMfnPluginPortAssocs().remove(mfnPluginPortAssoc);
		mfnPluginPortAssoc.setPlugin(null);

		return mfnPluginPortAssoc;
	}

	public List<MfnPort> getMfnPorts() {
		return this.mfnPorts;
	}

	public void setMfnPorts(List<MfnPort> mfnPorts) {
		this.mfnPorts = mfnPorts;
	}

	public MfnPort addMfnPort(MfnPort mfnPort) {
		getMfnPorts().add(mfnPort);
		mfnPort.setPlugin(this);

		return mfnPort;
	}

	public MfnPort removeMfnPort(MfnPort mfnPort) {
		getMfnPorts().remove(mfnPort);
		mfnPort.setPlugin(null);

		return mfnPort;
	}

	public List<MfnPortPortAssoc> getMfnPortPortAssocs1() {
		return this.mfnPortPortAssocs1;
	}

	public void setMfnPortPortAssocs1(List<MfnPortPortAssoc> mfnPortPortAssocs1) {
		this.mfnPortPortAssocs1 = mfnPortPortAssocs1;
	}

	public MfnPortPortAssoc addMfnPortPortAssocs1(MfnPortPortAssoc mfnPortPortAssocs1) {
		getMfnPortPortAssocs1().add(mfnPortPortAssocs1);
		mfnPortPortAssocs1.setPlugin1(this);

		return mfnPortPortAssocs1;
	}

	public MfnPortPortAssoc removeMfnPortPortAssocs1(MfnPortPortAssoc mfnPortPortAssocs1) {
		getMfnPortPortAssocs1().remove(mfnPortPortAssocs1);
		mfnPortPortAssocs1.setPlugin1(null);

		return mfnPortPortAssocs1;
	}

	public List<MfnPortPortAssoc> getMfnPortPortAssocs2() {
		return this.mfnPortPortAssocs2;
	}

	public void setMfnPortPortAssocs2(List<MfnPortPortAssoc> mfnPortPortAssocs2) {
		this.mfnPortPortAssocs2 = mfnPortPortAssocs2;
	}

	public MfnPortPortAssoc addMfnPortPortAssocs2(MfnPortPortAssoc mfnPortPortAssocs2) {
		getMfnPortPortAssocs2().add(mfnPortPortAssocs2);
		mfnPortPortAssocs2.setPlugin2(this);

		return mfnPortPortAssocs2;
	}

	public MfnPortPortAssoc removeMfnPortPortAssocs2(MfnPortPortAssoc mfnPortPortAssocs2) {
		getMfnPortPortAssocs2().remove(mfnPortPortAssocs2);
		mfnPortPortAssocs2.setPlugin2(null);

		return mfnPortPortAssocs2;
	}

	public List<NteCsPortTerm> getNteCsPortTerms() {
		return this.nteCsPortTerms;
	}

	public void setNteCsPortTerms(List<NteCsPortTerm> nteCsPortTerms) {
		this.nteCsPortTerms = nteCsPortTerms;
	}

	public NteCsPortTerm addNteCsPortTerm(NteCsPortTerm nteCsPortTerm) {
		getNteCsPortTerms().add(nteCsPortTerm);
		nteCsPortTerm.setPlugin(this);

		return nteCsPortTerm;
	}

	public NteCsPortTerm removeNteCsPortTerm(NteCsPortTerm nteCsPortTerm) {
		getNteCsPortTerms().remove(nteCsPortTerm);
		nteCsPortTerm.setPlugin(null);

		return nteCsPortTerm;
	}

	public List<NtePhPluginAssoc> getNtePhPluginAssocs() {
		return this.ntePhPluginAssocs;
	}

	public void setNtePhPluginAssocs(List<NtePhPluginAssoc> ntePhPluginAssocs) {
		this.ntePhPluginAssocs = ntePhPluginAssocs;
	}

	public NtePhPluginAssoc addNtePhPluginAssoc(NtePhPluginAssoc ntePhPluginAssoc) {
		getNtePhPluginAssocs().add(ntePhPluginAssoc);
		ntePhPluginAssoc.setPlugin(this);

		return ntePhPluginAssoc;
	}

	public NtePhPluginAssoc removeNtePhPluginAssoc(NtePhPluginAssoc ntePhPluginAssoc) {
		getNtePhPluginAssocs().remove(ntePhPluginAssoc);
		ntePhPluginAssoc.setPlugin(null);

		return ntePhPluginAssoc;
	}

	public List<NtePluginPortAssoc> getNtePluginPortAssocs() {
		return this.ntePluginPortAssocs;
	}

	public void setNtePluginPortAssocs(List<NtePluginPortAssoc> ntePluginPortAssocs) {
		this.ntePluginPortAssocs = ntePluginPortAssocs;
	}

	public NtePluginPortAssoc addNtePluginPortAssoc(NtePluginPortAssoc ntePluginPortAssoc) {
		getNtePluginPortAssocs().add(ntePluginPortAssoc);
		ntePluginPortAssoc.setPlugin(this);

		return ntePluginPortAssoc;
	}

	public NtePluginPortAssoc removeNtePluginPortAssoc(NtePluginPortAssoc ntePluginPortAssoc) {
		getNtePluginPortAssocs().remove(ntePluginPortAssoc);
		ntePluginPortAssoc.setPlugin(null);

		return ntePluginPortAssoc;
	}

	public List<NtePort> getNtePorts() {
		return this.ntePorts;
	}

	public void setNtePorts(List<NtePort> ntePorts) {
		this.ntePorts = ntePorts;
	}

	public NtePort addNtePort(NtePort ntePort) {
		getNtePorts().add(ntePort);
		ntePort.setPlugin(this);

		return ntePort;
	}

	public NtePort removeNtePort(NtePort ntePort) {
		getNtePorts().remove(ntePort);
		ntePort.setPlugin(null);

		return ntePort;
	}

	public List<NtePortPortAssoc> getNtePortPortAssocs1() {
		return this.ntePortPortAssocs1;
	}

	public void setNtePortPortAssocs1(List<NtePortPortAssoc> ntePortPortAssocs1) {
		this.ntePortPortAssocs1 = ntePortPortAssocs1;
	}

	public NtePortPortAssoc addNtePortPortAssocs1(NtePortPortAssoc ntePortPortAssocs1) {
		getNtePortPortAssocs1().add(ntePortPortAssocs1);
		ntePortPortAssocs1.setPlugin1(this);

		return ntePortPortAssocs1;
	}

	public NtePortPortAssoc removeNtePortPortAssocs1(NtePortPortAssoc ntePortPortAssocs1) {
		getNtePortPortAssocs1().remove(ntePortPortAssocs1);
		ntePortPortAssocs1.setPlugin1(null);

		return ntePortPortAssocs1;
	}

	public List<NtePortPortAssoc> getNtePortPortAssocs2() {
		return this.ntePortPortAssocs2;
	}

	public void setNtePortPortAssocs2(List<NtePortPortAssoc> ntePortPortAssocs2) {
		this.ntePortPortAssocs2 = ntePortPortAssocs2;
	}

	public NtePortPortAssoc addNtePortPortAssocs2(NtePortPortAssoc ntePortPortAssocs2) {
		getNtePortPortAssocs2().add(ntePortPortAssocs2);
		ntePortPortAssocs2.setPlugin2(this);

		return ntePortPortAssocs2;
	}

	public NtePortPortAssoc removeNtePortPortAssocs2(NtePortPortAssoc ntePortPortAssocs2) {
		getNtePortPortAssocs2().remove(ntePortPortAssocs2);
		ntePortPortAssocs2.setPlugin2(null);

		return ntePortPortAssocs2;
	}

	public PluginHolder getPluginHolder() {
		return this.pluginHolder;
	}

	public void setPluginHolder(PluginHolder pluginHolder) {
		this.pluginHolder = pluginHolder;
	}

	public CrossConnectPoint getCrossConnectPoint() {
		return this.crossConnectPoint;
	}

	public void setCrossConnectPoint(CrossConnectPoint crossConnectPoint) {
		this.crossConnectPoint = crossConnectPoint;
	}

	public CustomerPremiseEquipment getCustomerPremiseEquipment() {
		return this.customerPremiseEquipment;
	}

	public void setCustomerPremiseEquipment(CustomerPremiseEquipment customerPremiseEquipment) {
		this.customerPremiseEquipment = customerPremiseEquipment;
	}

	public DistributionPoint getDistributionPoint() {
		return this.distributionPoint;
	}

	public void setDistributionPoint(DistributionPoint distributionPoint) {
		this.distributionPoint = distributionPoint;
	}

	public JointClosure getJointClosure() {
		return this.jointClosure;
	}

	public void setJointClosure(JointClosure jointClosure) {
		this.jointClosure = jointClosure;
	}

	public MultiFunctionalNode getMultiFunctionalNode() {
		return this.multiFunctionalNode;
	}

	public void setMultiFunctionalNode(MultiFunctionalNode multiFunctionalNode) {
		this.multiFunctionalNode = multiFunctionalNode;
	}

	public NetworkTerminatingEquipment getNetworkTerminatingEquipment() {
		return this.networkTerminatingEquipment;
	}

	public void setNetworkTerminatingEquipment(NetworkTerminatingEquipment networkTerminatingEquipment) {
		this.networkTerminatingEquipment = networkTerminatingEquipment;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public WirelessEquipment getWirelessEquipment() {
		return this.wirelessEquipment;
	}

	public void setWirelessEquipment(WirelessEquipment wirelessEquipment) {
		this.wirelessEquipment = wirelessEquipment;
	}

	public List<PluginChar> getPluginChars() {
		return this.pluginChars;
	}

	public void setPluginChars(List<PluginChar> pluginChars) {
		this.pluginChars = pluginChars;
	}

	public PluginChar addPluginChar(PluginChar pluginChar) {
		getPluginChars().add(pluginChar);
		pluginChar.setPlugin(this);

		return pluginChar;
	}

	public PluginChar removePluginChar(PluginChar pluginChar) {
		getPluginChars().remove(pluginChar);
		pluginChar.setPlugin(null);

		return pluginChar;
	}

	public List<WeCsPortTerm> getWeCsPortTerms() {
		return this.weCsPortTerms;
	}

	public void setWeCsPortTerms(List<WeCsPortTerm> weCsPortTerms) {
		this.weCsPortTerms = weCsPortTerms;
	}

	public WeCsPortTerm addWeCsPortTerm(WeCsPortTerm weCsPortTerm) {
		getWeCsPortTerms().add(weCsPortTerm);
		weCsPortTerm.setPlugin(this);

		return weCsPortTerm;
	}

	public WeCsPortTerm removeWeCsPortTerm(WeCsPortTerm weCsPortTerm) {
		getWeCsPortTerms().remove(weCsPortTerm);
		weCsPortTerm.setPlugin(null);

		return weCsPortTerm;
	}

	public List<WePhPluginAssoc> getWePhPluginAssocs() {
		return this.wePhPluginAssocs;
	}

	public void setWePhPluginAssocs(List<WePhPluginAssoc> wePhPluginAssocs) {
		this.wePhPluginAssocs = wePhPluginAssocs;
	}

	public WePhPluginAssoc addWePhPluginAssoc(WePhPluginAssoc wePhPluginAssoc) {
		getWePhPluginAssocs().add(wePhPluginAssoc);
		wePhPluginAssoc.setPlugin(this);

		return wePhPluginAssoc;
	}

	public WePhPluginAssoc removeWePhPluginAssoc(WePhPluginAssoc wePhPluginAssoc) {
		getWePhPluginAssocs().remove(wePhPluginAssoc);
		wePhPluginAssoc.setPlugin(null);

		return wePhPluginAssoc;
	}

	public List<WePluginPortAssoc> getWePluginPortAssocs() {
		return this.wePluginPortAssocs;
	}

	public void setWePluginPortAssocs(List<WePluginPortAssoc> wePluginPortAssocs) {
		this.wePluginPortAssocs = wePluginPortAssocs;
	}

	public WePluginPortAssoc addWePluginPortAssoc(WePluginPortAssoc wePluginPortAssoc) {
		getWePluginPortAssocs().add(wePluginPortAssoc);
		wePluginPortAssoc.setPlugin(this);

		return wePluginPortAssoc;
	}

	public WePluginPortAssoc removeWePluginPortAssoc(WePluginPortAssoc wePluginPortAssoc) {
		getWePluginPortAssocs().remove(wePluginPortAssoc);
		wePluginPortAssoc.setPlugin(null);

		return wePluginPortAssoc;
	}

	public List<WePort> getWePorts() {
		return this.wePorts;
	}

	public void setWePorts(List<WePort> wePorts) {
		this.wePorts = wePorts;
	}

	public WePort addWePort(WePort wePort) {
		getWePorts().add(wePort);
		wePort.setPlugin(this);

		return wePort;
	}

	public WePort removeWePort(WePort wePort) {
		getWePorts().remove(wePort);
		wePort.setPlugin(null);

		return wePort;
	}

	public List<WePortPortAssoc> getWePortPortAssocs1() {
		return this.wePortPortAssocs1;
	}

	public void setWePortPortAssocs1(List<WePortPortAssoc> wePortPortAssocs1) {
		this.wePortPortAssocs1 = wePortPortAssocs1;
	}

	public WePortPortAssoc addWePortPortAssocs1(WePortPortAssoc wePortPortAssocs1) {
		getWePortPortAssocs1().add(wePortPortAssocs1);
		wePortPortAssocs1.setPlugin1(this);

		return wePortPortAssocs1;
	}

	public WePortPortAssoc removeWePortPortAssocs1(WePortPortAssoc wePortPortAssocs1) {
		getWePortPortAssocs1().remove(wePortPortAssocs1);
		wePortPortAssocs1.setPlugin1(null);

		return wePortPortAssocs1;
	}

	public List<WePortPortAssoc> getWePortPortAssocs2() {
		return this.wePortPortAssocs2;
	}

	public void setWePortPortAssocs2(List<WePortPortAssoc> wePortPortAssocs2) {
		this.wePortPortAssocs2 = wePortPortAssocs2;
	}

	public WePortPortAssoc addWePortPortAssocs2(WePortPortAssoc wePortPortAssocs2) {
		getWePortPortAssocs2().add(wePortPortAssocs2);
		wePortPortAssocs2.setPlugin2(this);

		return wePortPortAssocs2;
	}

	public WePortPortAssoc removeWePortPortAssocs2(WePortPortAssoc wePortPortAssocs2) {
		getWePortPortAssocs2().remove(wePortPortAssocs2);
		wePortPortAssocs2.setPlugin2(null);

		return wePortPortAssocs2;
	}

}