package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.CableSectionEnd;
import com.bt.ngp.datasource.entities.Entity;

@Repository
public interface CableSectionEndRepository
		extends SqlRepository<CableSectionEnd> {

	CableSectionEnd findByCableSection(CableSection cs);

	List<CableSectionEnd> findByOrigEndName(@Param("name") String name);

	List<CableSectionEnd> findByTermEndName(@Param("name") String name);

	List<CableSectionEnd> findByTermEndEntityNameAndTermEndName(
			Entity termEndEntityName, String termEndName);

	List<CableSectionEnd> findByOrigEndEntityNameAndOrigEndName(
			Entity origEndEntityName, String origEndName);

}
