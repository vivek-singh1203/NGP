package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the SPEC_TYPE database table.
 * 
 */
@javax.persistence.Entity
@Table(name="SPEC_TYPE")
@NamedQuery(name="SpecType.findAll", query="SELECT s FROM SpecType s")
public class SpecType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=30)
	private String name;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(length=50)
	private String description;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to CableCbAssocSpec
	@OneToMany(mappedBy="specType1")
	private List<CableCbAssocSpec> cableCbAssocSpecs1;

	//bi-directional many-to-one association to CableCbAssocSpec
	@OneToMany(mappedBy="specType2")
	private List<CableCbAssocSpec> cableCbAssocSpecs2;

	//bi-directional many-to-one association to CableCharSpecRel
	@OneToMany(mappedBy="specType")
	private List<CableCharSpecRel> cableCharSpecRels;

	//bi-directional many-to-one association to CableCondAssocSpec
	@OneToMany(mappedBy="specType1")
	private List<CableCondAssocSpec> cableCondAssocSpecs1;

	//bi-directional many-to-one association to CableCondAssocSpec
	@OneToMany(mappedBy="specType2")
	private List<CableCondAssocSpec> cableCondAssocSpecs2;

	//bi-directional many-to-one association to CableHierarchySpec
	@OneToMany(mappedBy="specType")
	private List<CableHierarchySpec> cableHierarchySpecs;

	//bi-directional many-to-one association to CableSpanCompatSpec
	@OneToMany(mappedBy="specType1")
	private List<CableSpanCompatSpec> cableSpanCompatSpecs1;

	//bi-directional many-to-one association to CableSpanCompatSpec
	@OneToMany(mappedBy="specType2")
	private List<CableSpanCompatSpec> cableSpanCompatSpecs2;

	//bi-directional many-to-one association to CableSpec
	@OneToMany(mappedBy="specType")
	private List<CableSpec> cableSpecs;

	//bi-directional many-to-one association to CableSpecCharSpec
	@OneToMany(mappedBy="specType")
	private List<CableSpecCharSpec> cableSpecCharSpecs;

	//bi-directional many-to-one association to CableSpecCharValueSpec
	@OneToMany(mappedBy="specType")
	private List<CableSpecCharValueSpec> cableSpecCharValueSpecs;

	//bi-directional many-to-one association to CbCondAssocSpec
	@OneToMany(mappedBy="specType1")
	private List<CbCondAssocSpec> cbCondAssocSpecs1;

	//bi-directional many-to-one association to CbCondAssocSpec
	@OneToMany(mappedBy="specType2")
	private List<CbCondAssocSpec> cbCondAssocSpecs2;

	//bi-directional many-to-one association to CbSpec
	@OneToMany(mappedBy="specType")
	private List<CbSpec> cbSpecs;

	//bi-directional many-to-one association to CbSpecCharSpec
	@OneToMany(mappedBy="specType")
	private List<CbSpecCharSpec> cbSpecCharSpecs;

	//bi-directional many-to-one association to CbSpecCharSpecRel
	@OneToMany(mappedBy="specType")
	private List<CbSpecCharSpecRel> cbSpecCharSpecRels;

	//bi-directional many-to-one association to CbSpecCharValueSpec
	@OneToMany(mappedBy="specType")
	private List<CbSpecCharValueSpec> cbSpecCharValueSpecs;

	//bi-directional many-to-one association to ConductorSpec
	@OneToMany(mappedBy="specType")
	private List<ConductorSpec> conductorSpecs;

	//bi-directional many-to-one association to CondSpecCharSpec
	@OneToMany(mappedBy="specType")
	private List<CondSpecCharSpec> condSpecCharSpecs;

	//bi-directional many-to-one association to CondSpecCharSpecRel
	@OneToMany(mappedBy="specType")
	private List<CondSpecCharSpecRel> condSpecCharSpecRels;

	//bi-directional many-to-one association to CondSpecCharValueSpec
	@OneToMany(mappedBy="specType")
	private List<CondSpecCharValueSpec> condSpecCharValueSpecs;

	//bi-directional many-to-one association to ConnectorSpec
	@OneToMany(mappedBy="specType")
	private List<ConnectorSpec> connectorSpecs;

	//bi-directional many-to-one association to ConnectorSpecCharSpec
	@OneToMany(mappedBy="specType")
	private List<ConnectorSpecCharSpec> connectorSpecCharSpecs;

	//bi-directional many-to-one association to ConnectorSpecCharSpecRel
	@OneToMany(mappedBy="specType")
	private List<ConnectorSpecCharSpecRel> connectorSpecCharSpecRels;

	//bi-directional many-to-one association to ConnectorSpecCharValueSpec
	@OneToMany(mappedBy="specType")
	private List<ConnectorSpecCharValueSpec> connectorSpecCharValueSpecs;

	//bi-directional many-to-one association to DeviceCableCompatSpec
	@OneToMany(mappedBy="specType1")
	private List<DeviceCableCompatSpec> deviceCableCompatSpecs1;

	//bi-directional many-to-one association to DeviceCableCompatSpec
	@OneToMany(mappedBy="specType2")
	private List<DeviceCableCompatSpec> deviceCableCompatSpecs2;

	//bi-directional many-to-one association to DeviceCompHolderAssocSpec
	@OneToMany(mappedBy="specType1")
	private List<DeviceCompHolderAssocSpec> deviceCompHolderAssocSpecs1;

	//bi-directional many-to-one association to DeviceCompHolderAssocSpec
	@OneToMany(mappedBy="specType2")
	private List<DeviceCompHolderAssocSpec> deviceCompHolderAssocSpecs2;

	//bi-directional many-to-one association to DeviceCompHolderAssocSpec
	@OneToMany(mappedBy="specType3")
	private List<DeviceCompHolderAssocSpec> deviceCompHolderAssocSpecs3;

	//bi-directional many-to-one association to DeviceCompPortAssocSpec
	@OneToMany(mappedBy="specType1")
	private List<DeviceCompPortAssocSpec> deviceCompPortAssocSpecs1;

	//bi-directional many-to-one association to DeviceCompPortAssocSpec
	@OneToMany(mappedBy="specType2")
	private List<DeviceCompPortAssocSpec> deviceCompPortAssocSpecs2;

	//bi-directional many-to-one association to DeviceCompPortAssocSpec
	@OneToMany(mappedBy="specType3")
	private List<DeviceCompPortAssocSpec> deviceCompPortAssocSpecs3;

	//bi-directional many-to-one association to DeviceHierarchySpec
	@OneToMany(mappedBy="specType")
	private List<DeviceHierarchySpec> deviceHierarchySpecs;

	//bi-directional many-to-one association to DeviceHolderCompAssocSpec
	@OneToMany(mappedBy="specType1")
	private List<DeviceHolderCompAssocSpec> deviceHolderCompAssocSpecs1;

	//bi-directional many-to-one association to DeviceHolderCompAssocSpec
	@OneToMany(mappedBy="specType2")
	private List<DeviceHolderCompAssocSpec> deviceHolderCompAssocSpecs2;

	//bi-directional many-to-one association to DeviceHolderCompAssocSpec
	@OneToMany(mappedBy="specType3")
	private List<DeviceHolderCompAssocSpec> deviceHolderCompAssocSpecs3;

	//bi-directional many-to-one association to DevicePortPortAssocSpec
	@OneToMany(mappedBy="specType")
	private List<DevicePortPortAssocSpec> devicePortPortAssocSpecs;

	//bi-directional many-to-one association to DeviceSpec
	@OneToMany(mappedBy="specType")
	private List<DeviceSpec> deviceSpecs;

	//bi-directional many-to-one association to DeviceSpecCharSpec
	@OneToMany(mappedBy="specType")
	private List<DeviceSpecCharSpec> deviceSpecCharSpecs;

	//bi-directional many-to-one association to DeviceSpecCharSpecRel
	@OneToMany(mappedBy="specType")
	private List<DeviceSpecCharSpecRel> deviceSpecCharSpecRels;

	//bi-directional many-to-one association to DeviceSpecCharValueSpec
	@OneToMany(mappedBy="specType")
	private List<DeviceSpecCharValueSpec> deviceSpecCharValueSpecs;

	//bi-directional many-to-one association to EqCableCompatSpec
	@OneToMany(mappedBy="specType1")
	private List<EqCableCompatSpec> eqCableCompatSpecs1;

	//bi-directional many-to-one association to EqCableCompatSpec
	@OneToMany(mappedBy="specType2")
	private List<EqCableCompatSpec> eqCableCompatSpecs2;

	//bi-directional many-to-one association to EqCompHolderAssocSpec
	@OneToMany(mappedBy="specType1")
	private List<EqCompHolderAssocSpec> eqCompHolderAssocSpecs1;

	//bi-directional many-to-one association to EqCompHolderAssocSpec
	@OneToMany(mappedBy="specType2")
	private List<EqCompHolderAssocSpec> eqCompHolderAssocSpecs2;

	//bi-directional many-to-one association to EqCompHolderAssocSpec
	@OneToMany(mappedBy="specType3")
	private List<EqCompHolderAssocSpec> eqCompHolderAssocSpecs3;

	//bi-directional many-to-one association to EqCompPortAssocSpec
	@OneToMany(mappedBy="specType1")
	private List<EqCompPortAssocSpec> eqCompPortAssocSpecs1;

	//bi-directional many-to-one association to EqCompPortAssocSpec
	@OneToMany(mappedBy="specType2")
	private List<EqCompPortAssocSpec> eqCompPortAssocSpecs2;

	//bi-directional many-to-one association to EqCompPortAssocSpec
	@OneToMany(mappedBy="specType3")
	private List<EqCompPortAssocSpec> eqCompPortAssocSpecs3;

	//bi-directional many-to-one association to EqHierarchySpec
	@OneToMany(mappedBy="specType")
	private List<EqHierarchySpec> eqHierarchySpecs;

	//bi-directional many-to-one association to EqHolderCompAssocSpec
	@OneToMany(mappedBy="specType1")
	private List<EqHolderCompAssocSpec> eqHolderCompAssocSpecs1;

	//bi-directional many-to-one association to EqHolderCompAssocSpec
	@OneToMany(mappedBy="specType2")
	private List<EqHolderCompAssocSpec> eqHolderCompAssocSpecs2;

	//bi-directional many-to-one association to EqHolderCompAssocSpec
	@OneToMany(mappedBy="specType3")
	private List<EqHolderCompAssocSpec> eqHolderCompAssocSpecs3;

	//bi-directional many-to-one association to EqPortPortAssocSpec
	@OneToMany(mappedBy="specType")
	private List<EqPortPortAssocSpec> eqPortPortAssocSpecs;

	//bi-directional many-to-one association to EqSpec
	@OneToMany(mappedBy="specType")
	private List<EqSpec> eqSpecs;

	//bi-directional many-to-one association to EqSpecCharSpec
	@OneToMany(mappedBy="specType")
	private List<EqSpecCharSpec> eqSpecCharSpecs;

	//bi-directional many-to-one association to EqSpecCharSpecRel
	@OneToMany(mappedBy="specType")
	private List<EqSpecCharSpecRel> eqSpecCharSpecRels;

	//bi-directional many-to-one association to EqSpecCharValueSpec
	@OneToMany(mappedBy="specType")
	private List<EqSpecCharValueSpec> eqSpecCharValueSpecs;

	//bi-directional many-to-one association to EqStructureCompatSpec
	@OneToMany(mappedBy="specType1")
	private List<EqStructureCompatSpec> eqStructureCompatSpecs1;

	//bi-directional many-to-one association to EqStructureCompatSpec
	@OneToMany(mappedBy="specType2")
	private List<EqStructureCompatSpec> eqStructureCompatSpecs2;

	//bi-directional many-to-one association to HolderSpec
	@OneToMany(mappedBy="specType")
	private List<HolderSpec> holderSpecs;

	//bi-directional many-to-one association to HolderSpecCharSpec
	@OneToMany(mappedBy="specType")
	private List<HolderSpecCharSpec> holderSpecCharSpecs;

	//bi-directional many-to-one association to HolderSpecCharSpecRel
	@OneToMany(mappedBy="specType")
	private List<HolderSpecCharSpecRel> holderSpecCharSpecRels;

	//bi-directional many-to-one association to HolderSpecCharValueSpec
	@OneToMany(mappedBy="specType")
	private List<HolderSpecCharValueSpec> holderSpecCharValueSpecs;

	//bi-directional many-to-one association to PortSpec
	@OneToMany(mappedBy="specType")
	private List<PortSpec> portSpecs;

	//bi-directional many-to-one association to PortSpecCharSpec
	@OneToMany(mappedBy="specType")
	private List<PortSpecCharSpec> portSpecCharSpecs;

	//bi-directional many-to-one association to PortSpecCharSpecRel
	@OneToMany(mappedBy="specType")
	private List<PortSpecCharSpecRel> portSpecCharSpecRels;

	//bi-directional many-to-one association to PortSpecCharValueSpec
	@OneToMany(mappedBy="specType")
	private List<PortSpecCharValueSpec> portSpecCharValueSpecs;

	//bi-directional many-to-one association to SpanSpec
	@OneToMany(mappedBy="specType")
	private List<SpanSpec> spanSpecs;

	//bi-directional many-to-one association to SpanSpecCharSpec
	@OneToMany(mappedBy="specType")
	private List<SpanSpecCharSpec> spanSpecCharSpecs;

	//bi-directional many-to-one association to SpanSpecCharSpecRel
	@OneToMany(mappedBy="specType")
	private List<SpanSpecCharSpecRel> spanSpecCharSpecRels;

	//bi-directional many-to-one association to SpanSpecCharValueSpec
	@OneToMany(mappedBy="specType")
	private List<SpanSpecCharValueSpec> spanSpecCharValueSpecs;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to StructureSpanCompatSpec
	@OneToMany(mappedBy="specType1")
	private List<StructureSpanCompatSpec> structureSpanCompatSpecs1;

	//bi-directional many-to-one association to StructureSpanCompatSpec
	@OneToMany(mappedBy="specType2")
	private List<StructureSpanCompatSpec> structureSpanCompatSpecs2;

	//bi-directional many-to-one association to StructureSpec
	@OneToMany(mappedBy="specType")
	private List<StructureSpec> structureSpecs;

	//bi-directional many-to-one association to StructureSpecCharSpec
	@OneToMany(mappedBy="specType")
	private List<StructureSpecCharSpec> structureSpecCharSpecs;

	//bi-directional many-to-one association to StructureSpecCharSpecRel
	@OneToMany(mappedBy="specType")
	private List<StructureSpecCharSpecRel> structureSpecCharSpecRels;

	//bi-directional many-to-one association to StructureSpecCharValueSpec
	@OneToMany(mappedBy="specType")
	private List<StructureSpecCharValueSpec> structureSpecCharValueSpecs;

	public SpecType() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public List<CableCbAssocSpec> getCableCbAssocSpecs1() {
		return this.cableCbAssocSpecs1;
	}

	public void setCableCbAssocSpecs1(List<CableCbAssocSpec> cableCbAssocSpecs1) {
		this.cableCbAssocSpecs1 = cableCbAssocSpecs1;
	}

	public CableCbAssocSpec addCableCbAssocSpecs1(CableCbAssocSpec cableCbAssocSpecs1) {
		getCableCbAssocSpecs1().add(cableCbAssocSpecs1);
		cableCbAssocSpecs1.setSpecType1(this);

		return cableCbAssocSpecs1;
	}

	public CableCbAssocSpec removeCableCbAssocSpecs1(CableCbAssocSpec cableCbAssocSpecs1) {
		getCableCbAssocSpecs1().remove(cableCbAssocSpecs1);
		cableCbAssocSpecs1.setSpecType1(null);

		return cableCbAssocSpecs1;
	}

	public List<CableCbAssocSpec> getCableCbAssocSpecs2() {
		return this.cableCbAssocSpecs2;
	}

	public void setCableCbAssocSpecs2(List<CableCbAssocSpec> cableCbAssocSpecs2) {
		this.cableCbAssocSpecs2 = cableCbAssocSpecs2;
	}

	public CableCbAssocSpec addCableCbAssocSpecs2(CableCbAssocSpec cableCbAssocSpecs2) {
		getCableCbAssocSpecs2().add(cableCbAssocSpecs2);
		cableCbAssocSpecs2.setSpecType2(this);

		return cableCbAssocSpecs2;
	}

	public CableCbAssocSpec removeCableCbAssocSpecs2(CableCbAssocSpec cableCbAssocSpecs2) {
		getCableCbAssocSpecs2().remove(cableCbAssocSpecs2);
		cableCbAssocSpecs2.setSpecType2(null);

		return cableCbAssocSpecs2;
	}

	public List<CableCharSpecRel> getCableCharSpecRels() {
		return this.cableCharSpecRels;
	}

	public void setCableCharSpecRels(List<CableCharSpecRel> cableCharSpecRels) {
		this.cableCharSpecRels = cableCharSpecRels;
	}

	public CableCharSpecRel addCableCharSpecRel(CableCharSpecRel cableCharSpecRel) {
		getCableCharSpecRels().add(cableCharSpecRel);
		cableCharSpecRel.setSpecType(this);

		return cableCharSpecRel;
	}

	public CableCharSpecRel removeCableCharSpecRel(CableCharSpecRel cableCharSpecRel) {
		getCableCharSpecRels().remove(cableCharSpecRel);
		cableCharSpecRel.setSpecType(null);

		return cableCharSpecRel;
	}

	public List<CableCondAssocSpec> getCableCondAssocSpecs1() {
		return this.cableCondAssocSpecs1;
	}

	public void setCableCondAssocSpecs1(List<CableCondAssocSpec> cableCondAssocSpecs1) {
		this.cableCondAssocSpecs1 = cableCondAssocSpecs1;
	}

	public CableCondAssocSpec addCableCondAssocSpecs1(CableCondAssocSpec cableCondAssocSpecs1) {
		getCableCondAssocSpecs1().add(cableCondAssocSpecs1);
		cableCondAssocSpecs1.setSpecType1(this);

		return cableCondAssocSpecs1;
	}

	public CableCondAssocSpec removeCableCondAssocSpecs1(CableCondAssocSpec cableCondAssocSpecs1) {
		getCableCondAssocSpecs1().remove(cableCondAssocSpecs1);
		cableCondAssocSpecs1.setSpecType1(null);

		return cableCondAssocSpecs1;
	}

	public List<CableCondAssocSpec> getCableCondAssocSpecs2() {
		return this.cableCondAssocSpecs2;
	}

	public void setCableCondAssocSpecs2(List<CableCondAssocSpec> cableCondAssocSpecs2) {
		this.cableCondAssocSpecs2 = cableCondAssocSpecs2;
	}

	public CableCondAssocSpec addCableCondAssocSpecs2(CableCondAssocSpec cableCondAssocSpecs2) {
		getCableCondAssocSpecs2().add(cableCondAssocSpecs2);
		cableCondAssocSpecs2.setSpecType2(this);

		return cableCondAssocSpecs2;
	}

	public CableCondAssocSpec removeCableCondAssocSpecs2(CableCondAssocSpec cableCondAssocSpecs2) {
		getCableCondAssocSpecs2().remove(cableCondAssocSpecs2);
		cableCondAssocSpecs2.setSpecType2(null);

		return cableCondAssocSpecs2;
	}

	public List<CableHierarchySpec> getCableHierarchySpecs() {
		return this.cableHierarchySpecs;
	}

	public void setCableHierarchySpecs(List<CableHierarchySpec> cableHierarchySpecs) {
		this.cableHierarchySpecs = cableHierarchySpecs;
	}

	public CableHierarchySpec addCableHierarchySpec(CableHierarchySpec cableHierarchySpec) {
		getCableHierarchySpecs().add(cableHierarchySpec);
		cableHierarchySpec.setSpecType(this);

		return cableHierarchySpec;
	}

	public CableHierarchySpec removeCableHierarchySpec(CableHierarchySpec cableHierarchySpec) {
		getCableHierarchySpecs().remove(cableHierarchySpec);
		cableHierarchySpec.setSpecType(null);

		return cableHierarchySpec;
	}

	public List<CableSpanCompatSpec> getCableSpanCompatSpecs1() {
		return this.cableSpanCompatSpecs1;
	}

	public void setCableSpanCompatSpecs1(List<CableSpanCompatSpec> cableSpanCompatSpecs1) {
		this.cableSpanCompatSpecs1 = cableSpanCompatSpecs1;
	}

	public CableSpanCompatSpec addCableSpanCompatSpecs1(CableSpanCompatSpec cableSpanCompatSpecs1) {
		getCableSpanCompatSpecs1().add(cableSpanCompatSpecs1);
		cableSpanCompatSpecs1.setSpecType1(this);

		return cableSpanCompatSpecs1;
	}

	public CableSpanCompatSpec removeCableSpanCompatSpecs1(CableSpanCompatSpec cableSpanCompatSpecs1) {
		getCableSpanCompatSpecs1().remove(cableSpanCompatSpecs1);
		cableSpanCompatSpecs1.setSpecType1(null);

		return cableSpanCompatSpecs1;
	}

	public List<CableSpanCompatSpec> getCableSpanCompatSpecs2() {
		return this.cableSpanCompatSpecs2;
	}

	public void setCableSpanCompatSpecs2(List<CableSpanCompatSpec> cableSpanCompatSpecs2) {
		this.cableSpanCompatSpecs2 = cableSpanCompatSpecs2;
	}

	public CableSpanCompatSpec addCableSpanCompatSpecs2(CableSpanCompatSpec cableSpanCompatSpecs2) {
		getCableSpanCompatSpecs2().add(cableSpanCompatSpecs2);
		cableSpanCompatSpecs2.setSpecType2(this);

		return cableSpanCompatSpecs2;
	}

	public CableSpanCompatSpec removeCableSpanCompatSpecs2(CableSpanCompatSpec cableSpanCompatSpecs2) {
		getCableSpanCompatSpecs2().remove(cableSpanCompatSpecs2);
		cableSpanCompatSpecs2.setSpecType2(null);

		return cableSpanCompatSpecs2;
	}

	public List<CableSpec> getCableSpecs() {
		return this.cableSpecs;
	}

	public void setCableSpecs(List<CableSpec> cableSpecs) {
		this.cableSpecs = cableSpecs;
	}

	public CableSpec addCableSpec(CableSpec cableSpec) {
		getCableSpecs().add(cableSpec);
		cableSpec.setSpecType(this);

		return cableSpec;
	}

	public CableSpec removeCableSpec(CableSpec cableSpec) {
		getCableSpecs().remove(cableSpec);
		cableSpec.setSpecType(null);

		return cableSpec;
	}

	public List<CableSpecCharSpec> getCableSpecCharSpecs() {
		return this.cableSpecCharSpecs;
	}

	public void setCableSpecCharSpecs(List<CableSpecCharSpec> cableSpecCharSpecs) {
		this.cableSpecCharSpecs = cableSpecCharSpecs;
	}

	public CableSpecCharSpec addCableSpecCharSpec(CableSpecCharSpec cableSpecCharSpec) {
		getCableSpecCharSpecs().add(cableSpecCharSpec);
		cableSpecCharSpec.setSpecType(this);

		return cableSpecCharSpec;
	}

	public CableSpecCharSpec removeCableSpecCharSpec(CableSpecCharSpec cableSpecCharSpec) {
		getCableSpecCharSpecs().remove(cableSpecCharSpec);
		cableSpecCharSpec.setSpecType(null);

		return cableSpecCharSpec;
	}

	public List<CableSpecCharValueSpec> getCableSpecCharValueSpecs() {
		return this.cableSpecCharValueSpecs;
	}

	public void setCableSpecCharValueSpecs(List<CableSpecCharValueSpec> cableSpecCharValueSpecs) {
		this.cableSpecCharValueSpecs = cableSpecCharValueSpecs;
	}

	public CableSpecCharValueSpec addCableSpecCharValueSpec(CableSpecCharValueSpec cableSpecCharValueSpec) {
		getCableSpecCharValueSpecs().add(cableSpecCharValueSpec);
		cableSpecCharValueSpec.setSpecType(this);

		return cableSpecCharValueSpec;
	}

	public CableSpecCharValueSpec removeCableSpecCharValueSpec(CableSpecCharValueSpec cableSpecCharValueSpec) {
		getCableSpecCharValueSpecs().remove(cableSpecCharValueSpec);
		cableSpecCharValueSpec.setSpecType(null);

		return cableSpecCharValueSpec;
	}

	public List<CbCondAssocSpec> getCbCondAssocSpecs1() {
		return this.cbCondAssocSpecs1;
	}

	public void setCbCondAssocSpecs1(List<CbCondAssocSpec> cbCondAssocSpecs1) {
		this.cbCondAssocSpecs1 = cbCondAssocSpecs1;
	}

	public CbCondAssocSpec addCbCondAssocSpecs1(CbCondAssocSpec cbCondAssocSpecs1) {
		getCbCondAssocSpecs1().add(cbCondAssocSpecs1);
		cbCondAssocSpecs1.setSpecType1(this);

		return cbCondAssocSpecs1;
	}

	public CbCondAssocSpec removeCbCondAssocSpecs1(CbCondAssocSpec cbCondAssocSpecs1) {
		getCbCondAssocSpecs1().remove(cbCondAssocSpecs1);
		cbCondAssocSpecs1.setSpecType1(null);

		return cbCondAssocSpecs1;
	}

	public List<CbCondAssocSpec> getCbCondAssocSpecs2() {
		return this.cbCondAssocSpecs2;
	}

	public void setCbCondAssocSpecs2(List<CbCondAssocSpec> cbCondAssocSpecs2) {
		this.cbCondAssocSpecs2 = cbCondAssocSpecs2;
	}

	public CbCondAssocSpec addCbCondAssocSpecs2(CbCondAssocSpec cbCondAssocSpecs2) {
		getCbCondAssocSpecs2().add(cbCondAssocSpecs2);
		cbCondAssocSpecs2.setSpecType2(this);

		return cbCondAssocSpecs2;
	}

	public CbCondAssocSpec removeCbCondAssocSpecs2(CbCondAssocSpec cbCondAssocSpecs2) {
		getCbCondAssocSpecs2().remove(cbCondAssocSpecs2);
		cbCondAssocSpecs2.setSpecType2(null);

		return cbCondAssocSpecs2;
	}

	public List<CbSpec> getCbSpecs() {
		return this.cbSpecs;
	}

	public void setCbSpecs(List<CbSpec> cbSpecs) {
		this.cbSpecs = cbSpecs;
	}

	public CbSpec addCbSpec(CbSpec cbSpec) {
		getCbSpecs().add(cbSpec);
		cbSpec.setSpecType(this);

		return cbSpec;
	}

	public CbSpec removeCbSpec(CbSpec cbSpec) {
		getCbSpecs().remove(cbSpec);
		cbSpec.setSpecType(null);

		return cbSpec;
	}

	public List<CbSpecCharSpec> getCbSpecCharSpecs() {
		return this.cbSpecCharSpecs;
	}

	public void setCbSpecCharSpecs(List<CbSpecCharSpec> cbSpecCharSpecs) {
		this.cbSpecCharSpecs = cbSpecCharSpecs;
	}

	public CbSpecCharSpec addCbSpecCharSpec(CbSpecCharSpec cbSpecCharSpec) {
		getCbSpecCharSpecs().add(cbSpecCharSpec);
		cbSpecCharSpec.setSpecType(this);

		return cbSpecCharSpec;
	}

	public CbSpecCharSpec removeCbSpecCharSpec(CbSpecCharSpec cbSpecCharSpec) {
		getCbSpecCharSpecs().remove(cbSpecCharSpec);
		cbSpecCharSpec.setSpecType(null);

		return cbSpecCharSpec;
	}

	public List<CbSpecCharSpecRel> getCbSpecCharSpecRels() {
		return this.cbSpecCharSpecRels;
	}

	public void setCbSpecCharSpecRels(List<CbSpecCharSpecRel> cbSpecCharSpecRels) {
		this.cbSpecCharSpecRels = cbSpecCharSpecRels;
	}

	public CbSpecCharSpecRel addCbSpecCharSpecRel(CbSpecCharSpecRel cbSpecCharSpecRel) {
		getCbSpecCharSpecRels().add(cbSpecCharSpecRel);
		cbSpecCharSpecRel.setSpecType(this);

		return cbSpecCharSpecRel;
	}

	public CbSpecCharSpecRel removeCbSpecCharSpecRel(CbSpecCharSpecRel cbSpecCharSpecRel) {
		getCbSpecCharSpecRels().remove(cbSpecCharSpecRel);
		cbSpecCharSpecRel.setSpecType(null);

		return cbSpecCharSpecRel;
	}

	public List<CbSpecCharValueSpec> getCbSpecCharValueSpecs() {
		return this.cbSpecCharValueSpecs;
	}

	public void setCbSpecCharValueSpecs(List<CbSpecCharValueSpec> cbSpecCharValueSpecs) {
		this.cbSpecCharValueSpecs = cbSpecCharValueSpecs;
	}

	public CbSpecCharValueSpec addCbSpecCharValueSpec(CbSpecCharValueSpec cbSpecCharValueSpec) {
		getCbSpecCharValueSpecs().add(cbSpecCharValueSpec);
		cbSpecCharValueSpec.setSpecType(this);

		return cbSpecCharValueSpec;
	}

	public CbSpecCharValueSpec removeCbSpecCharValueSpec(CbSpecCharValueSpec cbSpecCharValueSpec) {
		getCbSpecCharValueSpecs().remove(cbSpecCharValueSpec);
		cbSpecCharValueSpec.setSpecType(null);

		return cbSpecCharValueSpec;
	}

	public List<ConductorSpec> getConductorSpecs() {
		return this.conductorSpecs;
	}

	public void setConductorSpecs(List<ConductorSpec> conductorSpecs) {
		this.conductorSpecs = conductorSpecs;
	}

	public ConductorSpec addConductorSpec(ConductorSpec conductorSpec) {
		getConductorSpecs().add(conductorSpec);
		conductorSpec.setSpecType(this);

		return conductorSpec;
	}

	public ConductorSpec removeConductorSpec(ConductorSpec conductorSpec) {
		getConductorSpecs().remove(conductorSpec);
		conductorSpec.setSpecType(null);

		return conductorSpec;
	}

	public List<CondSpecCharSpec> getCondSpecCharSpecs() {
		return this.condSpecCharSpecs;
	}

	public void setCondSpecCharSpecs(List<CondSpecCharSpec> condSpecCharSpecs) {
		this.condSpecCharSpecs = condSpecCharSpecs;
	}

	public CondSpecCharSpec addCondSpecCharSpec(CondSpecCharSpec condSpecCharSpec) {
		getCondSpecCharSpecs().add(condSpecCharSpec);
		condSpecCharSpec.setSpecType(this);

		return condSpecCharSpec;
	}

	public CondSpecCharSpec removeCondSpecCharSpec(CondSpecCharSpec condSpecCharSpec) {
		getCondSpecCharSpecs().remove(condSpecCharSpec);
		condSpecCharSpec.setSpecType(null);

		return condSpecCharSpec;
	}

	public List<CondSpecCharSpecRel> getCondSpecCharSpecRels() {
		return this.condSpecCharSpecRels;
	}

	public void setCondSpecCharSpecRels(List<CondSpecCharSpecRel> condSpecCharSpecRels) {
		this.condSpecCharSpecRels = condSpecCharSpecRels;
	}

	public CondSpecCharSpecRel addCondSpecCharSpecRel(CondSpecCharSpecRel condSpecCharSpecRel) {
		getCondSpecCharSpecRels().add(condSpecCharSpecRel);
		condSpecCharSpecRel.setSpecType(this);

		return condSpecCharSpecRel;
	}

	public CondSpecCharSpecRel removeCondSpecCharSpecRel(CondSpecCharSpecRel condSpecCharSpecRel) {
		getCondSpecCharSpecRels().remove(condSpecCharSpecRel);
		condSpecCharSpecRel.setSpecType(null);

		return condSpecCharSpecRel;
	}

	public List<CondSpecCharValueSpec> getCondSpecCharValueSpecs() {
		return this.condSpecCharValueSpecs;
	}

	public void setCondSpecCharValueSpecs(List<CondSpecCharValueSpec> condSpecCharValueSpecs) {
		this.condSpecCharValueSpecs = condSpecCharValueSpecs;
	}

	public CondSpecCharValueSpec addCondSpecCharValueSpec(CondSpecCharValueSpec condSpecCharValueSpec) {
		getCondSpecCharValueSpecs().add(condSpecCharValueSpec);
		condSpecCharValueSpec.setSpecType(this);

		return condSpecCharValueSpec;
	}

	public CondSpecCharValueSpec removeCondSpecCharValueSpec(CondSpecCharValueSpec condSpecCharValueSpec) {
		getCondSpecCharValueSpecs().remove(condSpecCharValueSpec);
		condSpecCharValueSpec.setSpecType(null);

		return condSpecCharValueSpec;
	}

	public List<ConnectorSpec> getConnectorSpecs() {
		return this.connectorSpecs;
	}

	public void setConnectorSpecs(List<ConnectorSpec> connectorSpecs) {
		this.connectorSpecs = connectorSpecs;
	}

	public ConnectorSpec addConnectorSpec(ConnectorSpec connectorSpec) {
		getConnectorSpecs().add(connectorSpec);
		connectorSpec.setSpecType(this);

		return connectorSpec;
	}

	public ConnectorSpec removeConnectorSpec(ConnectorSpec connectorSpec) {
		getConnectorSpecs().remove(connectorSpec);
		connectorSpec.setSpecType(null);

		return connectorSpec;
	}

	public List<ConnectorSpecCharSpec> getConnectorSpecCharSpecs() {
		return this.connectorSpecCharSpecs;
	}

	public void setConnectorSpecCharSpecs(List<ConnectorSpecCharSpec> connectorSpecCharSpecs) {
		this.connectorSpecCharSpecs = connectorSpecCharSpecs;
	}

	public ConnectorSpecCharSpec addConnectorSpecCharSpec(ConnectorSpecCharSpec connectorSpecCharSpec) {
		getConnectorSpecCharSpecs().add(connectorSpecCharSpec);
		connectorSpecCharSpec.setSpecType(this);

		return connectorSpecCharSpec;
	}

	public ConnectorSpecCharSpec removeConnectorSpecCharSpec(ConnectorSpecCharSpec connectorSpecCharSpec) {
		getConnectorSpecCharSpecs().remove(connectorSpecCharSpec);
		connectorSpecCharSpec.setSpecType(null);

		return connectorSpecCharSpec;
	}

	public List<ConnectorSpecCharSpecRel> getConnectorSpecCharSpecRels() {
		return this.connectorSpecCharSpecRels;
	}

	public void setConnectorSpecCharSpecRels(List<ConnectorSpecCharSpecRel> connectorSpecCharSpecRels) {
		this.connectorSpecCharSpecRels = connectorSpecCharSpecRels;
	}

	public ConnectorSpecCharSpecRel addConnectorSpecCharSpecRel(ConnectorSpecCharSpecRel connectorSpecCharSpecRel) {
		getConnectorSpecCharSpecRels().add(connectorSpecCharSpecRel);
		connectorSpecCharSpecRel.setSpecType(this);

		return connectorSpecCharSpecRel;
	}

	public ConnectorSpecCharSpecRel removeConnectorSpecCharSpecRel(ConnectorSpecCharSpecRel connectorSpecCharSpecRel) {
		getConnectorSpecCharSpecRels().remove(connectorSpecCharSpecRel);
		connectorSpecCharSpecRel.setSpecType(null);

		return connectorSpecCharSpecRel;
	}

	public List<ConnectorSpecCharValueSpec> getConnectorSpecCharValueSpecs() {
		return this.connectorSpecCharValueSpecs;
	}

	public void setConnectorSpecCharValueSpecs(List<ConnectorSpecCharValueSpec> connectorSpecCharValueSpecs) {
		this.connectorSpecCharValueSpecs = connectorSpecCharValueSpecs;
	}

	public ConnectorSpecCharValueSpec addConnectorSpecCharValueSpec(ConnectorSpecCharValueSpec connectorSpecCharValueSpec) {
		getConnectorSpecCharValueSpecs().add(connectorSpecCharValueSpec);
		connectorSpecCharValueSpec.setSpecType(this);

		return connectorSpecCharValueSpec;
	}

	public ConnectorSpecCharValueSpec removeConnectorSpecCharValueSpec(ConnectorSpecCharValueSpec connectorSpecCharValueSpec) {
		getConnectorSpecCharValueSpecs().remove(connectorSpecCharValueSpec);
		connectorSpecCharValueSpec.setSpecType(null);

		return connectorSpecCharValueSpec;
	}

	public List<DeviceCableCompatSpec> getDeviceCableCompatSpecs1() {
		return this.deviceCableCompatSpecs1;
	}

	public void setDeviceCableCompatSpecs1(List<DeviceCableCompatSpec> deviceCableCompatSpecs1) {
		this.deviceCableCompatSpecs1 = deviceCableCompatSpecs1;
	}

	public DeviceCableCompatSpec addDeviceCableCompatSpecs1(DeviceCableCompatSpec deviceCableCompatSpecs1) {
		getDeviceCableCompatSpecs1().add(deviceCableCompatSpecs1);
		deviceCableCompatSpecs1.setSpecType1(this);

		return deviceCableCompatSpecs1;
	}

	public DeviceCableCompatSpec removeDeviceCableCompatSpecs1(DeviceCableCompatSpec deviceCableCompatSpecs1) {
		getDeviceCableCompatSpecs1().remove(deviceCableCompatSpecs1);
		deviceCableCompatSpecs1.setSpecType1(null);

		return deviceCableCompatSpecs1;
	}

	public List<DeviceCableCompatSpec> getDeviceCableCompatSpecs2() {
		return this.deviceCableCompatSpecs2;
	}

	public void setDeviceCableCompatSpecs2(List<DeviceCableCompatSpec> deviceCableCompatSpecs2) {
		this.deviceCableCompatSpecs2 = deviceCableCompatSpecs2;
	}

	public DeviceCableCompatSpec addDeviceCableCompatSpecs2(DeviceCableCompatSpec deviceCableCompatSpecs2) {
		getDeviceCableCompatSpecs2().add(deviceCableCompatSpecs2);
		deviceCableCompatSpecs2.setSpecType2(this);

		return deviceCableCompatSpecs2;
	}

	public DeviceCableCompatSpec removeDeviceCableCompatSpecs2(DeviceCableCompatSpec deviceCableCompatSpecs2) {
		getDeviceCableCompatSpecs2().remove(deviceCableCompatSpecs2);
		deviceCableCompatSpecs2.setSpecType2(null);

		return deviceCableCompatSpecs2;
	}

	public List<DeviceCompHolderAssocSpec> getDeviceCompHolderAssocSpecs1() {
		return this.deviceCompHolderAssocSpecs1;
	}

	public void setDeviceCompHolderAssocSpecs1(List<DeviceCompHolderAssocSpec> deviceCompHolderAssocSpecs1) {
		this.deviceCompHolderAssocSpecs1 = deviceCompHolderAssocSpecs1;
	}

	public DeviceCompHolderAssocSpec addDeviceCompHolderAssocSpecs1(DeviceCompHolderAssocSpec deviceCompHolderAssocSpecs1) {
		getDeviceCompHolderAssocSpecs1().add(deviceCompHolderAssocSpecs1);
		deviceCompHolderAssocSpecs1.setSpecType1(this);

		return deviceCompHolderAssocSpecs1;
	}

	public DeviceCompHolderAssocSpec removeDeviceCompHolderAssocSpecs1(DeviceCompHolderAssocSpec deviceCompHolderAssocSpecs1) {
		getDeviceCompHolderAssocSpecs1().remove(deviceCompHolderAssocSpecs1);
		deviceCompHolderAssocSpecs1.setSpecType1(null);

		return deviceCompHolderAssocSpecs1;
	}

	public List<DeviceCompHolderAssocSpec> getDeviceCompHolderAssocSpecs2() {
		return this.deviceCompHolderAssocSpecs2;
	}

	public void setDeviceCompHolderAssocSpecs2(List<DeviceCompHolderAssocSpec> deviceCompHolderAssocSpecs2) {
		this.deviceCompHolderAssocSpecs2 = deviceCompHolderAssocSpecs2;
	}

	public DeviceCompHolderAssocSpec addDeviceCompHolderAssocSpecs2(DeviceCompHolderAssocSpec deviceCompHolderAssocSpecs2) {
		getDeviceCompHolderAssocSpecs2().add(deviceCompHolderAssocSpecs2);
		deviceCompHolderAssocSpecs2.setSpecType2(this);

		return deviceCompHolderAssocSpecs2;
	}

	public DeviceCompHolderAssocSpec removeDeviceCompHolderAssocSpecs2(DeviceCompHolderAssocSpec deviceCompHolderAssocSpecs2) {
		getDeviceCompHolderAssocSpecs2().remove(deviceCompHolderAssocSpecs2);
		deviceCompHolderAssocSpecs2.setSpecType2(null);

		return deviceCompHolderAssocSpecs2;
	}

	public List<DeviceCompHolderAssocSpec> getDeviceCompHolderAssocSpecs3() {
		return this.deviceCompHolderAssocSpecs3;
	}

	public void setDeviceCompHolderAssocSpecs3(List<DeviceCompHolderAssocSpec> deviceCompHolderAssocSpecs3) {
		this.deviceCompHolderAssocSpecs3 = deviceCompHolderAssocSpecs3;
	}

	public DeviceCompHolderAssocSpec addDeviceCompHolderAssocSpecs3(DeviceCompHolderAssocSpec deviceCompHolderAssocSpecs3) {
		getDeviceCompHolderAssocSpecs3().add(deviceCompHolderAssocSpecs3);
		deviceCompHolderAssocSpecs3.setSpecType3(this);

		return deviceCompHolderAssocSpecs3;
	}

	public DeviceCompHolderAssocSpec removeDeviceCompHolderAssocSpecs3(DeviceCompHolderAssocSpec deviceCompHolderAssocSpecs3) {
		getDeviceCompHolderAssocSpecs3().remove(deviceCompHolderAssocSpecs3);
		deviceCompHolderAssocSpecs3.setSpecType3(null);

		return deviceCompHolderAssocSpecs3;
	}

	public List<DeviceCompPortAssocSpec> getDeviceCompPortAssocSpecs1() {
		return this.deviceCompPortAssocSpecs1;
	}

	public void setDeviceCompPortAssocSpecs1(List<DeviceCompPortAssocSpec> deviceCompPortAssocSpecs1) {
		this.deviceCompPortAssocSpecs1 = deviceCompPortAssocSpecs1;
	}

	public DeviceCompPortAssocSpec addDeviceCompPortAssocSpecs1(DeviceCompPortAssocSpec deviceCompPortAssocSpecs1) {
		getDeviceCompPortAssocSpecs1().add(deviceCompPortAssocSpecs1);
		deviceCompPortAssocSpecs1.setSpecType1(this);

		return deviceCompPortAssocSpecs1;
	}

	public DeviceCompPortAssocSpec removeDeviceCompPortAssocSpecs1(DeviceCompPortAssocSpec deviceCompPortAssocSpecs1) {
		getDeviceCompPortAssocSpecs1().remove(deviceCompPortAssocSpecs1);
		deviceCompPortAssocSpecs1.setSpecType1(null);

		return deviceCompPortAssocSpecs1;
	}

	public List<DeviceCompPortAssocSpec> getDeviceCompPortAssocSpecs2() {
		return this.deviceCompPortAssocSpecs2;
	}

	public void setDeviceCompPortAssocSpecs2(List<DeviceCompPortAssocSpec> deviceCompPortAssocSpecs2) {
		this.deviceCompPortAssocSpecs2 = deviceCompPortAssocSpecs2;
	}

	public DeviceCompPortAssocSpec addDeviceCompPortAssocSpecs2(DeviceCompPortAssocSpec deviceCompPortAssocSpecs2) {
		getDeviceCompPortAssocSpecs2().add(deviceCompPortAssocSpecs2);
		deviceCompPortAssocSpecs2.setSpecType2(this);

		return deviceCompPortAssocSpecs2;
	}

	public DeviceCompPortAssocSpec removeDeviceCompPortAssocSpecs2(DeviceCompPortAssocSpec deviceCompPortAssocSpecs2) {
		getDeviceCompPortAssocSpecs2().remove(deviceCompPortAssocSpecs2);
		deviceCompPortAssocSpecs2.setSpecType2(null);

		return deviceCompPortAssocSpecs2;
	}

	public List<DeviceCompPortAssocSpec> getDeviceCompPortAssocSpecs3() {
		return this.deviceCompPortAssocSpecs3;
	}

	public void setDeviceCompPortAssocSpecs3(List<DeviceCompPortAssocSpec> deviceCompPortAssocSpecs3) {
		this.deviceCompPortAssocSpecs3 = deviceCompPortAssocSpecs3;
	}

	public DeviceCompPortAssocSpec addDeviceCompPortAssocSpecs3(DeviceCompPortAssocSpec deviceCompPortAssocSpecs3) {
		getDeviceCompPortAssocSpecs3().add(deviceCompPortAssocSpecs3);
		deviceCompPortAssocSpecs3.setSpecType3(this);

		return deviceCompPortAssocSpecs3;
	}

	public DeviceCompPortAssocSpec removeDeviceCompPortAssocSpecs3(DeviceCompPortAssocSpec deviceCompPortAssocSpecs3) {
		getDeviceCompPortAssocSpecs3().remove(deviceCompPortAssocSpecs3);
		deviceCompPortAssocSpecs3.setSpecType3(null);

		return deviceCompPortAssocSpecs3;
	}

	public List<DeviceHierarchySpec> getDeviceHierarchySpecs() {
		return this.deviceHierarchySpecs;
	}

	public void setDeviceHierarchySpecs(List<DeviceHierarchySpec> deviceHierarchySpecs) {
		this.deviceHierarchySpecs = deviceHierarchySpecs;
	}

	public DeviceHierarchySpec addDeviceHierarchySpec(DeviceHierarchySpec deviceHierarchySpec) {
		getDeviceHierarchySpecs().add(deviceHierarchySpec);
		deviceHierarchySpec.setSpecType(this);

		return deviceHierarchySpec;
	}

	public DeviceHierarchySpec removeDeviceHierarchySpec(DeviceHierarchySpec deviceHierarchySpec) {
		getDeviceHierarchySpecs().remove(deviceHierarchySpec);
		deviceHierarchySpec.setSpecType(null);

		return deviceHierarchySpec;
	}

	public List<DeviceHolderCompAssocSpec> getDeviceHolderCompAssocSpecs1() {
		return this.deviceHolderCompAssocSpecs1;
	}

	public void setDeviceHolderCompAssocSpecs1(List<DeviceHolderCompAssocSpec> deviceHolderCompAssocSpecs1) {
		this.deviceHolderCompAssocSpecs1 = deviceHolderCompAssocSpecs1;
	}

	public DeviceHolderCompAssocSpec addDeviceHolderCompAssocSpecs1(DeviceHolderCompAssocSpec deviceHolderCompAssocSpecs1) {
		getDeviceHolderCompAssocSpecs1().add(deviceHolderCompAssocSpecs1);
		deviceHolderCompAssocSpecs1.setSpecType1(this);

		return deviceHolderCompAssocSpecs1;
	}

	public DeviceHolderCompAssocSpec removeDeviceHolderCompAssocSpecs1(DeviceHolderCompAssocSpec deviceHolderCompAssocSpecs1) {
		getDeviceHolderCompAssocSpecs1().remove(deviceHolderCompAssocSpecs1);
		deviceHolderCompAssocSpecs1.setSpecType1(null);

		return deviceHolderCompAssocSpecs1;
	}

	public List<DeviceHolderCompAssocSpec> getDeviceHolderCompAssocSpecs2() {
		return this.deviceHolderCompAssocSpecs2;
	}

	public void setDeviceHolderCompAssocSpecs2(List<DeviceHolderCompAssocSpec> deviceHolderCompAssocSpecs2) {
		this.deviceHolderCompAssocSpecs2 = deviceHolderCompAssocSpecs2;
	}

	public DeviceHolderCompAssocSpec addDeviceHolderCompAssocSpecs2(DeviceHolderCompAssocSpec deviceHolderCompAssocSpecs2) {
		getDeviceHolderCompAssocSpecs2().add(deviceHolderCompAssocSpecs2);
		deviceHolderCompAssocSpecs2.setSpecType2(this);

		return deviceHolderCompAssocSpecs2;
	}

	public DeviceHolderCompAssocSpec removeDeviceHolderCompAssocSpecs2(DeviceHolderCompAssocSpec deviceHolderCompAssocSpecs2) {
		getDeviceHolderCompAssocSpecs2().remove(deviceHolderCompAssocSpecs2);
		deviceHolderCompAssocSpecs2.setSpecType2(null);

		return deviceHolderCompAssocSpecs2;
	}

	public List<DeviceHolderCompAssocSpec> getDeviceHolderCompAssocSpecs3() {
		return this.deviceHolderCompAssocSpecs3;
	}

	public void setDeviceHolderCompAssocSpecs3(List<DeviceHolderCompAssocSpec> deviceHolderCompAssocSpecs3) {
		this.deviceHolderCompAssocSpecs3 = deviceHolderCompAssocSpecs3;
	}

	public DeviceHolderCompAssocSpec addDeviceHolderCompAssocSpecs3(DeviceHolderCompAssocSpec deviceHolderCompAssocSpecs3) {
		getDeviceHolderCompAssocSpecs3().add(deviceHolderCompAssocSpecs3);
		deviceHolderCompAssocSpecs3.setSpecType3(this);

		return deviceHolderCompAssocSpecs3;
	}

	public DeviceHolderCompAssocSpec removeDeviceHolderCompAssocSpecs3(DeviceHolderCompAssocSpec deviceHolderCompAssocSpecs3) {
		getDeviceHolderCompAssocSpecs3().remove(deviceHolderCompAssocSpecs3);
		deviceHolderCompAssocSpecs3.setSpecType3(null);

		return deviceHolderCompAssocSpecs3;
	}

	public List<DevicePortPortAssocSpec> getDevicePortPortAssocSpecs() {
		return this.devicePortPortAssocSpecs;
	}

	public void setDevicePortPortAssocSpecs(List<DevicePortPortAssocSpec> devicePortPortAssocSpecs) {
		this.devicePortPortAssocSpecs = devicePortPortAssocSpecs;
	}

	public DevicePortPortAssocSpec addDevicePortPortAssocSpec(DevicePortPortAssocSpec devicePortPortAssocSpec) {
		getDevicePortPortAssocSpecs().add(devicePortPortAssocSpec);
		devicePortPortAssocSpec.setSpecType(this);

		return devicePortPortAssocSpec;
	}

	public DevicePortPortAssocSpec removeDevicePortPortAssocSpec(DevicePortPortAssocSpec devicePortPortAssocSpec) {
		getDevicePortPortAssocSpecs().remove(devicePortPortAssocSpec);
		devicePortPortAssocSpec.setSpecType(null);

		return devicePortPortAssocSpec;
	}

	public List<DeviceSpec> getDeviceSpecs() {
		return this.deviceSpecs;
	}

	public void setDeviceSpecs(List<DeviceSpec> deviceSpecs) {
		this.deviceSpecs = deviceSpecs;
	}

	public DeviceSpec addDeviceSpec(DeviceSpec deviceSpec) {
		getDeviceSpecs().add(deviceSpec);
		deviceSpec.setSpecType(this);

		return deviceSpec;
	}

	public DeviceSpec removeDeviceSpec(DeviceSpec deviceSpec) {
		getDeviceSpecs().remove(deviceSpec);
		deviceSpec.setSpecType(null);

		return deviceSpec;
	}

	public List<DeviceSpecCharSpec> getDeviceSpecCharSpecs() {
		return this.deviceSpecCharSpecs;
	}

	public void setDeviceSpecCharSpecs(List<DeviceSpecCharSpec> deviceSpecCharSpecs) {
		this.deviceSpecCharSpecs = deviceSpecCharSpecs;
	}

	public DeviceSpecCharSpec addDeviceSpecCharSpec(DeviceSpecCharSpec deviceSpecCharSpec) {
		getDeviceSpecCharSpecs().add(deviceSpecCharSpec);
		deviceSpecCharSpec.setSpecType(this);

		return deviceSpecCharSpec;
	}

	public DeviceSpecCharSpec removeDeviceSpecCharSpec(DeviceSpecCharSpec deviceSpecCharSpec) {
		getDeviceSpecCharSpecs().remove(deviceSpecCharSpec);
		deviceSpecCharSpec.setSpecType(null);

		return deviceSpecCharSpec;
	}

	public List<DeviceSpecCharSpecRel> getDeviceSpecCharSpecRels() {
		return this.deviceSpecCharSpecRels;
	}

	public void setDeviceSpecCharSpecRels(List<DeviceSpecCharSpecRel> deviceSpecCharSpecRels) {
		this.deviceSpecCharSpecRels = deviceSpecCharSpecRels;
	}

	public DeviceSpecCharSpecRel addDeviceSpecCharSpecRel(DeviceSpecCharSpecRel deviceSpecCharSpecRel) {
		getDeviceSpecCharSpecRels().add(deviceSpecCharSpecRel);
		deviceSpecCharSpecRel.setSpecType(this);

		return deviceSpecCharSpecRel;
	}

	public DeviceSpecCharSpecRel removeDeviceSpecCharSpecRel(DeviceSpecCharSpecRel deviceSpecCharSpecRel) {
		getDeviceSpecCharSpecRels().remove(deviceSpecCharSpecRel);
		deviceSpecCharSpecRel.setSpecType(null);

		return deviceSpecCharSpecRel;
	}

	public List<DeviceSpecCharValueSpec> getDeviceSpecCharValueSpecs() {
		return this.deviceSpecCharValueSpecs;
	}

	public void setDeviceSpecCharValueSpecs(List<DeviceSpecCharValueSpec> deviceSpecCharValueSpecs) {
		this.deviceSpecCharValueSpecs = deviceSpecCharValueSpecs;
	}

	public DeviceSpecCharValueSpec addDeviceSpecCharValueSpec(DeviceSpecCharValueSpec deviceSpecCharValueSpec) {
		getDeviceSpecCharValueSpecs().add(deviceSpecCharValueSpec);
		deviceSpecCharValueSpec.setSpecType(this);

		return deviceSpecCharValueSpec;
	}

	public DeviceSpecCharValueSpec removeDeviceSpecCharValueSpec(DeviceSpecCharValueSpec deviceSpecCharValueSpec) {
		getDeviceSpecCharValueSpecs().remove(deviceSpecCharValueSpec);
		deviceSpecCharValueSpec.setSpecType(null);

		return deviceSpecCharValueSpec;
	}

	public List<EqCableCompatSpec> getEqCableCompatSpecs1() {
		return this.eqCableCompatSpecs1;
	}

	public void setEqCableCompatSpecs1(List<EqCableCompatSpec> eqCableCompatSpecs1) {
		this.eqCableCompatSpecs1 = eqCableCompatSpecs1;
	}

	public EqCableCompatSpec addEqCableCompatSpecs1(EqCableCompatSpec eqCableCompatSpecs1) {
		getEqCableCompatSpecs1().add(eqCableCompatSpecs1);
		eqCableCompatSpecs1.setSpecType1(this);

		return eqCableCompatSpecs1;
	}

	public EqCableCompatSpec removeEqCableCompatSpecs1(EqCableCompatSpec eqCableCompatSpecs1) {
		getEqCableCompatSpecs1().remove(eqCableCompatSpecs1);
		eqCableCompatSpecs1.setSpecType1(null);

		return eqCableCompatSpecs1;
	}

	public List<EqCableCompatSpec> getEqCableCompatSpecs2() {
		return this.eqCableCompatSpecs2;
	}

	public void setEqCableCompatSpecs2(List<EqCableCompatSpec> eqCableCompatSpecs2) {
		this.eqCableCompatSpecs2 = eqCableCompatSpecs2;
	}

	public EqCableCompatSpec addEqCableCompatSpecs2(EqCableCompatSpec eqCableCompatSpecs2) {
		getEqCableCompatSpecs2().add(eqCableCompatSpecs2);
		eqCableCompatSpecs2.setSpecType2(this);

		return eqCableCompatSpecs2;
	}

	public EqCableCompatSpec removeEqCableCompatSpecs2(EqCableCompatSpec eqCableCompatSpecs2) {
		getEqCableCompatSpecs2().remove(eqCableCompatSpecs2);
		eqCableCompatSpecs2.setSpecType2(null);

		return eqCableCompatSpecs2;
	}

	public List<EqCompHolderAssocSpec> getEqCompHolderAssocSpecs1() {
		return this.eqCompHolderAssocSpecs1;
	}

	public void setEqCompHolderAssocSpecs1(List<EqCompHolderAssocSpec> eqCompHolderAssocSpecs1) {
		this.eqCompHolderAssocSpecs1 = eqCompHolderAssocSpecs1;
	}

	public EqCompHolderAssocSpec addEqCompHolderAssocSpecs1(EqCompHolderAssocSpec eqCompHolderAssocSpecs1) {
		getEqCompHolderAssocSpecs1().add(eqCompHolderAssocSpecs1);
		eqCompHolderAssocSpecs1.setSpecType1(this);

		return eqCompHolderAssocSpecs1;
	}

	public EqCompHolderAssocSpec removeEqCompHolderAssocSpecs1(EqCompHolderAssocSpec eqCompHolderAssocSpecs1) {
		getEqCompHolderAssocSpecs1().remove(eqCompHolderAssocSpecs1);
		eqCompHolderAssocSpecs1.setSpecType1(null);

		return eqCompHolderAssocSpecs1;
	}

	public List<EqCompHolderAssocSpec> getEqCompHolderAssocSpecs2() {
		return this.eqCompHolderAssocSpecs2;
	}

	public void setEqCompHolderAssocSpecs2(List<EqCompHolderAssocSpec> eqCompHolderAssocSpecs2) {
		this.eqCompHolderAssocSpecs2 = eqCompHolderAssocSpecs2;
	}

	public EqCompHolderAssocSpec addEqCompHolderAssocSpecs2(EqCompHolderAssocSpec eqCompHolderAssocSpecs2) {
		getEqCompHolderAssocSpecs2().add(eqCompHolderAssocSpecs2);
		eqCompHolderAssocSpecs2.setSpecType2(this);

		return eqCompHolderAssocSpecs2;
	}

	public EqCompHolderAssocSpec removeEqCompHolderAssocSpecs2(EqCompHolderAssocSpec eqCompHolderAssocSpecs2) {
		getEqCompHolderAssocSpecs2().remove(eqCompHolderAssocSpecs2);
		eqCompHolderAssocSpecs2.setSpecType2(null);

		return eqCompHolderAssocSpecs2;
	}

	public List<EqCompHolderAssocSpec> getEqCompHolderAssocSpecs3() {
		return this.eqCompHolderAssocSpecs3;
	}

	public void setEqCompHolderAssocSpecs3(List<EqCompHolderAssocSpec> eqCompHolderAssocSpecs3) {
		this.eqCompHolderAssocSpecs3 = eqCompHolderAssocSpecs3;
	}

	public EqCompHolderAssocSpec addEqCompHolderAssocSpecs3(EqCompHolderAssocSpec eqCompHolderAssocSpecs3) {
		getEqCompHolderAssocSpecs3().add(eqCompHolderAssocSpecs3);
		eqCompHolderAssocSpecs3.setSpecType3(this);

		return eqCompHolderAssocSpecs3;
	}

	public EqCompHolderAssocSpec removeEqCompHolderAssocSpecs3(EqCompHolderAssocSpec eqCompHolderAssocSpecs3) {
		getEqCompHolderAssocSpecs3().remove(eqCompHolderAssocSpecs3);
		eqCompHolderAssocSpecs3.setSpecType3(null);

		return eqCompHolderAssocSpecs3;
	}

	public List<EqCompPortAssocSpec> getEqCompPortAssocSpecs1() {
		return this.eqCompPortAssocSpecs1;
	}

	public void setEqCompPortAssocSpecs1(List<EqCompPortAssocSpec> eqCompPortAssocSpecs1) {
		this.eqCompPortAssocSpecs1 = eqCompPortAssocSpecs1;
	}

	public EqCompPortAssocSpec addEqCompPortAssocSpecs1(EqCompPortAssocSpec eqCompPortAssocSpecs1) {
		getEqCompPortAssocSpecs1().add(eqCompPortAssocSpecs1);
		eqCompPortAssocSpecs1.setSpecType1(this);

		return eqCompPortAssocSpecs1;
	}

	public EqCompPortAssocSpec removeEqCompPortAssocSpecs1(EqCompPortAssocSpec eqCompPortAssocSpecs1) {
		getEqCompPortAssocSpecs1().remove(eqCompPortAssocSpecs1);
		eqCompPortAssocSpecs1.setSpecType1(null);

		return eqCompPortAssocSpecs1;
	}

	public List<EqCompPortAssocSpec> getEqCompPortAssocSpecs2() {
		return this.eqCompPortAssocSpecs2;
	}

	public void setEqCompPortAssocSpecs2(List<EqCompPortAssocSpec> eqCompPortAssocSpecs2) {
		this.eqCompPortAssocSpecs2 = eqCompPortAssocSpecs2;
	}

	public EqCompPortAssocSpec addEqCompPortAssocSpecs2(EqCompPortAssocSpec eqCompPortAssocSpecs2) {
		getEqCompPortAssocSpecs2().add(eqCompPortAssocSpecs2);
		eqCompPortAssocSpecs2.setSpecType2(this);

		return eqCompPortAssocSpecs2;
	}

	public EqCompPortAssocSpec removeEqCompPortAssocSpecs2(EqCompPortAssocSpec eqCompPortAssocSpecs2) {
		getEqCompPortAssocSpecs2().remove(eqCompPortAssocSpecs2);
		eqCompPortAssocSpecs2.setSpecType2(null);

		return eqCompPortAssocSpecs2;
	}

	public List<EqCompPortAssocSpec> getEqCompPortAssocSpecs3() {
		return this.eqCompPortAssocSpecs3;
	}

	public void setEqCompPortAssocSpecs3(List<EqCompPortAssocSpec> eqCompPortAssocSpecs3) {
		this.eqCompPortAssocSpecs3 = eqCompPortAssocSpecs3;
	}

	public EqCompPortAssocSpec addEqCompPortAssocSpecs3(EqCompPortAssocSpec eqCompPortAssocSpecs3) {
		getEqCompPortAssocSpecs3().add(eqCompPortAssocSpecs3);
		eqCompPortAssocSpecs3.setSpecType3(this);

		return eqCompPortAssocSpecs3;
	}

	public EqCompPortAssocSpec removeEqCompPortAssocSpecs3(EqCompPortAssocSpec eqCompPortAssocSpecs3) {
		getEqCompPortAssocSpecs3().remove(eqCompPortAssocSpecs3);
		eqCompPortAssocSpecs3.setSpecType3(null);

		return eqCompPortAssocSpecs3;
	}

	public List<EqHierarchySpec> getEqHierarchySpecs() {
		return this.eqHierarchySpecs;
	}

	public void setEqHierarchySpecs(List<EqHierarchySpec> eqHierarchySpecs) {
		this.eqHierarchySpecs = eqHierarchySpecs;
	}

	public EqHierarchySpec addEqHierarchySpec(EqHierarchySpec eqHierarchySpec) {
		getEqHierarchySpecs().add(eqHierarchySpec);
		eqHierarchySpec.setSpecType(this);

		return eqHierarchySpec;
	}

	public EqHierarchySpec removeEqHierarchySpec(EqHierarchySpec eqHierarchySpec) {
		getEqHierarchySpecs().remove(eqHierarchySpec);
		eqHierarchySpec.setSpecType(null);

		return eqHierarchySpec;
	}

	public List<EqHolderCompAssocSpec> getEqHolderCompAssocSpecs1() {
		return this.eqHolderCompAssocSpecs1;
	}

	public void setEqHolderCompAssocSpecs1(List<EqHolderCompAssocSpec> eqHolderCompAssocSpecs1) {
		this.eqHolderCompAssocSpecs1 = eqHolderCompAssocSpecs1;
	}

	public EqHolderCompAssocSpec addEqHolderCompAssocSpecs1(EqHolderCompAssocSpec eqHolderCompAssocSpecs1) {
		getEqHolderCompAssocSpecs1().add(eqHolderCompAssocSpecs1);
		eqHolderCompAssocSpecs1.setSpecType1(this);

		return eqHolderCompAssocSpecs1;
	}

	public EqHolderCompAssocSpec removeEqHolderCompAssocSpecs1(EqHolderCompAssocSpec eqHolderCompAssocSpecs1) {
		getEqHolderCompAssocSpecs1().remove(eqHolderCompAssocSpecs1);
		eqHolderCompAssocSpecs1.setSpecType1(null);

		return eqHolderCompAssocSpecs1;
	}

	public List<EqHolderCompAssocSpec> getEqHolderCompAssocSpecs2() {
		return this.eqHolderCompAssocSpecs2;
	}

	public void setEqHolderCompAssocSpecs2(List<EqHolderCompAssocSpec> eqHolderCompAssocSpecs2) {
		this.eqHolderCompAssocSpecs2 = eqHolderCompAssocSpecs2;
	}

	public EqHolderCompAssocSpec addEqHolderCompAssocSpecs2(EqHolderCompAssocSpec eqHolderCompAssocSpecs2) {
		getEqHolderCompAssocSpecs2().add(eqHolderCompAssocSpecs2);
		eqHolderCompAssocSpecs2.setSpecType2(this);

		return eqHolderCompAssocSpecs2;
	}

	public EqHolderCompAssocSpec removeEqHolderCompAssocSpecs2(EqHolderCompAssocSpec eqHolderCompAssocSpecs2) {
		getEqHolderCompAssocSpecs2().remove(eqHolderCompAssocSpecs2);
		eqHolderCompAssocSpecs2.setSpecType2(null);

		return eqHolderCompAssocSpecs2;
	}

	public List<EqHolderCompAssocSpec> getEqHolderCompAssocSpecs3() {
		return this.eqHolderCompAssocSpecs3;
	}

	public void setEqHolderCompAssocSpecs3(List<EqHolderCompAssocSpec> eqHolderCompAssocSpecs3) {
		this.eqHolderCompAssocSpecs3 = eqHolderCompAssocSpecs3;
	}

	public EqHolderCompAssocSpec addEqHolderCompAssocSpecs3(EqHolderCompAssocSpec eqHolderCompAssocSpecs3) {
		getEqHolderCompAssocSpecs3().add(eqHolderCompAssocSpecs3);
		eqHolderCompAssocSpecs3.setSpecType3(this);

		return eqHolderCompAssocSpecs3;
	}

	public EqHolderCompAssocSpec removeEqHolderCompAssocSpecs3(EqHolderCompAssocSpec eqHolderCompAssocSpecs3) {
		getEqHolderCompAssocSpecs3().remove(eqHolderCompAssocSpecs3);
		eqHolderCompAssocSpecs3.setSpecType3(null);

		return eqHolderCompAssocSpecs3;
	}

	public List<EqPortPortAssocSpec> getEqPortPortAssocSpecs() {
		return this.eqPortPortAssocSpecs;
	}

	public void setEqPortPortAssocSpecs(List<EqPortPortAssocSpec> eqPortPortAssocSpecs) {
		this.eqPortPortAssocSpecs = eqPortPortAssocSpecs;
	}

	public EqPortPortAssocSpec addEqPortPortAssocSpec(EqPortPortAssocSpec eqPortPortAssocSpec) {
		getEqPortPortAssocSpecs().add(eqPortPortAssocSpec);
		eqPortPortAssocSpec.setSpecType(this);

		return eqPortPortAssocSpec;
	}

	public EqPortPortAssocSpec removeEqPortPortAssocSpec(EqPortPortAssocSpec eqPortPortAssocSpec) {
		getEqPortPortAssocSpecs().remove(eqPortPortAssocSpec);
		eqPortPortAssocSpec.setSpecType(null);

		return eqPortPortAssocSpec;
	}

	public List<EqSpec> getEqSpecs() {
		return this.eqSpecs;
	}

	public void setEqSpecs(List<EqSpec> eqSpecs) {
		this.eqSpecs = eqSpecs;
	}

	public EqSpec addEqSpec(EqSpec eqSpec) {
		getEqSpecs().add(eqSpec);
		eqSpec.setSpecType(this);

		return eqSpec;
	}

	public EqSpec removeEqSpec(EqSpec eqSpec) {
		getEqSpecs().remove(eqSpec);
		eqSpec.setSpecType(null);

		return eqSpec;
	}

	public List<EqSpecCharSpec> getEqSpecCharSpecs() {
		return this.eqSpecCharSpecs;
	}

	public void setEqSpecCharSpecs(List<EqSpecCharSpec> eqSpecCharSpecs) {
		this.eqSpecCharSpecs = eqSpecCharSpecs;
	}

	public EqSpecCharSpec addEqSpecCharSpec(EqSpecCharSpec eqSpecCharSpec) {
		getEqSpecCharSpecs().add(eqSpecCharSpec);
		eqSpecCharSpec.setSpecType(this);

		return eqSpecCharSpec;
	}

	public EqSpecCharSpec removeEqSpecCharSpec(EqSpecCharSpec eqSpecCharSpec) {
		getEqSpecCharSpecs().remove(eqSpecCharSpec);
		eqSpecCharSpec.setSpecType(null);

		return eqSpecCharSpec;
	}

	public List<EqSpecCharSpecRel> getEqSpecCharSpecRels() {
		return this.eqSpecCharSpecRels;
	}

	public void setEqSpecCharSpecRels(List<EqSpecCharSpecRel> eqSpecCharSpecRels) {
		this.eqSpecCharSpecRels = eqSpecCharSpecRels;
	}

	public EqSpecCharSpecRel addEqSpecCharSpecRel(EqSpecCharSpecRel eqSpecCharSpecRel) {
		getEqSpecCharSpecRels().add(eqSpecCharSpecRel);
		eqSpecCharSpecRel.setSpecType(this);

		return eqSpecCharSpecRel;
	}

	public EqSpecCharSpecRel removeEqSpecCharSpecRel(EqSpecCharSpecRel eqSpecCharSpecRel) {
		getEqSpecCharSpecRels().remove(eqSpecCharSpecRel);
		eqSpecCharSpecRel.setSpecType(null);

		return eqSpecCharSpecRel;
	}

	public List<EqSpecCharValueSpec> getEqSpecCharValueSpecs() {
		return this.eqSpecCharValueSpecs;
	}

	public void setEqSpecCharValueSpecs(List<EqSpecCharValueSpec> eqSpecCharValueSpecs) {
		this.eqSpecCharValueSpecs = eqSpecCharValueSpecs;
	}

	public EqSpecCharValueSpec addEqSpecCharValueSpec(EqSpecCharValueSpec eqSpecCharValueSpec) {
		getEqSpecCharValueSpecs().add(eqSpecCharValueSpec);
		eqSpecCharValueSpec.setSpecType(this);

		return eqSpecCharValueSpec;
	}

	public EqSpecCharValueSpec removeEqSpecCharValueSpec(EqSpecCharValueSpec eqSpecCharValueSpec) {
		getEqSpecCharValueSpecs().remove(eqSpecCharValueSpec);
		eqSpecCharValueSpec.setSpecType(null);

		return eqSpecCharValueSpec;
	}

	public List<EqStructureCompatSpec> getEqStructureCompatSpecs1() {
		return this.eqStructureCompatSpecs1;
	}

	public void setEqStructureCompatSpecs1(List<EqStructureCompatSpec> eqStructureCompatSpecs1) {
		this.eqStructureCompatSpecs1 = eqStructureCompatSpecs1;
	}

	public EqStructureCompatSpec addEqStructureCompatSpecs1(EqStructureCompatSpec eqStructureCompatSpecs1) {
		getEqStructureCompatSpecs1().add(eqStructureCompatSpecs1);
		eqStructureCompatSpecs1.setSpecType1(this);

		return eqStructureCompatSpecs1;
	}

	public EqStructureCompatSpec removeEqStructureCompatSpecs1(EqStructureCompatSpec eqStructureCompatSpecs1) {
		getEqStructureCompatSpecs1().remove(eqStructureCompatSpecs1);
		eqStructureCompatSpecs1.setSpecType1(null);

		return eqStructureCompatSpecs1;
	}

	public List<EqStructureCompatSpec> getEqStructureCompatSpecs2() {
		return this.eqStructureCompatSpecs2;
	}

	public void setEqStructureCompatSpecs2(List<EqStructureCompatSpec> eqStructureCompatSpecs2) {
		this.eqStructureCompatSpecs2 = eqStructureCompatSpecs2;
	}

	public EqStructureCompatSpec addEqStructureCompatSpecs2(EqStructureCompatSpec eqStructureCompatSpecs2) {
		getEqStructureCompatSpecs2().add(eqStructureCompatSpecs2);
		eqStructureCompatSpecs2.setSpecType2(this);

		return eqStructureCompatSpecs2;
	}

	public EqStructureCompatSpec removeEqStructureCompatSpecs2(EqStructureCompatSpec eqStructureCompatSpecs2) {
		getEqStructureCompatSpecs2().remove(eqStructureCompatSpecs2);
		eqStructureCompatSpecs2.setSpecType2(null);

		return eqStructureCompatSpecs2;
	}

	public List<HolderSpec> getHolderSpecs() {
		return this.holderSpecs;
	}

	public void setHolderSpecs(List<HolderSpec> holderSpecs) {
		this.holderSpecs = holderSpecs;
	}

	public HolderSpec addHolderSpec(HolderSpec holderSpec) {
		getHolderSpecs().add(holderSpec);
		holderSpec.setSpecType(this);

		return holderSpec;
	}

	public HolderSpec removeHolderSpec(HolderSpec holderSpec) {
		getHolderSpecs().remove(holderSpec);
		holderSpec.setSpecType(null);

		return holderSpec;
	}

	public List<HolderSpecCharSpec> getHolderSpecCharSpecs() {
		return this.holderSpecCharSpecs;
	}

	public void setHolderSpecCharSpecs(List<HolderSpecCharSpec> holderSpecCharSpecs) {
		this.holderSpecCharSpecs = holderSpecCharSpecs;
	}

	public HolderSpecCharSpec addHolderSpecCharSpec(HolderSpecCharSpec holderSpecCharSpec) {
		getHolderSpecCharSpecs().add(holderSpecCharSpec);
		holderSpecCharSpec.setSpecType(this);

		return holderSpecCharSpec;
	}

	public HolderSpecCharSpec removeHolderSpecCharSpec(HolderSpecCharSpec holderSpecCharSpec) {
		getHolderSpecCharSpecs().remove(holderSpecCharSpec);
		holderSpecCharSpec.setSpecType(null);

		return holderSpecCharSpec;
	}

	public List<HolderSpecCharSpecRel> getHolderSpecCharSpecRels() {
		return this.holderSpecCharSpecRels;
	}

	public void setHolderSpecCharSpecRels(List<HolderSpecCharSpecRel> holderSpecCharSpecRels) {
		this.holderSpecCharSpecRels = holderSpecCharSpecRels;
	}

	public HolderSpecCharSpecRel addHolderSpecCharSpecRel(HolderSpecCharSpecRel holderSpecCharSpecRel) {
		getHolderSpecCharSpecRels().add(holderSpecCharSpecRel);
		holderSpecCharSpecRel.setSpecType(this);

		return holderSpecCharSpecRel;
	}

	public HolderSpecCharSpecRel removeHolderSpecCharSpecRel(HolderSpecCharSpecRel holderSpecCharSpecRel) {
		getHolderSpecCharSpecRels().remove(holderSpecCharSpecRel);
		holderSpecCharSpecRel.setSpecType(null);

		return holderSpecCharSpecRel;
	}

	public List<HolderSpecCharValueSpec> getHolderSpecCharValueSpecs() {
		return this.holderSpecCharValueSpecs;
	}

	public void setHolderSpecCharValueSpecs(List<HolderSpecCharValueSpec> holderSpecCharValueSpecs) {
		this.holderSpecCharValueSpecs = holderSpecCharValueSpecs;
	}

	public HolderSpecCharValueSpec addHolderSpecCharValueSpec(HolderSpecCharValueSpec holderSpecCharValueSpec) {
		getHolderSpecCharValueSpecs().add(holderSpecCharValueSpec);
		holderSpecCharValueSpec.setSpecType(this);

		return holderSpecCharValueSpec;
	}

	public HolderSpecCharValueSpec removeHolderSpecCharValueSpec(HolderSpecCharValueSpec holderSpecCharValueSpec) {
		getHolderSpecCharValueSpecs().remove(holderSpecCharValueSpec);
		holderSpecCharValueSpec.setSpecType(null);

		return holderSpecCharValueSpec;
	}

	public List<PortSpec> getPortSpecs() {
		return this.portSpecs;
	}

	public void setPortSpecs(List<PortSpec> portSpecs) {
		this.portSpecs = portSpecs;
	}

	public PortSpec addPortSpec(PortSpec portSpec) {
		getPortSpecs().add(portSpec);
		portSpec.setSpecType(this);

		return portSpec;
	}

	public PortSpec removePortSpec(PortSpec portSpec) {
		getPortSpecs().remove(portSpec);
		portSpec.setSpecType(null);

		return portSpec;
	}

	public List<PortSpecCharSpec> getPortSpecCharSpecs() {
		return this.portSpecCharSpecs;
	}

	public void setPortSpecCharSpecs(List<PortSpecCharSpec> portSpecCharSpecs) {
		this.portSpecCharSpecs = portSpecCharSpecs;
	}

	public PortSpecCharSpec addPortSpecCharSpec(PortSpecCharSpec portSpecCharSpec) {
		getPortSpecCharSpecs().add(portSpecCharSpec);
		portSpecCharSpec.setSpecType(this);

		return portSpecCharSpec;
	}

	public PortSpecCharSpec removePortSpecCharSpec(PortSpecCharSpec portSpecCharSpec) {
		getPortSpecCharSpecs().remove(portSpecCharSpec);
		portSpecCharSpec.setSpecType(null);

		return portSpecCharSpec;
	}

	public List<PortSpecCharSpecRel> getPortSpecCharSpecRels() {
		return this.portSpecCharSpecRels;
	}

	public void setPortSpecCharSpecRels(List<PortSpecCharSpecRel> portSpecCharSpecRels) {
		this.portSpecCharSpecRels = portSpecCharSpecRels;
	}

	public PortSpecCharSpecRel addPortSpecCharSpecRel(PortSpecCharSpecRel portSpecCharSpecRel) {
		getPortSpecCharSpecRels().add(portSpecCharSpecRel);
		portSpecCharSpecRel.setSpecType(this);

		return portSpecCharSpecRel;
	}

	public PortSpecCharSpecRel removePortSpecCharSpecRel(PortSpecCharSpecRel portSpecCharSpecRel) {
		getPortSpecCharSpecRels().remove(portSpecCharSpecRel);
		portSpecCharSpecRel.setSpecType(null);

		return portSpecCharSpecRel;
	}

	public List<PortSpecCharValueSpec> getPortSpecCharValueSpecs() {
		return this.portSpecCharValueSpecs;
	}

	public void setPortSpecCharValueSpecs(List<PortSpecCharValueSpec> portSpecCharValueSpecs) {
		this.portSpecCharValueSpecs = portSpecCharValueSpecs;
	}

	public PortSpecCharValueSpec addPortSpecCharValueSpec(PortSpecCharValueSpec portSpecCharValueSpec) {
		getPortSpecCharValueSpecs().add(portSpecCharValueSpec);
		portSpecCharValueSpec.setSpecType(this);

		return portSpecCharValueSpec;
	}

	public PortSpecCharValueSpec removePortSpecCharValueSpec(PortSpecCharValueSpec portSpecCharValueSpec) {
		getPortSpecCharValueSpecs().remove(portSpecCharValueSpec);
		portSpecCharValueSpec.setSpecType(null);

		return portSpecCharValueSpec;
	}

	public List<SpanSpec> getSpanSpecs() {
		return this.spanSpecs;
	}

	public void setSpanSpecs(List<SpanSpec> spanSpecs) {
		this.spanSpecs = spanSpecs;
	}

	public SpanSpec addSpanSpec(SpanSpec spanSpec) {
		getSpanSpecs().add(spanSpec);
		spanSpec.setSpecType(this);

		return spanSpec;
	}

	public SpanSpec removeSpanSpec(SpanSpec spanSpec) {
		getSpanSpecs().remove(spanSpec);
		spanSpec.setSpecType(null);

		return spanSpec;
	}

	public List<SpanSpecCharSpec> getSpanSpecCharSpecs() {
		return this.spanSpecCharSpecs;
	}

	public void setSpanSpecCharSpecs(List<SpanSpecCharSpec> spanSpecCharSpecs) {
		this.spanSpecCharSpecs = spanSpecCharSpecs;
	}

	public SpanSpecCharSpec addSpanSpecCharSpec(SpanSpecCharSpec spanSpecCharSpec) {
		getSpanSpecCharSpecs().add(spanSpecCharSpec);
		spanSpecCharSpec.setSpecType(this);

		return spanSpecCharSpec;
	}

	public SpanSpecCharSpec removeSpanSpecCharSpec(SpanSpecCharSpec spanSpecCharSpec) {
		getSpanSpecCharSpecs().remove(spanSpecCharSpec);
		spanSpecCharSpec.setSpecType(null);

		return spanSpecCharSpec;
	}

	public List<SpanSpecCharSpecRel> getSpanSpecCharSpecRels() {
		return this.spanSpecCharSpecRels;
	}

	public void setSpanSpecCharSpecRels(List<SpanSpecCharSpecRel> spanSpecCharSpecRels) {
		this.spanSpecCharSpecRels = spanSpecCharSpecRels;
	}

	public SpanSpecCharSpecRel addSpanSpecCharSpecRel(SpanSpecCharSpecRel spanSpecCharSpecRel) {
		getSpanSpecCharSpecRels().add(spanSpecCharSpecRel);
		spanSpecCharSpecRel.setSpecType(this);

		return spanSpecCharSpecRel;
	}

	public SpanSpecCharSpecRel removeSpanSpecCharSpecRel(SpanSpecCharSpecRel spanSpecCharSpecRel) {
		getSpanSpecCharSpecRels().remove(spanSpecCharSpecRel);
		spanSpecCharSpecRel.setSpecType(null);

		return spanSpecCharSpecRel;
	}

	public List<SpanSpecCharValueSpec> getSpanSpecCharValueSpecs() {
		return this.spanSpecCharValueSpecs;
	}

	public void setSpanSpecCharValueSpecs(List<SpanSpecCharValueSpec> spanSpecCharValueSpecs) {
		this.spanSpecCharValueSpecs = spanSpecCharValueSpecs;
	}

	public SpanSpecCharValueSpec addSpanSpecCharValueSpec(SpanSpecCharValueSpec spanSpecCharValueSpec) {
		getSpanSpecCharValueSpecs().add(spanSpecCharValueSpec);
		spanSpecCharValueSpec.setSpecType(this);

		return spanSpecCharValueSpec;
	}

	public SpanSpecCharValueSpec removeSpanSpecCharValueSpec(SpanSpecCharValueSpec spanSpecCharValueSpec) {
		getSpanSpecCharValueSpecs().remove(spanSpecCharValueSpec);
		spanSpecCharValueSpec.setSpecType(null);

		return spanSpecCharValueSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public List<StructureSpanCompatSpec> getStructureSpanCompatSpecs1() {
		return this.structureSpanCompatSpecs1;
	}

	public void setStructureSpanCompatSpecs1(List<StructureSpanCompatSpec> structureSpanCompatSpecs1) {
		this.structureSpanCompatSpecs1 = structureSpanCompatSpecs1;
	}

	public StructureSpanCompatSpec addStructureSpanCompatSpecs1(StructureSpanCompatSpec structureSpanCompatSpecs1) {
		getStructureSpanCompatSpecs1().add(structureSpanCompatSpecs1);
		structureSpanCompatSpecs1.setSpecType1(this);

		return structureSpanCompatSpecs1;
	}

	public StructureSpanCompatSpec removeStructureSpanCompatSpecs1(StructureSpanCompatSpec structureSpanCompatSpecs1) {
		getStructureSpanCompatSpecs1().remove(structureSpanCompatSpecs1);
		structureSpanCompatSpecs1.setSpecType1(null);

		return structureSpanCompatSpecs1;
	}

	public List<StructureSpanCompatSpec> getStructureSpanCompatSpecs2() {
		return this.structureSpanCompatSpecs2;
	}

	public void setStructureSpanCompatSpecs2(List<StructureSpanCompatSpec> structureSpanCompatSpecs2) {
		this.structureSpanCompatSpecs2 = structureSpanCompatSpecs2;
	}

	public StructureSpanCompatSpec addStructureSpanCompatSpecs2(StructureSpanCompatSpec structureSpanCompatSpecs2) {
		getStructureSpanCompatSpecs2().add(structureSpanCompatSpecs2);
		structureSpanCompatSpecs2.setSpecType2(this);

		return structureSpanCompatSpecs2;
	}

	public StructureSpanCompatSpec removeStructureSpanCompatSpecs2(StructureSpanCompatSpec structureSpanCompatSpecs2) {
		getStructureSpanCompatSpecs2().remove(structureSpanCompatSpecs2);
		structureSpanCompatSpecs2.setSpecType2(null);

		return structureSpanCompatSpecs2;
	}

	public List<StructureSpec> getStructureSpecs() {
		return this.structureSpecs;
	}

	public void setStructureSpecs(List<StructureSpec> structureSpecs) {
		this.structureSpecs = structureSpecs;
	}

	public StructureSpec addStructureSpec(StructureSpec structureSpec) {
		getStructureSpecs().add(structureSpec);
		structureSpec.setSpecType(this);

		return structureSpec;
	}

	public StructureSpec removeStructureSpec(StructureSpec structureSpec) {
		getStructureSpecs().remove(structureSpec);
		structureSpec.setSpecType(null);

		return structureSpec;
	}

	public List<StructureSpecCharSpec> getStructureSpecCharSpecs() {
		return this.structureSpecCharSpecs;
	}

	public void setStructureSpecCharSpecs(List<StructureSpecCharSpec> structureSpecCharSpecs) {
		this.structureSpecCharSpecs = structureSpecCharSpecs;
	}

	public StructureSpecCharSpec addStructureSpecCharSpec(StructureSpecCharSpec structureSpecCharSpec) {
		getStructureSpecCharSpecs().add(structureSpecCharSpec);
		structureSpecCharSpec.setSpecType(this);

		return structureSpecCharSpec;
	}

	public StructureSpecCharSpec removeStructureSpecCharSpec(StructureSpecCharSpec structureSpecCharSpec) {
		getStructureSpecCharSpecs().remove(structureSpecCharSpec);
		structureSpecCharSpec.setSpecType(null);

		return structureSpecCharSpec;
	}

	public List<StructureSpecCharSpecRel> getStructureSpecCharSpecRels() {
		return this.structureSpecCharSpecRels;
	}

	public void setStructureSpecCharSpecRels(List<StructureSpecCharSpecRel> structureSpecCharSpecRels) {
		this.structureSpecCharSpecRels = structureSpecCharSpecRels;
	}

	public StructureSpecCharSpecRel addStructureSpecCharSpecRel(StructureSpecCharSpecRel structureSpecCharSpecRel) {
		getStructureSpecCharSpecRels().add(structureSpecCharSpecRel);
		structureSpecCharSpecRel.setSpecType(this);

		return structureSpecCharSpecRel;
	}

	public StructureSpecCharSpecRel removeStructureSpecCharSpecRel(StructureSpecCharSpecRel structureSpecCharSpecRel) {
		getStructureSpecCharSpecRels().remove(structureSpecCharSpecRel);
		structureSpecCharSpecRel.setSpecType(null);

		return structureSpecCharSpecRel;
	}

	public List<StructureSpecCharValueSpec> getStructureSpecCharValueSpecs() {
		return this.structureSpecCharValueSpecs;
	}

	public void setStructureSpecCharValueSpecs(List<StructureSpecCharValueSpec> structureSpecCharValueSpecs) {
		this.structureSpecCharValueSpecs = structureSpecCharValueSpecs;
	}

	public StructureSpecCharValueSpec addStructureSpecCharValueSpec(StructureSpecCharValueSpec structureSpecCharValueSpec) {
		getStructureSpecCharValueSpecs().add(structureSpecCharValueSpec);
		structureSpecCharValueSpec.setSpecType(this);

		return structureSpecCharValueSpec;
	}

	public StructureSpecCharValueSpec removeStructureSpecCharValueSpec(StructureSpecCharValueSpec structureSpecCharValueSpec) {
		getStructureSpecCharValueSpecs().remove(structureSpecCharValueSpec);
		structureSpecCharValueSpec.setSpecType(null);

		return structureSpecCharValueSpec;
	}

}