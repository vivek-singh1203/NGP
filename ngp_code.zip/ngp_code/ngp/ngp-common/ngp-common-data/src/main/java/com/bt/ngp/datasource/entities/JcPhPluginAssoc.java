package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the JC_PH_PLUGIN_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="JC_PH_PLUGIN_ASSOC")
@NamedQuery(name="JcPhPluginAssoc.findAll", query="SELECT j FROM JcPhPluginAssoc j")
public class JcPhPluginAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="HOLDER_COMP_ASSOC_SPEC_ID", length=50)
	private String holderCompAssocSpecId;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to JcHierarchy
	@OneToMany(mappedBy="jcPhPluginAssoc")
	private List<JcHierarchy> jcHierarchies;

	//bi-directional many-to-one association to JointClosure
	@ManyToOne
	@JoinColumn(name="JC_NAME")
	private JointClosure jointClosure;

	//bi-directional many-to-one association to PluginHolder
	@ManyToOne
	@JoinColumn(name="PH_NAME")
	private PluginHolder pluginHolder;

	//bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	public JcPhPluginAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getHolderCompAssocSpecId() {
		return this.holderCompAssocSpecId;
	}

	public void setHolderCompAssocSpecId(String holderCompAssocSpecId) {
		this.holderCompAssocSpecId = holderCompAssocSpecId;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public List<JcHierarchy> getJcHierarchies() {
		return this.jcHierarchies;
	}

	public void setJcHierarchies(List<JcHierarchy> jcHierarchies) {
		this.jcHierarchies = jcHierarchies;
	}

	public JcHierarchy addJcHierarchy(JcHierarchy jcHierarchy) {
		getJcHierarchies().add(jcHierarchy);
		jcHierarchy.setJcPhPluginAssoc(this);

		return jcHierarchy;
	}

	public JcHierarchy removeJcHierarchy(JcHierarchy jcHierarchy) {
		getJcHierarchies().remove(jcHierarchy);
		jcHierarchy.setJcPhPluginAssoc(null);

		return jcHierarchy;
	}

	public JointClosure getJointClosure() {
		return this.jointClosure;
	}

	public void setJointClosure(JointClosure jointClosure) {
		this.jointClosure = jointClosure;
	}

	public PluginHolder getPluginHolder() {
		return this.pluginHolder;
	}

	public void setPluginHolder(PluginHolder pluginHolder) {
		this.pluginHolder = pluginHolder;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

}