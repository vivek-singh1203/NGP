package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the CABLE_SECTION_ENDS database table.
 * 
 */
@javax.persistence.Entity
@Table(name = "CABLE_SECTION_ENDS")
@NamedQuery(name = "CableSectionEnd.findAll", query = "SELECT c FROM CableSectionEnd c")
public class CableSectionEnd implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "ID", unique = true, nullable = false, length = 50)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SeqGen")
    @SequenceGenerator(name = "SeqGen", sequenceName = "CABLE_SECTION_ENDS_SEQ", allocationSize = 1)
	private long id;

	@Column(name = "CONNECTION_STATE", nullable = false, length = 20)
	private String connectionState;

	@Column(name = "CREATED_BY", nullable = false, length = 40)
	private String createdBy;

	@Column(name = "CREATED_DATE", nullable = false)
	private Timestamp createdDate;

	@Column(name = "DATA_QUALITY_INDICATOR", length = 20)
	private String dataQualityIndicator;

	@Column(name = "LAST_MODIFIED_BY", length = 40)
	private String lastModifiedBy;

	@Column(name = "LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name = "ORIG_END_NAME", nullable = false, length = 30)
	private String origEndName;

	@Column(name = "TERM_END_NAME", nullable = false, length = 30)
	private String termEndName;

	// bi-directional many-to-one association to CableSection
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CS_NAME")
	private CableSection cableSection;

	// bi-directional many-to-one association to Entity
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ORIG_END_ENTITY_NAME")
	private Entity origEndEntityName;

	// bi-directional many-to-one association to Entity
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "TERM_END_ENTITY_NAME")
	private Entity termEndEntityName;

	public CableSectionEnd() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getConnectionState() {
		return this.connectionState;
	}

	public void setConnectionState(String connectionState) {
		this.connectionState = connectionState;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getOrigEndName() {
		return this.origEndName;
	}

	public void setOrigEndName(String origEndName) {
		this.origEndName = origEndName;
	}

	public String getTermEndName() {
		return this.termEndName;
	}

	public void setTermEndName(String termEndName) {
		this.termEndName = termEndName;
	}

	public CableSection getCableSection() {
		return this.cableSection;
	}

	public void setCableSection(CableSection cableSection) {
		this.cableSection = cableSection;
	}

	public Entity getOrigEndEntityName() {
		return this.origEndEntityName;
	}

	public void setOrigEndEntityName(Entity origEndEntityName) {
		this.origEndEntityName = origEndEntityName;
	}

	public Entity getTermEndEntityName() {
		return this.termEndEntityName;
	}

	public void setTermEndEntityName(Entity termEndEntityName) {
		this.termEndEntityName = termEndEntityName;
	}

}
