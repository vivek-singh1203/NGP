package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.vividsolutions.jts.geom.LineString;


/**
 * The persistent class for the CABLE_SECTION database table.
 * 
 */
@javax.persistence.Entity
@Table(name = "CABLE_SECTION")
@NamedQuery(name = "CableSection.findAll", query = "SELECT c FROM CableSection c")
public class CableSection implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique = true, nullable = false, length = 25)
	private String name;

	@Column(name = "ALTERNATE_NAME", length = 50)
	private String alternateName;

	@Column(name = "ASSET_IDENTIFIER", length = 30)
	private String assetIdentifier;

	@Column(name = "CALCULATED_LENGTH", precision = 126)
	private double calculatedLength;

	@Column(name = "CALCULATED_LENGTH_UNIT", length = 10)
	private String calculatedLengthUnit;

	@Column(name = "CREATED_BY", nullable = false, length = 40)
	private String createdBy;

	@Column(name = "CREATED_DATE", nullable = false)
	private Timestamp createdDate;

	@Column(name = "DATA_QUALITY_INDICATOR", length = 20)
	private String dataQualityIndicator;

	@Column(name = "DESG_NAME", length = 30)
	private String desgName;

	@Column(name = "DESG_NUM", precision = 38)
	private BigInteger desgNum;

	@Column(name = "FAULT_STATE", length = 25)
	private String faultState;

	@Column(name = "FIELD_LABEL", length = 30)
	private String fieldLabel;

	@Column(name = "GEO_POSITION", columnDefinition = "geometry(LineString,3857)")
	private LineString geoPosition;

	public LineString getGeoPosition() {
		return geoPosition;
	}

	public void setGeoPosition(LineString geoPosition) {
		this.geoPosition = geoPosition;
	}

	@Column(nullable = false, length = 50)
	private String id;

	@Column(name = "LAST_MODIFIED_BY", length = 40)
	private String lastModifiedBy;

	@Column(name = "LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name = "MEASURED_LENGTH", precision = 126)
	private double measuredLength;

	@Column(name = "MEASURED_LENGTH_UNIT", length = 10)
	private String measuredLengthUnit;

	@Column(name = "RESOURCE_1141_CODE", nullable = false, length = 30)
	private String resource1141Code;

	@Column(name = "RESOURCE_STATE", nullable = false, length = 25)
	private String resourceState;

	@Column(name = "SERIAL_NUMBER", length = 30)
	private String serialNumber;

	@Column(name = "SERVICE_STATE", length = 25)
	private String serviceState;

	@Column(name = "SPEC_CATEGORY_NAME", length = 30)
	private String specCategoryName;

	@Column(name = "SPEC_NAME", length = 30)
	private String specName;

	@Column(name = "SPEC_TYPE_NAME", length = 40)
	private String specTypeName;

	@Column(name = "SPEC_VERSION", length = 10)
	private String specVersion;

	@Column(name = "USER_LABEL", length = 50)
	private String userLabel;

	// bi-directional many-to-one association to Exchange
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EXCHANGE_1141_CODE")
	private Exchange exchange;

	// bi-directional many-to-one association to Store
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "STORE_NAME")
	private Store store;

	// bi-directional many-to-one association to Supplier
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SUPPLIER_NAME")
	private Supplier supplier;

	// bi-directional many-to-one association to CableSectionChar
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSection")
	private List<CableSectionChar> cableSectionChars;

	// bi-directional many-to-one association to CableSectionEnd
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSection")
	private List<CableSectionEnd> cableSectionEnds;

	// bi-directional many-to-one association to CableSectionHierarchy
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSection")
	private List<CableSectionHierarchy> cableSectionHierarchies;

	// bi-directional many-to-one association to CableSectionSelfAssoc
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "childCsName")
	private List<CableSectionSelfAssoc> childCsSelfAssocs;

	// bi-directional many-to-one association to CableSectionSelfAssoc
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "parentCsName")
	private List<CableSectionSelfAssoc> parentCsSelfAssocs;

	// bi-directional many-to-one association to CableSectionSelfRel
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "csRelFromName")
	private List<CableSectionSelfRel> csRelFromName;

	// bi-directional many-to-one association to CableSectionSelfRel
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "csRelFromParentCsName")
	private List<CableSectionSelfRel> csRelFromParentCsName;

	// bi-directional many-to-one association to CableSectionSelfRel
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "csRelToName")
	private List<CableSectionSelfRel> csRelToName;

	// bi-directional many-to-one association to CableSectionSelfRel
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "csRelToParentCsName")
	private List<CableSectionSelfRel> csRelToParentCsName;

	// bi-directional many-to-one association to CableSpanAssoc
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSection")
	private List<CableSpanAssoc> cableSpanAssocs;

	// bi-directional many-to-one association to CcpCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "origCsName")
	private List<CcpCsCondSplicing> ccpCableConductorSplicingsOrigCsName;

	// bi-directional many-to-one association to CcpCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "origParentCsName")
	private List<CcpCsCondSplicing> ccpCableConductorSplicingsOrigParentCsName;

	// bi-directional many-to-one association to CcpCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "termCsName")
	private List<CcpCsCondSplicing> ccpCableConductorSplicingsTermCsName;

	// bi-directional many-to-one association to CcpCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "termParentCsName")
	private List<CcpCsCondSplicing> ccpCableConductorSplicingsTermParentCsName;

	// bi-directional many-to-one association to CcpCsPortTerm
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSection")
	private List<CcpCsPortTerm> ccpCsPortTerms;

	// bi-directional many-to-one association to CpeCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "origCsName")
	private List<CpeCsCondSplicing> cpeCsCondSplicingsOrigCsName;

	// bi-directional many-to-one association to CpeCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "origParentCsName")
	private List<CpeCsCondSplicing> cpeCsCondSplicingsOrigParentCsName;

	// bi-directional many-to-one association to CpeCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "termCsName")
	private List<CpeCsCondSplicing> cpeCsCondSplicingsTermCsName;

	// bi-directional many-to-one association to CpeCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "termParentCsName")
	private List<CpeCsCondSplicing> cpeCsCondSplicingsTermParentCsName;

	// bi-directional many-to-one association to CpeCsPortTerm
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSection")
	private List<CpeCsPortTerm> cpeCsPortTerms;

	// bi-directional many-to-one association to DfCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "origCsName")
	private List<DfCsCondSplicing> dfCsCondSplicingsOrigCsName;

	// bi-directional many-to-one association to DfCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "origParentCsName")
	private List<DfCsCondSplicing> dfCsCondSplicingsOrigParentCsName;

	// bi-directional many-to-one association to DfCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "termCsName")
	private List<DfCsCondSplicing> dfCsCondSplicingsTermCsName;

	// bi-directional many-to-one association to DfCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "termParentCsName")
	private List<DfCsCondSplicing> dfCsCondSplicingsTermParentCsName;

	// bi-directional many-to-one association to DfCsPortTerm
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSection")
	private List<DfCsPortTerm> dfCsPortTerms;

	// bi-directional many-to-one association to DpCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionOrigCsName")
	private List<DpCsCondSplicing> dpCsCondSplicings1;

	// bi-directional many-to-one association to DpCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionOrigParentCsName")
	private List<DpCsCondSplicing> dpCsCondSplicings2;

	// bi-directional many-to-one association to DpCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionTermCsName")
	private List<DpCsCondSplicing> dpCsCondSplicings3;

	// bi-directional many-to-one association to DpCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionTermParentCsName")
	private List<DpCsCondSplicing> dpCsCondSplicings4;

	// bi-directional many-to-one association to DpCsPortTerm
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSection")
	private List<DpCsPortTerm> dpCsPortTerms;

	// bi-directional many-to-one association to DslamCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionOrigCsName")
	private List<DslamCsCondSplicing> dslamCsCondSplicings1;

	// bi-directional many-to-one association to DslamCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionOrigParentCsName")
	private List<DslamCsCondSplicing> dslamCsCondSplicings2;

	// bi-directional many-to-one association to DslamCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionTermCsName")
	private List<DslamCsCondSplicing> dslamCsCondSplicings3;

	// bi-directional many-to-one association to DslamCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionTermParentCsName")
	private List<DslamCsCondSplicing> dslamCsCondSplicings4;

	// bi-directional many-to-one association to DslamCsPortTerm
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSection")
	private List<DslamCsPortTerm> dslamCsPortTerms;

	// bi-directional many-to-one association to JcCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionOrigCsName")
	private List<JcCsCondSplicing> jcCsCondSplicings1;

	// bi-directional many-to-one association to JcCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionOrigParentCsName")
	private List<JcCsCondSplicing> jcCsCondSplicings2;

	// bi-directional many-to-one association to JcCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionTermCsName")
	private List<JcCsCondSplicing> jcCsCondSplicings3;

	// bi-directional many-to-one association to JcCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionTermParentCsName")
	private List<JcCsCondSplicing> jcCsCondSplicings4;

	// bi-directional many-to-one association to JcCsPortTerm
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSection")
	private List<JcCsPortTerm> jcCsPortTerms;

	// bi-directional many-to-one association to MfnCableConductorSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "origCsName")
	private List<MfnCsCondSplicing> mfnCableConductorOrigCsName;

	// bi-directional many-to-one association to MfnCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "origParCsName")
	private List<MfnCsCondSplicing> mfnCableConductorOrigParCsName;

	// bi-directional many-to-one association to MfnCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "termCsName")
	private List<MfnCsCondSplicing> mfnCableConductorTermCsName;

	// bi-directional many-to-one association to MfnCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "termParCsName")
	private List<MfnCsCondSplicing> mfnCableConductorTermParCsName;

	// bi-directional many-to-one association to MfnCsPortTerm
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSection")
	private List<MfnCsPortTerm> mfnCsPortTerms;

	// bi-directional many-to-one association to NteCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionOrigCsName")
	private List<NteCsCondSplicing> nteCsCondSplicings1;

	// bi-directional many-to-one association to NteCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionOrigParentCsName")
	private List<NteCsCondSplicing> nteCsCondSplicings2;

	// bi-directional many-to-one association to NteCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionTermCsName")
	private List<NteCsCondSplicing> nteCsCondSplicings3;

	// bi-directional many-to-one association to NteCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSectionTermParentCsName")
	private List<NteCsCondSplicing> nteCsCondSplicings4;

	// bi-directional many-to-one association to NteCsPortTerm
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSection")
	private List<NteCsPortTerm> nteCsPortTerms;

	// bi-directional many-to-one association to WeCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "origCsName")
	private List<WeCsCondSplicing> weCableConductorSplicingsOriginating;

	// bi-directional many-to-one association to WeCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "origParCsName")
	private List<WeCsCondSplicing> weCableConductorSplicingsOriginatingParent;

	// bi-directional many-to-one association to WeCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "termCsName")
	private List<WeCsCondSplicing> weCableConductorSplicingsTerminating;

	// bi-directional many-to-one association to WeCsCondSplicing
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "termParCsName")
	private List<WeCsCondSplicing> weCableConductorSplicingsTerminatingParent;

	// bi-directional many-to-one association to WeCsPortTerm
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "cableSection")
	private List<WeCsPortTerm> weCsPortTerms;

	public CableSection() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public double getCalculatedLength() {
		return this.calculatedLength;
	}

	public void setCalculatedLength(double calculatedLength) {
		this.calculatedLength = calculatedLength;
	}

	public String getCalculatedLengthUnit() {
		return this.calculatedLengthUnit;
	}

	public void setCalculatedLengthUnit(String calculatedLengthUnit) {
		this.calculatedLengthUnit = calculatedLengthUnit;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getDesgName() {
		return this.desgName;
	}

	public void setDesgName(String desgName) {
		this.desgName = desgName;
	}

	/*
	 * public BigDecimal getDesgNum() { return this.desgNum; }
	 * 
	 * public void setDesgNum(BigDecimal desgNum) { this.desgNum = desgNum; }
	 */

	public String getFaultState() {
		return this.faultState;
	}

	public BigInteger getDesgNum() {
		return desgNum;
	}

	public void setDesgNum(BigInteger desgNum) {
		this.desgNum = desgNum;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getFieldLabel() {
		return this.fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}

	/* public Object getGeoPosition() { return this.geoPosition;} */

	/*
	 * public void setGeoPosition(Object geoPosition) { this.geoPosition =
	 * geoPosition;}
	 */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public double getMeasuredLength() {
		return this.measuredLength;
	}

	public void setMeasuredLength(double measuredLength) {
		this.measuredLength = measuredLength;
	}

	public String getMeasuredLengthUnit() {
		return this.measuredLengthUnit;
	}

	public void setMeasuredLengthUnit(String measuredLengthUnit) {
		this.measuredLengthUnit = measuredLengthUnit;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public Exchange getExchange() {
		return this.exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public List<CableSectionChar> getCableSectionChars() {
		return this.cableSectionChars;
	}

	public void setCableSectionChars(List<CableSectionChar> cableSectionChars) {
		this.cableSectionChars = cableSectionChars;
	}

	public CableSectionChar addCableSectionChar(
			CableSectionChar cableSectionChar) {
		if (null == getCableSectionChars()) {
			setCableSectionChars(new ArrayList<>());
		}
		getCableSectionChars().add(cableSectionChar);
		cableSectionChar.setCableSection(this);

		return cableSectionChar;
	}

	public CableSectionChar removeCableSectionChar(
			CableSectionChar cableSectionChar) {
		getCableSectionChars().remove(cableSectionChar);
		cableSectionChar.setCableSection(null);

		return cableSectionChar;
	}

	public List<CableSectionEnd> getCableSectionEnds() {
		return this.cableSectionEnds;
	}

	public void setCableSectionEnds(List<CableSectionEnd> cableSectionEnds) {
		this.cableSectionEnds = cableSectionEnds;
	}

	public CableSectionEnd addCableSectionEnd(CableSectionEnd cableSectionEnd) {
		getCableSectionEnds().add(cableSectionEnd);
		cableSectionEnd.setCableSection(this);

		return cableSectionEnd;
	}

	public CableSectionEnd removeCableSectionEnd(
			CableSectionEnd cableSectionEnd) {
		getCableSectionEnds().remove(cableSectionEnd);
		cableSectionEnd.setCableSection(null);

		return cableSectionEnd;
	}

	public List<CableSectionHierarchy> getCableSectionHierarchies() {
		return this.cableSectionHierarchies;
	}

	public void setCableSectionHierarchies(
			List<CableSectionHierarchy> cableSectionHierarchies) {
		this.cableSectionHierarchies = cableSectionHierarchies;
	}

	public CableSectionHierarchy addCableSectionHierarchy(
			CableSectionHierarchy cableSectionHierarchy) {
		if (null == getCableSectionHierarchies()) {
			setCableSectionHierarchies(new ArrayList<>());
		}
		getCableSectionHierarchies().add(cableSectionHierarchy);
		cableSectionHierarchy.setCableSection(this);

		return cableSectionHierarchy;
	}

	public CableSectionHierarchy removeCableSectionHierarchy(
			CableSectionHierarchy cableSectionHierarchy) {
		getCableSectionHierarchies().remove(cableSectionHierarchy);
		cableSectionHierarchy.setCableSection(null);

		return cableSectionHierarchy;
	}

	public List<CableSectionSelfAssoc> getChildCsSelfAssocs() {
		return childCsSelfAssocs;
	}

	public void setChildCsSelfAssocs(
			List<CableSectionSelfAssoc> childCsSelfAssocs) {
		this.childCsSelfAssocs = childCsSelfAssocs;
	}

	public List<CableSectionSelfAssoc> getParentCsSelfAssocs() {
		return parentCsSelfAssocs;
	}

	public void setParentCsSelfAssocs(
			List<CableSectionSelfAssoc> parentCsSelfAssocs) {
		this.parentCsSelfAssocs = parentCsSelfAssocs;
	}

	public CableSectionSelfAssoc addChildCsSelfAssocs(
			CableSectionSelfAssoc childCsSelfAssocs) {
		if (null == getChildCsSelfAssocs()) {
			setChildCsSelfAssocs(new ArrayList<>());
		}

		getChildCsSelfAssocs().add(childCsSelfAssocs);
		childCsSelfAssocs.setChildCsName(this);

		return childCsSelfAssocs;
	}

	public CableSectionSelfAssoc removeChildCsSelfAssocs(
			CableSectionSelfAssoc childCsSelfAssocs) {
		getChildCsSelfAssocs().remove(childCsSelfAssocs);
		childCsSelfAssocs.setChildCsName(null);

		return childCsSelfAssocs;
	}

	public CableSectionSelfAssoc addParentCsSelfAssocs(
			CableSectionSelfAssoc parentCsSelfAssocs) {
		getParentCsSelfAssocs().add(parentCsSelfAssocs);
		parentCsSelfAssocs.setParentCsName(this);

		return parentCsSelfAssocs;
	}

	public CableSectionSelfAssoc removeParentCsSelfAssocs(
			CableSectionSelfAssoc parentCsSelfAssocs) {
		getParentCsSelfAssocs().remove(parentCsSelfAssocs);
		parentCsSelfAssocs.setParentCsName(null);

		return parentCsSelfAssocs;
	}

	public List<CableSectionSelfRel> getCsRelFromName() {
		return this.csRelFromName;
	}

	public void setCsRelFromName(List<CableSectionSelfRel> csRelFromName) {
		this.csRelFromName = csRelFromName;
	}

	public CableSectionSelfRel addCsRelFromName(
			CableSectionSelfRel csRelFromName) {
		getCsRelFromName().add(csRelFromName);
		csRelFromName.setCsRelFromName(this);

		return csRelFromName;
	}

	public CableSectionSelfRel removeCsRelFromName(
			CableSectionSelfRel csRelFromName) {
		getCsRelFromName().remove(csRelFromName);
		csRelFromName.setCsRelFromName(null);

		return csRelFromName;
	}

	public List<CableSectionSelfRel> getCsRelFromParentCsName() {
		return this.csRelFromParentCsName;
	}

	public void setCsRelFromParentCsName(
			List<CableSectionSelfRel> csRelFromParentCsName) {
		this.csRelFromParentCsName = csRelFromParentCsName;
	}

	public CableSectionSelfRel addCsRelFromParentCsName(
			CableSectionSelfRel csRelFromParentCsName) {
		getCsRelFromParentCsName().add(csRelFromParentCsName);
		csRelFromParentCsName.setCsRelFromParentCsName(this);

		return csRelFromParentCsName;
	}

	public CableSectionSelfRel removeCsRelFromParentCsName(
			CableSectionSelfRel csRelFromParentCsName) {
		getCsRelFromParentCsName().remove(csRelFromParentCsName);
		csRelFromParentCsName.setCsRelFromParentCsName(null);

		return csRelFromParentCsName;
	}

	public List<CableSectionSelfRel> getCsRelToName() {
		return this.csRelToName;
	}

	public void setCsRelToName(List<CableSectionSelfRel> csRelToName) {
		this.csRelToName = csRelToName;
	}

	public CableSectionSelfRel addCsRelToName(CableSectionSelfRel csRelToName) {
		getCsRelToName().add(csRelToName);
		csRelToName.setCsRelToName(this);

		return csRelToName;
	}

	public CableSectionSelfRel removeCsRelToName(
			CableSectionSelfRel csRelToName) {
		getCsRelToName().remove(csRelToName);
		csRelToName.setCsRelToName(null);

		return csRelToName;
	}

	public List<CableSectionSelfRel> getCsRelToParentCsName() {
		return this.csRelToParentCsName;
	}

	public void setCsRelToParentCsName(
			List<CableSectionSelfRel> csRelToParentCsName) {
		this.csRelToParentCsName = csRelToParentCsName;
	}

	public CableSectionSelfRel addCsRelToParentCsName(
			CableSectionSelfRel csRelToParentCsName) {
		getCsRelToParentCsName().add(csRelToParentCsName);
		csRelToParentCsName.setCsRelToParentCsName(this);

		return csRelToParentCsName;
	}

	public CableSectionSelfRel removeCsRelToParentCsName(
			CableSectionSelfRel csRelToParentCsName) {
		getCsRelToParentCsName().remove(csRelToParentCsName);
		csRelToParentCsName.setCsRelToParentCsName(null);

		return csRelToParentCsName;
	}

	public List<CableSpanAssoc> getCableSpanAssocs() {
		return this.cableSpanAssocs;
	}

	public void setCableSpanAssocs(List<CableSpanAssoc> cableSpanAssocs) {
		this.cableSpanAssocs = cableSpanAssocs;
	}

	public CableSpanAssoc addCableSpanAssoc(CableSpanAssoc cableSpanAssoc) {
		if (null == getCableSpanAssocs()) {
			setCableSpanAssocs(new ArrayList<>());
		}
		getCableSpanAssocs().add(cableSpanAssoc);
		cableSpanAssoc.setCableSection(this);

		return cableSpanAssoc;
	}

	public CableSpanAssoc removeCableSpanAssoc(CableSpanAssoc cableSpanAssoc) {
		getCableSpanAssocs().remove(cableSpanAssoc);
		cableSpanAssoc.setCableSection(null);

		return cableSpanAssoc;
	}

	public List<CcpCsCondSplicing> getCcpCableConductorSplicingsOrigCsName() {
		return this.ccpCableConductorSplicingsOrigCsName;
	}

	public void setCcpCableConductorSplicingsOrigCsName(
			List<CcpCsCondSplicing> ccpCableConductorSplicingsOrigCsName) {
		this.ccpCableConductorSplicingsOrigCsName = ccpCableConductorSplicingsOrigCsName;
	}

	public CcpCsCondSplicing addCcpCableConductorSplicingsOrigCsName(
			CcpCsCondSplicing ccpCableConductorSplicingsOrigCsName) {
		getCcpCableConductorSplicingsOrigCsName().add(ccpCableConductorSplicingsOrigCsName);
		ccpCableConductorSplicingsOrigCsName.setOrigCsName(this);

		return ccpCableConductorSplicingsOrigCsName;
	}

	public CcpCsCondSplicing removeCcpCableConductorSplicingsOrigCsName(
			CcpCsCondSplicing ccpCableConductorSplicingsOrigCsName) {
		getCcpCableConductorSplicingsOrigCsName().remove(ccpCableConductorSplicingsOrigCsName);
		ccpCableConductorSplicingsOrigCsName.setOrigCsName(this);

		return ccpCableConductorSplicingsOrigCsName;
	}

	public List<CcpCsCondSplicing> getCcpCableConductorSplicingsOrigParentCsName() {
		return this.ccpCableConductorSplicingsOrigParentCsName;
	}

	public void setCcpCableConductorSplicingsOrigParentCsName(
			List<CcpCsCondSplicing> ccpCableConductorSplicingsOrigParentCsName) {
		this.ccpCableConductorSplicingsOrigParentCsName = ccpCableConductorSplicingsOrigParentCsName;
	}

	public CcpCsCondSplicing addCcpCableConductorSplicings2(
			CcpCsCondSplicing ccpCableConductorSplicingsOrigParentCsName) {
		getCcpCableConductorSplicingsOrigParentCsName().add(ccpCableConductorSplicingsOrigParentCsName);
		ccpCableConductorSplicingsOrigParentCsName.setOrigParentCsName(this);

		return ccpCableConductorSplicingsOrigParentCsName;
	}

	public CcpCsCondSplicing removeCcpCableConductorSplicings2(
			CcpCsCondSplicing ccpCableConductorSplicingsOrigParentCsName) {
		getCcpCableConductorSplicingsOrigParentCsName().remove(ccpCableConductorSplicingsOrigParentCsName);
		ccpCableConductorSplicingsOrigParentCsName.setOrigParentCsName(null);

		return ccpCableConductorSplicingsOrigParentCsName;
	}

	public List<CcpCsCondSplicing> getCcpCableConductorSplicingsTermCsName() {
		return this.ccpCableConductorSplicingsTermCsName;
	}

	public void setCcpCableConductorSplicings3(List<CcpCsCondSplicing> ccpCableConductorSplicingsTermCsName) {
		this.ccpCableConductorSplicingsTermCsName = ccpCableConductorSplicingsTermCsName;
	}

	public CcpCsCondSplicing addCcpCableConductorSplicingsTermCsName(
			CcpCsCondSplicing ccpCableConductorSplicingsTermCsName) {
		getCcpCableConductorSplicingsTermCsName().add(ccpCableConductorSplicingsTermCsName);
		ccpCableConductorSplicingsTermCsName.setTermCsName(this);

		return ccpCableConductorSplicingsTermCsName;
	}

	public CcpCsCondSplicing removeCcpCableConductorSplicingsTermCsName(
			CcpCsCondSplicing ccpCableConductorSplicingsTermCsName) {
		getCcpCableConductorSplicingsTermCsName().remove(ccpCableConductorSplicingsTermCsName);
		ccpCableConductorSplicingsTermCsName.setTermCsName(null);

		return ccpCableConductorSplicingsTermCsName;
	}

	public List<CcpCsCondSplicing> getCcpCableConductorSplicingsTermParentCsName() {
		return this.ccpCableConductorSplicingsTermParentCsName;
	}

	public void setCcpCableConductorSplicingsTermParentCsName(
			List<CcpCsCondSplicing> ccpCableConductorSplicingsTermParentCsName) {
		this.ccpCableConductorSplicingsTermParentCsName = ccpCableConductorSplicingsTermParentCsName;
	}

	public CcpCsCondSplicing addCcpCableConductorSplicingsTermParentCsName(
			CcpCsCondSplicing ccpCableConductorSplicingsTermParentCsName) {
		getCcpCableConductorSplicingsTermParentCsName().add(ccpCableConductorSplicingsTermParentCsName);
		ccpCableConductorSplicingsTermParentCsName.setTermParentCsName(this);

		return ccpCableConductorSplicingsTermParentCsName;
	}

	public CcpCsCondSplicing removeCcpCableConductorSplicingsTermParentCsName(
			CcpCsCondSplicing ccpCableConductorSplicingsTermParentCsName) {
		getCcpCableConductorSplicingsTermParentCsName().remove(ccpCableConductorSplicingsTermParentCsName);
		ccpCableConductorSplicingsTermParentCsName.setTermParentCsName(null);

		return ccpCableConductorSplicingsTermParentCsName;
	}

	public List<CcpCsPortTerm> getCcpCsPortTerms() {
		return this.ccpCsPortTerms;
	}

	public void setCcpCsPortTerms(List<CcpCsPortTerm> ccpCsPortTerms) {
		this.ccpCsPortTerms = ccpCsPortTerms;
	}

	public CcpCsPortTerm addCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		if(getCcpCsPortTerms()==null) {
			setCcpCsPortTerms(new ArrayList<>());
		}
		getCcpCsPortTerms().add(ccpCsPortTerm);
		ccpCsPortTerm.setCableSection(this);

		return ccpCsPortTerm;
	}

	public CcpCsPortTerm removeCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		getCcpCsPortTerms().remove(ccpCsPortTerm);
		ccpCsPortTerm.setCableSection(null);

		return ccpCsPortTerm;
	}

	public List<CpeCsCondSplicing> getCpeCsCondSplicingsOrigCsName() {
		return this.cpeCsCondSplicingsOrigCsName;
	}

	public void setCpeCsCondSplicingsOrigCsName(
			List<CpeCsCondSplicing> cpeCsCondSplicingsOrigCsName) {
		this.cpeCsCondSplicingsOrigCsName = cpeCsCondSplicingsOrigCsName;
	}

	public CpeCsCondSplicing addCpeCsCondSplicingsOrigCsName(
			CpeCsCondSplicing cpeCsCondSplicingsOrigCsName) {
		getCpeCsCondSplicingsOrigCsName().add(cpeCsCondSplicingsOrigCsName);
		cpeCsCondSplicingsOrigCsName.setOrigCsName(this);

		return cpeCsCondSplicingsOrigCsName;
	}

	public CpeCsCondSplicing removeCpeCsCondSplicingsOrigCsName(
			CpeCsCondSplicing cpeCsCondSplicingsOrigCsName) {
		getCpeCsCondSplicingsOrigCsName().remove(cpeCsCondSplicingsOrigCsName);
		cpeCsCondSplicingsOrigCsName.setOrigCsName(null);

		return cpeCsCondSplicingsOrigCsName;
	}

	public List<CpeCsCondSplicing> getCpeCsCondSplicingsOrigParentCsName() {
		return this.cpeCsCondSplicingsOrigParentCsName;
	}

	public void setCpeCsCondSplicingsOrigParentCsName(
			List<CpeCsCondSplicing> cpeCsCondSplicingsOrigParentCsName) {
		this.cpeCsCondSplicingsOrigParentCsName = cpeCsCondSplicingsOrigParentCsName;
	}

	public CpeCsCondSplicing addCpeCsCondSplicingsOrigParentCsName(
			CpeCsCondSplicing cpeCsCondSplicingsOrigParentCsName) {
		getCpeCsCondSplicingsOrigParentCsName()
				.add(cpeCsCondSplicingsOrigParentCsName);
		cpeCsCondSplicingsOrigParentCsName.setOrigParentCsName(this);

		return cpeCsCondSplicingsOrigParentCsName;
	}

	public CpeCsCondSplicing removeCpeCsCondSplicingsOrigParentCsName(
			CpeCsCondSplicing cpeCsCondSplicingsOrigParentCsName) {
		getCpeCsCondSplicingsOrigParentCsName()
				.remove(cpeCsCondSplicingsOrigParentCsName);
		cpeCsCondSplicingsOrigParentCsName.setOrigParentCsName(null);

		return cpeCsCondSplicingsOrigParentCsName;
	}

	public List<CpeCsCondSplicing> getCpeCsCondSplicingsTermCsName() {
		return this.cpeCsCondSplicingsTermCsName;
	}

	public void setCpeCsCondSplicingsTermCsName(
			List<CpeCsCondSplicing> cpeCsCondSplicingsTermCsName) {
		this.cpeCsCondSplicingsTermCsName = cpeCsCondSplicingsTermCsName;
	}

	public CpeCsCondSplicing addCpeCsCondSplicingsTermCsName(
			CpeCsCondSplicing cpeCsCondSplicingsTermCsName) {
		getCpeCsCondSplicingsTermCsName().add(cpeCsCondSplicingsTermCsName);
		cpeCsCondSplicingsTermCsName.setTermCsName(this);

		return cpeCsCondSplicingsTermCsName;
	}

	public CpeCsCondSplicing removeCpeCsCondSplicingsTermCsName(
			CpeCsCondSplicing cpeCsCondSplicingsTermCsName) {
		getCpeCsCondSplicingsTermCsName().remove(cpeCsCondSplicingsTermCsName);
		cpeCsCondSplicingsTermCsName.setTermCsName(null);

		return cpeCsCondSplicingsTermCsName;
	}

	public List<CpeCsCondSplicing> getCpeCsCondSplicingsTermParentCsName() {
		return this.cpeCsCondSplicingsTermParentCsName;
	}

	public void setCpeCsCondSplicingsTermParentCsName(
			List<CpeCsCondSplicing> cpeCsCondSplicingsTermParentCsName) {
		this.cpeCsCondSplicingsTermParentCsName = cpeCsCondSplicingsTermParentCsName;
	}

	public CpeCsCondSplicing addCpeCsCondSplicingsTermParentCsName(
			CpeCsCondSplicing cpeCsCondSplicingsTermParentCsName) {
		getCpeCsCondSplicingsTermParentCsName()
				.add(cpeCsCondSplicingsTermParentCsName);
		cpeCsCondSplicingsTermParentCsName.setTermParentCsName(this);

		return cpeCsCondSplicingsTermParentCsName;
	}

	public CpeCsCondSplicing removeCpeCsCondSplicingssetTermParentCsName(
			CpeCsCondSplicing cpeCsCondSplicingsTermParentCsName) {
		getCpeCsCondSplicingsTermParentCsName()
				.remove(cpeCsCondSplicingsTermParentCsName);
		cpeCsCondSplicingsTermParentCsName.setTermParentCsName(null);

		return cpeCsCondSplicingsTermParentCsName;
	}

	public List<CpeCsPortTerm> getCpeCsPortTerms() {
		return this.cpeCsPortTerms;
	}

	public void setCpeCsPortTerms(List<CpeCsPortTerm> cpeCsPortTerms) {
		this.cpeCsPortTerms = cpeCsPortTerms;
	}

	public CpeCsPortTerm addCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		if(getCpeCsPortTerms()==null) {
			setCpeCsPortTerms(new ArrayList<>());
		}
		getCpeCsPortTerms().add(cpeCsPortTerm);
		cpeCsPortTerm.setCableSection(this);

		return cpeCsPortTerm;
	}

	public CpeCsPortTerm removeCpeCsPortTerm(CpeCsPortTerm cpeCsPortTerm) {
		getCpeCsPortTerms().remove(cpeCsPortTerm);
		cpeCsPortTerm.setCableSection(null);

		return cpeCsPortTerm;
	}

	public List<DfCsCondSplicing> getDfCsCondSplicingsOrigCsName() {
		return this.dfCsCondSplicingsOrigCsName;
	}

	public void setDfCsCondSplicings1(
			List<DfCsCondSplicing> dfCsCondSplicingsOrigCsName) {
		this.dfCsCondSplicingsOrigCsName = dfCsCondSplicingsOrigCsName;
	}

	public DfCsCondSplicing addDfCsCondSplicingsOrigCsName(
			DfCsCondSplicing dfCsCondSplicingsOrigCsName) {
		getDfCsCondSplicingsOrigCsName().add(dfCsCondSplicingsOrigCsName);
		dfCsCondSplicingsOrigCsName.setOrigCsName(this);

		return dfCsCondSplicingsOrigCsName;
	}

	public DfCsCondSplicing removeDfCsCondSplicingsOrigCsName(
			DfCsCondSplicing dfCsCondSplicingsOrigCsName) {
		getDfCsCondSplicingsOrigCsName().remove(dfCsCondSplicingsOrigCsName);
		dfCsCondSplicingsOrigCsName.setOrigCsName(null);

		return dfCsCondSplicingsOrigCsName;
	}

	public List<DfCsCondSplicing> getDfCsCondSplicingsOrigParentCsName() {
		return this.dfCsCondSplicingsOrigParentCsName;
	}

	public void setDfCsCondSplicingsOrigParentCsName(
			List<DfCsCondSplicing> dfCsCondSplicingsOrigParentCsName) {
		this.dfCsCondSplicingsOrigParentCsName = dfCsCondSplicingsOrigParentCsName;
	}

	public DfCsCondSplicing addDfCsCondSplicingsOrigParentCsName(
			DfCsCondSplicing dfCsCondSplicingsOrigParentCsName) {
		getDfCsCondSplicingsOrigParentCsName()
				.add(dfCsCondSplicingsOrigParentCsName);
		dfCsCondSplicingsOrigParentCsName.setOrigParentCsName(this);

		return dfCsCondSplicingsOrigParentCsName;
	}

	public DfCsCondSplicing removeDfCsCondSplicingsOrigParentCsName(
			DfCsCondSplicing dfCsCondSplicingsOrigParentCsName) {
		getDfCsCondSplicingsOrigParentCsName()
				.remove(dfCsCondSplicingsOrigParentCsName);
		dfCsCondSplicingsOrigParentCsName.setOrigParentCsName(null);

		return dfCsCondSplicingsOrigParentCsName;
	}

	public List<DfCsCondSplicing> getDfCsCondSplicingsTermCsName() {
		return this.dfCsCondSplicingsTermCsName;
	}

	public void setDfCsCondSplicingsTermCsName(
			List<DfCsCondSplicing> dfCsCondSplicingsTermCsName) {
		this.dfCsCondSplicingsTermCsName = dfCsCondSplicingsTermCsName;
	}

	public DfCsCondSplicing addDfCsCondSplicingsTermCsName(
			DfCsCondSplicing dfCsCondSplicingsTermCsName) {
		getDfCsCondSplicingsTermCsName().add(dfCsCondSplicingsTermCsName);
		dfCsCondSplicingsTermCsName.setTermCsName(this);

		return dfCsCondSplicingsTermCsName;
	}

	public DfCsCondSplicing removeDfCsCondSplicingsTermCsName(
			DfCsCondSplicing dfCsCondSplicingsTermCsName) {
		getDfCsCondSplicingsTermCsName().remove(dfCsCondSplicingsTermCsName);
		dfCsCondSplicingsTermCsName.setTermCsName(null);

		return dfCsCondSplicingsTermCsName;
	}

	public List<DfCsCondSplicing> getDfCsCondSplicingsTermParentCsName() {
		return this.dfCsCondSplicingsTermParentCsName;
	}

	public void setDfCsCondSplicingsTermParentCsName(
			List<DfCsCondSplicing> dfCsCondSplicingsTermParentCsName) {
		this.dfCsCondSplicingsTermParentCsName = dfCsCondSplicingsTermParentCsName;
	}

	public DfCsCondSplicing addDfCsCondSplicingsTermParentCsName(
			DfCsCondSplicing dfCsCondSplicingsTermParentCsName) {
		getDfCsCondSplicingsTermParentCsName()
				.add(dfCsCondSplicingsTermParentCsName);
		dfCsCondSplicingsTermParentCsName.setTermParentCsName(this);

		return dfCsCondSplicingsTermParentCsName;
	}

	public DfCsCondSplicing removeDfCsCondSplicingsTermParentCsName(
			DfCsCondSplicing dfCsCondSplicingsTermParentCsName) {
		getDfCsCondSplicingsTermParentCsName()
				.remove(dfCsCondSplicingsTermParentCsName);
		dfCsCondSplicingsTermParentCsName.setTermParentCsName(null);

		return dfCsCondSplicingsTermParentCsName;
	}

	public List<DfCsPortTerm> getDfCsPortTerms() {
		return this.dfCsPortTerms;
	}

	public void setDfCsPortTerms(List<DfCsPortTerm> dfCsPortTerms) {
		this.dfCsPortTerms = dfCsPortTerms;
	}

	public DfCsPortTerm addDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		if(getDfCsPortTerms()==null) {
			setDfCsPortTerms(new ArrayList<>());
		}
		getDfCsPortTerms().add(dfCsPortTerm);
		dfCsPortTerm.setCableSection(this);

		return dfCsPortTerm;
	}

	public DfCsPortTerm removeDfCsPortTerm(DfCsPortTerm dfCsPortTerm) {
		getDfCsPortTerms().remove(dfCsPortTerm);
		dfCsPortTerm.setCableSection(null);

		return dfCsPortTerm;
	}

	public List<DpCsCondSplicing> getDpCsCondSplicings1() {
		return this.dpCsCondSplicings1;
	}

	public void setDpCsCondSplicings1(
			List<DpCsCondSplicing> dpCsCondSplicings1) {
		this.dpCsCondSplicings1 = dpCsCondSplicings1;
	}

	public DpCsCondSplicing addDpCsCondSplicings1(
			DpCsCondSplicing dpCsCondSplicings1) {
		getDpCsCondSplicings1().add(dpCsCondSplicings1);
		dpCsCondSplicings1.setCableSectionOrigCsName(this);

		return dpCsCondSplicings1;
	}

	public DpCsCondSplicing removeDpCsCondSplicings1(
			DpCsCondSplicing dpCsCondSplicings1) {
		getDpCsCondSplicings1().remove(dpCsCondSplicings1);
		dpCsCondSplicings1.setCableSectionOrigCsName(null);

		return dpCsCondSplicings1;
	}

	public List<DpCsCondSplicing> getDpCsCondSplicings2() {
		return this.dpCsCondSplicings2;
	}

	public void setDpCsCondSplicings2(
			List<DpCsCondSplicing> dpCsCondSplicings2) {
		this.dpCsCondSplicings2 = dpCsCondSplicings2;
	}

	public DpCsCondSplicing addDpCsCondSplicings2(
			DpCsCondSplicing dpCsCondSplicings2) {
		getDpCsCondSplicings2().add(dpCsCondSplicings2);
		dpCsCondSplicings2.setCableSectionOrigParentCsName(this);

		return dpCsCondSplicings2;
	}

	public DpCsCondSplicing removeDpCsCondSplicings2(
			DpCsCondSplicing dpCsCondSplicings2) {
		getDpCsCondSplicings2().remove(dpCsCondSplicings2);
		dpCsCondSplicings2.setCableSectionOrigParentCsName(null);

		return dpCsCondSplicings2;
	}

	public List<DpCsCondSplicing> getDpCsCondSplicings3() {
		return this.dpCsCondSplicings3;
	}

	public void setDpCsCondSplicings3(
			List<DpCsCondSplicing> dpCsCondSplicings3) {
		this.dpCsCondSplicings3 = dpCsCondSplicings3;
	}

	public DpCsCondSplicing addDpCsCondSplicings3(
			DpCsCondSplicing dpCsCondSplicings3) {
		getDpCsCondSplicings3().add(dpCsCondSplicings3);
		dpCsCondSplicings3.setCableSectionTermCsName(this);

		return dpCsCondSplicings3;
	}

	public DpCsCondSplicing removeDpCsCondSplicings3(
			DpCsCondSplicing dpCsCondSplicings3) {
		getDpCsCondSplicings3().remove(dpCsCondSplicings3);
		dpCsCondSplicings3.setCableSectionTermCsName(null);

		return dpCsCondSplicings3;
	}

	public List<DpCsCondSplicing> getDpCsCondSplicings4() {
		return this.dpCsCondSplicings4;
	}

	public void setDpCsCondSplicings4(
			List<DpCsCondSplicing> dpCsCondSplicings4) {
		this.dpCsCondSplicings4 = dpCsCondSplicings4;
	}

	public DpCsCondSplicing addDpCsCondSplicings4(
			DpCsCondSplicing dpCsCondSplicings4) {
		getDpCsCondSplicings4().add(dpCsCondSplicings4);
		dpCsCondSplicings4.setCableSectionTermCsName(this);

		return dpCsCondSplicings4;
	}

	public DpCsCondSplicing removeDpCsCondSplicings4(
			DpCsCondSplicing dpCsCondSplicings4) {
		getDpCsCondSplicings4().remove(dpCsCondSplicings4);
		dpCsCondSplicings4.setCableSectionTermCsName(null);

		return dpCsCondSplicings4;
	}

	public List<DpCsPortTerm> getDpCsPortTerms() {
		return this.dpCsPortTerms;
	}

	public void setDpCsPortTerms(List<DpCsPortTerm> dpCsPortTerms) {
		this.dpCsPortTerms = dpCsPortTerms;
	}

	public DpCsPortTerm addDpCsPortTerm(DpCsPortTerm dpCsPortTerm) {
		if(getDpCsPortTerms()==null) {
			setDpCsPortTerms(new ArrayList<>());
		}
		getDpCsPortTerms().add(dpCsPortTerm);
		dpCsPortTerm.setCableSection(this);

		return dpCsPortTerm;
	}

	public DpCsPortTerm removeDpCsPortTerm(DpCsPortTerm dpCsPortTerm) {
		getDpCsPortTerms().remove(dpCsPortTerm);
		dpCsPortTerm.setCableSection(null);

		return dpCsPortTerm;
	}

	public List<DslamCsCondSplicing> getDslamCsCondSplicings1() {
		return this.dslamCsCondSplicings1;
	}

	public void setDslamCsCondSplicings1(
			List<DslamCsCondSplicing> dslamCsCondSplicings1) {
		this.dslamCsCondSplicings1 = dslamCsCondSplicings1;
	}

	public DslamCsCondSplicing addDslamCsCondSplicings1(
			DslamCsCondSplicing dslamCsCondSplicings1) {
		getDslamCsCondSplicings1().add(dslamCsCondSplicings1);
		dslamCsCondSplicings1.setCableSectionOrigCsName(this);

		return dslamCsCondSplicings1;
	}

	public DslamCsCondSplicing removeDslamCsCondSplicings1(
			DslamCsCondSplicing dslamCsCondSplicings1) {
		getDslamCsCondSplicings1().remove(dslamCsCondSplicings1);
		dslamCsCondSplicings1.setCableSectionOrigCsName(null);

		return dslamCsCondSplicings1;
	}

	public List<DslamCsCondSplicing> getDslamCsCondSplicings2() {
		return this.dslamCsCondSplicings2;
	}

	public void setDslamCsCondSplicings2(
			List<DslamCsCondSplicing> dslamCsCondSplicings2) {
		this.dslamCsCondSplicings2 = dslamCsCondSplicings2;
	}

	public DslamCsCondSplicing addDslamCsCondSplicings2(
			DslamCsCondSplicing dslamCsCondSplicings2) {
		getDslamCsCondSplicings2().add(dslamCsCondSplicings2);
		dslamCsCondSplicings2.setCableSectionOrigParentCsName(this);

		return dslamCsCondSplicings2;
	}

	public DslamCsCondSplicing removeDslamCsCondSplicings2(
			DslamCsCondSplicing dslamCsCondSplicings2) {
		getDslamCsCondSplicings2().remove(dslamCsCondSplicings2);
		dslamCsCondSplicings2.setCableSectionOrigParentCsName(null);

		return dslamCsCondSplicings2;
	}

	public List<DslamCsCondSplicing> getDslamCsCondSplicings3() {
		return this.dslamCsCondSplicings3;
	}

	public void setDslamCsCondSplicings3(
			List<DslamCsCondSplicing> dslamCsCondSplicings3) {
		this.dslamCsCondSplicings3 = dslamCsCondSplicings3;
	}

	public DslamCsCondSplicing addDslamCsCondSplicings3(
			DslamCsCondSplicing dslamCsCondSplicings3) {
		getDslamCsCondSplicings3().add(dslamCsCondSplicings3);
		dslamCsCondSplicings3.setCableSectionTermCsName(this);

		return dslamCsCondSplicings3;
	}

	public DslamCsCondSplicing removeDslamCsCondSplicings3(
			DslamCsCondSplicing dslamCsCondSplicings3) {
		getDslamCsCondSplicings3().remove(dslamCsCondSplicings3);
		dslamCsCondSplicings3.setCableSectionTermCsName(null);

		return dslamCsCondSplicings3;
	}

	public List<DslamCsCondSplicing> getDslamCsCondSplicings4() {
		return this.dslamCsCondSplicings4;
	}

	public void setDslamCsCondSplicings4(
			List<DslamCsCondSplicing> dslamCsCondSplicings4) {
		this.dslamCsCondSplicings4 = dslamCsCondSplicings4;
	}

	public DslamCsCondSplicing addDslamCsCondSplicings4(
			DslamCsCondSplicing dslamCsCondSplicings4) {
		getDslamCsCondSplicings4().add(dslamCsCondSplicings4);
		dslamCsCondSplicings4.setCableSectionTermParentCsName(this);

		return dslamCsCondSplicings4;
	}

	public DslamCsCondSplicing removeDslamCsCondSplicings4(
			DslamCsCondSplicing dslamCsCondSplicings4) {
		getDslamCsCondSplicings4().remove(dslamCsCondSplicings4);
		dslamCsCondSplicings4.setCableSectionTermParentCsName(null);

		return dslamCsCondSplicings4;
	}

	public List<DslamCsPortTerm> getDslamCsPortTerms() {
		return this.dslamCsPortTerms;
	}

	public void setDslamCsPortTerms(List<DslamCsPortTerm> dslamCsPortTerms) {
		this.dslamCsPortTerms = dslamCsPortTerms;
	}

	public DslamCsPortTerm addDslamCsPortTerm(DslamCsPortTerm dslamCsPortTerm) {
		if(getDslamCsPortTerms()==null) {
			setDslamCsPortTerms(new ArrayList<>());
		}
		getDslamCsPortTerms().add(dslamCsPortTerm);
		dslamCsPortTerm.setCableSection(this);

		return dslamCsPortTerm;
	}

	public DslamCsPortTerm removeDslamCsPortTerm(
			DslamCsPortTerm dslamCsPortTerm) {
		getDslamCsPortTerms().remove(dslamCsPortTerm);
		dslamCsPortTerm.setCableSection(null);

		return dslamCsPortTerm;
	}

	public List<JcCsCondSplicing> getJcCsCondSplicings1() {
		return this.jcCsCondSplicings1;
	}

	public void setJcCsCondSplicings1(
			List<JcCsCondSplicing> jcCsCondSplicings1) {
		this.jcCsCondSplicings1 = jcCsCondSplicings1;
	}

	public JcCsCondSplicing addJcCsCondSplicings1(
			JcCsCondSplicing jcCsCondSplicings1) {
		getJcCsCondSplicings1().add(jcCsCondSplicings1);
		jcCsCondSplicings1.setCableSectionOrigCsName(this);

		return jcCsCondSplicings1;
	}

	public JcCsCondSplicing removeJcCsCondSplicings1(
			JcCsCondSplicing jcCsCondSplicings1) {
		getJcCsCondSplicings1().remove(jcCsCondSplicings1);
		jcCsCondSplicings1.setCableSectionOrigCsName(null);

		return jcCsCondSplicings1;
	}

	public List<JcCsCondSplicing> getJcCsCondSplicings2() {
		return this.jcCsCondSplicings2;
	}

	public void setJcCsCondSplicings2(
			List<JcCsCondSplicing> jcCsCondSplicings2) {
		this.jcCsCondSplicings2 = jcCsCondSplicings2;
	}

	public JcCsCondSplicing addJcCsCondSplicings2(
			JcCsCondSplicing jcCsCondSplicings2) {
		getJcCsCondSplicings2().add(jcCsCondSplicings2);
		jcCsCondSplicings2.setCableSectionOrigParentCsName(this);

		return jcCsCondSplicings2;
	}

	public JcCsCondSplicing removeJcCsCondSplicings2(
			JcCsCondSplicing jcCsCondSplicings2) {
		getJcCsCondSplicings2().remove(jcCsCondSplicings2);
		jcCsCondSplicings2.setCableSectionOrigParentCsName(null);

		return jcCsCondSplicings2;
	}

	public List<JcCsCondSplicing> getJcCsCondSplicings3() {
		return this.jcCsCondSplicings3;
	}

	public void setJcCsCondSplicings3(
			List<JcCsCondSplicing> jcCsCondSplicings3) {
		this.jcCsCondSplicings3 = jcCsCondSplicings3;
	}

	public JcCsCondSplicing addJcCsCondSplicings3(
			JcCsCondSplicing jcCsCondSplicings3) {
		getJcCsCondSplicings3().add(jcCsCondSplicings3);
		jcCsCondSplicings3.setCableSectionTermCsName(this);

		return jcCsCondSplicings3;
	}

	public JcCsCondSplicing removeJcCsCondSplicings3(
			JcCsCondSplicing jcCsCondSplicings3) {
		getJcCsCondSplicings3().remove(jcCsCondSplicings3);
		jcCsCondSplicings3.setCableSectionTermCsName(null);

		return jcCsCondSplicings3;
	}

	public List<JcCsCondSplicing> getJcCsCondSplicings4() {
		return this.jcCsCondSplicings4;
	}

	public void setJcCsCondSplicings4(
			List<JcCsCondSplicing> jcCsCondSplicings4) {
		this.jcCsCondSplicings4 = jcCsCondSplicings4;
	}

	public JcCsCondSplicing addJcCsCondSplicings4(
			JcCsCondSplicing jcCsCondSplicings4) {
		getJcCsCondSplicings4().add(jcCsCondSplicings4);
		jcCsCondSplicings4.setCableSectionTermParentCsName(this);

		return jcCsCondSplicings4;
	}

	public JcCsCondSplicing removeJcCsCondSplicings4(
			JcCsCondSplicing jcCsCondSplicings4) {
		getJcCsCondSplicings4().remove(jcCsCondSplicings4);
		jcCsCondSplicings4.setCableSectionTermParentCsName(null);

		return jcCsCondSplicings4;
	}

	public List<JcCsPortTerm> getJcCsPortTerms() {
		return this.jcCsPortTerms;
	}

	public void setJcCsPortTerms(List<JcCsPortTerm> jcCsPortTerms) {
		this.jcCsPortTerms = jcCsPortTerms;
	}

	public JcCsPortTerm addJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		if(getJcCsPortTerms()==null) {
			setJcCsPortTerms(new ArrayList<>());
		}
		getJcCsPortTerms().add(jcCsPortTerm);
		jcCsPortTerm.setCableSection(this);

		return jcCsPortTerm;
	}

	public JcCsPortTerm removeJcCsPortTerm(JcCsPortTerm jcCsPortTerm) {
		getJcCsPortTerms().remove(jcCsPortTerm);
		jcCsPortTerm.setCableSection(null);

		return jcCsPortTerm;
	}

	public List<MfnCsCondSplicing> getMfnCableConductorSplicings1() {
		return this.mfnCableConductorOrigCsName;
	}

	public void setMfnCableConductorSplicings1(
			List<MfnCsCondSplicing> mfnCableConductorSplicings1) {
		this.mfnCableConductorOrigCsName = mfnCableConductorSplicings1;
	}

	public MfnCsCondSplicing addMfnCableConductorSplicings1(MfnCsCondSplicing mfnCableConductorSplicings1) {
		getMfnCableConductorSplicings1().add(mfnCableConductorSplicings1);
		mfnCableConductorSplicings1.setOrigCsName(this);

		return mfnCableConductorSplicings1;
	}

	public MfnCsCondSplicing removeMfnCableConductorSplicings1(MfnCsCondSplicing mfnCableConductorSplicings1) {
		getMfnCableConductorSplicings1().remove(mfnCableConductorSplicings1);
		mfnCableConductorSplicings1.setOrigCsName(null);

		return mfnCableConductorSplicings1;
	}

	public List<MfnCsCondSplicing> getMfnCableConductorSplicings2() {
		return this.mfnCableConductorOrigParCsName;
	}

	public void setMfnCableConductorSplicings2(
			List<MfnCsCondSplicing> mfnCableConductorSplicings2) {
		this.mfnCableConductorOrigParCsName = mfnCableConductorSplicings2;
	}

	public MfnCsCondSplicing addMfnCableConductorSplicings2(MfnCsCondSplicing mfnCableConductorSplicings2) {
		getMfnCableConductorSplicings2().add(mfnCableConductorSplicings2);
		mfnCableConductorSplicings2.setOrigParCsName(this);

		return mfnCableConductorSplicings2;
	}

	public MfnCsCondSplicing removeMfnCableConductorSplicings2(MfnCsCondSplicing mfnCableConductorSplicings2) {
		getMfnCableConductorSplicings2().remove(mfnCableConductorSplicings2);
		mfnCableConductorSplicings2.setOrigParCsName(null);

		return mfnCableConductorSplicings2;
	}

	public List<MfnCsCondSplicing> getMfnCableConductorSplicings3() {
		return this.mfnCableConductorTermCsName;
	}

	public void setMfnCableConductorSplicings3(
			List<MfnCsCondSplicing> mfnCableConductorSplicings3) {
		this.mfnCableConductorTermCsName = mfnCableConductorSplicings3;
	}

	public MfnCsCondSplicing addMfnCableConductorSplicings3(MfnCsCondSplicing mfnCableConductorSplicings3) {
		getMfnCableConductorSplicings3().add(mfnCableConductorSplicings3);
		mfnCableConductorSplicings3.setTermCsName(this);

		return mfnCableConductorSplicings3;
	}

	public MfnCsCondSplicing removeMfnCableConductorSplicings3(MfnCsCondSplicing mfnCableConductorSplicings3) {
		getMfnCableConductorSplicings3().remove(mfnCableConductorSplicings3);
		mfnCableConductorSplicings3.setTermCsName(null);

		return mfnCableConductorSplicings3;
	}

	public List<MfnCsCondSplicing> getMfnCableConductorSplicings4() {
		return this.mfnCableConductorTermParCsName;
	}

	public void setMfnCableConductorSplicings4(
			List<MfnCsCondSplicing> mfnCableConductorSplicings4) {
		this.mfnCableConductorTermParCsName = mfnCableConductorSplicings4;
	}

	public MfnCsCondSplicing addMfnCableConductorSplicings4(MfnCsCondSplicing mfnCableConductorSplicings4) {
		getMfnCableConductorSplicings4().add(mfnCableConductorSplicings4);
		mfnCableConductorSplicings4.setTermParCsName(this);

		return mfnCableConductorSplicings4;
	}

	public MfnCsCondSplicing removeMfnCableConductorSplicings4(MfnCsCondSplicing mfnCableConductorSplicings4) {
		getMfnCableConductorSplicings4().remove(mfnCableConductorSplicings4);
		mfnCableConductorSplicings4.setTermParCsName(null);

		return mfnCableConductorSplicings4;
	}

	public List<MfnCsPortTerm> getMfnCsPortTerms() {
		return this.mfnCsPortTerms;
	}

	public void setMfnCsPortTerms(List<MfnCsPortTerm> mfnCsPortTerms) {
		this.mfnCsPortTerms = mfnCsPortTerms;
	}

	public MfnCsPortTerm addMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		if(getMfnCsPortTerms()==null) {
			setMfnCsPortTerms(new ArrayList<>());
		}
		getMfnCsPortTerms().add(mfnCsPortTerm);
		mfnCsPortTerm.setCableSection(this);

		return mfnCsPortTerm;
	}

	public MfnCsPortTerm removeMfnCsPortTerm(MfnCsPortTerm mfnCsPortTerm) {
		getMfnCsPortTerms().remove(mfnCsPortTerm);
		mfnCsPortTerm.setCableSection(null);

		return mfnCsPortTerm;
	}

	public List<NteCsCondSplicing> getNteCsCondSplicings1() {
		return this.nteCsCondSplicings1;
	}

	public void setNteCsCondSplicings1(
			List<NteCsCondSplicing> nteCsCondSplicings1) {
		this.nteCsCondSplicings1 = nteCsCondSplicings1;
	}

	public NteCsCondSplicing addNteCsCondSplicings1(
			NteCsCondSplicing nteCsCondSplicings1) {
		getNteCsCondSplicings1().add(nteCsCondSplicings1);
		nteCsCondSplicings1.setCableSectionOrigCsName(this);

		return nteCsCondSplicings1;
	}

	public NteCsCondSplicing removeNteCsCondSplicings1(
			NteCsCondSplicing nteCsCondSplicings1) {
		getNteCsCondSplicings1().remove(nteCsCondSplicings1);
		nteCsCondSplicings1.setCableSectionOrigCsName(null);

		return nteCsCondSplicings1;
	}

	public List<NteCsCondSplicing> getNteCsCondSplicings2() {
		return this.nteCsCondSplicings2;
	}

	public void setNteCsCondSplicings2(
			List<NteCsCondSplicing> nteCsCondSplicings2) {
		this.nteCsCondSplicings2 = nteCsCondSplicings2;
	}

	public NteCsCondSplicing addNteCsCondSplicings2(
			NteCsCondSplicing nteCsCondSplicings2) {
		getNteCsCondSplicings2().add(nteCsCondSplicings2);
		nteCsCondSplicings2.setCableSectionOrigParentCsName(this);

		return nteCsCondSplicings2;
	}

	public NteCsCondSplicing removeNteCsCondSplicings2(
			NteCsCondSplicing nteCsCondSplicings2) {
		getNteCsCondSplicings2().remove(nteCsCondSplicings2);
		nteCsCondSplicings2.setCableSectionOrigParentCsName(null);

		return nteCsCondSplicings2;
	}

	public List<NteCsCondSplicing> getNteCsCondSplicings3() {
		return this.nteCsCondSplicings3;
	}

	public void setNteCsCondSplicings3(
			List<NteCsCondSplicing> nteCsCondSplicings3) {
		this.nteCsCondSplicings3 = nteCsCondSplicings3;
	}

	public NteCsCondSplicing addNteCsCondSplicings3(
			NteCsCondSplicing nteCsCondSplicings3) {
		getNteCsCondSplicings3().add(nteCsCondSplicings3);
		nteCsCondSplicings3.setCableSectionTermCsName(this);

		return nteCsCondSplicings3;
	}

	public NteCsCondSplicing removeNteCsCondSplicings3(
			NteCsCondSplicing nteCsCondSplicings3) {
		getNteCsCondSplicings3().remove(nteCsCondSplicings3);
		nteCsCondSplicings3.setCableSectionTermCsName(null);

		return nteCsCondSplicings3;
	}

	public List<NteCsCondSplicing> getNteCsCondSplicings4() {
		return this.nteCsCondSplicings4;
	}

	public void setNteCsCondSplicings4(
			List<NteCsCondSplicing> nteCsCondSplicings4) {
		this.nteCsCondSplicings4 = nteCsCondSplicings4;
	}

	public NteCsCondSplicing addNteCsCondSplicings4(
			NteCsCondSplicing nteCsCondSplicings4) {
		getNteCsCondSplicings4().add(nteCsCondSplicings4);
		nteCsCondSplicings4.setCableSectionTermParentCsName(this);

		return nteCsCondSplicings4;
	}

	public NteCsCondSplicing removeNteCsCondSplicings4(
			NteCsCondSplicing nteCsCondSplicings4) {
		getNteCsCondSplicings4().remove(nteCsCondSplicings4);
		nteCsCondSplicings4.setCableSectionTermParentCsName(null);

		return nteCsCondSplicings4;
	}

	public List<NteCsPortTerm> getNteCsPortTerms() {
		return this.nteCsPortTerms;
	}

	public void setNteCsPortTerms(List<NteCsPortTerm> nteCsPortTerms) {
		this.nteCsPortTerms = nteCsPortTerms;
	}

	public NteCsPortTerm addNteCsPortTerm(NteCsPortTerm nteCsPortTerm) {
		if(getNteCsPortTerms()==null) {
			setNteCsPortTerms(new ArrayList<>());
		}
		getNteCsPortTerms().add(nteCsPortTerm);
		nteCsPortTerm.setCableSection(this);

		return nteCsPortTerm;
	}

	public NteCsPortTerm removeNteCsPortTerm(NteCsPortTerm nteCsPortTerm) {
		getNteCsPortTerms().remove(nteCsPortTerm);
		nteCsPortTerm.setCableSection(null);

		return nteCsPortTerm;
	}

	public List<WeCsCondSplicing> getWeCableConductorSplicingsOriginating() {
		return this.weCableConductorSplicingsOriginating;
	}

	public void setWeCableConductorSplicingsOriginating(
			List<WeCsCondSplicing> weCableConductorSplicingsOriginating) {
		this.weCableConductorSplicingsOriginating = weCableConductorSplicingsOriginating;
	}

	public WeCsCondSplicing addWeCableConductorSplicings1(WeCsCondSplicing weCableConductorSplicingsOriginating) {
		getWeCableConductorSplicingsOriginating()
				.add(weCableConductorSplicingsOriginating);
		weCableConductorSplicingsOriginating.setOrigCsName(this);

		return weCableConductorSplicingsOriginating;
	}

	public WeCsCondSplicing removeWeCableConductorSplicingsOriginating(
			WeCsCondSplicing weCableConductorSplicingsOriginating) {
		getWeCableConductorSplicingsOriginating()
				.remove(weCableConductorSplicingsOriginating);
		weCableConductorSplicingsOriginating.setOrigCsName(null);

		return weCableConductorSplicingsOriginating;
	}

	public List<WeCsCondSplicing> getWeCableConductorSplicingsOriginatingParent() {
		return this.weCableConductorSplicingsOriginatingParent;
	}

	public void setWeCableConductorSplicingsOriginatingParent(
			List<WeCsCondSplicing> weCableConductorSplicingsOriginatingParent) {
		this.weCableConductorSplicingsOriginatingParent = weCableConductorSplicingsOriginatingParent;
	}

	public WeCsCondSplicing addWeCableConductorSplicingsOriginatingParent(
			WeCsCondSplicing weCableConductorSplicingsOriginatingParent) {
		getWeCableConductorSplicingsOriginatingParent()
				.add(weCableConductorSplicingsOriginatingParent);
		weCableConductorSplicingsOriginatingParent.setOrigParCsName(this);

		return weCableConductorSplicingsOriginatingParent;
	}

	public WeCsCondSplicing removeWeCableConductorSplicings2(
			WeCsCondSplicing weCableConductorSplicingsOriginatingParent) {
		getWeCableConductorSplicingsOriginatingParent()
				.remove(weCableConductorSplicingsOriginatingParent);
		weCableConductorSplicingsOriginatingParent.setOrigParCsName(null);

		return weCableConductorSplicingsOriginatingParent;
	}

	public List<WeCsCondSplicing> getWeCableConductorSplicingsTerminating() {
		return this.weCableConductorSplicingsTerminating;
	}

	public void setWeCableConductorSplicingsTerminating(
			List<WeCsCondSplicing> weCableConductorSplicingsTerminating) {
		this.weCableConductorSplicingsTerminating = weCableConductorSplicingsTerminating;
	}

	public WeCsCondSplicing addWeCableConductorSplicingsTerminating(
			WeCsCondSplicing weCableConductorSplicingsTerminating) {
		getWeCableConductorSplicingsTerminating()
				.add(weCableConductorSplicingsTerminating);
		weCableConductorSplicingsTerminating.setTermCsName(this);

		return weCableConductorSplicingsTerminating;
	}

	public WeCsCondSplicing removeWeCableConductorSplicingsTerminating(
			WeCsCondSplicing weCableConductorSplicingsTerminating) {
		getWeCableConductorSplicingsTerminating()
				.remove(weCableConductorSplicingsTerminating);
		weCableConductorSplicingsTerminating.setTermCsName(null);

		return weCableConductorSplicingsTerminating;
	}

	public List<WeCsCondSplicing> getWeCableConductorSplicingsTerminatingParent() {
		return this.weCableConductorSplicingsTerminatingParent;
	}

	public void setWeCableConductorSplicingsTerminatingParent(
			List<WeCsCondSplicing> weCableConductorSplicingsTerminatingParent) {
		this.weCableConductorSplicingsTerminatingParent = weCableConductorSplicingsTerminatingParent;
	}

	public WeCsCondSplicing addWeCableConductorSplicingsTerminatingParent(
			WeCsCondSplicing weCableConductorSplicingsTerminatingParent) {
		getWeCableConductorSplicingsTerminatingParent()
				.add(weCableConductorSplicingsTerminatingParent);
		weCableConductorSplicingsTerminatingParent.setTermParCsName(this);

		return weCableConductorSplicingsTerminatingParent;
	}

	public WeCsCondSplicing removeWeCableConductorSplicingsTerminatingParent(
			WeCsCondSplicing weCableConductorSplicingsTerminatingParent) {
		getWeCableConductorSplicingsTerminatingParent()
				.remove(weCableConductorSplicingsTerminatingParent);
		weCableConductorSplicingsTerminatingParent.setTermParCsName(null);

		return weCableConductorSplicingsTerminatingParent;
	}

	public List<WeCsPortTerm> getWeCsPortTerms() {
		return this.weCsPortTerms;
	}

	public void setWeCsPortTerms(List<WeCsPortTerm> weCsPortTerms) {
		this.weCsPortTerms = weCsPortTerms;
	}

	public WeCsPortTerm addWeCsPortTerm(WeCsPortTerm weCsPortTerm) {
		if(getWeCsPortTerms()==null) {
			setWeCsPortTerms(new ArrayList<>());
		}
		getWeCsPortTerms().add(weCsPortTerm);
		weCsPortTerm.setCableSection(this);

		return weCsPortTerm;
	}

	public WeCsPortTerm removeWeCsPortTerm(WeCsPortTerm weCsPortTerm) {
		getWeCsPortTerms().remove(weCsPortTerm);
		weCsPortTerm.setCableSection(null);

		return weCsPortTerm;
	}

}