package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the STRUCTURE_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="STRUCTURE_SPEC")
@NamedQuery(name="StructureSpec.findAll", query="SELECT s FROM StructureSpec s")
public class StructureSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private StructureSpecPK structureSpecPKId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DEPTH", precision=126)
	private double depth;

	@Column(name="DEPTH_UNIT", length=10)
	private String depthUnit;

	@Column(precision=126)
	private double diameter;

	@Column(name="DIAMETER_UNIT", length=10)
	private String diameterUnit;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(precision=126)
	private double height;

	@Column(name="HEIGHT_UNIT", length=10)
	private String heightUnit;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="IS_ORDERABLE")
	private String isOrderable;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LENGTH", precision=126)
	private double length;

	@Column(name="LENGTH_UNIT", length=10)
	private String lengthUnit;

	@Column(name="MANUFACTURER_NAME", length=30)
	private String manufacturerName;

	@Column(name="MATERIAL_COST_PER_UNIT", precision=126)
	private double materialCostPerUnit;

	@Column(name="MATERIAL_COST_UNIT", length=10)
	private String materialCostUnit;

	@Column(name="MATERIAL_TYPE", length=10)
	private String materialType;

	@Column(name="SPEC_REMARKS", length=50)
	private String specRemarks;

	@Column(name="SPEC_STATUS", nullable=false, length=10)
	private String specStatus;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	@Column(precision=126)
	private double volume;

	@Column(name="VOLUME_UNIT", length=10)
	private String volumeUnit;

	@Column(precision=126)
	private double weight;

	@Column(name="WEIGHT_UNIT", length=10)
	private String weightUnit;

	@Column(precision=126)
	private double width;

	@Column(name="WIDTH_UNIT", length=10)
	private String widthUnit;

	//bi-directional many-to-one association to CabinetSelfAssocSpec
	@OneToMany(mappedBy="structureSpec1")
	private List<CabinetSelfAssocSpec> cabinetSelfAssocSpecs1;

	//bi-directional many-to-one association to CabinetSelfAssocSpec
	@OneToMany(mappedBy="structureSpec2")
	private List<CabinetSelfAssocSpec> cabinetSelfAssocSpecs2;

	//bi-directional many-to-one association to JchamberSelfAssocSpec
	@OneToMany(mappedBy="structureSpec1")
	private List<JchamberSelfAssocSpec> jchamberSelfAssocSpecs1;

	//bi-directional many-to-one association to JchamberSelfAssocSpec
	@OneToMany(mappedBy="structureSpec2")
	private List<JchamberSelfAssocSpec> jchamberSelfAssocSpecs2;

	//bi-directional many-to-one association to StructureSelfAssocSpec
	@OneToMany(mappedBy="structureSpec1")
	private List<StructureSelfAssocSpec> structureSelfAssocSpecs1;

	//bi-directional many-to-one association to StructureSelfAssocSpec
	@OneToMany(mappedBy="structureSpec2")
	private List<StructureSelfAssocSpec> structureSelfAssocSpecs2;

	//bi-directional many-to-one association to StructureSpanCompatSpec
	@OneToMany(mappedBy="structureSpec")
	private List<StructureSpanCompatSpec> structureSpanCompatSpecs;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to StructureSpecCharSpec
	@OneToMany(mappedBy="structureSpec")
	private List<StructureSpecCharSpec> structureSpecCharSpecs;

	//bi-directional many-to-one association to StructureSpecCharSpecRel
	@OneToMany(mappedBy="structureSpec")
	private List<StructureSpecCharSpecRel> structureSpecCharSpecRels;

	//bi-directional many-to-one association to StructureSpecCharValueSpec
	@OneToMany(mappedBy="structureSpec")
	private List<StructureSpecCharValueSpec> structureSpecCharValueSpecs;

	public StructureSpec() {
	}

	public StructureSpecPK getStructureSpecPKId() {
		return this.structureSpecPKId;
	}

	public void setId(StructureSpecPK structureSpecPKId) {
		this.structureSpecPKId = structureSpecPKId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public double getDepth() {
		return this.depth;
	}

	public void setDepth(double depth) {
		this.depth = depth;
	}

	public String getDepthUnit() {
		return this.depthUnit;
	}

	public void setDepthUnit(String depthUnit) {
		this.depthUnit = depthUnit;
	}

	public double getDiameter() {
		return this.diameter;
	}

	public void setDiameter(double diameter) {
		this.diameter = diameter;
	}

	public String getDiameterUnit() {
		return this.diameterUnit;
	}

	public void setDiameterUnit(String diameterUnit) {
		this.diameterUnit = diameterUnit;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public double getHeight() {
		return this.height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public String getHeightUnit() {
		return this.heightUnit;
	}

	public void setHeightUnit(String heightUnit) {
		this.heightUnit = heightUnit;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIsOrderable() {
		return this.isOrderable;
	}

	public void setIsOrderable(String isOrderable) {
		this.isOrderable = isOrderable;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public double getLength() {
		return this.length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public String getLengthUnit() {
		return this.lengthUnit;
	}

	public void setLengthUnit(String lengthUnit) {
		this.lengthUnit = lengthUnit;
	}

	public String getManufacturerName() {
		return this.manufacturerName;
	}

	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}

	public double getMaterialCostPerUnit() {
		return this.materialCostPerUnit;
	}

	public void setMaterialCostPerUnit(double materialCostPerUnit) {
		this.materialCostPerUnit = materialCostPerUnit;
	}

	public String getMaterialCostUnit() {
		return this.materialCostUnit;
	}

	public void setMaterialCostUnit(String materialCostUnit) {
		this.materialCostUnit = materialCostUnit;
	}

	public String getMaterialType() {
		return this.materialType;
	}

	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}

	public String getSpecRemarks() {
		return this.specRemarks;
	}

	public void setSpecRemarks(String specRemarks) {
		this.specRemarks = specRemarks;
	}

	public String getSpecStatus() {
		return this.specStatus;
	}

	public void setSpecStatus(String specStatus) {
		this.specStatus = specStatus;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public double getVolume() {
		return this.volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public String getVolumeUnit() {
		return this.volumeUnit;
	}

	public void setVolumeUnit(String volumeUnit) {
		this.volumeUnit = volumeUnit;
	}

	public double getWeight() {
		return this.weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getWeightUnit() {
		return this.weightUnit;
	}

	public void setWeightUnit(String weightUnit) {
		this.weightUnit = weightUnit;
	}

	public double getWidth() {
		return this.width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public String getWidthUnit() {
		return this.widthUnit;
	}

	public void setWidthUnit(String widthUnit) {
		this.widthUnit = widthUnit;
	}

	public List<CabinetSelfAssocSpec> getCabinetSelfAssocSpecs1() {
		return this.cabinetSelfAssocSpecs1;
	}

	public void setCabinetSelfAssocSpecs1(List<CabinetSelfAssocSpec> cabinetSelfAssocSpecs1) {
		this.cabinetSelfAssocSpecs1 = cabinetSelfAssocSpecs1;
	}

	public CabinetSelfAssocSpec addCabinetSelfAssocSpecs1(CabinetSelfAssocSpec cabinetSelfAssocSpecs1) {
		getCabinetSelfAssocSpecs1().add(cabinetSelfAssocSpecs1);
		cabinetSelfAssocSpecs1.setStructureSpec1(this);

		return cabinetSelfAssocSpecs1;
	}

	public CabinetSelfAssocSpec removeCabinetSelfAssocSpecs1(CabinetSelfAssocSpec cabinetSelfAssocSpecs1) {
		getCabinetSelfAssocSpecs1().remove(cabinetSelfAssocSpecs1);
		cabinetSelfAssocSpecs1.setStructureSpec1(null);

		return cabinetSelfAssocSpecs1;
	}

	public List<CabinetSelfAssocSpec> getCabinetSelfAssocSpecs2() {
		return this.cabinetSelfAssocSpecs2;
	}

	public void setCabinetSelfAssocSpecs2(List<CabinetSelfAssocSpec> cabinetSelfAssocSpecs2) {
		this.cabinetSelfAssocSpecs2 = cabinetSelfAssocSpecs2;
	}

	public CabinetSelfAssocSpec addCabinetSelfAssocSpecs2(CabinetSelfAssocSpec cabinetSelfAssocSpecs2) {
		getCabinetSelfAssocSpecs2().add(cabinetSelfAssocSpecs2);
		cabinetSelfAssocSpecs2.setStructureSpec2(this);

		return cabinetSelfAssocSpecs2;
	}

	public CabinetSelfAssocSpec removeCabinetSelfAssocSpecs2(CabinetSelfAssocSpec cabinetSelfAssocSpecs2) {
		getCabinetSelfAssocSpecs2().remove(cabinetSelfAssocSpecs2);
		cabinetSelfAssocSpecs2.setStructureSpec2(null);

		return cabinetSelfAssocSpecs2;
	}

	public List<JchamberSelfAssocSpec> getJchamberSelfAssocSpecs1() {
		return this.jchamberSelfAssocSpecs1;
	}

	public void setJchamberSelfAssocSpecs1(List<JchamberSelfAssocSpec> jchamberSelfAssocSpecs1) {
		this.jchamberSelfAssocSpecs1 = jchamberSelfAssocSpecs1;
	}

	public JchamberSelfAssocSpec addJchamberSelfAssocSpecs1(JchamberSelfAssocSpec jchamberSelfAssocSpecs1) {
		getJchamberSelfAssocSpecs1().add(jchamberSelfAssocSpecs1);
		jchamberSelfAssocSpecs1.setStructureSpec1(this);

		return jchamberSelfAssocSpecs1;
	}

	public JchamberSelfAssocSpec removeJchamberSelfAssocSpecs1(JchamberSelfAssocSpec jchamberSelfAssocSpecs1) {
		getJchamberSelfAssocSpecs1().remove(jchamberSelfAssocSpecs1);
		jchamberSelfAssocSpecs1.setStructureSpec1(null);

		return jchamberSelfAssocSpecs1;
	}

	public List<JchamberSelfAssocSpec> getJchamberSelfAssocSpecs2() {
		return this.jchamberSelfAssocSpecs2;
	}

	public void setJchamberSelfAssocSpecs2(List<JchamberSelfAssocSpec> jchamberSelfAssocSpecs2) {
		this.jchamberSelfAssocSpecs2 = jchamberSelfAssocSpecs2;
	}

	public JchamberSelfAssocSpec addJchamberSelfAssocSpecs2(JchamberSelfAssocSpec jchamberSelfAssocSpecs2) {
		getJchamberSelfAssocSpecs2().add(jchamberSelfAssocSpecs2);
		jchamberSelfAssocSpecs2.setStructureSpec2(this);

		return jchamberSelfAssocSpecs2;
	}

	public JchamberSelfAssocSpec removeJchamberSelfAssocSpecs2(JchamberSelfAssocSpec jchamberSelfAssocSpecs2) {
		getJchamberSelfAssocSpecs2().remove(jchamberSelfAssocSpecs2);
		jchamberSelfAssocSpecs2.setStructureSpec2(null);

		return jchamberSelfAssocSpecs2;
	}

	public List<StructureSelfAssocSpec> getStructureSelfAssocSpecs1() {
		return this.structureSelfAssocSpecs1;
	}

	public void setStructureSelfAssocSpecs1(List<StructureSelfAssocSpec> structureSelfAssocSpecs1) {
		this.structureSelfAssocSpecs1 = structureSelfAssocSpecs1;
	}

	public StructureSelfAssocSpec addStructureSelfAssocSpecs1(StructureSelfAssocSpec structureSelfAssocSpecs1) {
		getStructureSelfAssocSpecs1().add(structureSelfAssocSpecs1);
		structureSelfAssocSpecs1.setStructureSpec1(this);

		return structureSelfAssocSpecs1;
	}

	public StructureSelfAssocSpec removeStructureSelfAssocSpecs1(StructureSelfAssocSpec structureSelfAssocSpecs1) {
		getStructureSelfAssocSpecs1().remove(structureSelfAssocSpecs1);
		structureSelfAssocSpecs1.setStructureSpec1(null);

		return structureSelfAssocSpecs1;
	}

	public List<StructureSelfAssocSpec> getStructureSelfAssocSpecs2() {
		return this.structureSelfAssocSpecs2;
	}

	public void setStructureSelfAssocSpecs2(List<StructureSelfAssocSpec> structureSelfAssocSpecs2) {
		this.structureSelfAssocSpecs2 = structureSelfAssocSpecs2;
	}

	public StructureSelfAssocSpec addStructureSelfAssocSpecs2(StructureSelfAssocSpec structureSelfAssocSpecs2) {
		getStructureSelfAssocSpecs2().add(structureSelfAssocSpecs2);
		structureSelfAssocSpecs2.setStructureSpec2(this);

		return structureSelfAssocSpecs2;
	}

	public StructureSelfAssocSpec removeStructureSelfAssocSpecs2(StructureSelfAssocSpec structureSelfAssocSpecs2) {
		getStructureSelfAssocSpecs2().remove(structureSelfAssocSpecs2);
		structureSelfAssocSpecs2.setStructureSpec2(null);

		return structureSelfAssocSpecs2;
	}

	public List<StructureSpanCompatSpec> getStructureSpanCompatSpecs() {
		return this.structureSpanCompatSpecs;
	}

	public void setStructureSpanCompatSpecs(List<StructureSpanCompatSpec> structureSpanCompatSpecs) {
		this.structureSpanCompatSpecs = structureSpanCompatSpecs;
	}

	public StructureSpanCompatSpec addStructureSpanCompatSpec(StructureSpanCompatSpec structureSpanCompatSpec) {
		getStructureSpanCompatSpecs().add(structureSpanCompatSpec);
		structureSpanCompatSpec.setStructureSpec(this);

		return structureSpanCompatSpec;
	}

	public StructureSpanCompatSpec removeStructureSpanCompatSpec(StructureSpanCompatSpec structureSpanCompatSpec) {
		getStructureSpanCompatSpecs().remove(structureSpanCompatSpec);
		structureSpanCompatSpec.setStructureSpec(null);

		return structureSpanCompatSpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public List<StructureSpecCharSpec> getStructureSpecCharSpecs() {
		return this.structureSpecCharSpecs;
	}

	public void setStructureSpecCharSpecs(List<StructureSpecCharSpec> structureSpecCharSpecs) {
		this.structureSpecCharSpecs = structureSpecCharSpecs;
	}

	public StructureSpecCharSpec addStructureSpecCharSpec(StructureSpecCharSpec structureSpecCharSpec) {
		getStructureSpecCharSpecs().add(structureSpecCharSpec);
		structureSpecCharSpec.setStructureSpec(this);

		return structureSpecCharSpec;
	}

	public StructureSpecCharSpec removeStructureSpecCharSpec(StructureSpecCharSpec structureSpecCharSpec) {
		getStructureSpecCharSpecs().remove(structureSpecCharSpec);
		structureSpecCharSpec.setStructureSpec(null);

		return structureSpecCharSpec;
	}

	public List<StructureSpecCharSpecRel> getStructureSpecCharSpecRels() {
		return this.structureSpecCharSpecRels;
	}

	public void setStructureSpecCharSpecRels(List<StructureSpecCharSpecRel> structureSpecCharSpecRels) {
		this.structureSpecCharSpecRels = structureSpecCharSpecRels;
	}

	public StructureSpecCharSpecRel addStructureSpecCharSpecRel(StructureSpecCharSpecRel structureSpecCharSpecRel) {
		getStructureSpecCharSpecRels().add(structureSpecCharSpecRel);
		structureSpecCharSpecRel.setStructureSpec(this);

		return structureSpecCharSpecRel;
	}

	public StructureSpecCharSpecRel removeStructureSpecCharSpecRel(StructureSpecCharSpecRel structureSpecCharSpecRel) {
		getStructureSpecCharSpecRels().remove(structureSpecCharSpecRel);
		structureSpecCharSpecRel.setStructureSpec(null);

		return structureSpecCharSpecRel;
	}

	public List<StructureSpecCharValueSpec> getStructureSpecCharValueSpecs() {
		return this.structureSpecCharValueSpecs;
	}

	public void setStructureSpecCharValueSpecs(List<StructureSpecCharValueSpec> structureSpecCharValueSpecs) {
		this.structureSpecCharValueSpecs = structureSpecCharValueSpecs;
	}

	public StructureSpecCharValueSpec addStructureSpecCharValueSpec(StructureSpecCharValueSpec structureSpecCharValueSpec) {
		getStructureSpecCharValueSpecs().add(structureSpecCharValueSpec);
		structureSpecCharValueSpec.setStructureSpec(this);

		return structureSpecCharValueSpec;
	}

	public StructureSpecCharValueSpec removeStructureSpecCharValueSpec(StructureSpecCharValueSpec structureSpecCharValueSpec) {
		getStructureSpecCharValueSpecs().remove(structureSpecCharValueSpec);
		structureSpecCharValueSpec.setStructureSpec(null);

		return structureSpecCharValueSpec;
	}

}