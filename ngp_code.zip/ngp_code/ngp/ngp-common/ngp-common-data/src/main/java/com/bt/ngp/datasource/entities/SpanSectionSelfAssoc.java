package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the SPAN_SECTION_SELF_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="SPAN_SECTION_SELF_ASSOC")
@NamedQuery(name="SpanSectionSelfAssoc.findAll", query="SELECT s FROM SpanSectionSelfAssoc s")
public class SpanSectionSelfAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, precision=38)
	private long id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="SPAN_SELF_ASSOC_SPEC_ID", precision=38)
	private java.math.BigDecimal spanSelfAssocSpecId;

	//bi-directional many-to-one association to SpanSection
	@ManyToOne
	@JoinColumn(name="CHILD_SPAN_SECTION_NAME")
	private SpanSection childSpanSection;

	//bi-directional many-to-one association to SpanSection
	@ManyToOne
	@JoinColumn(name="PARENT_SPAN_SECTION_NAME")
	private SpanSection parentSpanSection;

	public SpanSectionSelfAssoc() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public java.math.BigDecimal getSpanSelfAssocSpecId() {
		return this.spanSelfAssocSpecId;
	}

	public void setSpanSelfAssocSpecId(java.math.BigDecimal spanSelfAssocSpecId) {
		this.spanSelfAssocSpecId = spanSelfAssocSpecId;
	}

	public SpanSection getChildSpanSection() {
		return this.childSpanSection;
	}

	public void setChildSpanSection(SpanSection childSpanSection) {
		this.childSpanSection = childSpanSection;
	}

	public SpanSection getParentSpanSection() {
		return this.parentSpanSection;
	}

	public void setParentSpanSection(SpanSection parentSpanSection) {
		this.parentSpanSection = parentSpanSection;
	}

}