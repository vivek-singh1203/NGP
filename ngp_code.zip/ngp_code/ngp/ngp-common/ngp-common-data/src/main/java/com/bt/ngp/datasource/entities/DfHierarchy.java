package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the DF_HIERARCHY database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DF_HIERARCHY")
@NamedQuery(name="DfHierarchy.findAll", query="SELECT d FROM DfHierarchy d")
public class DfHierarchy implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="EQ_HIERARCHY_SPEC_ID", length=50)
	private String eqHierarchySpecId;

	@Column(name="FRAME_POS_END_NUM", nullable=false, precision=38)
	private BigDecimal framePosEndNum;

	@Column(name="FRAME_POS_START_NUM", nullable=false, precision=38)
	private BigDecimal framePosStartNum;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LEG_ID", precision=38)
	private BigDecimal legId;

	//bi-directional many-to-one association to DfBhBlockAssoc
	@ManyToOne
	@JoinColumn(name="BH_BLOCK_ASSOC_ID")
	private DfBhBlockAssoc dfBhBlockAssoc;

	//bi-directional many-to-one association to DfBlockPortAssoc
	@ManyToOne
	@JoinColumn(name="BLOCK_PORT_ASSOC_ID")
	private DfBlockPortAssoc dfBlockPortAssoc;

	//bi-directional many-to-one association to DistributionFrame
	@ManyToOne
	@JoinColumn(name="FRAME_NAME")
	private DistributionFrame distributionFrame;

	//bi-directional many-to-one association to DfRackBhAssoc
	@ManyToOne
	@JoinColumn(name="RACK_BH_ASSOC_ID")
	private DfRackBhAssoc dfRackBhAssoc;

	public DfHierarchy() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getEqHierarchySpecId() {
		return this.eqHierarchySpecId;
	}

	public void setEqHierarchySpecId(String eqHierarchySpecId) {
		this.eqHierarchySpecId = eqHierarchySpecId;
	}

	public BigDecimal getFramePosEndNum() {
		return this.framePosEndNum;
	}

	public void setFramePosEndNum(BigDecimal framePosEndNum) {
		this.framePosEndNum = framePosEndNum;
	}

	public BigDecimal getFramePosStartNum() {
		return this.framePosStartNum;
	}

	public void setFramePosStartNum(BigDecimal framePosStartNum) {
		this.framePosStartNum = framePosStartNum;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getLegId() {
		return this.legId;
	}

	public void setLegId(BigDecimal legId) {
		this.legId = legId;
	}

	public DfBhBlockAssoc getDfBhBlockAssoc() {
		return this.dfBhBlockAssoc;
	}

	public void setDfBhBlockAssoc(DfBhBlockAssoc dfBhBlockAssoc) {
		this.dfBhBlockAssoc = dfBhBlockAssoc;
	}

	public DfBlockPortAssoc getDfBlockPortAssoc() {
		return this.dfBlockPortAssoc;
	}

	public void setDfBlockPortAssoc(DfBlockPortAssoc dfBlockPortAssoc) {
		this.dfBlockPortAssoc = dfBlockPortAssoc;
	}

	public DistributionFrame getDistributionFrame() {
		return this.distributionFrame;
	}

	public void setDistributionFrame(DistributionFrame distributionFrame) {
		this.distributionFrame = distributionFrame;
	}

	public DfRackBhAssoc getDfRackBhAssoc() {
		return this.dfRackBhAssoc;
	}

	public void setDfRackBhAssoc(DfRackBhAssoc dfRackBhAssoc) {
		this.dfRackBhAssoc = dfRackBhAssoc;
	}

}