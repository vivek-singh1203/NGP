package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.common.data.jpa.repository.SqlRepository;
import com.bt.ngp.datasource.entities.HierarchyConfiguration;

@Repository
public interface HierarchyConfigurationRepository extends SqlRepository<HierarchyConfiguration> {

	@Query(name="HierarchyConfigurationRepository.findjointClosureByCondition",nativeQuery=true)
	public List<HierarchyConfiguration> findHierarchyConfigurationByCondition(@Param("entityName")String entityName,@Param("categoryName")String categoryName, @Param("typeName")String typeName);

	public HierarchyConfiguration findByEntityNameAndSpecCategoryNameOrSpecTypeName(String entityName,String categoryName,String typeName);

}