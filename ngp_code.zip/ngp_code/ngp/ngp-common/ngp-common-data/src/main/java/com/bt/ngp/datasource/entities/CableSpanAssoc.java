package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the CABLE_SPAN_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CABLE_SPAN_ASSOC")
@NamedQuery(name="CableSpanAssoc.findAll", query="SELECT c FROM CableSpanAssoc c")
public class CableSpanAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="ASSOCIATION_STATE", nullable=false, length=20)
	private String associationState;

	@Column(name="CABLE_SPAN_COMP_SPEC_ID", length=50)
	private String cableSpanCompSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to CableSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CS_NAME")
	private CableSection cableSection;

	//bi-directional many-to-one association to SpanSection
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="SPAN_SECTION_NAME")
	private SpanSection spanSection;

	public CableSpanAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAssociationState() {
		return this.associationState;
	}

	public void setAssociationState(String associationState) {
		this.associationState = associationState;
	}

	public String getCableSpanCompSpecId() {
		return this.cableSpanCompSpecId;
	}

	public void setCableSpanCompSpecId(String cableSpanCompSpecId) {
		this.cableSpanCompSpecId = cableSpanCompSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public CableSection getCableSection() {
		return this.cableSection;
	}

	public void setCableSection(CableSection cableSection) {
		this.cableSection = cableSection;
	}

	public SpanSection getSpanSection() {
		return this.spanSection;
	}

	public void setSpanSection(SpanSection spanSection) {
		this.spanSection = spanSection;
	}

}