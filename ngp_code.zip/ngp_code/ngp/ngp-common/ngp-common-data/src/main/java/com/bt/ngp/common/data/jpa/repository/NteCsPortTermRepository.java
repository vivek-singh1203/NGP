package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.CableSection;
import com.bt.ngp.datasource.entities.Chassi;
import com.bt.ngp.datasource.entities.Conductor;
import com.bt.ngp.datasource.entities.ConductorBundle;
import com.bt.ngp.datasource.entities.NetworkTerminatingEquipment;
import com.bt.ngp.datasource.entities.NteCsPortTerm;
import com.bt.ngp.datasource.entities.NtePort;
import com.bt.ngp.datasource.entities.Plugin;

@Repository
public interface NteCsPortTermRepository extends SqlRepository<NteCsPortTerm> {

	public NteCsPortTerm findByNetworkTerminatingEquipmentAndChassiAndPluginAndNtePortAndCableSectionAndConductorBundleAndConductor(
			NetworkTerminatingEquipment networkTerminatingEquipment, Chassi chassi, Plugin plugin, NtePort ntePort,
			CableSection cableSection, ConductorBundle conductorBundle, Conductor conductor);

	@Query(name = "NteCsPortTermRepository.findNteCsPortTerm", nativeQuery = true)
	List<NteCsPortTerm> findNteCsPortTerm(@Param("termObj") NteCsPortTerm termObj);

	@Query(name = "NteCsPortTermRepository.fetchViaNteCsCbCond", nativeQuery = true)
	public NteCsPortTerm fetchNteCsPortTerm(@Param("nteCsPortTerm") NteCsPortTerm nteCsPortTerm);

	List<NteCsPortTerm> findByNetworkTerminatingEquipment(
			@Param("networkTerminatingEquipment") NetworkTerminatingEquipment networkTerminatingEquipment);

	@Query(name = "NteCsPortTermRepository.findByConductorAndTerminationType")
	List<NteCsPortTerm> findByConductorAndTerminationType(@Param("nteCsPortTermObj") NteCsPortTerm nteCsPortTermObj);

	@Query(name = "NteCsPortTermRepository.findByCableSectionAndPort")
	List<NteCsPortTerm> findByCableSectionAndPort(@Param("nteCsPortTermObj") NteCsPortTerm nteCsPortTermObj);

	@Query(name = "NteCsPortTermRepository.findByNteCableAndConductor")
	List<NteCsPortTerm> findByNteCableAndConductor(@Param("nteCsPortTerm") NteCsPortTerm nteCsPortTerm);
}