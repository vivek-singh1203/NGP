package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the CABLE_SELF_REL_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CABLE_SELF_REL_SPEC")
@NamedQuery(name="CableSelfRelSpec.findAll", query="SELECT c FROM CableSelfRelSpec c")
public class CableSelfRelSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=30)
	private String id;

	@Column(name="CREATED_BY", length=40)
	private String createdBy;

	@Column(name="CREATED_DATE")
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RELATION_TYPE", length=30)
	private String relationType;

	//bi-directional many-to-one association to CableSpec
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="CS_REL_FROM_SPEC_NAME", referencedColumnName="NAME", nullable=false),
		@JoinColumn(name="CS_REL_FROM_SPEC_VER", referencedColumnName="SPEC_VERSION", nullable=false)
		})
	private CableSpec cableSpec1;

	//bi-directional many-to-one association to CableSpec
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="CS_REL_FRM_PARNT_CS_SPEC_NAME", referencedColumnName="NAME", nullable=false),
		@JoinColumn(name="CS_REL_FRM_PARNT_CS_SPEC_VER", referencedColumnName="SPEC_VERSION", nullable=false)
		})
	private CableSpec cableSpec2;

	//bi-directional many-to-one association to CableSpec
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="CS_REL_TO_PARNT_CS_SPEC_NAME", referencedColumnName="NAME", nullable=false),
		@JoinColumn(name="CS_REL_TO_PARNT_CS_SPEC_VER", referencedColumnName="SPEC_VERSION", nullable=false)
		})
	private CableSpec cableSpec3;

	//bi-directional many-to-one association to CableSpec
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumns({
		@JoinColumn(name="CS_REL_TO_SPEC_NAME", referencedColumnName="NAME", nullable=false),
		@JoinColumn(name="CS_REL_TO_SPEC_VERSION", referencedColumnName="SPEC_VERSION", nullable=false)
		})
	private CableSpec cableSpec4;

	public CableSelfRelSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getRelationType() {
		return this.relationType;
	}

	public void setRelationType(String relationType) {
		this.relationType = relationType;
	}

	public CableSpec getCableSpec1() {
		return this.cableSpec1;
	}

	public void setCableSpec1(CableSpec cableSpec1) {
		this.cableSpec1 = cableSpec1;
	}

	public CableSpec getCableSpec2() {
		return this.cableSpec2;
	}

	public void setCableSpec2(CableSpec cableSpec2) {
		this.cableSpec2 = cableSpec2;
	}

	public CableSpec getCableSpec3() {
		return this.cableSpec3;
	}

	public void setCableSpec3(CableSpec cableSpec3) {
		this.cableSpec3 = cableSpec3;
	}

	public CableSpec getCableSpec4() {
		return this.cableSpec4;
	}

	public void setCableSpec4(CableSpec cableSpec4) {
		this.cableSpec4 = cableSpec4;
	}

}