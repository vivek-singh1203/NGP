package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the EQ_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="EQ_SPEC")
@NamedQuery(name="EqSpec.findAll", query="SELECT e FROM EqSpec e")
public class EqSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private EqSpecPK eqSpecPKId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DEPTH", precision=126)
	private double depth;

	@Column(name="DEPTH_UNIT", length=10)
	private String depthUnit;

	@Column(precision=126)
	private double diameter;

	@Column(name="DIAMETER_UNIT", length=10)
	private String diameterUnit;

	@Column(name="ENTITY_NAME", length=30)
	private String entityName;

	@Column(precision=126)
	private double height;

	@Column(name="HEIGHT_UNIT", length=10)
	private String heightUnit;

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="IS_ORDERABLE")
	private String isOrderable;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="LENGTH", precision=126)
	private double length;

	@Column(name="LENGTH_UNIT", length=10)
	private String lengthUnit;

	@Column(name="MANUFACTURER_NAME", length=30)
	private String manufacturerName;
	
	@Column(name="MANUFACTURER_CODE", length=30)
	private String manufacturerCode;

	@Column(name="MATERIAL_COST_PER_UNIT", precision=126)
	private double materialCostPerUnit;

	@Column(name="MATERIAL_COST_UNIT", length=10)
	private String materialCostUnit;

	@Column(name="MATERIAL_TYPE", length=10)
	private String materialType;

	@Column(name="NO_OF_POSITIONS", precision=38)
	private BigDecimal noOfPositions;

	@Column(name="POWER_CONSUMPTION", precision=126)
	private double powerConsumption;

	@Column(name="POWER_CONSUMPTION_UNIT", length=10)
	private String powerConsumptionUnit;

	@Column(name="POWER_DISSIPATION", precision=126)
	private double powerDissipation;

	@Column(name="POWER_DISSIPATION_UNIT", length=10)
	private String powerDissipationUnit;

	@Column(name="POWER_RATING", precision=126)
	private double powerRating;

	@Column(name="POWER_RATING_UNIT", length=10)
	private String powerRatingUnit;

	@Column(name="POWER_SUPPLY", length=10)
	private String powerSupply;

	@Column(name="SPEC_REMARKS", length=50)
	private String specRemarks;

	@Column(name="SPEC_STATUS", nullable=false, length=10)
	private String specStatus;

	@Column(name="SPLIT_RATIO", length=10)
	private String splitRatio;

	@Column(name="START_POSITION_NUM", precision=38)
	private BigDecimal startPositionNum;

	@Column(name="VALID_FROM")
	private Timestamp validFrom;

	@Column(name="VALID_TO")
	private Timestamp validTo;

	@Column(precision=126)
	private double volume;

	@Column(name="VOLUME_UNIT", length=10)
	private String volumeUnit;

	@Column(precision=126)
	private double weight;

	@Column(name="WEIGHT_UNIT", length=10)
	private String weightUnit;

	@Column(precision=126)
	private double width;

	@Column(name="WIDTH_UNIT", length=10)
	private String widthUnit;

	//bi-directional many-to-one association to BlockSelfAssocSpec
	@OneToMany(mappedBy="eqSpec1")
	private List<BlockSelfAssocSpec> blockSelfAssocSpecs1;

	//bi-directional many-to-one association to BlockSelfAssocSpec
	@OneToMany(mappedBy="eqSpec2")
	private List<BlockSelfAssocSpec> blockSelfAssocSpecs2;

	//bi-directional many-to-one association to CardSelfAssocSpec
	@OneToMany(mappedBy="eqSpec1")
	private List<CardSelfAssocSpec> cardSelfAssocSpecs1;

	//bi-directional many-to-one association to CardSelfAssocSpec
	@OneToMany(mappedBy="eqSpec2")
	private List<CardSelfAssocSpec> cardSelfAssocSpecs2;

	//bi-directional many-to-one association to DeviceCompHolderAssocSpec
	@OneToMany(mappedBy="eqSpec")
	private List<DeviceCompHolderAssocSpec> deviceCompHolderAssocSpecs;

	//bi-directional many-to-one association to DeviceCompPortAssocSpec
	@OneToMany(mappedBy="eqSpec")
	private List<DeviceCompPortAssocSpec> deviceCompPortAssocSpecs;

	//bi-directional many-to-one association to DeviceHolderCompAssocSpec
	@OneToMany(mappedBy="eqSpec")
	private List<DeviceHolderCompAssocSpec> deviceHolderCompAssocSpecs;

	//bi-directional many-to-one association to EqCableCompatSpec
	@OneToMany(mappedBy="eqSpec")
	private List<EqCableCompatSpec> eqCableCompatSpecs;

	//bi-directional many-to-one association to EqCompHolderAssocSpec
	@OneToMany(mappedBy="eqSpec1")
	private List<EqCompHolderAssocSpec> eqCompHolderAssocSpecs1;

	//bi-directional many-to-one association to EqCompHolderAssocSpec
	@OneToMany(mappedBy="eqSpec2")
	private List<EqCompHolderAssocSpec> eqCompHolderAssocSpecs2;

	//bi-directional many-to-one association to EqCompPortAssocSpec
	@OneToMany(mappedBy="eqSpec1")
	private List<EqCompPortAssocSpec> eqCompPortAssocSpecs1;

	//bi-directional many-to-one association to EqCompPortAssocSpec
	@OneToMany(mappedBy="eqSpec2")
	private List<EqCompPortAssocSpec> eqCompPortAssocSpecs2;

	//bi-directional many-to-one association to EqHierarchySpec
	@OneToMany(mappedBy="eqSpec")
	private List<EqHierarchySpec> eqHierarchySpecs;

	//bi-directional many-to-one association to EqHolderCompAssocSpec
	@OneToMany(mappedBy="eqSpec1")
	private List<EqHolderCompAssocSpec> eqHolderCompAssocSpecs1;

	//bi-directional many-to-one association to EqHolderCompAssocSpec
	@OneToMany(mappedBy="eqSpec2")
	private List<EqHolderCompAssocSpec> eqHolderCompAssocSpecs2;

	//bi-directional many-to-one association to EqPortPortAssocSpec
	@OneToMany(mappedBy="eqSpec")
	private List<EqPortPortAssocSpec> eqPortPortAssocSpecs;

	//bi-directional many-to-one association to EqCapacitySpec
	@ManyToOne
	@JoinColumn(name="CAPACITY_SPEC_NAME", nullable=false)
	private EqCapacitySpec eqCapacitySpec;

	//bi-directional many-to-one association to SpecCategory
	@ManyToOne
	@JoinColumn(name="SPEC_CATEGORY_NAME")
	private SpecCategory specCategory;

	//bi-directional many-to-one association to SpecType
	@ManyToOne
	@JoinColumn(name="SPEC_TYPE_NAME")
	private SpecType specType;

	//bi-directional many-to-one association to EqSpecCharSpec
	@OneToMany(mappedBy="eqSpec")
	private List<EqSpecCharSpec> eqSpecCharSpecs;

	//bi-directional many-to-one association to EqSpecCharSpecRel
	@OneToMany(mappedBy="eqSpec")
	private List<EqSpecCharSpecRel> eqSpecCharSpecRels;

	//bi-directional many-to-one association to EqSpecCharValueSpec
	@OneToMany(mappedBy="eqSpec")
	private List<EqSpecCharValueSpec> eqSpecCharValueSpecs;

	//bi-directional many-to-one association to EqSpecRoleSpec
	@OneToMany(mappedBy="eqSpec")
	private List<EqSpecRoleSpec> eqSpecRoleSpecs;

	//bi-directional many-to-one association to EqStructureCompatSpec
	@OneToMany(mappedBy="eqSpec")
	private List<EqStructureCompatSpec> eqStructureCompatSpecs;

	//bi-directional many-to-one association to PluginSelfAssocSpec
	@OneToMany(mappedBy="eqSpec1")
	private List<PluginSelfAssocSpec> pluginSelfAssocSpecs1;

	//bi-directional many-to-one association to PluginSelfAssocSpec
	@OneToMany(mappedBy="eqSpec2")
	private List<PluginSelfAssocSpec> pluginSelfAssocSpecs2;

	public EqSpec() {
	}

	public EqSpecPK getEqSpecPKId() {
		return this.eqSpecPKId;
	}

	public void setEqSpecPKId(EqSpecPK eqSpecPKId) {
		this.eqSpecPKId = eqSpecPKId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public double getDepth() {
		return this.depth;
	}

	public void setDepth(double depth) {
		this.depth = depth;
	}

	public String getDepthUnit() {
		return this.depthUnit;
	}

	public void setDepthUnit(String depthUnit) {
		this.depthUnit = depthUnit;
	}

	public double getDiameter() {
		return this.diameter;
	}

	public void setDiameter(double diameter) {
		this.diameter = diameter;
	}

	public String getDiameterUnit() {
		return this.diameterUnit;
	}

	public void setDiameterUnit(String diameterUnit) {
		this.diameterUnit = diameterUnit;
	}

	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public double getHeight() {
		return this.height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public String getHeightUnit() {
		return this.heightUnit;
	}

	public void setHeightUnit(String heightUnit) {
		this.heightUnit = heightUnit;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getIsOrderable() {
		return this.isOrderable;
	}

	public void setIsOrderable(String isOrderable) {
		this.isOrderable = isOrderable;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public double getLength() {
		return this.length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public String getLengthUnit() {
		return this.lengthUnit;
	}

	public void setLengthUnit(String lengthUnit) {
		this.lengthUnit = lengthUnit;
	}

	public String getManufacturerName() {
		return this.manufacturerName;
	}

	public void setManufacturerName(String manufacturerName) {
		this.manufacturerName = manufacturerName;
	}
	
	public String getManufacturerCode() {
		return manufacturerCode;
	}

	public void setManufacturerCode(String manufacturerCode) {
		this.manufacturerCode = manufacturerCode;
	}

	public double getMaterialCostPerUnit() {
		return this.materialCostPerUnit;
	}

	public void setMaterialCostPerUnit(double materialCostPerUnit) {
		this.materialCostPerUnit = materialCostPerUnit;
	}

	public String getMaterialCostUnit() {
		return this.materialCostUnit;
	}

	public void setMaterialCostUnit(String materialCostUnit) {
		this.materialCostUnit = materialCostUnit;
	}

	public String getMaterialType() {
		return this.materialType;
	}

	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}

	public BigDecimal getNoOfPositions() {
		return this.noOfPositions;
	}

	public void setNoOfPositions(BigDecimal noOfPositions) {
		this.noOfPositions = noOfPositions;
	}

	public double getPowerConsumption() {
		return this.powerConsumption;
	}

	public void setPowerConsumption(double powerConsumption) {
		this.powerConsumption = powerConsumption;
	}

	public String getPowerConsumptionUnit() {
		return this.powerConsumptionUnit;
	}

	public void setPowerConsumptionUnit(String powerConsumptionUnit) {
		this.powerConsumptionUnit = powerConsumptionUnit;
	}

	public double getPowerDissipation() {
		return this.powerDissipation;
	}

	public void setPowerDissipation(double powerDissipation) {
		this.powerDissipation = powerDissipation;
	}

	public String getPowerDissipationUnit() {
		return this.powerDissipationUnit;
	}

	public void setPowerDissipationUnit(String powerDissipationUnit) {
		this.powerDissipationUnit = powerDissipationUnit;
	}

	public double getPowerRating() {
		return this.powerRating;
	}

	public void setPowerRating(double powerRating) {
		this.powerRating = powerRating;
	}

	public String getPowerRatingUnit() {
		return this.powerRatingUnit;
	}

	public void setPowerRatingUnit(String powerRatingUnit) {
		this.powerRatingUnit = powerRatingUnit;
	}

	public String getPowerSupply() {
		return this.powerSupply;
	}

	public void setPowerSupply(String powerSupply) {
		this.powerSupply = powerSupply;
	}

	public String getSpecRemarks() {
		return this.specRemarks;
	}

	public void setSpecRemarks(String specRemarks) {
		this.specRemarks = specRemarks;
	}

	public String getSpecStatus() {
		return this.specStatus;
	}

	public void setSpecStatus(String specStatus) {
		this.specStatus = specStatus;
	}

	public String getSplitRatio() {
		return this.splitRatio;
	}

	public void setSplitRatio(String splitRatio) {
		this.splitRatio = splitRatio;
	}

	public BigDecimal getStartPositionNum() {
		return this.startPositionNum;
	}

	public void setStartPositionNum(BigDecimal startPositionNum) {
		this.startPositionNum = startPositionNum;
	}

	public Timestamp getValidFrom() {
		return this.validFrom;
	}

	public void setValidFrom(Timestamp validFrom) {
		this.validFrom = validFrom;
	}

	public Timestamp getValidTo() {
		return this.validTo;
	}

	public void setValidTo(Timestamp validTo) {
		this.validTo = validTo;
	}

	public double getVolume() {
		return this.volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public String getVolumeUnit() {
		return this.volumeUnit;
	}

	public void setVolumeUnit(String volumeUnit) {
		this.volumeUnit = volumeUnit;
	}

	public double getWeight() {
		return this.weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getWeightUnit() {
		return this.weightUnit;
	}

	public void setWeightUnit(String weightUnit) {
		this.weightUnit = weightUnit;
	}

	public double getWidth() {
		return this.width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public String getWidthUnit() {
		return this.widthUnit;
	}

	public void setWidthUnit(String widthUnit) {
		this.widthUnit = widthUnit;
	}

	public List<BlockSelfAssocSpec> getBlockSelfAssocSpecs1() {
		return this.blockSelfAssocSpecs1;
	}

	public void setBlockSelfAssocSpecs1(List<BlockSelfAssocSpec> blockSelfAssocSpecs1) {
		this.blockSelfAssocSpecs1 = blockSelfAssocSpecs1;
	}

	public BlockSelfAssocSpec addBlockSelfAssocSpecs1(BlockSelfAssocSpec blockSelfAssocSpecs1) {
		getBlockSelfAssocSpecs1().add(blockSelfAssocSpecs1);
		blockSelfAssocSpecs1.setEqSpec1(this);

		return blockSelfAssocSpecs1;
	}

	public BlockSelfAssocSpec removeBlockSelfAssocSpecs1(BlockSelfAssocSpec blockSelfAssocSpecs1) {
		getBlockSelfAssocSpecs1().remove(blockSelfAssocSpecs1);
		blockSelfAssocSpecs1.setEqSpec1(null);

		return blockSelfAssocSpecs1;
	}

	public List<BlockSelfAssocSpec> getBlockSelfAssocSpecs2() {
		return this.blockSelfAssocSpecs2;
	}

	public void setBlockSelfAssocSpecs2(List<BlockSelfAssocSpec> blockSelfAssocSpecs2) {
		this.blockSelfAssocSpecs2 = blockSelfAssocSpecs2;
	}

	public BlockSelfAssocSpec addBlockSelfAssocSpecs2(BlockSelfAssocSpec blockSelfAssocSpecs2) {
		getBlockSelfAssocSpecs2().add(blockSelfAssocSpecs2);
		blockSelfAssocSpecs2.setEqSpec2(this);

		return blockSelfAssocSpecs2;
	}

	public BlockSelfAssocSpec removeBlockSelfAssocSpecs2(BlockSelfAssocSpec blockSelfAssocSpecs2) {
		getBlockSelfAssocSpecs2().remove(blockSelfAssocSpecs2);
		blockSelfAssocSpecs2.setEqSpec2(null);

		return blockSelfAssocSpecs2;
	}

	public List<CardSelfAssocSpec> getCardSelfAssocSpecs1() {
		return this.cardSelfAssocSpecs1;
	}

	public void setCardSelfAssocSpecs1(List<CardSelfAssocSpec> cardSelfAssocSpecs1) {
		this.cardSelfAssocSpecs1 = cardSelfAssocSpecs1;
	}

	public CardSelfAssocSpec addCardSelfAssocSpecs1(CardSelfAssocSpec cardSelfAssocSpecs1) {
		getCardSelfAssocSpecs1().add(cardSelfAssocSpecs1);
		cardSelfAssocSpecs1.setEqSpec1(this);

		return cardSelfAssocSpecs1;
	}

	public CardSelfAssocSpec removeCardSelfAssocSpecs1(CardSelfAssocSpec cardSelfAssocSpecs1) {
		getCardSelfAssocSpecs1().remove(cardSelfAssocSpecs1);
		cardSelfAssocSpecs1.setEqSpec1(null);

		return cardSelfAssocSpecs1;
	}

	public List<CardSelfAssocSpec> getCardSelfAssocSpecs2() {
		return this.cardSelfAssocSpecs2;
	}

	public void setCardSelfAssocSpecs2(List<CardSelfAssocSpec> cardSelfAssocSpecs2) {
		this.cardSelfAssocSpecs2 = cardSelfAssocSpecs2;
	}

	public CardSelfAssocSpec addCardSelfAssocSpecs2(CardSelfAssocSpec cardSelfAssocSpecs2) {
		getCardSelfAssocSpecs2().add(cardSelfAssocSpecs2);
		cardSelfAssocSpecs2.setEqSpec2(this);

		return cardSelfAssocSpecs2;
	}

	public CardSelfAssocSpec removeCardSelfAssocSpecs2(CardSelfAssocSpec cardSelfAssocSpecs2) {
		getCardSelfAssocSpecs2().remove(cardSelfAssocSpecs2);
		cardSelfAssocSpecs2.setEqSpec2(null);

		return cardSelfAssocSpecs2;
	}

	public List<DeviceCompHolderAssocSpec> getDeviceCompHolderAssocSpecs() {
		return this.deviceCompHolderAssocSpecs;
	}

	public void setDeviceCompHolderAssocSpecs(List<DeviceCompHolderAssocSpec> deviceCompHolderAssocSpecs) {
		this.deviceCompHolderAssocSpecs = deviceCompHolderAssocSpecs;
	}

	public DeviceCompHolderAssocSpec addDeviceCompHolderAssocSpec(DeviceCompHolderAssocSpec deviceCompHolderAssocSpec) {
		getDeviceCompHolderAssocSpecs().add(deviceCompHolderAssocSpec);
		deviceCompHolderAssocSpec.setEqSpec(this);

		return deviceCompHolderAssocSpec;
	}

	public DeviceCompHolderAssocSpec removeDeviceCompHolderAssocSpec(DeviceCompHolderAssocSpec deviceCompHolderAssocSpec) {
		getDeviceCompHolderAssocSpecs().remove(deviceCompHolderAssocSpec);
		deviceCompHolderAssocSpec.setEqSpec(null);

		return deviceCompHolderAssocSpec;
	}

	public List<DeviceCompPortAssocSpec> getDeviceCompPortAssocSpecs() {
		return this.deviceCompPortAssocSpecs;
	}

	public void setDeviceCompPortAssocSpecs(List<DeviceCompPortAssocSpec> deviceCompPortAssocSpecs) {
		this.deviceCompPortAssocSpecs = deviceCompPortAssocSpecs;
	}

	public DeviceCompPortAssocSpec addDeviceCompPortAssocSpec(DeviceCompPortAssocSpec deviceCompPortAssocSpec) {
		getDeviceCompPortAssocSpecs().add(deviceCompPortAssocSpec);
		deviceCompPortAssocSpec.setEqSpec(this);

		return deviceCompPortAssocSpec;
	}

	public DeviceCompPortAssocSpec removeDeviceCompPortAssocSpec(DeviceCompPortAssocSpec deviceCompPortAssocSpec) {
		getDeviceCompPortAssocSpecs().remove(deviceCompPortAssocSpec);
		deviceCompPortAssocSpec.setEqSpec(null);

		return deviceCompPortAssocSpec;
	}

	public List<DeviceHolderCompAssocSpec> getDeviceHolderCompAssocSpecs() {
		return this.deviceHolderCompAssocSpecs;
	}

	public void setDeviceHolderCompAssocSpecs(List<DeviceHolderCompAssocSpec> deviceHolderCompAssocSpecs) {
		this.deviceHolderCompAssocSpecs = deviceHolderCompAssocSpecs;
	}

	public DeviceHolderCompAssocSpec addDeviceHolderCompAssocSpec(DeviceHolderCompAssocSpec deviceHolderCompAssocSpec) {
		getDeviceHolderCompAssocSpecs().add(deviceHolderCompAssocSpec);
		deviceHolderCompAssocSpec.setEqSpec(this);

		return deviceHolderCompAssocSpec;
	}

	public DeviceHolderCompAssocSpec removeDeviceHolderCompAssocSpec(DeviceHolderCompAssocSpec deviceHolderCompAssocSpec) {
		getDeviceHolderCompAssocSpecs().remove(deviceHolderCompAssocSpec);
		deviceHolderCompAssocSpec.setEqSpec(null);

		return deviceHolderCompAssocSpec;
	}

	public List<EqCableCompatSpec> getEqCableCompatSpecs() {
		return this.eqCableCompatSpecs;
	}

	public void setEqCableCompatSpecs(List<EqCableCompatSpec> eqCableCompatSpecs) {
		this.eqCableCompatSpecs = eqCableCompatSpecs;
	}

	public EqCableCompatSpec addEqCableCompatSpec(EqCableCompatSpec eqCableCompatSpec) {
		getEqCableCompatSpecs().add(eqCableCompatSpec);
		eqCableCompatSpec.setEqSpec(this);

		return eqCableCompatSpec;
	}

	public EqCableCompatSpec removeEqCableCompatSpec(EqCableCompatSpec eqCableCompatSpec) {
		getEqCableCompatSpecs().remove(eqCableCompatSpec);
		eqCableCompatSpec.setEqSpec(null);

		return eqCableCompatSpec;
	}

	public List<EqCompHolderAssocSpec> getEqCompHolderAssocSpecs1() {
		return this.eqCompHolderAssocSpecs1;
	}

	public void setEqCompHolderAssocSpecs1(List<EqCompHolderAssocSpec> eqCompHolderAssocSpecs1) {
		this.eqCompHolderAssocSpecs1 = eqCompHolderAssocSpecs1;
	}

	public EqCompHolderAssocSpec addEqCompHolderAssocSpecs1(EqCompHolderAssocSpec eqCompHolderAssocSpecs1) {
		getEqCompHolderAssocSpecs1().add(eqCompHolderAssocSpecs1);
		eqCompHolderAssocSpecs1.setEqSpec1(this);

		return eqCompHolderAssocSpecs1;
	}

	public EqCompHolderAssocSpec removeEqCompHolderAssocSpecs1(EqCompHolderAssocSpec eqCompHolderAssocSpecs1) {
		getEqCompHolderAssocSpecs1().remove(eqCompHolderAssocSpecs1);
		eqCompHolderAssocSpecs1.setEqSpec1(null);

		return eqCompHolderAssocSpecs1;
	}

	public List<EqCompHolderAssocSpec> getEqCompHolderAssocSpecs2() {
		return this.eqCompHolderAssocSpecs2;
	}

	public void setEqCompHolderAssocSpecs2(List<EqCompHolderAssocSpec> eqCompHolderAssocSpecs2) {
		this.eqCompHolderAssocSpecs2 = eqCompHolderAssocSpecs2;
	}

	public EqCompHolderAssocSpec addEqCompHolderAssocSpecs2(EqCompHolderAssocSpec eqCompHolderAssocSpecs2) {
		getEqCompHolderAssocSpecs2().add(eqCompHolderAssocSpecs2);
		eqCompHolderAssocSpecs2.setEqSpec2(this);

		return eqCompHolderAssocSpecs2;
	}

	public EqCompHolderAssocSpec removeEqCompHolderAssocSpecs2(EqCompHolderAssocSpec eqCompHolderAssocSpecs2) {
		getEqCompHolderAssocSpecs2().remove(eqCompHolderAssocSpecs2);
		eqCompHolderAssocSpecs2.setEqSpec2(null);

		return eqCompHolderAssocSpecs2;
	}

	public List<EqCompPortAssocSpec> getEqCompPortAssocSpecs1() {
		return this.eqCompPortAssocSpecs1;
	}

	public void setEqCompPortAssocSpecs1(List<EqCompPortAssocSpec> eqCompPortAssocSpecs1) {
		this.eqCompPortAssocSpecs1 = eqCompPortAssocSpecs1;
	}

	public EqCompPortAssocSpec addEqCompPortAssocSpecs1(EqCompPortAssocSpec eqCompPortAssocSpecs1) {
		getEqCompPortAssocSpecs1().add(eqCompPortAssocSpecs1);
		eqCompPortAssocSpecs1.setEqSpec1(this);

		return eqCompPortAssocSpecs1;
	}

	public EqCompPortAssocSpec removeEqCompPortAssocSpecs1(EqCompPortAssocSpec eqCompPortAssocSpecs1) {
		getEqCompPortAssocSpecs1().remove(eqCompPortAssocSpecs1);
		eqCompPortAssocSpecs1.setEqSpec1(null);

		return eqCompPortAssocSpecs1;
	}

	public List<EqCompPortAssocSpec> getEqCompPortAssocSpecs2() {
		return this.eqCompPortAssocSpecs2;
	}

	public void setEqCompPortAssocSpecs2(List<EqCompPortAssocSpec> eqCompPortAssocSpecs2) {
		this.eqCompPortAssocSpecs2 = eqCompPortAssocSpecs2;
	}

	public EqCompPortAssocSpec addEqCompPortAssocSpecs2(EqCompPortAssocSpec eqCompPortAssocSpecs2) {
		getEqCompPortAssocSpecs2().add(eqCompPortAssocSpecs2);
		eqCompPortAssocSpecs2.setEqSpec2(this);

		return eqCompPortAssocSpecs2;
	}

	public EqCompPortAssocSpec removeEqCompPortAssocSpecs2(EqCompPortAssocSpec eqCompPortAssocSpecs2) {
		getEqCompPortAssocSpecs2().remove(eqCompPortAssocSpecs2);
		eqCompPortAssocSpecs2.setEqSpec2(null);

		return eqCompPortAssocSpecs2;
	}

	public List<EqHierarchySpec> getEqHierarchySpecs() {
		return this.eqHierarchySpecs;
	}

	public void setEqHierarchySpecs(List<EqHierarchySpec> eqHierarchySpecs) {
		this.eqHierarchySpecs = eqHierarchySpecs;
	}

	public EqHierarchySpec addEqHierarchySpec(EqHierarchySpec eqHierarchySpec) {
		getEqHierarchySpecs().add(eqHierarchySpec);
		eqHierarchySpec.setEqSpec(this);

		return eqHierarchySpec;
	}

	public EqHierarchySpec removeEqHierarchySpec(EqHierarchySpec eqHierarchySpec) {
		getEqHierarchySpecs().remove(eqHierarchySpec);
		eqHierarchySpec.setEqSpec(null);

		return eqHierarchySpec;
	}

	public List<EqHolderCompAssocSpec> getEqHolderCompAssocSpecs1() {
		return this.eqHolderCompAssocSpecs1;
	}

	public void setEqHolderCompAssocSpecs1(List<EqHolderCompAssocSpec> eqHolderCompAssocSpecs1) {
		this.eqHolderCompAssocSpecs1 = eqHolderCompAssocSpecs1;
	}

	public EqHolderCompAssocSpec addEqHolderCompAssocSpecs1(EqHolderCompAssocSpec eqHolderCompAssocSpecs1) {
		getEqHolderCompAssocSpecs1().add(eqHolderCompAssocSpecs1);
		eqHolderCompAssocSpecs1.setEqSpec1(this);

		return eqHolderCompAssocSpecs1;
	}

	public EqHolderCompAssocSpec removeEqHolderCompAssocSpecs1(EqHolderCompAssocSpec eqHolderCompAssocSpecs1) {
		getEqHolderCompAssocSpecs1().remove(eqHolderCompAssocSpecs1);
		eqHolderCompAssocSpecs1.setEqSpec1(null);

		return eqHolderCompAssocSpecs1;
	}

	public List<EqHolderCompAssocSpec> getEqHolderCompAssocSpecs2() {
		return this.eqHolderCompAssocSpecs2;
	}

	public void setEqHolderCompAssocSpecs2(List<EqHolderCompAssocSpec> eqHolderCompAssocSpecs2) {
		this.eqHolderCompAssocSpecs2 = eqHolderCompAssocSpecs2;
	}

	public EqHolderCompAssocSpec addEqHolderCompAssocSpecs2(EqHolderCompAssocSpec eqHolderCompAssocSpecs2) {
		getEqHolderCompAssocSpecs2().add(eqHolderCompAssocSpecs2);
		eqHolderCompAssocSpecs2.setEqSpec2(this);

		return eqHolderCompAssocSpecs2;
	}

	public EqHolderCompAssocSpec removeEqHolderCompAssocSpecs2(EqHolderCompAssocSpec eqHolderCompAssocSpecs2) {
		getEqHolderCompAssocSpecs2().remove(eqHolderCompAssocSpecs2);
		eqHolderCompAssocSpecs2.setEqSpec2(null);

		return eqHolderCompAssocSpecs2;
	}

	public List<EqPortPortAssocSpec> getEqPortPortAssocSpecs() {
		return this.eqPortPortAssocSpecs;
	}

	public void setEqPortPortAssocSpecs(List<EqPortPortAssocSpec> eqPortPortAssocSpecs) {
		this.eqPortPortAssocSpecs = eqPortPortAssocSpecs;
	}

	public EqPortPortAssocSpec addEqPortPortAssocSpec(EqPortPortAssocSpec eqPortPortAssocSpec) {
		getEqPortPortAssocSpecs().add(eqPortPortAssocSpec);
		eqPortPortAssocSpec.setEqSpec(this);

		return eqPortPortAssocSpec;
	}

	public EqPortPortAssocSpec removeEqPortPortAssocSpec(EqPortPortAssocSpec eqPortPortAssocSpec) {
		getEqPortPortAssocSpecs().remove(eqPortPortAssocSpec);
		eqPortPortAssocSpec.setEqSpec(null);

		return eqPortPortAssocSpec;
	}

	public EqCapacitySpec getEqCapacitySpec() {
		return this.eqCapacitySpec;
	}

	public void setEqCapacitySpec(EqCapacitySpec eqCapacitySpec) {
		this.eqCapacitySpec = eqCapacitySpec;
	}

	public SpecCategory getSpecCategory() {
		return this.specCategory;
	}

	public void setSpecCategory(SpecCategory specCategory) {
		this.specCategory = specCategory;
	}

	public SpecType getSpecType() {
		return this.specType;
	}

	public void setSpecType(SpecType specType) {
		this.specType = specType;
	}

	public List<EqSpecCharSpec> getEqSpecCharSpecs() {
		return this.eqSpecCharSpecs;
	}

	public void setEqSpecCharSpecs(List<EqSpecCharSpec> eqSpecCharSpecs) {
		this.eqSpecCharSpecs = eqSpecCharSpecs;
	}

	public EqSpecCharSpec addEqSpecCharSpec(EqSpecCharSpec eqSpecCharSpec) {
		getEqSpecCharSpecs().add(eqSpecCharSpec);
		eqSpecCharSpec.setEqSpec(this);

		return eqSpecCharSpec;
	}

	public EqSpecCharSpec removeEqSpecCharSpec(EqSpecCharSpec eqSpecCharSpec) {
		getEqSpecCharSpecs().remove(eqSpecCharSpec);
		eqSpecCharSpec.setEqSpec(null);

		return eqSpecCharSpec;
	}

	public List<EqSpecCharSpecRel> getEqSpecCharSpecRels() {
		return this.eqSpecCharSpecRels;
	}

	public void setEqSpecCharSpecRels(List<EqSpecCharSpecRel> eqSpecCharSpecRels) {
		this.eqSpecCharSpecRels = eqSpecCharSpecRels;
	}

	public EqSpecCharSpecRel addEqSpecCharSpecRel(EqSpecCharSpecRel eqSpecCharSpecRel) {
		getEqSpecCharSpecRels().add(eqSpecCharSpecRel);
		eqSpecCharSpecRel.setEqSpec(this);

		return eqSpecCharSpecRel;
	}

	public EqSpecCharSpecRel removeEqSpecCharSpecRel(EqSpecCharSpecRel eqSpecCharSpecRel) {
		getEqSpecCharSpecRels().remove(eqSpecCharSpecRel);
		eqSpecCharSpecRel.setEqSpec(null);

		return eqSpecCharSpecRel;
	}

	public List<EqSpecCharValueSpec> getEqSpecCharValueSpecs() {
		return this.eqSpecCharValueSpecs;
	}

	public void setEqSpecCharValueSpecs(List<EqSpecCharValueSpec> eqSpecCharValueSpecs) {
		this.eqSpecCharValueSpecs = eqSpecCharValueSpecs;
	}

	public EqSpecCharValueSpec addEqSpecCharValueSpec(EqSpecCharValueSpec eqSpecCharValueSpec) {
		getEqSpecCharValueSpecs().add(eqSpecCharValueSpec);
		eqSpecCharValueSpec.setEqSpec(this);

		return eqSpecCharValueSpec;
	}

	public EqSpecCharValueSpec removeEqSpecCharValueSpec(EqSpecCharValueSpec eqSpecCharValueSpec) {
		getEqSpecCharValueSpecs().remove(eqSpecCharValueSpec);
		eqSpecCharValueSpec.setEqSpec(null);

		return eqSpecCharValueSpec;
	}

	public List<EqSpecRoleSpec> getEqSpecRoleSpecs() {
		return this.eqSpecRoleSpecs;
	}

	public void setEqSpecRoleSpecs(List<EqSpecRoleSpec> eqSpecRoleSpecs) {
		this.eqSpecRoleSpecs = eqSpecRoleSpecs;
	}

	public EqSpecRoleSpec addEqSpecRoleSpec(EqSpecRoleSpec eqSpecRoleSpec) {
		getEqSpecRoleSpecs().add(eqSpecRoleSpec);
		eqSpecRoleSpec.setEqSpec(this);

		return eqSpecRoleSpec;
	}

	public EqSpecRoleSpec removeEqSpecRoleSpec(EqSpecRoleSpec eqSpecRoleSpec) {
		getEqSpecRoleSpecs().remove(eqSpecRoleSpec);
		eqSpecRoleSpec.setEqSpec(null);

		return eqSpecRoleSpec;
	}

	public List<EqStructureCompatSpec> getEqStructureCompatSpecs() {
		return this.eqStructureCompatSpecs;
	}

	public void setEqStructureCompatSpecs(List<EqStructureCompatSpec> eqStructureCompatSpecs) {
		this.eqStructureCompatSpecs = eqStructureCompatSpecs;
	}

	public EqStructureCompatSpec addEqStructureCompatSpec(EqStructureCompatSpec eqStructureCompatSpec) {
		getEqStructureCompatSpecs().add(eqStructureCompatSpec);
		eqStructureCompatSpec.setEqSpec(this);

		return eqStructureCompatSpec;
	}

	public EqStructureCompatSpec removeEqStructureCompatSpec(EqStructureCompatSpec eqStructureCompatSpec) {
		getEqStructureCompatSpecs().remove(eqStructureCompatSpec);
		eqStructureCompatSpec.setEqSpec(null);

		return eqStructureCompatSpec;
	}

	public List<PluginSelfAssocSpec> getPluginSelfAssocSpecs1() {
		return this.pluginSelfAssocSpecs1;
	}

	public void setPluginSelfAssocSpecs1(List<PluginSelfAssocSpec> pluginSelfAssocSpecs1) {
		this.pluginSelfAssocSpecs1 = pluginSelfAssocSpecs1;
	}

	public PluginSelfAssocSpec addPluginSelfAssocSpecs1(PluginSelfAssocSpec pluginSelfAssocSpecs1) {
		getPluginSelfAssocSpecs1().add(pluginSelfAssocSpecs1);
		pluginSelfAssocSpecs1.setEqSpec1(this);

		return pluginSelfAssocSpecs1;
	}

	public PluginSelfAssocSpec removePluginSelfAssocSpecs1(PluginSelfAssocSpec pluginSelfAssocSpecs1) {
		getPluginSelfAssocSpecs1().remove(pluginSelfAssocSpecs1);
		pluginSelfAssocSpecs1.setEqSpec1(null);

		return pluginSelfAssocSpecs1;
	}

	public List<PluginSelfAssocSpec> getPluginSelfAssocSpecs2() {
		return this.pluginSelfAssocSpecs2;
	}

	public void setPluginSelfAssocSpecs2(List<PluginSelfAssocSpec> pluginSelfAssocSpecs2) {
		this.pluginSelfAssocSpecs2 = pluginSelfAssocSpecs2;
	}

	public PluginSelfAssocSpec addPluginSelfAssocSpecs2(PluginSelfAssocSpec pluginSelfAssocSpecs2) {
		getPluginSelfAssocSpecs2().add(pluginSelfAssocSpecs2);
		pluginSelfAssocSpecs2.setEqSpec2(this);

		return pluginSelfAssocSpecs2;
	}

	public PluginSelfAssocSpec removePluginSelfAssocSpecs2(PluginSelfAssocSpec pluginSelfAssocSpecs2) {
		getPluginSelfAssocSpecs2().remove(pluginSelfAssocSpecs2);
		pluginSelfAssocSpecs2.setEqSpec2(null);

		return pluginSelfAssocSpecs2;
	}

}