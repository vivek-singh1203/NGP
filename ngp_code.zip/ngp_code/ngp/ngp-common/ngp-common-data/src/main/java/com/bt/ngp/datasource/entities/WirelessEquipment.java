package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.vividsolutions.jts.geom.Point;


/**
 * The persistent class for the WIRELESS_EQUIPMENT database table.
 * 
 */
@javax.persistence.Entity
@Table(name="WIRELESS_EQUIPMENT")
@NamedQuery(name="WirelessEquipment.findAll", query="SELECT w FROM WirelessEquipment w")
public class WirelessEquipment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="DESG_NAME", length=30)
	private String desgName;

	@Column(name="DESG_NUM", precision=38)
	private BigDecimal desgNum;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(name="FIELD_LABEL", length=30)
	private String fieldLabel;

	@Column(name = "GEO_POSITION", columnDefinition = "geometry(Point,3857)")
	private Point geoPosition;

	public Point getGeoPosition() {
		return geoPosition;
	}

	public void setGeoPosition(Point geoPosition) {
		this.geoPosition = geoPosition;
	}

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to AuxComponent
	@OneToMany(mappedBy="wirelessEquipment")
	private List<AuxComponent> auxComponents;

	//bi-directional many-to-one association to Chassi
	@OneToMany(mappedBy="wirelessEquipment")
	private List<Chassi> chassis;

	//bi-directional many-to-one association to Connector
	@OneToMany(mappedBy="wirelessEquipment")
	private List<Connector> connectors;

	//bi-directional many-to-one association to Plugin
	@OneToMany(mappedBy="wirelessEquipment")
	private List<Plugin> plugins;

	//bi-directional many-to-one association to PluginHolder
	@OneToMany(mappedBy="wirelessEquipment")
	private List<PluginHolder> pluginHolders;

	//bi-directional many-to-one association to WeCableConductorSplicing
	@OneToMany(mappedBy="wirelessEquipment")
	private List<WeCsCondSplicing> weCableConductorSplicings;

	//bi-directional many-to-one association to WeChar
	@OneToMany(mappedBy="wirelessEquipment")
	private List<WeChar> weChars;

	//bi-directional many-to-one association to WeChassisPhAssoc
	@OneToMany(mappedBy="wirelessEquipment")
	private List<WeChassisPhAssoc> weChassisPhAssocs;

	//bi-directional many-to-one association to WeCsPortTerm
	@OneToMany(mappedBy="wirelessEquipment")
	private List<WeCsPortTerm> weCsPortTerms;

	//bi-directional many-to-one association to WeHierarchy
	@OneToMany(mappedBy="wirelessEquipment")
	private List<WeHierarchy> weHierarchies;

	//bi-directional many-to-one association to WePhPluginAssoc
	@OneToMany(mappedBy="wirelessEquipment")
	private List<WePhPluginAssoc> wePhPluginAssocs;

	//bi-directional many-to-one association to WePluginPortAssoc
	@OneToMany(mappedBy="wirelessEquipment")
	private List<WePluginPortAssoc> wePluginPortAssocs;

	//bi-directional many-to-one association to WePort
	@OneToMany(mappedBy="wirelessEquipment")
	private List<WePort> wePorts;

	//bi-directional many-to-one association to WePortChar
	@OneToMany(mappedBy="wirelessEquipment")
	private List<WePortChar> wePortChars;

	//bi-directional many-to-one association to WePortPortAssoc
	@OneToMany(mappedBy="wirelessEquipment")
	private List<WePortPortAssoc> wePortPortAssocs;

	//bi-directional many-to-one association to WeStructureAssoc
	@OneToMany(mappedBy="wirelessEquipment")
	private List<WeStructureAssoc> weStructureAssocs;

	//bi-directional many-to-one association to Exchange
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="EXCHANGE_1141_CODE")
	private Exchange exchange;

	//bi-directional many-to-one association to Store
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	public WirelessEquipment() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getDesgName() {
		return this.desgName;
	}

	public void setDesgName(String desgName) {
		this.desgName = desgName;
	}

	public BigDecimal getDesgNum() {
		return this.desgNum;
	}

	public void setDesgNum(BigDecimal desgNum) {
		this.desgNum = desgNum;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getFieldLabel() {
		return this.fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<AuxComponent> getAuxComponents() {
		return this.auxComponents;
	}

	public void setAuxComponents(List<AuxComponent> auxComponents) {
		this.auxComponents = auxComponents;
	}

	public AuxComponent addAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().add(auxComponent);
		auxComponent.setWirelessEquipment(this);

		return auxComponent;
	}

	public AuxComponent removeAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().remove(auxComponent);
		auxComponent.setWirelessEquipment(null);

		return auxComponent;
	}

	public List<Chassi> getChassis() {
		return this.chassis;
	}

	public void setChassis(List<Chassi> chassis) {
		this.chassis = chassis;
	}

	public Chassi addChassi(Chassi chassi) {
		getChassis().add(chassi);
		chassi.setWirelessEquipment(this);

		return chassi;
	}

	public Chassi removeChassi(Chassi chassi) {
		getChassis().remove(chassi);
		chassi.setWirelessEquipment(null);

		return chassi;
	}

	public List<Connector> getConnectors() {
		return this.connectors;
	}

	public void setConnectors(List<Connector> connectors) {
		this.connectors = connectors;
	}

	public Connector addConnector(Connector connector) {
		getConnectors().add(connector);
		connector.setWirelessEquipment(this);

		return connector;
	}

	public Connector removeConnector(Connector connector) {
		getConnectors().remove(connector);
		connector.setWirelessEquipment(null);

		return connector;
	}

	public List<Plugin> getPlugins() {
		return this.plugins;
	}

	public void setPlugins(List<Plugin> plugins) {
		this.plugins = plugins;
	}

	public Plugin addPlugin(Plugin plugin) {
		getPlugins().add(plugin);
		plugin.setWirelessEquipment(this);

		return plugin;
	}

	public Plugin removePlugin(Plugin plugin) {
		getPlugins().remove(plugin);
		plugin.setWirelessEquipment(null);

		return plugin;
	}

	public List<PluginHolder> getPluginHolders() {
		return this.pluginHolders;
	}

	public void setPluginHolders(List<PluginHolder> pluginHolders) {
		this.pluginHolders = pluginHolders;
	}

	public PluginHolder addPluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().add(pluginHolder);
		pluginHolder.setWirelessEquipment(this);

		return pluginHolder;
	}

	public PluginHolder removePluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().remove(pluginHolder);
		pluginHolder.setWirelessEquipment(null);

		return pluginHolder;
	}

	public List<WeCsCondSplicing> getWeCableConductorSplicings() {
		return this.weCableConductorSplicings;
	}

	public void setWeCableConductorSplicings(List<WeCsCondSplicing> weCableConductorSplicings) {
		this.weCableConductorSplicings = weCableConductorSplicings;
	}

	public WeCsCondSplicing addWeCableConductorSplicing(WeCsCondSplicing weCableConductorSplicing) {
		getWeCableConductorSplicings().add(weCableConductorSplicing);
		weCableConductorSplicing.setWirelessEquipment(this);

		return weCableConductorSplicing;
	}

	public WeCsCondSplicing removeWeCableConductorSplicing(WeCsCondSplicing weCableConductorSplicing) {
		getWeCableConductorSplicings().remove(weCableConductorSplicing);
		weCableConductorSplicing.setWirelessEquipment(null);

		return weCableConductorSplicing;
	}

	public List<WeChar> getWeChars() {
		return this.weChars;
	}

	public void setWeChars(List<WeChar> weChars) {
		this.weChars = weChars;
	}

	public WeChar addWeChar(WeChar weChar) {
		getWeChars().add(weChar);
		weChar.setWirelessEquipment(this);

		return weChar;
	}

	public WeChar removeWeChar(WeChar weChar) {
		getWeChars().remove(weChar);
		weChar.setWirelessEquipment(null);

		return weChar;
	}

	public List<WeChassisPhAssoc> getWeChassisPhAssocs() {
		return this.weChassisPhAssocs;
	}

	public void setWeChassisPhAssocs(List<WeChassisPhAssoc> weChassisPhAssocs) {
		this.weChassisPhAssocs = weChassisPhAssocs;
	}

	public WeChassisPhAssoc addWeChassisPhAssoc(WeChassisPhAssoc weChassisPhAssoc) {
		getWeChassisPhAssocs().add(weChassisPhAssoc);
		weChassisPhAssoc.setWirelessEquipment(this);

		return weChassisPhAssoc;
	}

	public WeChassisPhAssoc removeWeChassisPhAssoc(WeChassisPhAssoc weChassisPhAssoc) {
		getWeChassisPhAssocs().remove(weChassisPhAssoc);
		weChassisPhAssoc.setWirelessEquipment(null);

		return weChassisPhAssoc;
	}

	public List<WeCsPortTerm> getWeCsPortTerms() {
		return this.weCsPortTerms;
	}

	public void setWeCsPortTerms(List<WeCsPortTerm> weCsPortTerms) {
		this.weCsPortTerms = weCsPortTerms;
	}

	public WeCsPortTerm addWeCsPortTerm(WeCsPortTerm weCsPortTerm) {
		getWeCsPortTerms().add(weCsPortTerm);
		weCsPortTerm.setWirelessEquipment(this);

		return weCsPortTerm;
	}

	public WeCsPortTerm removeWeCsPortTerm(WeCsPortTerm weCsPortTerm) {
		getWeCsPortTerms().remove(weCsPortTerm);
		weCsPortTerm.setWirelessEquipment(null);

		return weCsPortTerm;
	}

	public List<WeHierarchy> getWeHierarchies() {
		return this.weHierarchies;
	}

	public void setWeHierarchies(List<WeHierarchy> weHierarchies) {
		this.weHierarchies = weHierarchies;
	}

	public WeHierarchy addWeHierarchy(WeHierarchy weHierarchy) {
		getWeHierarchies().add(weHierarchy);
		weHierarchy.setWirelessEquipment(this);

		return weHierarchy;
	}

	public WeHierarchy removeWeHierarchy(WeHierarchy weHierarchy) {
		getWeHierarchies().remove(weHierarchy);
		weHierarchy.setWirelessEquipment(null);

		return weHierarchy;
	}

	public List<WePhPluginAssoc> getWePhPluginAssocs() {
		return this.wePhPluginAssocs;
	}

	public void setWePhPluginAssocs(List<WePhPluginAssoc> wePhPluginAssocs) {
		this.wePhPluginAssocs = wePhPluginAssocs;
	}

	public WePhPluginAssoc addWePhPluginAssoc(WePhPluginAssoc wePhPluginAssoc) {
		getWePhPluginAssocs().add(wePhPluginAssoc);
		wePhPluginAssoc.setWirelessEquipment(this);

		return wePhPluginAssoc;
	}

	public WePhPluginAssoc removeWePhPluginAssoc(WePhPluginAssoc wePhPluginAssoc) {
		getWePhPluginAssocs().remove(wePhPluginAssoc);
		wePhPluginAssoc.setWirelessEquipment(null);

		return wePhPluginAssoc;
	}

	public List<WePluginPortAssoc> getWePluginPortAssocs() {
		return this.wePluginPortAssocs;
	}

	public void setWePluginPortAssocs(List<WePluginPortAssoc> wePluginPortAssocs) {
		this.wePluginPortAssocs = wePluginPortAssocs;
	}

	public WePluginPortAssoc addWePluginPortAssoc(WePluginPortAssoc wePluginPortAssoc) {
		getWePluginPortAssocs().add(wePluginPortAssoc);
		wePluginPortAssoc.setWirelessEquipment(this);

		return wePluginPortAssoc;
	}

	public WePluginPortAssoc removeWePluginPortAssoc(WePluginPortAssoc wePluginPortAssoc) {
		getWePluginPortAssocs().remove(wePluginPortAssoc);
		wePluginPortAssoc.setWirelessEquipment(null);

		return wePluginPortAssoc;
	}

	public List<WePort> getWePorts() {
		return this.wePorts;
	}

	public void setWePorts(List<WePort> wePorts) {
		this.wePorts = wePorts;
	}

	public WePort addWePort(WePort wePort) {
		getWePorts().add(wePort);
		wePort.setWirelessEquipment(this);

		return wePort;
	}

	public WePort removeWePort(WePort wePort) {
		getWePorts().remove(wePort);
		wePort.setWirelessEquipment(null);

		return wePort;
	}

	public List<WePortChar> getWePortChars() {
		return this.wePortChars;
	}

	public void setWePortChars(List<WePortChar> wePortChars) {
		this.wePortChars = wePortChars;
	}

	public WePortChar addWePortChar(WePortChar wePortChar) {
		getWePortChars().add(wePortChar);
		wePortChar.setWirelessEquipment(this);

		return wePortChar;
	}

	public WePortChar removeWePortChar(WePortChar wePortChar) {
		getWePortChars().remove(wePortChar);
		wePortChar.setWirelessEquipment(null);

		return wePortChar;
	}

	public List<WePortPortAssoc> getWePortPortAssocs() {
		return this.wePortPortAssocs;
	}

	public void setWePortPortAssocs(List<WePortPortAssoc> wePortPortAssocs) {
		this.wePortPortAssocs = wePortPortAssocs;
	}

	public WePortPortAssoc addWePortPortAssoc(WePortPortAssoc wePortPortAssoc) {
		getWePortPortAssocs().add(wePortPortAssoc);
		wePortPortAssoc.setWirelessEquipment(this);

		return wePortPortAssoc;
	}

	public WePortPortAssoc removeWePortPortAssoc(WePortPortAssoc wePortPortAssoc) {
		getWePortPortAssocs().remove(wePortPortAssoc);
		wePortPortAssoc.setWirelessEquipment(null);

		return wePortPortAssoc;
	}

	public List<WeStructureAssoc> getWeStructureAssocs() {
		return this.weStructureAssocs;
	}

	public void setWeStructureAssocs(List<WeStructureAssoc> weStructureAssocs) {
		this.weStructureAssocs = weStructureAssocs;
	}

	public WeStructureAssoc addWeStructureAssoc(WeStructureAssoc weStructureAssoc) {
		getWeStructureAssocs().add(weStructureAssoc);
		weStructureAssoc.setWirelessEquipment(this);

		return weStructureAssoc;
	}

	public WeStructureAssoc removeWeStructureAssoc(WeStructureAssoc weStructureAssoc) {
		getWeStructureAssocs().remove(weStructureAssoc);
		weStructureAssoc.setWirelessEquipment(null);

		return weStructureAssoc;
	}

	public Exchange getExchange() {
		return this.exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

}