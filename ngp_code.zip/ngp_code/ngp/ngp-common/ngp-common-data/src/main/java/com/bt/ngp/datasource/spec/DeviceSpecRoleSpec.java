package com.bt.ngp.datasource.spec;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.*;


/**
 * The persistent class for the DEVICE_SPEC_ROLE_SPEC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="DEVICE_SPEC_ROLE_SPEC")
@NamedQuery(name="DeviceSpecRoleSpec.findAll", query="SELECT d FROM DeviceSpecRoleSpec d")
public class DeviceSpecRoleSpec implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	//bi-directional many-to-one association to DeviceRoleSpec
	@ManyToOne
	@JoinColumn(name="ROLE_SPEC_NAME", nullable=false)
	private DeviceRoleSpec deviceRoleSpec;

	//bi-directional many-to-one association to DeviceSpec
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name="DEVICE_SPEC_NAME", referencedColumnName="NAME", nullable=false),
		@JoinColumn(name="DEVICE_SPEC_VERSION", referencedColumnName="SPEC_VERSION", nullable=false)
		})
	private DeviceSpec deviceSpec;

	public DeviceSpecRoleSpec() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public DeviceRoleSpec getDeviceRoleSpec() {
		return this.deviceRoleSpec;
	}

	public void setDeviceRoleSpec(DeviceRoleSpec deviceRoleSpec) {
		this.deviceRoleSpec = deviceRoleSpec;
	}

	public DeviceSpec getDeviceSpec() {
		return this.deviceSpec;
	}

	public void setDeviceSpec(DeviceSpec deviceSpec) {
		this.deviceSpec = deviceSpec;
	}

}