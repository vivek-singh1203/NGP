package com.bt.ngp.common.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bt.ngp.datasource.entities.Exchange;
import com.bt.ngp.datasource.entities.JointClosure;

@Repository
public interface JointClosureRepository extends CommonOperation<JointClosure> {

	@Query(name="JointClosureRepository.findEquipmentWithoutCableSectionAssoc", nativeQuery=true)
	List<JointClosure> findEquipmentWithoutCableSectionAssoc(@Param("exchangeCode") String exchange1141Code);
	
	List<JointClosure> findByExchangeAndJcStructureAssocsIsNull(@Param("exchange") Exchange exchange);
}