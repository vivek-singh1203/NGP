package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the WE_PLUGIN_PORT_ASSOC database table.
 * 
 */
@javax.persistence.Entity
@Table(name="WE_PLUGIN_PORT_ASSOC")
@NamedQuery(name="WePluginPortAssoc.findAll", query="SELECT w FROM WePluginPortAssoc w")
public class WePluginPortAssoc implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=50)
	private String id;

	@Column(name="COMP_PORT_ASSOC_SPEC_ID", length=50)
	private String compPortAssocSpecId;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="PORT_SEQ_NUM", nullable=false, precision=38)
	private BigDecimal portSeqNum;

	//bi-directional many-to-one association to WeHierarchy
	@OneToMany(mappedBy="wePluginPortAssoc")
	private List<WeHierarchy> weHierarchies;

	//bi-directional many-to-one association to Plugin
	@ManyToOne
	@JoinColumn(name="PLUGIN_NAME")
	private Plugin plugin;

	//bi-directional many-to-one association to WirelessEquipment
	@ManyToOne
	@JoinColumn(name="WEQ_NAME")
	private WirelessEquipment wirelessEquipment;

	//bi-directional many-to-one association to WePort
	@ManyToOne
	@JoinColumn(name="PORT_NAME")
	private WePort wePort;

	public WePluginPortAssoc() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCompPortAssocSpecId() {
		return this.compPortAssocSpecId;
	}

	public void setCompPortAssocSpecId(String compPortAssocSpecId) {
		this.compPortAssocSpecId = compPortAssocSpecId;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public BigDecimal getPortSeqNum() {
		return this.portSeqNum;
	}

	public void setPortSeqNum(BigDecimal portSeqNum) {
		this.portSeqNum = portSeqNum;
	}

	public List<WeHierarchy> getWeHierarchies() {
		return this.weHierarchies;
	}

	public void setWeHierarchies(List<WeHierarchy> weHierarchies) {
		this.weHierarchies = weHierarchies;
	}

	public WeHierarchy addWeHierarchy(WeHierarchy weHierarchy) {
		getWeHierarchies().add(weHierarchy);
		weHierarchy.setWePluginPortAssoc(this);

		return weHierarchy;
	}

	public WeHierarchy removeWeHierarchy(WeHierarchy weHierarchy) {
		getWeHierarchies().remove(weHierarchy);
		weHierarchy.setWePluginPortAssoc(null);

		return weHierarchy;
	}

	public Plugin getPlugin() {
		return this.plugin;
	}

	public void setPlugin(Plugin plugin) {
		this.plugin = plugin;
	}

	public WirelessEquipment getWirelessEquipment() {
		return this.wirelessEquipment;
	}

	public void setWirelessEquipment(WirelessEquipment wirelessEquipment) {
		this.wirelessEquipment = wirelessEquipment;
	}

	public WePort getWePort() {
		return this.wePort;
	}

	public void setWePort(WePort wePort) {
		this.wePort = wePort;
	}

}