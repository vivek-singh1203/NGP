package com.bt.ngp.common.data.jpa.spec.repository;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.bt.ngp.common.data.jpa.repository.SqlRepository;
import com.bt.ngp.datasource.spec.EqCableCompatSpec;

@Repository
public interface EqCableCompatSpecRepository extends SqlRepository<EqCableCompatSpec> {
	@Query(name="EqCableCompatSpecRepository.findEqCableCompatSpec",nativeQuery=true)
	EqCableCompatSpec findEqCableCompatSpec(@Param("compatibilityObj") EqCableCompatSpec compatibilityObj);
}