package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.vividsolutions.jts.geom.Point;


/**
 * The persistent class for the CROSS_CONNECT_POINTS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="CROSS_CONNECT_POINTS")
@NamedQuery(name="CrossConnectPoint.findAll", query="SELECT c FROM CrossConnectPoint c")
public class CrossConnectPoint implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=25)
	private String name;

	@Column(name="ALTERNATE_NAME", length=25)
	private String alternateName;

	@Column(name="ASSET_IDENTIFIER", length=30)
	private String assetIdentifier;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	@Column(name="DATA_QUALITY_INDICATOR", length=20)
	private String dataQualityIndicator;

	@Column(name="DESG_NAME", length=30)
	private String desgName;

	@Column(name="DESG_NUM", precision=38)
	private BigDecimal desgNum;

	@Column(name="FAULT_STATE", length=25)
	private String faultState;

	@Column(name="FIELD_LABEL", length=30)
	private String fieldLabel;

	@Column(name = "GEO_POSITION", columnDefinition = "geometry(Point,4326)")
	private Point geoPosition;

	public Point getGeoPosition() {
		return geoPosition;
	}

	public void setGeoPosition(Point geoPosition) {
		this.geoPosition = geoPosition;
	}

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="RESOURCE_1141_CODE", nullable=false, length=30)
	private String resource1141Code;

	@Column(name="RESOURCE_STATE", nullable=false, length=25)
	private String resourceState;

	@Column(name="SERIAL_NUMBER", length=30)
	private String serialNumber;

	@Column(name="SERVICE_STATE", length=25)
	private String serviceState;

	@Column(name="SPEC_CATEGORY_NAME", length=30)
	private String specCategoryName;

	@Column(name="SPEC_NAME", length=30)
	private String specName;

	@Column(name="SPEC_TYPE_NAME", length=30)
	private String specTypeName;

	@Column(name="SPEC_VERSION", length=5)
	private String specVersion;

	@Column(name="USER_LABEL", length=30)
	private String userLabel;

	//bi-directional many-to-one association to AuxComponent
	@OneToMany(mappedBy="crossConnectPoint")
	private List<AuxComponent> auxComponents;

	//bi-directional many-to-one association to CcpCableConductorSplicing
	@OneToMany(mappedBy="crossConnectPoint")
	private List<CcpCsCondSplicing> ccpCableConductorSplicings;

	//bi-directional many-to-one association to CcpChar
	@OneToMany(mappedBy="crossConnectPoint")
	private List<CcpChar> ccpChars;

	//bi-directional many-to-one association to CcpChassisPhAssoc
	@OneToMany(mappedBy="crossConnectPoint")
	private List<CcpChassisPhAssoc> ccpChassisPhAssocs;

	//bi-directional many-to-one association to CcpCsPortTerm
	@OneToMany(mappedBy="crossConnectPoint")
	private List<CcpCsPortTerm> ccpCsPortTerms;

	//bi-directional many-to-one association to CcpHierarchy
	@OneToMany(mappedBy="crossConnectPoint")
	private List<CcpHierarchy> ccpHierarchies;

	//bi-directional many-to-one association to CcpPhPluginAssoc
	@OneToMany(mappedBy="crossConnectPoint")
	private List<CcpPhPluginAssoc> ccpPhPluginAssocs;

	//bi-directional many-to-one association to CcpPluginPortAssoc
	@OneToMany(mappedBy="crossConnectPoint")
	private List<CcpPluginPortAssoc> ccpPluginPortAssocs;

	//bi-directional many-to-one association to CcpPort
	@OneToMany(mappedBy="crossConnectPoint")
	private List<CcpPort> ccpPorts;

	//bi-directional many-to-one association to CcpPortChar
	@OneToMany(mappedBy="crossConnectPoint")
	private List<CcpPortChar> ccpPortChars;

	//bi-directional many-to-one association to CcpPortPortAssoc
	@OneToMany(mappedBy="crossConnectPoint")
	private List<CcpPortPortAssoc> ccpPortPortAssocs;

	//bi-directional many-to-one association to CcpStructureAssoc
	@OneToMany(mappedBy="crossConnectPoint")
	private List<CcpStructureAssoc> ccpStructureAssocs;

	//bi-directional many-to-one association to Chassi
	@OneToMany(mappedBy="crossConnectPoint")
	private List<Chassi> chassis;

	//bi-directional many-to-one association to Connector
	@OneToMany(mappedBy="crossConnectPoint")
	private List<Connector> connectors;

	//bi-directional many-to-one association to Store
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="STORE_NAME")
	private Store store;

	//bi-directional many-to-one association to Supplier
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="SUPPLIER_NAME")
	private Supplier supplier;

	//bi-directional many-to-one association to Exchange
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="EXCHANGE_1141_CODE")
	private Exchange exchange;

	//bi-directional many-to-one association to Plugin
	@OneToMany(mappedBy="crossConnectPoint")
	private List<Plugin> plugins;

	//bi-directional many-to-one association to PluginHolder
	@OneToMany(mappedBy="crossConnectPoint")
	private List<PluginHolder> pluginHolders;

	public CrossConnectPoint() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAlternateName() {
		return this.alternateName;
	}

	public void setAlternateName(String alternateName) {
		this.alternateName = alternateName;
	}

	public String getAssetIdentifier() {
		return this.assetIdentifier;
	}

	public void setAssetIdentifier(String assetIdentifier) {
		this.assetIdentifier = assetIdentifier;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public String getDataQualityIndicator() {
		return this.dataQualityIndicator;
	}

	public void setDataQualityIndicator(String dataQualityIndicator) {
		this.dataQualityIndicator = dataQualityIndicator;
	}

	public String getDesgName() {
		return this.desgName;
	}

	public void setDesgName(String desgName) {
		this.desgName = desgName;
	}

	public BigDecimal getDesgNum() {
		return this.desgNum;
	}

	public void setDesgNum(BigDecimal desgNum) {
		this.desgNum = desgNum;
	}

	public String getFaultState() {
		return this.faultState;
	}

	public void setFaultState(String faultState) {
		this.faultState = faultState;
	}

	public String getFieldLabel() {
		return this.fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getResource1141Code() {
		return this.resource1141Code;
	}

	public void setResource1141Code(String resource1141Code) {
		this.resource1141Code = resource1141Code;
	}

	public String getResourceState() {
		return this.resourceState;
	}

	public void setResourceState(String resourceState) {
		this.resourceState = resourceState;
	}

	public String getSerialNumber() {
		return this.serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getServiceState() {
		return this.serviceState;
	}

	public void setServiceState(String serviceState) {
		this.serviceState = serviceState;
	}

	public String getSpecCategoryName() {
		return this.specCategoryName;
	}

	public void setSpecCategoryName(String specCategoryName) {
		this.specCategoryName = specCategoryName;
	}

	public String getSpecName() {
		return this.specName;
	}

	public void setSpecName(String specName) {
		this.specName = specName;
	}

	public String getSpecTypeName() {
		return this.specTypeName;
	}

	public void setSpecTypeName(String specTypeName) {
		this.specTypeName = specTypeName;
	}

	public String getSpecVersion() {
		return this.specVersion;
	}

	public void setSpecVersion(String specVersion) {
		this.specVersion = specVersion;
	}

	public String getUserLabel() {
		return this.userLabel;
	}

	public void setUserLabel(String userLabel) {
		this.userLabel = userLabel;
	}

	public List<AuxComponent> getAuxComponents() {
		return this.auxComponents;
	}

	public void setAuxComponents(List<AuxComponent> auxComponents) {
		this.auxComponents = auxComponents;
	}

	public AuxComponent addAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().add(auxComponent);
		auxComponent.setCrossConnectPoint(this);

		return auxComponent;
	}

	public AuxComponent removeAuxComponent(AuxComponent auxComponent) {
		getAuxComponents().remove(auxComponent);
		auxComponent.setCrossConnectPoint(null);

		return auxComponent;
	}

	public List<CcpCsCondSplicing> getCcpCableConductorSplicings() {
		return this.ccpCableConductorSplicings;
	}

	public void setCcpCableConductorSplicings(List<CcpCsCondSplicing> ccpCableConductorSplicings) {
		this.ccpCableConductorSplicings = ccpCableConductorSplicings;
	}

	public CcpCsCondSplicing addCcpCableConductorSplicing(CcpCsCondSplicing ccpCableConductorSplicing) {
		getCcpCableConductorSplicings().add(ccpCableConductorSplicing);
		ccpCableConductorSplicing.setCrossConnectPoint(this);

		return ccpCableConductorSplicing;
	}

	public CcpCsCondSplicing removeCcpCableConductorSplicing(CcpCsCondSplicing ccpCableConductorSplicing) {
		getCcpCableConductorSplicings().remove(ccpCableConductorSplicing);
		ccpCableConductorSplicing.setCrossConnectPoint(null);

		return ccpCableConductorSplicing;
	}

	public List<CcpChar> getCcpChars() {
		return this.ccpChars;
	}

	public void setCcpChars(List<CcpChar> ccpChars) {
		this.ccpChars = ccpChars;
	}

	public CcpChar addCcpChar(CcpChar ccpChar) {
		getCcpChars().add(ccpChar);
		ccpChar.setCrossConnectPoint(this);

		return ccpChar;
	}

	public CcpChar removeCcpChar(CcpChar ccpChar) {
		getCcpChars().remove(ccpChar);
		ccpChar.setCrossConnectPoint(null);

		return ccpChar;
	}

	public List<CcpChassisPhAssoc> getCcpChassisPhAssocs() {
		return this.ccpChassisPhAssocs;
	}

	public void setCcpChassisPhAssocs(List<CcpChassisPhAssoc> ccpChassisPhAssocs) {
		this.ccpChassisPhAssocs = ccpChassisPhAssocs;
	}

	public CcpChassisPhAssoc addCcpChassisPhAssoc(CcpChassisPhAssoc ccpChassisPhAssoc) {
		getCcpChassisPhAssocs().add(ccpChassisPhAssoc);
		ccpChassisPhAssoc.setCrossConnectPoint(this);

		return ccpChassisPhAssoc;
	}

	public CcpChassisPhAssoc removeCcpChassisPhAssoc(CcpChassisPhAssoc ccpChassisPhAssoc) {
		getCcpChassisPhAssocs().remove(ccpChassisPhAssoc);
		ccpChassisPhAssoc.setCrossConnectPoint(null);

		return ccpChassisPhAssoc;
	}

	public List<CcpCsPortTerm> getCcpCsPortTerms() {
		return this.ccpCsPortTerms;
	}

	public void setCcpCsPortTerms(List<CcpCsPortTerm> ccpCsPortTerms) {
		this.ccpCsPortTerms = ccpCsPortTerms;
	}

	public CcpCsPortTerm addCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		getCcpCsPortTerms().add(ccpCsPortTerm);
		ccpCsPortTerm.setCrossConnectPoint(this);

		return ccpCsPortTerm;
	}

	public CcpCsPortTerm removeCcpCsPortTerm(CcpCsPortTerm ccpCsPortTerm) {
		getCcpCsPortTerms().remove(ccpCsPortTerm);
		ccpCsPortTerm.setCrossConnectPoint(null);

		return ccpCsPortTerm;
	}

	public List<CcpHierarchy> getCcpHierarchies() {
		return this.ccpHierarchies;
	}

	public void setCcpHierarchies(List<CcpHierarchy> ccpHierarchies) {
		this.ccpHierarchies = ccpHierarchies;
	}

	public CcpHierarchy addCcpHierarchy(CcpHierarchy ccpHierarchy) {
		getCcpHierarchies().add(ccpHierarchy);
		ccpHierarchy.setCrossConnectPoint(this);

		return ccpHierarchy;
	}

	public CcpHierarchy removeCcpHierarchy(CcpHierarchy ccpHierarchy) {
		getCcpHierarchies().remove(ccpHierarchy);
		ccpHierarchy.setCrossConnectPoint(null);

		return ccpHierarchy;
	}

	public List<CcpPhPluginAssoc> getCcpPhPluginAssocs() {
		return this.ccpPhPluginAssocs;
	}

	public void setCcpPhPluginAssocs(List<CcpPhPluginAssoc> ccpPhPluginAssocs) {
		this.ccpPhPluginAssocs = ccpPhPluginAssocs;
	}

	public CcpPhPluginAssoc addCcpPhPluginAssoc(CcpPhPluginAssoc ccpPhPluginAssoc) {
		getCcpPhPluginAssocs().add(ccpPhPluginAssoc);
		ccpPhPluginAssoc.setCrossConnectPoint(this);

		return ccpPhPluginAssoc;
	}

	public CcpPhPluginAssoc removeCcpPhPluginAssoc(CcpPhPluginAssoc ccpPhPluginAssoc) {
		getCcpPhPluginAssocs().remove(ccpPhPluginAssoc);
		ccpPhPluginAssoc.setCrossConnectPoint(null);

		return ccpPhPluginAssoc;
	}

	public List<CcpPluginPortAssoc> getCcpPluginPortAssocs() {
		return this.ccpPluginPortAssocs;
	}

	public void setCcpPluginPortAssocs(List<CcpPluginPortAssoc> ccpPluginPortAssocs) {
		this.ccpPluginPortAssocs = ccpPluginPortAssocs;
	}

	public CcpPluginPortAssoc addCcpPluginPortAssoc(CcpPluginPortAssoc ccpPluginPortAssoc) {
		getCcpPluginPortAssocs().add(ccpPluginPortAssoc);
		ccpPluginPortAssoc.setCrossConnectPoint(this);

		return ccpPluginPortAssoc;
	}

	public CcpPluginPortAssoc removeCcpPluginPortAssoc(CcpPluginPortAssoc ccpPluginPortAssoc) {
		getCcpPluginPortAssocs().remove(ccpPluginPortAssoc);
		ccpPluginPortAssoc.setCrossConnectPoint(null);

		return ccpPluginPortAssoc;
	}

	public List<CcpPort> getCcpPorts() {
		return this.ccpPorts;
	}

	public void setCcpPorts(List<CcpPort> ccpPorts) {
		this.ccpPorts = ccpPorts;
	}

	public CcpPort addCcpPort(CcpPort ccpPort) {
		getCcpPorts().add(ccpPort);
		ccpPort.setCrossConnectPoint(this);

		return ccpPort;
	}

	public CcpPort removeCcpPort(CcpPort ccpPort) {
		getCcpPorts().remove(ccpPort);
		ccpPort.setCrossConnectPoint(null);

		return ccpPort;
	}

	public List<CcpPortChar> getCcpPortChars() {
		return this.ccpPortChars;
	}

	public void setCcpPortChars(List<CcpPortChar> ccpPortChars) {
		this.ccpPortChars = ccpPortChars;
	}

	public CcpPortChar addCcpPortChar(CcpPortChar ccpPortChar) {
		getCcpPortChars().add(ccpPortChar);
		ccpPortChar.setCrossConnectPoint(this);

		return ccpPortChar;
	}

	public CcpPortChar removeCcpPortChar(CcpPortChar ccpPortChar) {
		getCcpPortChars().remove(ccpPortChar);
		ccpPortChar.setCrossConnectPoint(null);

		return ccpPortChar;
	}

	public List<CcpPortPortAssoc> getCcpPortPortAssocs() {
		return this.ccpPortPortAssocs;
	}

	public void setCcpPortPortAssocs(List<CcpPortPortAssoc> ccpPortPortAssocs) {
		this.ccpPortPortAssocs = ccpPortPortAssocs;
	}

	public CcpPortPortAssoc addCcpPortPortAssoc(CcpPortPortAssoc ccpPortPortAssoc) {
		getCcpPortPortAssocs().add(ccpPortPortAssoc);
		ccpPortPortAssoc.setCrossConnectPoint(this);

		return ccpPortPortAssoc;
	}

	public CcpPortPortAssoc removeCcpPortPortAssoc(CcpPortPortAssoc ccpPortPortAssoc) {
		getCcpPortPortAssocs().remove(ccpPortPortAssoc);
		ccpPortPortAssoc.setCrossConnectPoint(null);

		return ccpPortPortAssoc;
	}

	public List<CcpStructureAssoc> getCcpStructureAssocs() {
		return this.ccpStructureAssocs;
	}

	public void setCcpStructureAssocs(List<CcpStructureAssoc> ccpStructureAssocs) {
		this.ccpStructureAssocs = ccpStructureAssocs;
	}

	public CcpStructureAssoc addCcpStructureAssoc(CcpStructureAssoc ccpStructureAssoc) {
		getCcpStructureAssocs().add(ccpStructureAssoc);
		ccpStructureAssoc.setCrossConnectPoint(this);

		return ccpStructureAssoc;
	}

	public CcpStructureAssoc removeCcpStructureAssoc(CcpStructureAssoc ccpStructureAssoc) {
		getCcpStructureAssocs().remove(ccpStructureAssoc);
		ccpStructureAssoc.setCrossConnectPoint(null);

		return ccpStructureAssoc;
	}

	public List<Chassi> getChassis() {
		return this.chassis;
	}

	public void setChassis(List<Chassi> chassis) {
		this.chassis = chassis;
	}

	public Chassi addChassi(Chassi chassi) {
		getChassis().add(chassi);
		chassi.setCrossConnectPoint(this);

		return chassi;
	}

	public Chassi removeChassi(Chassi chassi) {
		getChassis().remove(chassi);
		chassi.setCrossConnectPoint(null);

		return chassi;
	}

	public List<Connector> getConnectors() {
		return this.connectors;
	}

	public void setConnectors(List<Connector> connectors) {
		this.connectors = connectors;
	}

	public Connector addConnector(Connector connector) {
		getConnectors().add(connector);
		connector.setCrossConnectPoint(this);

		return connector;
	}

	public Connector removeConnector(Connector connector) {
		getConnectors().remove(connector);
		connector.setCrossConnectPoint(null);

		return connector;
	}

	public Store getStore() {
		return this.store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public Supplier getSupplier() {
		return this.supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public Exchange getExchange() {
		return this.exchange;
	}

	public void setExchange(Exchange exchange) {
		this.exchange = exchange;
	}

	public List<Plugin> getPlugins() {
		return this.plugins;
	}

	public void setPlugins(List<Plugin> plugins) {
		this.plugins = plugins;
	}

	public Plugin addPlugin(Plugin plugin) {
		getPlugins().add(plugin);
		plugin.setCrossConnectPoint(this);

		return plugin;
	}

	public Plugin removePlugin(Plugin plugin) {
		getPlugins().remove(plugin);
		plugin.setCrossConnectPoint(null);

		return plugin;
	}

	public List<PluginHolder> getPluginHolders() {
		return this.pluginHolders;
	}

	public void setPluginHolders(List<PluginHolder> pluginHolders) {
		this.pluginHolders = pluginHolders;
	}

	public PluginHolder addPluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().add(pluginHolder);
		pluginHolder.setCrossConnectPoint(this);

		return pluginHolder;
	}

	public PluginHolder removePluginHolder(PluginHolder pluginHolder) {
		getPluginHolders().remove(pluginHolder);
		pluginHolder.setCrossConnectPoint(null);

		return pluginHolder;
	}

}