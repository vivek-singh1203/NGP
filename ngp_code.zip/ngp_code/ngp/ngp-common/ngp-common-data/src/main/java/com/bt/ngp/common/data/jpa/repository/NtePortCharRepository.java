package com.bt.ngp.common.data.jpa.repository;

import org.springframework.stereotype.Repository;
import com.bt.ngp.datasource.entities.NtePortChar;

@Repository
public interface NtePortCharRepository extends SqlRepository<NtePortChar> {
	
}