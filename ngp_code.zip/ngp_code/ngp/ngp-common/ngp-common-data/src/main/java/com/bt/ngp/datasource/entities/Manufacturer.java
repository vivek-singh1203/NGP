package com.bt.ngp.datasource.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;


/**
 * The persistent class for the MANUFACTURERS database table.
 * 
 */
@javax.persistence.Entity
@Table(name="MANUFACTURERS")
@NamedQuery(name="Manufacturer.findAll", query="SELECT m FROM Manufacturer m")
public class Manufacturer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(unique=true, nullable=false, length=30)
	private String name;

	@Column(name="CREATED_BY", nullable=false, length=40)
	private String createdBy;

	@Column(name="CREATED_DATE", nullable=false)
	private Timestamp createdDate;

	/*@Column(name="GEO_POSITION")
	 private Object geoPosition; */

	@Column(nullable=false, length=50)
	private String id;

	@Column(name="LAST_MODIFIED_BY", length=40)
	private String lastModifiedBy;

	@Column(name="LAST_MODIFIED_DATE")
	private Timestamp lastModifiedDate;

	@Column(name="POST_CODE", length=10)
	private String postCode;

	@Column(name="POST_TOWN", length=30)
	private String postTown;

	@Column(name="STREET_NAME", length=50)
	private String streetName;

	@Column(length=50)
	private String url;

	//bi-directional many-to-one association to CbSpec
/*	@OneToMany(mappedBy="manufacturer")
	private List<CbSpec> cbSpecs;*/

	public Manufacturer() {
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDate() {
		return this.createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

/* public Object getGeoPosition() {  return this.geoPosition;}  */

	/* public void setGeoPosition(Object geoPosition) { this.geoPosition = geoPosition;} */

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLastModifiedBy() {
		return this.lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Timestamp getLastModifiedDate() {
		return this.lastModifiedDate;
	}

	public void setLastModifiedDate(Timestamp lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getPostCode() {
		return this.postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getPostTown() {
		return this.postTown;
	}

	public void setPostTown(String postTown) {
		this.postTown = postTown;
	}

	public String getStreetName() {
		return this.streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

/*	public List<CbSpec> getCbSpecs() {
		return this.cbSpecs;
	}

	public void setCbSpecs(List<CbSpec> cbSpecs) {
		this.cbSpecs = cbSpecs;
	}

	public CbSpec addCbSpec(CbSpec cbSpec) {
		getCbSpecs().add(cbSpec);
		cbSpec.setManufacturer(this);

		return cbSpec;
	}

	public CbSpec removeCbSpec(CbSpec cbSpec) {
		getCbSpecs().remove(cbSpec);
		cbSpec.setManufacturer(null);

		return cbSpec;
	}*/

}